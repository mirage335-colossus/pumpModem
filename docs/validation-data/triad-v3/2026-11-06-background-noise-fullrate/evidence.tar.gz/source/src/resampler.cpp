#include "datapump/resampler.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <numbers>

namespace datapump::audio {
Resampler::Resampler(std::uint32_t input_rate,std::uint32_t output_rate,bool adjustable)
    :input_rate_(input_rate),output_rate_(output_rate),adjustable_(adjustable),capture_nominal_unshifted_(!adjustable) {
    if(input_rate<64 || input_rate>120000000 || output_rate<64 || output_rate>120000000)
        throw Error("resampler rate must be 64..120000000 Hz");
    if(input_rate==output_rate && !adjustable_)return;
    if(static_cast<std::uint64_t>(input_rate)>static_cast<std::uint64_t>(output_rate)*4) {
        auto intermediate_rate=output_rate;
        while(static_cast<std::uint64_t>(intermediate_rate)*4<input_rate)intermediate_rate*=4;
        first_stage_=std::make_unique<Resampler>(input_rate,intermediate_rate);
        last_stage_=std::make_unique<Resampler>(intermediate_rate,output_rate,adjustable_);
        intermediate_.resize(256);
        return;
    }
    const double ratio=std::min(1.,static_cast<double>(output_rate)/input_rate);
    radius_=static_cast<std::size_t>(std::ceil(48/ratio));
    taps_=radius_*2+1;
    ring_.resize(taps_+2);
    coefficients_.resize((phases+1)*taps_);
    constexpr double pi=std::numbers::pi;
    const double cutoff=.46*ratio;
    for(unsigned phase=0;phase<=phases;++phase) {
        const double fraction=static_cast<double>(phase)/phases;
        double sum=0;
        for(std::size_t tap=0;tap<taps_;++tap) {
            const double distance=static_cast<double>(tap)-static_cast<double>(radius_)-fraction;
            const double window_position=distance/static_cast<double>(radius_);
            const double window=std::abs(window_position)>=1?0:.42+.5*std::cos(pi*window_position)+.08*std::cos(2*pi*window_position);
            const double value=std::abs(distance)<1e-12?2*cutoff:std::sin(2*pi*cutoff*distance)/(pi*distance);
            coefficients_[phase*taps_+tap]=static_cast<float>(value*window);
            sum+=value*window;
        }
        for(std::size_t tap=0;tap<taps_;++tap)
            coefficients_[phase*taps_+tap]=static_cast<float>(coefficients_[phase*taps_+tap]/sum);
    }
}
void Resampler::set_rate_correction(double correction,double slew) {
    if(!adjustable_ || !std::isfinite(correction) || std::abs(correction)>.001 ||
       !std::isfinite(slew) || slew<=0 || slew>.001)
        throw Error("invalid continuous resampler rate correction");
    if(last_stage_) {last_stage_->set_rate_correction(correction,slew);return;}
    target_correction_=correction;correction_step_=slew/output_rate_;
}
void Resampler::initialize_timing(double fraction,double correction) {
    if(!adjustable_ || started_ || !std::isfinite(fraction) || fraction<0 || fraction>=1 ||
       !std::isfinite(correction) || std::abs(correction)>.001)
        throw Error("invalid initial resampler timing");
    if(last_stage_) {
        // Both stages preserve time zero. Express the original fractional
        // sample in the final stage's input clock without moving either history.
        last_stage_->initialize_timing(fraction*last_stage_->input_rate_/input_rate_,correction);
        return;
    }
    fraction_=fraction;correction_=target_correction_=correction;correction_roundoff_=0;
}
long double Resampler::source_seconds() const noexcept {
    if(last_stage_)return last_stage_->source_seconds();
    return (static_cast<long double>(source_)+(adjustable_?fraction_:
        static_cast<long double>(remainder_)/output_rate_))/input_rate_;
}
double Resampler::rate_correction() const noexcept {
    return last_stage_?last_stage_->rate_correction():correction_;
}
void Resampler::observe_affine_timing(long double origin,double initial_rate) {
    if(last_stage_){last_stage_->observe_affine_timing(origin,initial_rate);return;}
    if(started_ || observe_timing_ || !std::isfinite(origin) || !std::isfinite(initial_rate))
        throw Error("cannot replace the original resampler timing reference");
    observe_timing_=true;timing_origin_=origin;timing_rate_=initial_rate;begin_timing_block();
}
void Resampler::begin_timing_block() {
    if(last_stage_){last_stage_->begin_timing_block();return;}
    timing_min_=timing_max_=std::fma(-(1.L+timing_rate_),static_cast<long double>(produced_)/output_rate_,source_seconds()-timing_origin_);
}
Resampler::TimingBlock Resampler::timing_block() const noexcept {
    return last_stage_?last_stage_->timing_block():TimingBlock{produced_,timing_min_,timing_max_};
}
double Resampler::source_lookahead_seconds() const noexcept {
    return first_stage_?first_stage_->source_lookahead_seconds()+last_stage_->source_lookahead_seconds()+
        static_cast<double>(intermediate_.size())/last_stage_->input_rate_:static_cast<double>(radius_+2)/input_rate_;
}
std::uint64_t Resampler::final_count() const {
    // Quotient/remainder avoids multiplying a long-running input counter.
    const auto whole=received_/input_rate_;
    if(whole>std::numeric_limits<std::uint64_t>::max()/output_rate_)
        throw Error("resampler duration exceeds counter range");
    const auto tail=((received_%input_rate_)*output_rate_+input_rate_-1)/input_rate_;
    if(whole*output_rate_>std::numeric_limits<std::uint64_t>::max()-tail)
        throw Error("resampler duration exceeds counter range");
    return whole*output_rate_+tail;
}
bool Resampler::finished() const noexcept {
    if(last_stage_)return last_stage_->finished();
    if(!ending_)return false;
    // source_ is the timestamp of the next output in input sample units.
    return source_>=received_;
}
std::size_t Resampler::workspace_bytes() const noexcept {
    return sizeof(*this)+(ring_.capacity()+coefficients_.capacity()+intermediate_.capacity())*sizeof(float)+
        (first_stage_?first_stage_->workspace_bytes()+last_stage_->workspace_bytes():0);
}
Resampler::Progress Resampler::process_stages(std::span<const float> input,std::span<float> output,bool end) {
    Progress progress;
    while(progress.produced<output.size() && !last_stage_->finished()) {
        const auto converted=last_stage_->process(
            std::span<const float>(intermediate_.data()+intermediate_position_,intermediate_count_-intermediate_position_),
            output.subspan(progress.produced),first_stage_->finished());
        intermediate_position_+=converted.consumed;
        progress.produced+=converted.produced;
        if(converted.consumed || converted.produced)continue;
        if(intermediate_position_!=intermediate_count_)
            throw Error("resampler stage buffer invariant failed");
        const auto filled=first_stage_->process(input.subspan(progress.consumed),intermediate_,end);
        progress.consumed+=filled.consumed;
        intermediate_position_=0;intermediate_count_=filled.produced;
        if(!filled.consumed && !filled.produced && !first_stage_->finished())break;
    }
    if(end && progress.consumed==input.size())ending_=true;
    return progress;
}
double Resampler::passband_hz() const noexcept {
    return (input_rate_==output_rate_ && !adjustable_?.5:.42)*std::min(input_rate_,output_rate_);
}
float Resampler::interpolate() const {
    const double phase_position=(adjustable_?fraction_:static_cast<double>(remainder_)/output_rate_)*phases;
    const auto phase=static_cast<unsigned>(phase_position);
    const double blend=phase_position-phase;
    double value=0;
    for(std::size_t tap=0;tap<taps_;++tap) {
        // Negative input times and the final FIR tail are zero extended.
        if(tap<radius_ && source_<radius_-tap)continue;
        if(tap>=radius_ && source_>std::numeric_limits<std::uint64_t>::max()-(tap-radius_))continue;
        const auto index=tap>=radius_?source_+(tap-radius_):source_-(radius_-tap);
        if(index<first_ || index>=received_)continue;
        const auto offset=static_cast<std::size_t>(index-first_);
        if(offset>=size_)throw Error("resampler history invariant failed");
        const auto a=coefficients_[phase*taps_+tap];
        const auto b=coefficients_[(phase+1)*taps_+tap];
        value+=ring_[(head_+offset)%ring_.size()]*(a+(b-a)*blend);
    }
    return static_cast<float>(value);
}
void Resampler::discard_history() {
    const auto keep=source_>radius_?source_-radius_:0;
    const auto count=static_cast<std::size_t>(std::min<std::uint64_t>(size_,keep>first_?keep-first_:0));
    head_=(head_+count)%ring_.size();size_-=count;first_+=count;
}
void Resampler::set_output_gain(std::function<double(long double)> gain) {
    if(started_)throw Error("resampler output envelope must be set before processing");
    if(gain)capture_nominal_unshifted_=false;
    if(last_stage_)last_stage_->set_output_gain(std::move(gain));
    else output_gain_=std::move(gain);
}
void Resampler::set_output_transform(std::function<float(float,long double,std::uint32_t)> transform) {
    if(started_)throw Error("resampler output transform must be set before processing");
    if(transform)capture_nominal_unshifted_=false;
    if(last_stage_)last_stage_->set_output_transform(std::move(transform));
    else output_transform_=std::move(transform);
}
CaptureTransportRecipe Resampler::capture_transport()const noexcept {
    if(!capture_nominal_unshifted_ || adjustable_ || output_gain_ || output_transform_ ||
       (first_stage_&&first_stage_->capture_transport().kind!=CaptureTransportKind::fixed_nominal_audio) ||
       (last_stage_&&last_stage_->capture_transport().kind!=CaptureTransportKind::fixed_nominal_audio))return {};
    return {CaptureTransportKind::fixed_nominal_audio,input_rate_,output_rate_,0,0};
}
Resampler::Progress Resampler::process(std::span<const float> input,std::span<float> output,bool end) {
    if(ending_ && !input.empty())throw Error("cannot append to a finished resampler");
    started_=true;
    if(first_stage_)return process_stages(input,output,end);
    Progress progress;
    if(input_rate_==output_rate_ && !adjustable_) {
        const auto count=std::min(input.size(),output.size());
        for(std::size_t i=0;i<count;++i) {
            if(!std::isfinite(input[i]))throw Error("nonfinite resampler input");
            const auto gain=output_gain_?output_gain_((static_cast<long double>(source_)+i)/input_rate_):1.;
            if(!std::isfinite(gain)||gain<0||gain>1)throw Error("invalid output safety gain");
            output[i]=static_cast<float>(gain*input[i]);
            if(output_transform_) {
                output[i]=output_transform_(output[i],(static_cast<long double>(source_)+i)/input_rate_,output_rate_);
                if(!std::isfinite(output[i]))throw Error("nonfinite resampler output transform");
            }
        }
        if(received_>std::numeric_limits<std::uint64_t>::max()-count)throw Error("resampler duration exceeds counter range");
        received_+=count;source_=received_;produced_=received_;
        ending_=ending_ || (end && count==input.size());
        return {count,count};
    }
    while(progress.produced<output.size()) {
        if(end && progress.consumed==input.size())ending_=true;
        if(ending_ && (adjustable_?source_>=received_:produced_>=final_count()))break;
        if((source_<=std::numeric_limits<std::uint64_t>::max()-radius_ && received_>source_+radius_) || ending_) {
            const auto sample=interpolate();
            if(!std::isfinite(sample))throw Error("resampler output overflow");
            const auto gain=output_gain_?output_gain_(source_seconds()):1.;
            if(!std::isfinite(gain)||gain<0||gain>1)throw Error("invalid output safety gain");
            auto value=static_cast<float>(gain*sample);
            if(output_transform_) {
                value=output_transform_(value,source_seconds(),output_rate_);
                if(!std::isfinite(value))throw Error("nonfinite resampler output transform");
            }
            output[progress.produced++]=value;
            const auto before=observe_timing_?std::fma(-(1.L+timing_rate_),static_cast<long double>(produced_)/output_rate_,source_seconds()-timing_origin_):0;
            const auto previous_rate=correction_;
            ++produced_;
            if(adjustable_) {
                // Slew the derivative only. No sample insertion/deletion, phase
                // jump, periodic reset, or dependence on callback boundaries.
                const auto delta=std::clamp(target_correction_-correction_,-correction_step_,correction_step_)-correction_roundoff_;
                const auto next=correction_+delta;
                correction_roundoff_=(next-correction_)-delta;
                const auto phase=fraction_+static_cast<double>(input_rate_)/output_rate_*(1+(correction_+next)*.5);
                const auto advance=static_cast<std::uint64_t>(phase);
                if(source_>std::numeric_limits<std::uint64_t>::max()-advance)
                    throw Error("resampler duration exceeds counter range");
                source_+=advance;fraction_=phase-static_cast<double>(advance);correction_=next;
            } else {
                const auto advance=static_cast<std::uint64_t>(remainder_)+input_rate_;
                if(source_>std::numeric_limits<std::uint64_t>::max()-advance/output_rate_)
                    throw Error("resampler duration exceeds counter range");
                source_+=advance/output_rate_;remainder_=static_cast<std::uint32_t>(advance%output_rate_);
            }
            if(observe_timing_) {
                const auto after=std::fma(-(1.L+timing_rate_),static_cast<long double>(produced_)/output_rate_,source_seconds()-timing_origin_);
                timing_min_=std::min({timing_min_,before,after});timing_max_=std::max({timing_max_,before,after});
                const auto velocity=static_cast<long double>(previous_rate)-timing_rate_;
                const auto acceleration=(static_cast<long double>(correction_)-previous_rate)*output_rate_;
                if(acceleration!=0) {
                    const auto t=-velocity/acceleration;
                    if(t>0 && t<1.L/output_rate_) {
                        const auto extremum=before+.5L*velocity*t;
                        timing_min_=std::min(timing_min_,extremum);timing_max_=std::max(timing_max_,extremum);
                    }
                }
            }
            discard_history();
        } else if(progress.consumed<input.size()) {
            if(size_==ring_.size())throw Error("resampler buffer invariant failed");
            const auto sample=input[progress.consumed++];
            if(!std::isfinite(sample))throw Error("nonfinite resampler input");
            ring_[(head_+size_)%ring_.size()]=sample;++size_;
            if(received_==std::numeric_limits<std::uint64_t>::max())throw Error("resampler duration exceeds counter range");
            ++received_;
        } else break;
    }
    if(end && progress.consumed==input.size())ending_=true;
    return progress;
}
}

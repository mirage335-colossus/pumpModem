"""CLI integration for the fixed interval format and physical end gate."""
import json
import math
import pathlib
import subprocess
import sys
import tempfile
import unittest
import wave

PUMP = str(pathlib.Path(sys.argv.pop(1)).resolve())
ALLOWED_RECEIVED = b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.@ -_/=\n'

def safe_received(source):
    return ''.join(chr(byte) if byte in ALLOWED_RECEIVED else '_' for byte in source)

AUDIO = ('--sample-rate','8000','--bw','1000','--carrier','1500','--spreading','16','--time','1800000000','--search-seconds','0')

class StreamCLI(unittest.TestCase):
    def run_pump(self,*args,data=None,ok=True,timeout=90):
        p=subprocess.run([PUMP,*map(str,args)],input=data,capture_output=True,timeout=timeout)
        self.assertEqual(p.returncode,0 if ok else 2,p.stderr.decode(errors='replace'))
        return p
    def helper_envelope(self,result):
        events=[json.loads(line) for line in result.stderr.decode().splitlines() if line.startswith('{')]
        envelopes=[event for event in events if event.get('event')=='helper_envelope']
        self.assertEqual(len(envelopes),1)
        return envelopes[0]
    def run_pump_with_exact_save(self,*args,source,data=None,receive_options=AUDIO):
        # Preserve byte-for-byte transport assertions independently of the
        # intentionally lossy received-text presentation. simulate can write
        # its sampled channel capture; only rx supports saving decoded bytes.
        with tempfile.TemporaryDirectory() as directory:
            destination=pathlib.Path(directory)/'received.bin'
            if args[0]=='simulate':
                if '--output' in args:
                    capture=args[args.index('--output')+1]
                    output=()
                else:
                    capture=pathlib.Path(directory)/'simulated.wav'
                    output=('--output',capture)
                result=self.run_pump(*args,*output,data=data)
                self.run_pump('rx','--input',capture,'--save',destination,*receive_options)
            else:
                self.assertEqual(args[0],'rx')
                result=self.run_pump(*args,'--save',destination,data=data)
            self.assertEqual(destination.read_bytes(),source)
            return result
    def test_removed_commands(self):
        helptext=self.run_pump('--help').stdout
        self.assertNotIn(b'pack/unpack',helptext)
        for command in ('pack','unpack'):
            self.run_pump(command,'--text','x',ok=False)
    def test_background_noise_output_scope(self):
        self.assertIn(b'--background-noise-bits',self.run_pump('--help').stdout)
        for args in (('simulate','--text','e'),('estimate','--text','e'),
                     ('status-tx','--bits','0','--output','unused.wav'),('listen',)):
            result=self.run_pump(*args,'--background-noise-bits','10',ok=False)
            self.assertIn(b'background noise',result.stderr)
        result=self.run_pump('tx','--text','e','--device','nonexistent',
            '--background-noise-bits','10','--background-noise-reference-rms','.1',*AUDIO,ok=False)
        self.assertIn(b'reference values require --background-noise-watts',result.stderr)
    def test_helper_options_and_disabled_preservation(self):
        helptext=self.run_pump('--help').stdout
        for flag in (b'--helper-power',b'--helper-data-power',b'--helper-ratio-limit',
                     b'--helper-frequency',b'--helper-callsign'):
            self.assertIn(flag,helptext)
        baseline=self.run_pump('estimate','--text','e',*AUDIO).stdout
        self.assertEqual(self.run_pump('estimate','--text','e','--helper-power','0',*AUDIO).stdout,baseline)
        for command in ('estimate','analyze-link','devices','qr','keygen'):
            # Reject before source/device/file operations and analysis requirements.
            error=self.run_pump(command,'--helper-power','1.5kW',ok=False)
            self.assertIn(b'helper',error.stderr)
        for flag,value in (('--helper-power','nan'),('--helper-power','-1W'),
                           ('--helper-power','1horsepower'),('--helper-data-power','0'),
                           ('--helper-ratio-limit','11'),('--helper-ratio-limit','nan'),
                           ('--helper-frequency','middle'),('--helper-callsign','A'*17),
                           ('--helper-callsign','bad\ncall')):
            self.run_pump('tx','--text','e',flag,value,*AUDIO,ok=False)
        for frequency in ('low','0'):
            error=self.run_pump('tx','--text','e','--helper-frequency',frequency,*AUDIO,ok=False)
            self.assertIn(b'only high',error.stderr)
        with tempfile.TemporaryDirectory() as directory:
            original=pathlib.Path(directory)/'original.wav'
            disabled=pathlib.Path(directory)/'disabled.wav'
            self.run_pump('tx','--text','e','--output',original,*AUDIO)
            self.run_pump('tx','--text','e','--output',disabled,'--helper-power','0',
                '--helper-data-power','2uW','--helper-ratio-limit','10dB',
                '--helper-frequency','high','--helper-callsign','W1ABC',*AUDIO)
            self.assertEqual(original.read_bytes(),disabled.read_bytes())
    def test_helper_batch_receive_declines_unqualified_acquisition(self):
        # A short capture cannot satisfy the receiver-local observation rule.
        # Batch receive has no causal narrow admission yet, so it must decline
        # instead of constructing an ordinary receiver on retrospective input.
        with tempfile.TemporaryDirectory() as directory:
            capture=pathlib.Path(directory)/'short.wav'
            with wave.open(str(capture),'wb') as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(48000)
                output.writeframes(b'\0\0'*48000)
            for command,extra in (('rx',('--json',)),('status-rx',('--bits','001'))):
                result=self.run_pump(command,'--input',capture,'--helper-power','100W',
                    *extra,*AUDIO,ok=False)
                self.assertIn(b'causal 36-second observation and measured narrowed acquisition are not implemented',
                    result.stderr)
            missing=pathlib.Path(directory)/'missing.wav'
            malformed=pathlib.Path(directory)/'malformed.wav'
            malformed.write_bytes(b'not a WAV file')
            for path in (missing,malformed):
                for command,extra in (('rx',('--json',)),('status-rx',('--bits','001')),
                                      ('simulate',())):
                    result=self.run_pump(command,'--input',path,'--helper-power','100W',
                        *extra,*AUDIO,ok=False)
                    self.assertIn(b'causal 36-second observation and measured narrowed acquisition are not implemented',
                        result.stderr)
                    self.assertNotIn(b'cannot open',result.stderr)
            result=self.run_pump('rx','--device','nonexistent-helper-test-device',
                '--helper-power','100W',*AUDIO,ok=False)
            self.assertIn(b'causal 36-second observation and measured narrowed acquisition are not implemented',
                result.stderr)
    def test_helper_wav_composition_and_separation(self):
        with tempfile.TemporaryDirectory() as directory:
            directory=pathlib.Path(directory)
            original=directory/'original.wav'
            self.run_pump('status-tx','--bits','001','--output',original,*AUDIO)
            with wave.open(str(original),'rb') as source:
                original_frames=source.getnframes()
                original_rate=source.getframerate()
            for frequency in ('high',):
                output=directory/(frequency+'.wav')
                transmitted=self.run_pump('status-tx','--bits','001','--output',output,
                    '--helper-power','1.5kW','--helper-data-power','4W',
                    '--helper-ratio-limit','90dB','--helper-frequency',frequency,
                    '--helper-callsign','W1ABC',*AUDIO)
                envelope=self.helper_envelope(transmitted)
                self.assertEqual(envelope['sample_rate'],48000)
                lead=envelope['helper_lead_frames']; robust=envelope['robust_frames']
                post=envelope['helper_post_frames']
                self.assertEqual(lead,38*48000)
                self.assertGreaterEqual(post,2*48000)
                with wave.open(str(output),'rb') as source:
                    self.assertEqual(source.getframerate(),48000)
                    # The complete original waveform/separation keeps its
                    # duration; only helper-only lead and post PCM are added.
                    self.assertEqual(source.getnframes(),original_frames*48000//original_rate+lead+post)
                    pcm=source.readframes(source.getnframes())
                    frame_width=source.getsampwidth()*source.getnchannels()
                    self.assertTrue(any(pcm[:lead*frame_width]))
                    self.assertTrue(any(pcm[(lead+robust)*frame_width:(lead+robust+post)*frame_width]))
                    # Tail silence is actual PCM, and never includes the helper.
                    self.assertEqual(pcm[-6*48000*frame_width:],b'\0'*(6*48000*frame_width))
                if frequency=='high':
                    decoded=self.run_pump('status-rx','--bits','001','--input',output,
                        '--helper-power','1.5kW','--helper-data-power','4W',*AUDIO)
                    self.assertTrue(json.loads(decoded.stdout)['known_bits_match'])
                    truncated=directory/'high-truncated.wav'
                    with wave.open(str(output),'rb') as source, wave.open(str(truncated),'wb') as target:
                        target.setparams(source.getparams())
                        # Preserve every original source frame, including its
                        # suppression drain, but omit new helper-only post and
                        # the actual quiet separation. EOF supplies no absence.
                        target.writeframes(source.readframes(lead+robust))
                    pending=json.loads(self.run_pump('status-rx','--bits','001','--input',truncated,
                        '--helper-power','1.5kW','--helper-data-power','4W',*AUDIO).stdout)
                    self.assertEqual(pending['raw_bits'],'001')
                    self.assertFalse(pending['stream_complete'],'FIR/EOF invented physical absence')
            # Helper identification copies the local callsign unless overridden.
            copied=directory/'copied.wav'; explicit=directory/'explicit.wav'
            for output,extra in ((copied,()),(explicit,('--helper-callsign','W1ABC'))):
                self.run_pump('tx','--text','e','--callsign','W1ABC','--output',output,
                    '--helper-power','100W',*extra,*AUDIO)
            self.assertEqual(copied.read_bytes(),explicit.read_bytes())
            self.run_pump('tx','--text','e','--callsign','A'*20,'--helper-power','100W',
                '--output',directory/'invalid.wav',*AUDIO,ok=False)
    def test_helper_wav_callsign_and_timecode_metadata(self):
        # Dense APSK decoding is optional on weaker/mixed captures. This fixture
        # keeps data far below the clean 16-bit helper, exercising the metadata
        # key/coordinate path independently of Robust sensitivity.
        geometry=list(AUDIO)
        geometry[geometry.index('--spreading')+1]='256'
        helper=('--helper-power','1.5kW','--helper-data-power','2uW')
        with tempfile.TemporaryDirectory() as directory:
            directory=pathlib.Path(directory)
            key=directory/'helper.key'
            self.run_pump('keygen','--output',key)
            for label,callsign,extra in (('clear_time','',()),
                                         ('callsign','N0CALL',('--helper-callsign','N0CALL'))):
                capture=directory/(label+'.wav')
                self.run_pump('status-tx','--bits','001001001001','--output',capture,
                    *helper,*extra,*geometry)
                value=json.loads(self.run_pump('status-rx','--bits','001001001001','--input',capture,
                    *helper,*extra,*geometry).stdout)
                observed=value['helper_carrier']
                self.assertTrue(observed['present'])
                metadata=observed['metadata']
                self.assertIsNotNone(metadata,label)
                self.assertEqual(metadata['kind'],'metadata')
                self.assertFalse(metadata['authenticated'])
                self.assertEqual(metadata['callsign'],callsign)
                self.assertGreaterEqual(metadata['time_phase'],0)
                self.assertLess(metadata['time_phase'],16384)
            for label,extra in (('encrypted_time',('--keyfile',key)),
                                ('encrypted_id',('--keyfile',key,'--helper-callsign','N0CALL'))):
                capture=directory/(label+'.wav')
                self.run_pump('status-tx','--bits','001001001001','--output',capture,
                    *helper,*extra,*geometry)
                # WAV has no trusted capture epoch, so keyed metadata is not decoded.
                value=json.loads(self.run_pump('status-rx','--bits','001001001001','--input',capture,
                    *helper,*extra,*geometry).stdout)
                self.assertTrue(value['helper_carrier']['present'])
                self.assertIsNone(value['helper_carrier']['metadata'])
            self.assertNotEqual((directory/'encrypted_time.wav').read_bytes(),
                (directory/'encrypted_id.wav').read_bytes(),
                'encrypted callsign did not change the transmitted waveform')
            without_key=json.loads(self.run_pump('status-rx','--bits','001001001001',
                '--input',directory/'encrypted_time.wav',*helper,*geometry,ok=False).stdout)
            self.assertTrue(without_key['helper_carrier']['present'])
            self.assertFalse(without_key['content_validated'])
            self.assertFalse(without_key['stream_complete'])
            self.assertIn('no sufficiently confident pattern',without_key['error'])
            # A keyfile flag does not enable encryption for the unencrypted
            # tone mode, so its public helper ID still requires validation.
            invalid=self.run_pump('tx','--text','e','--pattern','auto-tone','--bw','1000',
                '--keyfile',key,'--helper-power','100W','--helper-callsign','A'*20,
                '--output',directory/'invalid-tone.wav',ok=False)
            self.assertIn(b'callsign',invalid.stderr)

    def test_helper_physical_simulation(self):
        common=('--text','e','--json','--snr','30','--clock-error-ppm','0','--phase-noise','0',
                '--helper-power','1.5kW','--helper-data-power','4W','--helper-callsign','N0CALL',*AUDIO)
        with tempfile.TemporaryDirectory() as directory:
            for extra in ((),('--output',pathlib.Path(directory)/'physical.wav')):
                value=json.loads(self.run_pump('simulate',*common,*extra).stdout)
                self.assertTrue(value['stream_complete'])
                self.assertEqual(value['raw_bits'],'001')
                self.assertEqual(value['missing_symbols'],0)
                self.assertEqual(value['data_text'],'e')
                self.assertTrue(value['helper_carrier']['present'])
            with wave.open(str(pathlib.Path(directory)/'physical.wav'),'rb') as capture:
                self.assertGreater(capture.getframerate(),16000)
                self.assertEqual(capture.getframerate()%8000,0)

    def test_helper_simulation_diagnostics_survive_payload_failure(self):
        result=self.run_pump('simulate','--text','e','--json','--snr','-50',
            '--clock-error-ppm','0','--phase-noise','0','--helper-power','1.5kW',
            '--helper-data-power','2uW','--helper-callsign','N0CALL',*AUDIO,ok=False)
        value=json.loads(result.stdout)
        self.assertEqual(value['event'],'helper_carrier')
        self.assertTrue(value['helper_carrier']['present'])
        self.assertFalse(value['content_validated'])
        self.assertFalse(value['stream_complete'])
        self.assertNotIn('raw_bits',value)
        self.assertIn('no sufficiently confident pattern',value['error'])

    def test_helper_framed_encrypted_wav_and_physical_end(self):
        text='helper framed text.'
        self.assertEqual(len(text),19)
        helper=('--helper-power','1.5kW','--helper-data-power','4W')
        with tempfile.TemporaryDirectory() as directory:
            directory=pathlib.Path(directory)
            key=directory/'framed.key'; capture=directory/'framed.wav'; saved=directory/'received.txt'
            self.run_pump('keygen','--output',key)
            transmitted=self.run_pump('tx','--text',text,'--keyfile',key,'--output',capture,*helper,*AUDIO)
            envelope=self.helper_envelope(transmitted)
            self.assertEqual(envelope['helper_lead_frames'],38*envelope['sample_rate'])
            self.assertGreaterEqual(envelope['helper_post_frames'],2*envelope['sample_rate'])
            value=json.loads(self.run_pump('rx','--input',capture,'--keyfile',key,
                '--json','--save',saved,*helper,*AUDIO).stdout)
            self.assertTrue(value['stream_complete'])
            self.assertTrue(value['content_validated'])
            self.assertTrue(value['authenticated'])
            self.assertEqual(value['data_text'],text)
            self.assertEqual(saved.read_bytes(),text.encode('ascii'))
            self.assertEqual(value['raw_bit_count'],1216)
            self.assertTrue(value['helper_carrier']['present'])
            truncated=directory/'framed-truncated.wav'
            with wave.open(str(capture),'rb') as source, wave.open(str(truncated),'wb') as target:
                target.setparams(source.getparams())
                target.writeframes(source.readframes(envelope['helper_lead_frames']+envelope['robust_frames']))
            pending=json.loads(self.run_pump('rx','--input',truncated,'--keyfile',key,
                '--json',*helper,*AUDIO).stdout)
            self.assertEqual(pending['raw_bit_count'],1216)
            self.assertFalse(pending['stream_complete'])
            self.assertFalse(pending['content_validated'])
            self.assertFalse(pending['authenticated'])
            self.assertEqual(pending['data_text'],'')

    def test_helper_only_live_simulation(self):
        result=self.run_pump('listen','--helper-only','--helper-power','1.5kW',
            '--helper-callsign','N0CALL','--simulation','3dBm -60dB','--seconds','4',
            '--json','--clock-error-ppm','0','--phase-noise','0',*AUDIO)
        events=[json.loads(line) for line in result.stdout.splitlines()]
        helper_events=[event for event in events if event.get('event')=='helper_carrier']
        self.assertTrue(helper_events,'helper-only simulated capture has no helper row')
        self.assertTrue(any(event['state']=='pending' for event in helper_events))
        self.assertFalse(any(event.get('event')=='raw_bits' for event in events),
                         'helper-only simulation manufactured Robust payload bits')
        self.assertFalse(any(event.get('stream_complete') for event in events))

    def test_short_text_dictionary_threshold(self):
        for size in (1,15,16,17):
            for fec in ('off','20','60'):
                value=json.loads(self.run_pump('estimate','--text','e'*size,'--fec',fec,*AUDIO).stdout)
                self.assertEqual(value['coded_bytes'],(3*size+7)//8 if size<=16 else 128)
                self.assertEqual(value['wire_bits'],3*size if size<=16 else 1216)
                self.assertNotIn('packet_bytes',value)
    def test_audio_timing_allowance(self):
        baseline=self.run_pump('estimate','--text','e',*AUDIO).stdout
        for allowance in ('default','Default','50ms','0ms','1us','30ms','1.25s'):
            # Independent of default-clock waveform/framing/airtime estimates.
            self.assertEqual(self.run_pump('estimate','--text','e','--audio-error',allowance,*AUDIO).stdout,baseline)
        for allowance in ('-1ms','NaNms','61s','30'):
            self.run_pump('estimate','--text','e','--audio-error',allowance,*AUDIO,ok=False)
    def test_scheduled_hop_controls(self):
        helptext=self.run_pump('--help').stdout
        for flag in (b'--sched-hop',b'--sched-frequency-search',b'--sched-hop-dilution'):
            self.assertIn(flag,helptext)
        baseline=self.run_pump('estimate','--text','e',*AUDIO).stdout
        self.assertEqual(json.loads(baseline)['sched_hop'],'0')
        self.assertEqual(json.loads(baseline)['sched_frequency_search'],1)
        self.assertEqual(json.loads(baseline)['sched_hop_dilution'],0)
        for alias in ('0','off','disabled','1'):
            self.assertEqual(self.run_pump('estimate','--text','e','--sched-hop',alias,
                '--sched-hop-dilution','3',*AUDIO).stdout,baseline)
        for expansion in ('1','2','4','8','16','32'):
            self.assertEqual(self.run_pump('estimate','--text','e','--sched-hop','0',
                '--sched-frequency-search',expansion,*AUDIO).stdout,baseline)
        for factor in ('3','5'):
            error=self.run_pump('estimate','--text','e','--sched-hop',factor,*AUDIO,ok=False)
            self.assertIn(b'keyfile',error.stderr)
        for old in ('10','100','1k','1000','10k','10000'):
            error=self.run_pump('estimate','--text','e','--sched-hop',old,*AUDIO,ok=False)
            self.assertIn(b'explicit new choice',error.stderr)
        for flag,value in (('--sched-hop','2'),('--sched-hop','nan'),
                           ('--sched-frequency-search','0'),('--sched-frequency-search','3'),
                           ('--sched-frequency-search','64'),('--sched-frequency-search','nan'),
                           ('--sched-hop-dilution','2'),('--sched-hop-dilution','37'),
                           ('--sched-hop-dilution','10001'),('--sched-hop-dilution','1.5'),('--sched-hop-dilution','nan')):
            self.run_pump('estimate','--text','e',flag,value,*AUDIO,ok=False)
        with tempfile.TemporaryDirectory() as directory:
            key=pathlib.Path(directory)/'scheduled-hop-synthetic.key'
            self.run_pump('keygen','--output',key)
            for factor,dilution,expansion in (('3','0','1'),('5','0','4'),('5','3','8'),('3','3','16')):
                value=json.loads(self.run_pump('estimate','--text','e','--keyfile',key,
                    '--sched-hop',factor,'--sched-hop-dilution',dilution,'--sched-frequency-search',expansion,
                    '--clock-sync','GPS_1ms-10ms_region-2564ms_offset','--audio-error','60ms',*AUDIO).stdout)
                self.assertEqual(value['sched_hop'],factor)
                self.assertEqual(value['sched_hop_dilution'],int(dilution))
                self.assertEqual(value['sched_frequency_search'],int(expansion))
                self.assertEqual(value['wire_bits'],3)
            legacy=json.loads(self.run_pump('estimate','--text','e','--keyfile',key,
                '--sched-hop','5','--sched-hop-dilution','1',*AUDIO).stdout)
            self.assertEqual(legacy['sched_hop_dilution'],0)
            self.run_pump('estimate','--text','e','--keyfile',key,'--sched-hop','5',
                '--sched-hop-dilution','20',*AUDIO,ok=False)
    def test_search_arithmetic(self):
        self.assertIn(b'--search-arithmetic',self.run_pump('--help').stdout)
        fields=('wire_bits','coded_bytes','coded_seconds','total_seconds','sample_rate',
                'spreading','symbol_seconds','carrier_hz','stream_carrier_hz','dsss_factor','dsss_version')
        for geometry in (AUDIO,('--bw','1000','--target-snr','55','--time','1800000000')):
            baseline=json.loads(self.run_pump('estimate','--text','e',*geometry).stdout)
            self.assertEqual(baseline['search_arithmetic'],'default')
            for requested,canonical in (('default','default'),('matrix8','default'),('8-bit','default'),
                                        ('int8','default'),('INT8','default'),('fp32','fp32-min'),('fp64','fp64-force'),
                                        ('fp32-min','fp32-min'),('fp64-force','fp64-force')):
                value=json.loads(self.run_pump('estimate','--text','e','--search-arithmetic',requested,*geometry).stdout)
                self.assertEqual(value['search_arithmetic'],canonical)
                for field in fields:
                    if field == 'symbol_seconds' and field not in baseline:
                        continue  # Manual estimate output uses coded_seconds/bit_rate instead.
                    self.assertEqual(value[field],baseline[field],(requested,field))
        for invalid in ('matrix4','4-bit','fp8','gpu','unknown'):
            error=self.run_pump('estimate','--text','e','--search-arithmetic',invalid,*AUDIO,ok=False)
            self.assertIn(b'arithmetic',error.stderr)
        with tempfile.TemporaryDirectory() as directory:
            reference=None
            for arithmetic in ('default','matrix8','int8','fp32','fp64','fp32-min','fp64-force'):
                output=pathlib.Path(directory)/(arithmetic+'.wav')
                self.run_pump('tx','--text','e','--output',output,'--search-arithmetic',arithmetic,*AUDIO)
                pcm=output.read_bytes()
                if reference is None:
                    reference=pcm
                self.assertEqual(pcm,reference,'receiver arithmetic changed transmitted WAV')
    def test_receiver_strategy(self):
        helptext=self.run_pump('--help').stdout
        self.assertIn(b'--receiver-strategy',helptext)
        self.assertIn(b'--receiver-cpu-budget',helptext)
        fields=('wire_bits','coded_bytes','coded_seconds','total_seconds','sample_rate',
                'spreading','carrier_hz','stream_carrier_hz','dsss_factor','dsss_version')
        for geometry in (AUDIO,('--bw','1000','--target-snr','55','--time','1800000000')):
            baseline=json.loads(self.run_pump('estimate','--text','e',*geometry).stdout)
            self.assertEqual(baseline['receiver_strategy'],'auto')
            self.assertEqual(baseline['receiver_cpu_budget'],.6)
            for strategy in ('auto','existing','complex','amplitude'):
                value=json.loads(self.run_pump('estimate','--text','e','--receiver-strategy',strategy,
                    '--receiver-cpu-budget','.37',*geometry).stdout)
                self.assertEqual(value['receiver_strategy'],strategy)
                self.assertEqual(value['receiver_cpu_budget'],.37)
                for field in fields:
                    self.assertEqual(value[field],baseline[field],(strategy,field))
        for flag,value in (('--receiver-strategy','unknown'),('--receiver-cpu-budget','0'),
                           ('--receiver-cpu-budget','-.1'),('--receiver-cpu-budget','nan'),
                           ('--receiver-cpu-budget','inf')):
            self.run_pump('estimate','--text','e',flag,value,*AUDIO,ok=False)
        with tempfile.TemporaryDirectory() as directory:
            reference=None
            for strategy in ('auto','existing','complex','amplitude'):
                output=pathlib.Path(directory)/(strategy+'.wav')
                self.run_pump('tx','--text','e','--output',output,'--receiver-strategy',strategy,
                    '--receiver-cpu-budget','.37',*AUDIO)
                pcm=output.read_bytes()
                if reference is None:
                    reference=pcm
                self.assertEqual(pcm,reference,'receiver strategy changed transmitted WAV')
    def test_outer_dsss_version(self):
        self.assertIn(b'--dsss-version',self.run_pump('--help').stdout)
        self.assertIn(b'--dsss-mode',self.run_pump('--help').stdout)
        saved_off=json.loads(self.run_pump('estimate','--text','e','--dsss-mode','off',
            '--dsss-factor','100','--dsss-version','interleave',*AUDIO).stdout)
        self.assertEqual(saved_off['dsss_factor'],1)
        for args in (('--dsss-mode','legacy'),('--dsss-mode','interleave','--dsss-factor','1'),
                     ('--dsss-mode','interleave','--dsss-version','legacy')):
            self.run_pump('estimate','--text','e',*args,*AUDIO,ok=False)
        for invalid in ('v2','2','legacy-v1','INTERLEAVED-V2'):
            self.run_pump('estimate','--text','e','--dsss-version',invalid,*AUDIO,ok=False)
        off=json.loads(self.run_pump('estimate','--text','e','--dsss-version','interleaved-v2',*AUDIO).stdout)
        self.assertEqual(off['dsss_factor'],1)
        self.assertEqual(off['dsss_version'],'legacy')
        with tempfile.TemporaryDirectory() as directory:
            key=pathlib.Path(directory)/'dsss-version.key'
            self.run_pump('keygen','--output',key)
            geometry=('--bw','360','--target-snr','70','--dsss-factor','10','--keyfile',key,'--time','1800000000')
            default=json.loads(self.run_pump('estimate','--text','e',*geometry).stdout)
            v2=json.loads(self.run_pump('estimate','--text','e','--dsss-version','interleaved-v2',*geometry).stdout)
            legacy=json.loads(self.run_pump('estimate','--text','e','--dsss-version','legacy',*geometry).stdout)
            public=json.loads(self.run_pump('estimate','--text','e','--dsss-version','interleave',*geometry).stdout)
            self.assertEqual(default['dsss_version'],'interleave')
            self.assertEqual(v2['dsss_version'],'interleave')
            self.assertEqual(public,v2)
            self.assertEqual(legacy['dsss_version'],'legacy')
            for field in ('wire_bits','coded_bytes','coded_seconds','total_seconds','sample_rate',
                          'spreading','symbol_seconds','carrier_hz','stream_carrier_hz','dsss_factor'):
                self.assertEqual(v2[field],legacy[field],field)
                self.assertEqual(default[field],v2[field],field)
            self.assertEqual(v2['wire_bits'],3)
    def test_shannon_capacity_estimate(self):
        for bandwidth,target,expected in ((1000,30,1000), (2000,30,1169.9250014423124),
                                          (1000,60,9967.226258835993), (30000000,-200,1.4426950408889634e-20)):
            # Force a finite symbol at the weakest target, beyond automatic timing's range.
            pattern=('--pattern','pattern-16') if target==-200 else ()
            value=json.loads(self.run_pump('estimate','--text','e','--bw',bandwidth,
                                          '--target-snr',target,*pattern).stdout)
            self.assertTrue(math.isclose(value['shannon_capacity_bps'],expected,rel_tol=1e-12))
            self.assertEqual(value['wire_bits'],3)
            self.assertIn('bit_rate',value)
        manual=json.loads(self.run_pump('estimate','--text','e',*AUDIO).stdout)
        self.assertTrue(math.isclose(manual['shannon_capacity_bps'],1370.1046697509862,rel_tol=1e-12))
        extreme=json.loads(self.run_pump('estimate','--text','e','--bw','1000','--target-snr','1e308').stdout)
        self.assertIsNone(extreme['shannon_capacity_bps'])
    def test_short_dictionary_text_received_with_exact_bits(self):
        source=b'e\x00'
        value=json.loads(self.run_pump_with_exact_save('simulate','--input','-','--json','--snr','30',
            '--clock-error-ppm','0','--phase-noise','0',*AUDIO,data=source,source=source).stdout)
        self.assertTrue(value['stream_complete'])
        self.assertFalse(value['content_validated'])
        self.assertFalse(value['authenticated'])
        self.assertTrue(value['short_text_decoded'])
        self.assertEqual(value['data_text'],safe_received(source))
        self.assertEqual(value['raw_bits'],'001'+'11111'+'00000000')
        self.assertEqual(value['raw_bit_count'],16)
        self.assertEqual(value['filename'],'')
        self.assertEqual(value['recovery']['state'],'none')
        self.assertEqual(value['recovery']['attempts'],0)
        self.assertNotIn('data_base64',value)
    def test_received_text_is_restricted_in_json_and_pipes(self):
        # Each received byte must be filtered before JSON/terminal/pipe output.
        # Explicit save retains the original data, including controls, Unicode,
        # disallowed ASCII punctuation and trailing zero bytes.
        sources=(b'\nA;()\\&\x1b\r\n\xc3\xa9\n',ALLOWED_RECEIVED+bytes(range(256))+b'\x00\x00')
        for source in sources:
            args=('simulate','--input','-','--snr','30',
                  '--clock-error-ppm','0','--phase-noise','0',*AUDIO)
            output=self.run_pump_with_exact_save(*args,'--json',data=source,source=source).stdout
            self.assertEqual(output.count(b'\n'),1,'A received newline split a JSON record')
            self.assertEqual(output.count(b'\\n'),source.count(b'\n'))
            value=json.loads(output)
            self.assertTrue(value['stream_complete'])
            self.assertEqual(value['data_text'],safe_received(source))
            self.assertNotIn('data_base64',value)
            self.assertLessEqual(set(value['raw_bits']),set('01'))
            piped=self.run_pump(*args,data=source).stdout
            self.assertEqual(piped,safe_received(source).encode('ascii'))
    def test_received_attachment_name_is_restricted(self):
        with tempfile.TemporaryDirectory() as directory:
            source=pathlib.Path(directory)/'payload.bin'
            source.write_bytes(b'\x00\xff;payload')
            name='payload;(x)&caf\u00e9.bin'
            options=('simulate','--input',source,'--filename',name,'--snr','30',
                     '--clock-error-ppm','0','--phase-noise','0',*AUDIO)
            value=json.loads(self.run_pump(*options,'--json').stdout)
            self.assertEqual(value['filename'],safe_received(name.encode('utf-8')))
            human=self.run_pump(*options)
            self.assertIn(safe_received(name.encode('utf-8')).encode('ascii'),human.stderr)
            self.assertNotIn(name.encode('utf-8'),human.stderr)
    def test_lpi_advisory_estimates(self):
        public=json.loads(self.run_pump('estimate','--text','e','--bw','100','--target-snr','-3').stdout)
        self.assertEqual(public['lpi']['status'],'available')
        self.assertTrue(public['lpi']['hypothetical_encryption'])
        self.assertIn('Encryption is off',public['lpi']['warning'])
        self.assertIn('current timing',public['lpi']['warning'])
        self.assertEqual(public['lpi']['burst_exposure_basis'],'current_draft_airtime_at_receiver_reference')
        self.assertEqual(public['wire_bits'],3)
        public_strong=json.loads(self.run_pump('estimate','--text','e',*AUDIO).stdout)['lpi']
        self.assertEqual(public_strong['status'],'outside_weak_signal_model')
        self.assertTrue(public_strong['hypothetical_encryption'])
        self.assertIsNotNone(public_strong['warning'])
        self.assertIsNone(public_strong['equivalent_wire_symbols'])
        tone=json.loads(self.run_pump('analyze-link','--bits','001','--bw','100','--target-snr','-3',
            '--pattern','auto-tone','--simulation','3dBm -170dB','--trials','10').stdout)
        self.assertEqual(tone['lpi']['status'],'available')
        self.assertTrue(tone['lpi']['hypothetical_encryption'])
        self.assertIn('tone',tone['lpi']['warning'])
        self.assertEqual(tone['transmission']['wire_bits'],3)
        self.assertEqual(tone['lpi']['detection_seconds'],public['lpi']['detection_seconds'])
        with tempfile.TemporaryDirectory() as directory:
            key=pathlib.Path(directory)/'lpi.key'
            self.run_pump('keygen','--output',key)
            geometry=('--bw','100','--target-snr','-3','--keyfile',key)
            value=json.loads(self.run_pump('estimate','--text','e',*geometry).stdout)
            model=value['lpi']
            self.assertEqual(value['wire_bits'],3)
            self.assertEqual(model['status'],'available')
            self.assertFalse(model['hypothetical_encryption'])
            self.assertIsNone(model['warning'])
            self.assertEqual(model['equivalent_wire_symbols'],public['lpi']['equivalent_wire_symbols'])
            self.assertEqual(model['detection_seconds'],public['lpi']['detection_seconds'])
            self.assertEqual(model['model'],'relative_weak_signal_radiometer')
            self.assertEqual(model['cn0_basis'],'receiver_one_symbol_reference')
            self.assertEqual(model['receiver_reference_symbol_snr_db'],18)
            self.assertFalse(model['receiver_reference_is_calibrated'])
            self.assertNotIn('cn0_db_hz',model)
            self.assertFalse(model['safe_traffic_limit'])
            self.assertEqual(model['detection_probability'],.9)
            self.assertEqual(model['false_alarm_probability_per_window'],.01)
            self.assertTrue(math.isclose(model['reference_cn0_db_hz'],-4.144199392957368,rel_tol=1e-12))
            self.assertTrue(math.isclose(model['detection_seconds'],5509.6971517094125,rel_tol=1e-12))
            self.assertTrue(math.isclose(model['equivalent_wire_symbols'],33.62852265447639,rel_tol=1e-12))
            self.assertEqual(model['observation_ratio'],model['equivalent_wire_symbols'])
            self.assertTrue(math.isclose(model['additional_wire_symbols'],model['observation_ratio']-1,rel_tol=1e-12))
            self.assertTrue(math.isclose(model['burst_exposure_ratio'],value['total_seconds']/model['detection_seconds'],rel_tol=1e-12))
            # Manual keyed transfer automatically selects private Scrambler patterns.
            manual=json.loads(self.run_pump('analyze-link','--bits','001',*AUDIO,'--symbol-seconds','2',
                '--keyfile',key,'--simulation','3dBm -170dB','--trials','10').stdout)
            self.assertEqual(manual['lpi']['status'],'available')
            analysis=json.loads(self.run_pump('analyze-link','--bits','001',*geometry,
                '--simulation','3dBm -170dB','--trials','10').stdout)
            self.assertEqual(analysis['transmission']['wire_bits'],3)
            self.assertEqual(analysis['lpi'],model)
            # LPI is relative at the one-symbol reference. Actual power, noise,
            # oscillator and RX search targets still affect link analysis only.
            for channel in (('--simulation','3dBm -60dB'),('--simulation','50dBm -270dB'),
                            ('--tx-dbm','20','--attenuation-db','-160','--noise-figure-db','3',
                             '--oscillator','gpsdo-ocxo','--receive-targets','-3,32')):
                changed=json.loads(self.run_pump('analyze-link','--bits','001',*geometry,
                    *channel,'--trials','10').stdout)
                self.assertEqual(changed['lpi'],model)
                self.assertNotEqual(changed['link']['cn0_db_hz'],analysis['link']['cn0_db_hz'])
            strong=json.loads(self.run_pump('estimate','--text','e','--keyfile',key,*AUDIO).stdout)
            self.assertEqual(strong['lpi']['status'],'outside_weak_signal_model')
            self.assertIsNone(strong['lpi']['detection_seconds'])
    def test_sub_hertz_estimate(self):
        # At 10 Hz this target needs more chips than the narrow-rate floor.
        for bandwidth,seconds in (('0.001',128000), ('0.01',12800), ('0.1Hz',1280),
                                  ('0.5',256), ('10',204.8)):
            value=json.loads(self.run_pump('estimate','--text','a','--bw',bandwidth,
                                          '--target-snr','-3').stdout)
            self.assertEqual(value['wire_bits'],3)
            self.assertEqual(value['sample_rate'],6000)
            self.assertEqual(value['carrier_hz'],1500)
            self.assertTrue(math.isclose(value['symbol_seconds'],seconds,rel_tol=1e-12))
            self.assertTrue(math.isclose(value['bit_rate'],1/seconds,rel_tol=1e-12))
    def test_link_analysis_exact_draft_and_airtime(self):
        geometry=('--bw','100','--target-snr','-36','--time','1800000000')
        link=('--tx-dbm','3','--attenuation-db','-200','--trials','2000')
        for draft,count in ((('--bits','0'),1),(('--bits','001'),3),(('--text','a'),3)):
            value=json.loads(self.run_pump('analyze-link',*draft,*geometry,*link,timeout=10).stdout)
            self.assertEqual(value['transmission']['wire_bits'],count)
            self.assertTrue(value['transmission']['raw_wire_path'])
            self.assertFalse(value['production_decoder_run'])
            self.assertFalse(value['pcm_generated'])
            self.assertTrue(value['conditional_on_matched_timing_and_clock'])
            self.assertTrue(value['prescribed_template_correlation_not_measured'])
            self.assertEqual(value['receive_profile_assumption'],'matching_transmit_profile')
            self.assertTrue(value['current_receiver']['profile_matches'])
            receiver=value['current_receiver']
            self.assertIn('drift_model_available',receiver)
            self.assertIsNone(receiver['coherent_success_probability'])
            self.assertEqual(receiver['drift_sections'],4)
            sample_rate=value['transmission']['sample_rate']
            symbol_samples=round(value['transmission']['symbol_seconds']*sample_rate)
            longest_quarter=((symbol_samples+3)//4)/sample_rate
            self.assertTrue(math.isclose(receiver['drift_section_seconds'],longest_quarter,rel_tol=1e-12))
            self.assertGreater(receiver['phase_coherence_loss_db'],receiver['section_phase_coherence_loss_db'])
            self.assertGreater(receiver['section_phase_coherence_loss_db'],0)
            self.assertEqual(value['transmission']['symbol_duration_source'],'configured_tx_plan')
            self.assertNotIn('stream_complete',value)
            self.assertNotIn('raw_bits',value)
            self.assertNotIn('data_base64',value)
            self.assertEqual(value['link']['received_power_dbm'],-197)
            self.assertEqual(value['link']['cn0_db_hz'],-33)
            self.assertEqual(value['link']['snr_100hz_db'],-53)
            self.assertTrue(math.isclose(value['link']['ideal_18db_symbol_seconds'],10**5.1,rel_tol=1e-12))
            self.assertTrue(math.isclose(value['link']['zero_residual_coherent_energy_asymptote_linear'],
                                        4*10**(-3.3)/math.radians(0.5)**2,rel_tol=1e-12))
            self.assertIsNone(value['current_receiver']['success_probability'])
            self.assertFalse(value['current_receiver']['carrier_in_search'])
            self.assertFalse(value['current_receiver']['clock_in_search'])
            self.assertTrue(value['current_receiver']['oscillator_search_limited'])
            self.assertGreater(value['current_receiver']['requested_search_half_width_hz'],
                               value['current_receiver']['covered_search_half_width_hz'])
            self.assertEqual(value['current_receiver']['requested_search_half_width_hz'],
                             value['oscillator_search']['requested_frequency_half_width_hz'])
            self.assertEqual(value['current_receiver']['covered_search_half_width_hz'],
                             value['oscillator_search']['covered_frequency_half_width_hz'])
            self.assertEqual(value['current_receiver']['clock_error_ppm'],100)
            self.assertEqual(value['current_receiver']['frequency_offset_hz'],0)
            self.assertTrue(value['current_receiver']['gpu_hypothetical'])
            self.assertIn('Ryzen 5 PRO 5650U',value['current_receiver']['cpu_reference'])
            self.assertIn('4090 Laptop GPU',value['current_receiver']['gpu_reference'])
            self.assertGreaterEqual(value['current_receiver']['tracking_seconds'],0)
            self.assertGreaterEqual(value['current_receiver']['mitigation_seconds'],0)
            self.assertGreaterEqual(value['current_receiver']['payload_processing_seconds'],value['current_receiver']['mitigation_seconds'])
            self.assertGreaterEqual(value['current_receiver']['receiver_cpu_seconds'],value['current_receiver']['payload_processing_seconds'])
            self.assertGreaterEqual(value['current_receiver']['cpu_seconds'],value['current_receiver']['receiver_cpu_seconds'])
            self.assertGreaterEqual(value['current_receiver']['cpu_seconds'],value['current_receiver']['tracking_seconds'])
            self.assertGreaterEqual(value['current_receiver']['gpu_seconds'],value['current_receiver']['tracking_seconds'])
            self.assertEqual(value['current_receiver']['tracking_symbol_windows'],count)
            self.assertLessEqual(value['current_receiver']['frequency_hypotheses'],4097)
            self.assertGreater(value['current_receiver']['full_oscillator_frequency_hypotheses'],4097)
            for experiment in value['experiments'].values():
                self.assertEqual(experiment['trials'],2000)
                self.assertGreater(experiment['chips_per_segment'],0)
                self.assertLessEqual(experiment['correct_detection_probability_low'],experiment['correct_detection_probability'])
                self.assertGreaterEqual(experiment['correct_detection_probability_high'],experiment['correct_detection_probability'])
            self.assertFalse(value['experiments']['ideal_coherent']['phase_mean_energy_approximation'])
            self.assertTrue(value['experiments']['coherent_phase_model']['phase_mean_energy_approximation'])
        exact=json.loads(self.run_pump('estimate','--text','a',*geometry).stdout)
        for field in ('wire_bits','coded_bytes','content_bytes','coded_seconds','content_seconds'):
            self.assertEqual(value['transmission'][field],exact[field])
        self.assertEqual(value['transmission']['waveform_seconds'],exact['total_seconds'])
        self.assertGreater(value['transmission']['simulated_seconds'],exact['total_seconds'])
    def test_link_analysis_combined_receiver_estimate(self):
        args=('analyze-link','--bits','0','--bw','100','--symbol-seconds','16',
              '--time','1800000000','--tx-dbm','0','--attenuation-db','-150',
              '--clock-error-ppm','0','--phase-noise','40','--trials','100')
        value=json.loads(self.run_pump(*args,timeout=10).stdout)
        receiver=value['current_receiver']
        self.assertTrue(receiver['confidence_available'])
        self.assertTrue(receiver['drift_model_available'])
        self.assertFalse(receiver['coherent_reference_only'])
        self.assertEqual(receiver['probability_trials'],4096)
        self.assertFalse(receiver['differential_model_available'])
        self.assertLessEqual(receiver['success_probability_sampling_low'],receiver['success_probability'])
        self.assertGreaterEqual(receiver['success_probability_sampling_high'],receiver['success_probability'])
        for field in ('success_probability','coherent_success_probability'):
            self.assertGreaterEqual(receiver[field],0)
            self.assertLessEqual(receiver[field],1)
        repeat=json.loads(self.run_pump(*args,timeout=10).stdout)
        self.assertEqual(receiver,repeat['current_receiver'])
        self.assertFalse(value['pcm_generated'])
        self.assertFalse(value['production_decoder_run'])
    def test_link_analysis_differential_receiver_estimate(self):
        args=('analyze-link','--bits','0','--bw','0.01','--target-snr','-44.25748830262745',
              '--pattern','auto-pattern','--time','1800000000','--tx-dbm','0',
              '--attenuation-db','-200','--noise-figure-db','10','--oscillator','gpsdo-tcxo',
              '--dsp-mb','1024','--trials','100')
        value=json.loads(self.run_pump(*args,timeout=30).stdout)
        receiver=value['current_receiver']
        self.assertTrue(receiver['confidence_available'])
        self.assertTrue(receiver['differential_model_available'])
        self.assertEqual(receiver['differential_windows'],1024)
        self.assertEqual(receiver['differential_window_seconds'],3200)
        self.assertEqual(receiver['probability_trials'],4096)
        self.assertTrue(receiver['probability_search_approximation'])
        self.assertGreater(receiver['probability_carrier_candidates'],0)
        self.assertLess(receiver['success_probability_sampling_low'],receiver['success_probability'])
        self.assertGreaterEqual(receiver['success_probability_sampling_high'],receiver['success_probability'])
        self.assertIn('joint timing-path covariance',receiver['probability_model_limit'])
        self.assertFalse(value['pcm_generated'])
        self.assertFalse(value['production_decoder_run'])
    def test_link_analysis_bounded_extreme_duration(self):
        # A billion-second symbol must stay an O(trials) statistical job;
        # generating or searching even its first PCM symbol would time out.
        args=('analyze-link','--bits','001','--tx-dbm','3','--attenuation-db','-200',
              '--bw','100','--symbol-seconds','1e9','--trials','2000','--seed','17')
        value=json.loads(self.run_pump(*args,timeout=10).stdout)
        self.assertEqual(value['transmission']['symbol_seconds'],1e9)
        self.assertEqual(value['transmission']['symbol_duration_source'],'explicit_override')
        self.assertEqual(value['transmission']['wire_bits'],3)
        self.assertGreater(value['transmission']['waveform_samples'],10**12)
        segmented=value['experiments']['segmented_phase_model']
        self.assertEqual(segmented['segments'],math.ceil(1e9/3600))
        self.assertTrue(math.isclose(segmented['segments']*segmented['segment_seconds'],1e9,rel_tol=1e-12))
        self.assertFalse(value['current_receiver']['confidence_available'])
        self.assertIsNone(value['current_receiver']['success_probability'])
        self.assertTrue(math.isclose(value['reference_assumptions']['noise_pair_union_bound'],2e-12,rel_tol=1e-12))
        repeat=json.loads(self.run_pump(*args,timeout=10).stdout)
        self.assertEqual(value['experiments'],repeat['experiments'])
    def test_link_analysis_independent_targets_channel_and_reference(self):
        args=('analyze-link','--text','a','--bw','100','--trials','100',
              '--tx-dbm','3','--attenuation-db','-200')
        fast=json.loads(self.run_pump(*args,'--target-snr','32',timeout=10).stdout)
        slow=json.loads(self.run_pump(*args,'--target-snr','-36',timeout=10).stdout)
        self.assertEqual(fast['link'],slow['link'])
        self.assertGreater(slow['transmission']['symbol_seconds'],fast['transmission']['symbol_seconds'])
        profile=json.loads(self.run_pump(*args,'--target-snr','-36','--receive-targets','32',timeout=10).stdout)
        self.assertEqual(profile['receive_profile_assumption'],'explicit_receive_targets')
        self.assertFalse(profile['current_receiver']['profile_matches'])
        self.assertIsNone(profile['current_receiver']['success_probability'])
        ideal=json.loads(self.run_pump(*args,'--phase-noise','0','--clock-error-ppm','0',
            '--frequency-offset','0.125','--residual-frequency-hz','0.001',
            '--symbol-seconds','10000','--template-correlation','0.25','--noise-figure-db','4',timeout=10).stdout)
        self.assertEqual(ideal['link']['cn0_db_hz'],-27)
        self.assertIsNone(ideal['link']['zero_residual_coherent_energy_asymptote_linear'])
        self.assertEqual(ideal['current_receiver']['clock_error_ppm'],0)
        self.assertEqual(ideal['current_receiver']['frequency_offset_hz'],0.125)
        self.assertEqual(ideal['transmission']['symbol_duration_source'],'explicit_override')
        self.assertEqual(ideal['current_receiver']['actual_carrier_offset_hz'],0.125)
        self.assertEqual(ideal['reference_assumptions']['residual_frequency_hz'],0.001)
        self.assertEqual(ideal['experiments']['segmented_phase_model']['template_correlation'],0.25)
        preset=json.loads(self.run_pump('analyze-link','--input','-','--simulation','3dBm -200dB',
            '--trials','100','--bw','100','--target-snr','-36',data=b'a',timeout=10).stdout)
        self.assertEqual(preset['link'],slow['link'])
        self.assertEqual(preset['transmission']['wire_bits'],3)
    def test_link_analysis_default_calendar_clock_policy(self):
        with tempfile.TemporaryDirectory() as directory:
            key=pathlib.Path(directory)/'calendar.key'
            self.run_pump('keygen','--output',key)
            args=('analyze-link','--bits','0','--keyfile',key,'--sched-hop','3',
                  '--pattern','auto-keystream','--bw','900','--target-snr','32',
                  '--oscillator','crystal','--trials','100','--tx-dbm','3','--attenuation-db','-170')
            default=json.loads(self.run_pump(*args,timeout=10).stdout)
            explicit=json.loads(self.run_pump(*args,'--clock-sync','GPS_10ms-0ms_region-0ms_offset',timeout=10).stdout)
            self.assertEqual(default['oscillator_search'],explicit['oscillator_search'])
    def test_link_analysis_rejects_invalid_and_misplaced_options(self):
        args=('analyze-link','--text','a','--tx-dbm','3','--attenuation-db','-200','--trials','10')
        for extra in (('--symbol-seconds','0'),('--symbol-seconds','-1'),('--symbol-seconds','1e308'),
                      ('--coherent-seconds','0'),('--coherent-seconds','1e19'),
                      ('--hypotheses','1'),('--false-alarm','0'),('--false-alarm','1'),
                      ('--residual-frequency-hz','nan'),('--template-correlation','2'),
                      ('--noise-figure-db','-1'),('--output','unused.wav'),('--snr','20')):
            self.run_pump(*args,*extra,ok=False,timeout=10)
        for trials in ('0','1000001','1.5','-1'):
            self.run_pump(*args[:-2],'--trials',trials,ok=False,timeout=10)
        for draft in ((),('--bits',''),('--bits','01x'),('--bits','0','--text','a'),
                      ('--bits','0','--input','-'),('--bits','0','--callsign','CQ'),
                      ('--bits','0','--repeatable')):
            self.run_pump('analyze-link',*draft,'--tx-dbm','3','--attenuation-db','-200',ok=False,timeout=10)
        for power in ((),('--tx-dbm','3'),('--attenuation-db','-200'),
                      ('--tx-dbm','3','--attenuation-db','200'),
                      ('--simulation','off'),('--simulation','3dBm -170dB','--tx-dbm','3'),
                      ('--simulation','3dBm -170dB','--attenuation-db','-200')):
            self.run_pump('analyze-link','--text','a',*power,ok=False,timeout=10)
        for flag in ('tx-dbm','attenuation-db','noise-figure-db','symbol-seconds','coherent-seconds',
                     'trials','hypotheses','false-alarm','residual-frequency-hz','template-correlation'):
            self.run_pump('estimate','--text','a','--'+flag,'1',ok=False)
    def test_oscillator_models_and_overrides(self):
        args=('analyze-link','--text','a','--bw','100','--symbol-seconds','10000',
              '--simulation','3dBm -200dB','--trials','100')
        for name,clock,phase in (('crystal',100,.5),('gpsdo-xo',.0001,.5),
                                 ('gpsdo-tcxo',.0001,.05),('gpsdo-ocxo',.0001,.005)):
            value=json.loads(self.run_pump(*args,'--oscillator',name).stdout)
            self.assertEqual(value['oscillator_model'],{'preset':name,'illustrative':True,'overridden':False})
            self.assertEqual(value['current_receiver']['clock_error_ppm'],clock)
            self.assertEqual(value['reference_assumptions']['phase_noise_degrees_per_sqrt_second'],phase)
            explicit=json.loads(self.run_pump(*args,'--clock-error-ppm',clock,'--phase-noise',phase).stdout)
            # Explicit sampled impairments do not replace the declared search
            # model: geometry may differ while channel truth stays identical.
            self.assertEqual(value['current_receiver']['clock_error_ppm'],explicit['current_receiver']['clock_error_ppm'])
            self.assertEqual(value['current_receiver']['actual_carrier_offset_hz'],explicit['current_receiver']['actual_carrier_offset_hz'])
            self.assertEqual(value['experiments'],explicit['experiments'])
        override=json.loads(self.run_pump(*args,'--oscillator','gpsdo-ocxo','--phase-noise','2').stdout)
        self.assertTrue(override['oscillator_model']['overridden'])
        self.assertEqual(override['current_receiver']['clock_error_ppm'],.0001)
        self.assertEqual(override['reference_assumptions']['phase_noise_degrees_per_sqrt_second'],2)
        frequency_override=json.loads(self.run_pump(*args,'--oscillator','gpsdo-xo','--clock-error-ppm','.1').stdout)
        self.assertTrue(frequency_override['oscillator_model']['overridden'])
        self.assertEqual(frequency_override['current_receiver']['clock_error_ppm'],.1)
        self.assertEqual(frequency_override['reference_assumptions']['phase_noise_degrees_per_sqrt_second'],.5)
        # Custom negative transmit powers remain valid, but are no longer presets.
        negative=json.loads(self.run_pump('analyze-link','--bits','0','--tx-dbm','-3',
                                         '--attenuation-db','-200','--trials','10').stdout)
        self.assertEqual(negative['link']['received_power_dbm'],-203)
        self.run_pump('analyze-link','--bits','0','--simulation','-3dBm -200dB',ok=False)
        for command in ('simulate','listen','analyze-link'):
            self.run_pump(command,'--text','a','--simulation','3dBm -120dB',
                          '--oscillator','missing',ok=False)
        self.run_pump('estimate','--text','a','--oscillator','gpsdo-xo')
    def test_rf_oscillator_scope(self):
        for name in ('cb-ssb','ats-mini-v4-ssb','ic-7100'):
            self.run_pump('estimate','--text','a','--oscillator',name,ok=False)
        self.run_pump('estimate','--text','a','--carrier','10.0015MHz','--shift','10MHz',
                      '--rf-oscillator','ats-mini-v4-ssb')
        self.run_pump('estimate','--text','a','--carrier','10.0015MHz','--shift','10MHz',
                      '--rf-oscillator','cb-ssb','--reference','shared-radio',ok=False)
    def test_sampled_spread_and_perturbation_cli(self):
        # Physical listen accepts selected effects without --simulation. Stop
        # at the intentional duration validation before opening any device.
        physical = self.run_pump('listen','--spread-preset','hf-best','--seconds','-1',ok=False)
        self.assertIn(b'listen seconds must', physical.stderr)
        self.run_pump('estimate','--text','e','--spread-preset','none',ok=False)
        self.run_pump('simulate','--text','e','--selective-perturbation','each-2',*AUDIO,ok=False)
        with tempfile.TemporaryDirectory() as directory:
            default=pathlib.Path(directory)/'default.wav'
            zero=pathlib.Path(directory)/'zero.wav'
            stressed=pathlib.Path(directory)/'stressed.wav'
            trace=pathlib.Path(directory)/'spread.jsonl'
            common=('simulate','--text','e','--snr','40','--clock-error-ppm','0','--phase-noise','0',*AUDIO)
            self.run_pump(*common,'--output',default)
            self.run_pump(*common,'--output',zero,'--spread-preset','none','--selective-perturbation','each-65')
            self.run_pump(*common,'--output',stressed,'--spread-preset','sub9-best',
                          '--selective-perturbation','each-5','--simulation-trace',trace)
            self.assertEqual(default.read_bytes(),zero.read_bytes(), 'zero Doppler must bypass perturbation')
            self.assertNotEqual(default.read_bytes(),stressed.read_bytes(), 'enabled sampled channel must affect WAV')
            events=[json.loads(line) for line in trace.read_text().splitlines()]
            selective=next(event for event in events if event.get('event')=='simulation_frequency_selective_perturbation')
            self.assertAlmostEqual(selective['doppler_reference_hz'],.003)
            self.assertAlmostEqual(selective['slow_rate_hz'],.0003)
            self.assertAlmostEqual(selective['fast_rate_hz'],.003)
            for band in range(3):
                self.assertIn(f'band{band}_slow_phase_rad',selective)
                self.assertIn(f'band{band}_fast_phase_rad',selective)
    def test_real_radio_oscillator_search(self):
        args=('analyze-link','--bits','0','--bw','100','--tx-dbm','3','--attenuation-db','-200','--trials','10')
        radio=json.loads(self.run_pump(*args,'--carrier','10.0015MHz','--rf-shift','10MHz','--rf-oscillator','gpsdo-ocxo',
            '--reference','shared-radio').stdout)
        policy=radio['oscillator_search']
        self.assertEqual(policy['margin'],3)
        self.assertEqual(policy['rf_shift_hz'],10000000)
        self.assertEqual(policy['physical_rf_hz'],10001500)
        self.assertEqual(radio['transmission']['carrier_hz'],10001500)
        self.assertEqual(radio['transmission']['stream_carrier_hz'],1500)
        self.assertEqual(radio['transmission']['shift_hz'],10000000)
        self.assertEqual(radio['current_receiver']['clock_error_ppm'],.0001)
        self.assertAlmostEqual(radio['current_receiver']['frequency_offset_hz'],.001)
        total=json.loads(self.run_pump(*args,'--rf-carrier','10.0015MHz','--shift','10MHz','--rf-oscillator','gpsdo-ocxo',
            '--lf-reference','0').stdout)
        self.assertEqual(policy,total['oscillator_search'])
        self.assertEqual(radio['current_receiver'],total['current_receiver'])
        for ppm in ('-.0001','.0001'):
            override=json.loads(self.run_pump(*args,'--carrier','10.0015MHz','--rf-shift','10MHz','--rf-oscillator','gpsdo-ocxo',
                '--reference','shared-radio','--clock-error-ppm',ppm).stdout)
            self.assertEqual(override['oscillator_search'],policy)
            self.assertAlmostEqual(override['current_receiver']['frequency_offset_hz'],float(ppm)*10)
            self.assertEqual(override['current_receiver']['clock_error_ppm'],float(ppm))
        independent=json.loads(self.run_pump(*args,'--carrier','10.0015MHz','--rf-shift','10MHz','--rf-oscillator','gpsdo-ocxo').stdout)
        self.assertEqual(independent['current_receiver']['clock_error_ppm'],100)
        self.assertEqual(independent['oscillator_search']['requested_clock_half_width_ppm'],300)
        untranslated=json.loads(self.run_pump(*args,'--rf-oscillator','gpsdo-ocxo').stdout)
        self.assertEqual(untranslated['oscillator_search']['rf_shift_hz'],0)
        self.assertEqual(untranslated['current_receiver']['frequency_offset_hz'],0)
        for flags in (('--rf-shift','-1'),('--search-margin','.5'),('--reference','wrong'),
                      ('--sideband','wrong'),('--sideband','lower'),('--lf-reference','1500'),('--rf-shift','1','--rf-carrier','1'),
                      ('--reference','independent','--lf-reference','0')):
            self.run_pump(*args,*flags,ok=False)
    def test_absolute_carrier_shift_real_stream(self):
        args=('estimate','--text','a','--bw','100','--target-snr','32','--time','1800000000')
        default=json.loads(self.run_pump(*args).stdout)
        self.assertEqual((default['carrier_hz'],default['shift_hz'],default['stream_carrier_hz']),
                         (1500,0,1500))
        translated=json.loads(self.run_pump(*args,'--carrier','1.0015MHz','--shift','1MHz').stdout)
        self.assertEqual((translated['carrier_hz'],translated['shift_hz'],translated['stream_carrier_hz']),
                         (1001500,1000000,1500))
        self.assertEqual(translated['sample_rate'],default['sample_rate'])
        self.assertEqual(translated['wire_bits'],default['wire_bits'])
        direct=json.loads(self.run_pump(*args,'--carrier','1.0015MHz','--shift','0').stdout)
        self.assertEqual((direct['carrier_hz'],direct['shift_hz'],direct['stream_carrier_hz']),
                         (1001500,0,1001500))
        self.assertEqual(direct['sample_rate'],4006000)
        manual=json.loads(self.run_pump('estimate','--text','a','--bw','100','--spreading','16',
            '--carrier','1.0015MHz','--shift','0').stdout)
        self.assertEqual(manual['sample_rate'],4006000)
        alias=json.loads(self.run_pump(*args,'--rf-carrier','1.0015MHz','--rf-shift','1MHz',
            '--sideband','upper').stdout)
        self.assertEqual(alias,translated)
        matching=json.loads(self.run_pump(*args,'--carrier','1.0015MHz','--rf-carrier','1.0015MHz',
            '--shift','1MHz').stdout)
        self.assertEqual(matching,translated)
        for flags in (('--carrier','1MHz','--shift','1MHz'),
                      ('--carrier','1500','--shift','1MHz'),
                      ('--carrier','1500','--rf-carrier','1.0015MHz'),
                      ('--shift','nan'),('--shift','-1'),('--carrier','inf'),
                      ('--sideband','lower'),('--shift','0','--rf-shift','0')):
            self.run_pump(*args,*flags,ok=False)
    def test_static_radial_doppler(self):
        self.assertIn(b'--doppler',self.run_pump('--help').stdout)
        args=('estimate','--text','a','--bw','100','--target-snr','32','--time','1800000000',
              '--carrier','1.0015MHz','--shift','1MHz')
        baseline=json.loads(self.run_pump(*args).stdout)
        for zero in ('0c','-0c','0knots','0mph','0kph','0%'):
            self.assertEqual(json.loads(self.run_pump(*args,'--doppler',zero).stdout),baseline)
        for value,beta in (('0.001c',.001),('-0.001c',-.001),('1knots',1852/3600/299792458),
                           ('1mph',1609.344/3600/299792458),('1kph',1000/3600/299792458)):
            actual=json.loads(self.run_pump(*args,'--doppler',value).stdout)
            expected=1001500*math.sqrt((1-beta)/(1+beta))
            self.assertAlmostEqual(actual['carrier_hz'],expected,places=8)
            self.assertAlmostEqual(actual['stream_carrier_hz'],expected-1000000,places=8)
            self.assertEqual(actual['shift_hz'],1000000)
            self.assertEqual(actual['wire_bits'],baseline['wire_bits'])
        percentage=json.loads(self.run_pump(*args,'--doppler','-0.01%').stdout)
        self.assertAlmostEqual(percentage['carrier_hz'],1001500*.9999,places=8)
        # Doppler may make equal nominal Carrier/Shift a valid positive stream.
        approaching=json.loads(self.run_pump('estimate','--text','a','--bw','100','--target-snr','32',
            '--carrier','1MHz','--shift','1MHz','--doppler','-0.001c').stdout)
        self.assertGreater(approaching['stream_carrier_hz'],0)
        for value in ('1c','-1c','nan%','-100%','10','10Hz','0.01c'):
            self.run_pump(*args,'--doppler',value,ok=False)
    def test_frequency_order_units_and_zero_shift(self):
        args=('estimate','--text','a','--bw','100','--target-snr','32','--time','1800000000')
        for carrier,shift,expected in (
                ('  1.5 KHZ  ','0 hZ',1500),
                ('1.0015 mHz','1 MHz',1001500),
                ('2.4000015 GHz','2.4 ghz',2400001500),
                ('1.0000000015 THZ','1 THz',1000000001500),
                ('+1.5E3 Hz','0e1 GHz',1500)):
            result=json.loads(self.run_pump(*args,'--carrier',carrier,'--shift',shift).stdout)
            self.assertEqual(result['carrier_hz'],expected)
            self.assertEqual(result['stream_carrier_hz'],1500)
            self.assertEqual(result['sample_rate'],6000)
        for flags in (('--shift','1e308GHz'),('--carrier','1e308THz'),('--bw','1GHz'),
                      ('--carrier','1 2 MHz'),('--carrier','1 GHz extra')):
            self.run_pump(*args,*flags,ok=False)
        radio_args=('analyze-link','--bits','0','--bw','100','--tx-dbm','3','--attenuation-db','-200','--trials','10')
        base=json.loads(self.run_pump(*radio_args,'--oscillator','crystal').stdout)
        for flags in (('--reference','shared-radio'),('--lf-reference','0')):
            zero=json.loads(self.run_pump(*radio_args,'--oscillator','crystal','--rf-oscillator','gpsdo-ocxo',
                '--shift','0',*flags).stdout)
            self.assertEqual(zero['current_receiver'],base['current_receiver'])
            self.assertEqual(zero['oscillator_search']['requested_clock_half_width_ppm'],300)
    def test_oscillator_preset_applies_to_sampled_waveform(self):
        with tempfile.TemporaryDirectory() as directory:
            args=('simulate','--text','a',*AUDIO,'--snr','30','--seed','713')
            for name,clock,phase in (('gpsdo-xo',.0001,.5),('gpsdo-ocxo',.0001,.005)):
                preset=pathlib.Path(directory)/(name+'-preset.wav')
                explicit=pathlib.Path(directory)/(name+'-explicit.wav')
                self.run_pump(*args,'--oscillator',name,'--output',preset)
                self.run_pump(*args,'--clock-error-ppm',clock,'--phase-noise',phase,'--output',explicit)
                self.assertEqual(preset.read_bytes(),explicit.read_bytes())
    def test_sub_hertz_sampled_reception(self):
        # A reduced internal clock exercises the actual 3.56-hour symbol
        # geometry with a bounded test recording, without waiting in real time.
        # This is a zero-drift control, not a hardware sensitivity result.
        value=json.loads(self.run_pump('simulate','--text','a','--json','--bw','0.01',
            '--sample-rate','64','--carrier','16','--spreading','64',
            '--clock-error-ppm','0','--phase-noise','0','--snr','30',
            '--search-seconds','0','--time','1800000000').stdout)
        self.assertTrue(value['stream_complete'])
        self.assertEqual(value['raw_bits'],'011')
        self.assertEqual(value['missing_symbols'],0)
        self.assertEqual(value['data_text'],'a')
    def test_short_shaped_carrier_at_passband_edge(self):
        # The shaped waveform fits exactly above DC. Default offset search
        # must retain its valid center when no negative pair fits the passband.
        geometry=('--bw','3600','--sample-rate','14400','--carrier','1125','--spreading','16')
        estimate=json.loads(self.run_pump('estimate','--text','a',*geometry).stdout)
        self.assertEqual(estimate['wire_bits'],3)
        value=json.loads(self.run_pump('simulate','--text','a','--json',*geometry,
            '--snr','30','--clock-error-ppm','0','--phase-noise','0',
            '--time','1800000000','--search-seconds','0').stdout)
        self.assertTrue(value['stream_complete'])
        self.assertEqual(value['raw_bits'],'011')
        self.assertEqual(value['missing_symbols'],0)
        self.assertEqual(value['data_text'],'a')
    def test_recovery_settings(self):
        helptext=self.run_pump('--help').stdout
        for option in ('--recovery-seconds','--recovery-threads','--recovery-bits','--recovery-errors'):
            self.assertIn(option.encode(),helptext)
        # Recovery is a local receive policy and never changes the tiny wire path.
        value=json.loads(self.run_pump('simulate','--text','e','--json','--snr','30',
            '--clock-error-ppm','0','--phase-noise','0','--recovery-seconds','0',
            '--recovery-threads','1','--recovery-bits','1024','--recovery-errors','0',*AUDIO).stdout)
        self.assertTrue(value['stream_complete'])
        self.assertEqual(value['raw_bits'],'001')
        self.assertEqual(value['recovery']['state'],'none')
        self.assertEqual(value['recovery']['attempts'],0)
        for extra in (('--recovery-seconds','-1'),('--recovery-seconds','86401'),
                      ('--recovery-threads','1025'),('--recovery-threads','1.5'),
                      ('--recovery-bits','1023'),('--recovery-bits','1048577'),
                      ('--recovery-errors','25'),('--recovery-errors','-1')):
            self.run_pump('simulate','--text','e',*extra,*AUDIO,ok=False)
        for command in ('tx','estimate','status-rx'):
            self.run_pump(command,'--recovery-seconds','0',*AUDIO,ok=False)
    def test_live_json_reception_identity(self):
        result=self.run_pump('listen','--text','quick\nbrown','--json','--seconds','8',
            '--simulation','3dBm -90dB','--bw','3600','--pattern','auto-pattern',
            '--target-snr','32','--receive-targets','55,32','--time','1800000000',
            '--search-seconds','0','--clock-error-ppm','0','--phase-noise','0')
        events=[json.loads(line) for line in result.stdout.splitlines()]
        pending=[event for event in events if event.get('event')=='raw_bits' and not event['complete']]
        completed=[event for event in events if event.get('stream_complete')]
        self.assertTrue(pending,'Live JSON lost the pending raw-bit events')
        self.assertEqual(len(completed),1,'Competing profiles emitted duplicate completed payloads')
        payload=completed[0]
        self.assertEqual(payload['data_text'],'quick\nbrown')
        updates=[event for event in events if event.get('event')=='reception_update']
        self.assertTrue(updates,'Completed interpretation did not publish its live reception identity')
        self.assertEqual(updates[-1]['reception_id'],payload['id'])
        self.assertEqual(updates[-1]['signal_id'],payload['signal_id'])
        self.assertEqual(updates[-1]['revision'],payload['revision'])
        revisions={}
        for event in events:
            if 'signal_id' not in event:
                continue
            self.assertIsInstance(event['revision'],int)
            self.assertIsInstance(event['superseded_ids'],list)
            if event.get('event') in ('raw_bits','reception_update'):
                self.assertEqual(event['recovery']['state'],'none')
                self.assertEqual(event['recovery']['attempts'],0)
            self.assertGreaterEqual(event['revision'],revisions.get(event['signal_id'],0))
            revisions[event['signal_id']]=event['revision']
        self.assertTrue(any(event['signal_id']==payload['signal_id'] for event in pending),
                        'Pending raw bits and completed payload have unrelated identities')
    def test_automatic_profile_short_text_and_binary_dictionary(self):
        defaults=('--bw','3600','--pattern','auto-pattern',
                  '--time','1800000000','--search-seconds','0')
        for source,expected_bits in (('quick brown',70),('quick brown fox ',98),('e'*16,48)):
            estimate=json.loads(self.run_pump('estimate','--text',source,*defaults).stdout)
            self.assertEqual(estimate['wire_bits'],expected_bits)
            value=json.loads(self.run_pump('simulate','--text',source,'--json','--snr','30',
                '--clock-error-ppm','0','--phase-noise','0',*defaults).stdout)
            self.assertTrue(value['stream_complete'])
            self.assertTrue(value['short_text_decoded'])
            self.assertFalse(value['content_validated'])
            self.assertEqual(value['observed_bit_count'],expected_bits)
            self.assertEqual(value['data_text'],source)
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'raw.wav'
            self.run_pump('status-tx','--bits','010','--output',path,*defaults)
            value=json.loads(self.run_pump('rx','--input',path,'--json',*defaults).stdout)
            self.assertEqual(value['raw_bits'],'010')
            self.assertEqual(value['data_text'],'t')
            self.assertTrue(value['short_text_decoded'])
    def test_three_bit_dictionary_text_and_physical_end(self):
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'letter.wav'
            self.run_pump('tx','--text','e','--output',path,*AUDIO)
            value=json.loads(self.run_pump('rx','--input',path,'--json',*AUDIO).stdout)
            self.assertTrue(value['stream_complete'])
            self.assertTrue(value['short_text_decoded'])
            self.assertFalse(value['content_validated'])
            self.assertEqual(value['raw_bits'],'001')
            self.assertEqual(value['data_text'],'e')
            output=pathlib.Path(directory)/'letter.txt'
            self.run_pump('rx','--input',path,'--save',output,*AUDIO)
            self.assertEqual(output.read_bytes(),b'e')
            with wave.open(str(path),'rb') as f:
                params=f.getparams();pcm=f.readframes(f.getnframes())
            trim=6*params.framerate*params.sampwidth*params.nchannels
            with wave.open(str(path),'wb') as f:
                f.setparams(params);f.writeframes(pcm[:-trim])
            pending=json.loads(self.run_pump('rx','--input',path,'--json',*AUDIO).stdout)
            self.assertFalse(pending['stream_complete'])
            self.assertFalse(pending['short_text_decoded'])
            self.assertEqual(pending['data_text'],'')
            self.assertEqual(pending['recovery']['state'],'none')
            self.assertEqual(pending['recovery']['attempts'],0)
    def test_sampled_stream_roundtrip(self):
        source=b'fixed intervals\x00\x00'
        value=json.loads(self.run_pump_with_exact_save('simulate','--input','-','--json','--snr','30',
            '--clock-error-ppm','0','--phase-noise','0',*AUDIO,data=source,source=source).stdout)
        self.assertTrue(value['stream_complete'])
        self.assertTrue(value['content_validated'])
        self.assertFalse(value['authenticated'])
        self.assertEqual(value['data_text'],safe_received(source))
        self.assertNotIn('packet_validated',value)
        self.assertEqual(value['kind'],'text')
        self.assertEqual(value['filename'],'')
        self.assertEqual(value['fec_repairs']['data']['repaired_bytes'],0)
        self.assertGreater(value['pre_fec_accuracy']['received_data_bits'],0)
    def test_uncompressed_exact_binary(self):
        source=bytes(range(32))+b'\x00\x00'
        value=json.loads(self.run_pump_with_exact_save('simulate','--input','-','--no-compression','--json',
            '--snr','30','--clock-error-ppm','0','--phase-noise','0',*AUDIO,data=source,source=source,
            receive_options=(*AUDIO,'--no-compression')).stdout)
        self.assertTrue(value['content_validated'])
        self.assertEqual(value['data_text'],safe_received(source))
        self.assertEqual(value['kind'],'text')
        self.assertEqual(value['filename'],'')
    def test_explicit_attachment(self):
        source=bytes(range(32))+b'\x00\x00'
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'payload.bin'
            path.write_bytes(source)
            value=json.loads(self.run_pump_with_exact_save('simulate','--input',path,'--repeatable','--json',
                '--snr','30','--clock-error-ppm','0','--phase-noise','0',*AUDIO,source=source).stdout)
            self.assertTrue(value['content_validated'])
            self.assertEqual(value['kind'],'file')
            self.assertEqual(value['filename'],path.name)
            self.assertFalse(value['repeatable'])
            self.assertEqual(value['data_text'],safe_received(source))
    def test_wav_end_and_eof_are_distinct(self):
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'source.wav'
            self.run_pump('tx','--text','physical stream end','--output',path,*AUDIO)
            full=json.loads(self.run_pump('rx','--input',path,'--json',*AUDIO).stdout)
            self.assertTrue(full['content_validated'])
            self.assertTrue(full['stream_complete'])
            with wave.open(str(path),'rb') as f:
                params=f.getparams(); pcm=f.readframes(f.getnframes())
            # Keep less than one second of the transmitter's quiet tail.
            trim=6*params.framerate*params.sampwidth*params.nchannels
            with wave.open(str(path),'wb') as f:
                f.setparams(params);f.writeframes(pcm[:-trim])
            incomplete=json.loads(self.run_pump('rx','--input',path,'--json',*AUDIO).stdout)
            self.assertFalse(incomplete['stream_complete'])
            self.assertFalse(incomplete['content_validated'])
            self.assertEqual(incomplete['data_text'],'')
            output=pathlib.Path(directory)/'incomplete.bin'
            self.run_pump('rx','--input',path,'--save',output,*AUDIO,ok=False)
            self.assertFalse(output.exists())
    def test_simulate_output_retains_observed_absence(self):
        source=b'saved simulated stream\x00\x00'
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'simulated.wav'
            simulated=json.loads(self.run_pump_with_exact_save('simulate','--input','-','--output',path,'--json',
                '--snr','30','--clock-error-ppm','0','--phase-noise','0',*AUDIO,data=source,source=source).stdout)
            recorded=json.loads(self.run_pump_with_exact_save('rx','--input',path,'--json',*AUDIO,source=source).stdout)
            for value in (simulated,recorded):
                self.assertTrue(value['stream_complete'])
                self.assertTrue(value['content_validated'])
                self.assertEqual(value['data_text'],safe_received(source))
    def test_raw_bits_same_physical_rule(self):
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'raw.wav'
            self.run_pump('status-tx','--bits','001','--output',path,'--no-mono',*AUDIO)
            value=json.loads(self.run_pump('status-rx','--bits','001','--input',path,*AUDIO).stdout)
            self.assertEqual(value['raw_bits'],'001')
            self.assertTrue(value['known_bits_match'])
            self.assertFalse(value['content_validated'])
            self.assertTrue(value['stream_complete'])
            with wave.open(str(path),'rb') as f:
                params=f.getparams();pcm=f.readframes(f.getnframes())
            self.assertEqual(params.nchannels,1,'Live stereo routing must not change WAV framing')
            trim=6*params.framerate*params.sampwidth*params.nchannels
            with wave.open(str(path),'wb') as f:
                f.setparams(params);f.writeframes(pcm[:-trim])
            incomplete=json.loads(self.run_pump('status-rx','--bits','001','--input',path,*AUDIO).stdout)
            self.assertFalse(incomplete['stream_complete'])
            self.assertFalse(incomplete['known_bits_match'])
    def test_invalid_input_is_bounded(self):
        for extra in (('--fec','99'),('--cache-mb','0'),('--bw','0'),('--bw','0.0009'),('--nonsense','x')):
            self.run_pump('estimate','--text','x',*extra,ok=False)
        self.run_pump('tx','--text','x',ok=False)

if __name__=='__main__': unittest.main()

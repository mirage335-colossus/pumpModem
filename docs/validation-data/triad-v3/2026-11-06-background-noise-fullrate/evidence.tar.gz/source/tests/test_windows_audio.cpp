#include "resource_test_margin.hpp"
#include "datapump/audio.hpp"
#include <mmsystem.h>
#include <cmath>
#include <iostream>
#include <limits>
#include <numbers>
#include <stdexcept>
namespace audio=datapump::audio;
namespace fake=winmm_test;
void require(bool b,const char* message) {if(!b)throw std::runtime_error(message);}
void clean() {
    require(fake::state.events==0 && fake::state.opened==0 && fake::state.prepared==0 && fake::state.pending.empty(),"Windows audio resource leak");
}
void direct_format() {
    require(!fake::state.attempted_flags.empty(),"no audio format was attempted");
    for(const auto flags:fake::state.attempted_flags)
        require((flags&WAVE_FORMAT_DIRECT)!=0,"ACM conversion bypasses application sample-rate negotiation");
}
template<class F> void rejects(F action) {
    bool failed=false;try{action();}catch(const datapump::Error&){failed=true;}
    require(failed,"device error was ignored");clean();
}
void channel_routing() {
    const std::vector<float> samples{0,.25f,-.5f,1,-1,2,-2};
    const std::vector<std::int16_t> pcm{0,8191,-16383,32767,-32767,32767,-32767};
    for(const auto& supported:std::vector<std::vector<unsigned>>{{1,2},{2}}) {
        fake::reset();fake::state.supported_channels=supported;
        audio::play(samples,48000,"7");direct_format();
        require(fake::state.channels==2 && fake::state.attempted_channels==std::vector<unsigned>{2},"stereo playback must prefer two channels, including a stereo-only device");
        require(fake::state.selected_device==7 && fake::state.played.size()==pcm.size()*2,"default mono routing changed device or stereo frame count");
        for(std::size_t i=0;i<pcm.size();++i)
            require(fake::state.played[2*i]==pcm[i] && fake::state.played[2*i+1]==0,"default mono must preserve left and silence right PCM");
        clean();
        fake::reset();fake::state.supported_channels=supported;
        audio::play(samples,48000,"7",{},{},false);direct_format();
        require(fake::state.channels==2 && fake::state.played.size()==pcm.size()*2,"disabled mono changed stereo frame count");
        for(std::size_t i=0;i<pcm.size();++i)
            require(fake::state.played[2*i]==pcm[i] && fake::state.played[2*i+1]==pcm[i],"disabled mono must send the same PCM through both channels");
        clean();
    }
    for(const auto mode:{audio::ChannelMode::left_mono,audio::ChannelMode::right_mono,audio::ChannelMode::stereo}) {
        const bool left=mode!=audio::ChannelMode::right_mono,right=mode!=audio::ChannelMode::left_mono;
        fake::reset();audio::play(samples,48000,"7",{},{},mode);direct_format();
        require(fake::state.channels==1 && fake::state.attempted_channels==std::vector<unsigned>{2,1},"mono-only card did not fall back at its original rate");
        require(fake::state.selected_device==7 && fake::state.played==pcm,"mono-only device lost or changed transmit PCM");clean();
        fake::reset();fake::state.supported_channels={2};
        std::size_t generated=0;
        audio::playback(48000,"7",[&](std::span<float> chunk) {
            require(chunk.size()<=2400,"stereo playback expanded the logical callback into channel samples");
            const auto count=std::min<std::size_t>(chunk.size(),10003-generated);
            for(std::size_t i=0;i<count;++i)chunk[i]=samples[(generated+i)%samples.size()];
            generated+=count;return count;
        },{},{},mode);direct_format();
        require(fake::state.played.size()==20006 && fake::state.open_calls==1,"streamed stereo changed duration or reopened its device");
        require(fake::state.initial_queue==2 && !fake::state.gap,"streamed stereo lost double buffering");
        require(std::all_of(fake::state.queued_frames.begin(),fake::state.queued_frames.end(),[](auto count){return count<=2400;}),"stereo buffers count samples instead of frames");
        for(std::size_t i=0;i<10003;++i)
            require(fake::state.played[2*i]==(left?pcm[i%pcm.size()]:0) && fake::state.played[2*i+1]==(right?pcm[i%pcm.size()]:0),"streamed stereo changed channel or source frame alignment");
        clean();
        fake::reset();fake::state.supported_rates={44100};fake::state.supported_channels={2};
        std::vector<float> tone(9600+17);
        for(std::size_t i=0;i<tone.size();++i)tone[i]=static_cast<float>(.5*std::sin(2*std::numbers::pi*1500*static_cast<double>(i)/96000));
        audio::play(tone,96000,"7",{},{},mode);direct_format();
        const auto frames=(tone.size()*44100+95999)/96000;
        require(fake::state.rate==44100 && fake::state.channels==2 && fake::state.played.size()==frames*2,"stereo rate fallback changed transmit duration");
        require(fake::state.selected_device==7 && fake::state.initial_queue==2 && !fake::state.gap,"resampled stereo changed endpoint or lost double buffering");
        for(std::size_t i=0;i<frames;++i)
            require((left || fake::state.played[2*i]==0) && (right || fake::state.played[2*i+1]==0) &&
                  (!(left&&right) || fake::state.played[2*i]==fake::state.played[2*i+1]),"resampling changed channel routing");
        double error=0;
        for(std::size_t i=100;i+100<frames;++i)
            error=std::max(error,std::abs(fake::state.played[2*i+(left?0:1)]/32767.-.5*std::sin(2*std::numbers::pi*1500*static_cast<double>(i)/44100)));
        require(error<.00015,"resampling changed active-channel phase/amplitude");clean();
    }
}
void full_rate_background_noise() {
    audio::Options options;options.background_noise.mode=datapump::background_noise::Mode::EffectiveBits;
    options.background_noise.value=5;
    audio::BackgroundNoiseReport report;bool reported=false;
    options.background_noise_report=[&](const auto& value){report=value;reported=true;};
    fake::reset();fake::state.supported_rates={48000};std::size_t generated=0;
    audio::playback(8000,"7",[&](std::span<float> out) {
        const auto count=std::min<std::size_t>(out.size(),1001-generated);
        std::fill_n(out.begin(),count,0.f);generated+=count;return count;
    },{},{},audio::ChannelMode::left_mono,options);
    require(generated==1001 && fake::state.played.size()==6006,"full-rate WinMM noise changed resampled duration");
    require(std::any_of(fake::state.played.begin(),fake::state.played.end(),[](auto value){return value!=0;}),
        "final S16 WinMM provider stage did not add noise to silence");
    require(reported && report.enabled && report.sample_rate_hz==48000 && report.active_samples==6006,
        "WinMM noise report omitted final DAC-rate frame accounting");
    require(report.measured_variance>0 && report.peak>0,"WinMM noise report omitted emitted noise measurements");
    const auto first=fake::state.played;
    fake::reset();fake::state.supported_rates={48000};generated=0;
    audio::playback(8000,"7",[&](std::span<float> out) {
        const auto count=std::min<std::size_t>(out.size(),1001-generated);
        std::fill_n(out.begin(),count,0.f);generated+=count;return count;
    },{},{},audio::ChannelMode::left_mono,options);
    require(first!=fake::state.played,"separate WinMM transmissions reused one noise stream");clean();
}
void audio_options() {
    require(!audio::exclusive_supported(),"WinMM incorrectly advertises exclusive hardware support");
    const std::vector<float> samples{0,.25f,-.5f,1,-1,2,-2,.00004f,-.00004f};
    const std::vector<std::pair<double,std::vector<std::int16_t>>> vectors{
        {.0001,{0,0,-1,3,-3,6,-6,0,0}},
        {.001,{0,8,-16,32,-32,65,-65,0,0}},
        {.005,{0,40,-81,163,-163,327,-327,0,0}},
        {.5,{0,4095,-8191,16383,-16383,32767,-32767,0,0}},
        {1.,{0,8191,-16383,32767,-32767,32767,-32767,1,-1}},
        {1.05,{0,8601,-17202,32767,-32767,32767,-32767,1,-1}},
        {1.75,{0,14335,-28671,32767,-32767,32767,-32767,2,-2}}};
    for(const auto channels:{audio::ChannelMode::left_mono,audio::ChannelMode::right_mono,audio::ChannelMode::stereo}) {
        for(const auto& [gain,pcm]:vectors) {
            fake::reset();fake::state.supported_channels={2};
            audio::play(samples,48000,"7",{},{},channels,{gain,false});direct_format();
            require(fake::state.selected_device==7 && fake::state.played.size()==samples.size()*2,"transmit gain changed device or duration");
            for(std::size_t i=0;i<samples.size();++i) {
                const auto expected=pcm[i];
                require(fake::state.played[2*i]==(channels==audio::ChannelMode::right_mono?0:expected) &&
                        fake::state.played[2*i+1]==(channels==audio::ChannelMode::left_mono?0:expected),
                        "gain was applied before clipping/routing or changed unity PCM");
            }
            clean();
        }
    }
    std::vector<float> tone(15001);
    for(std::size_t i=0;i<tone.size();++i)tone[i]=static_cast<float>(1.2*std::sin(i*.071));
    for(const unsigned rate:{48000u,96000u})
        for(const unsigned hardware_channels:{1u,2u})
            for(const auto channels:{audio::ChannelMode::left_mono,audio::ChannelMode::right_mono,audio::ChannelMode::stereo}) {
                fake::reset();fake::state.supported_rates={48000};fake::state.supported_channels={hardware_channels};
                audio::play(tone,rate,"7",{},{},channels);const auto original=fake::state.played;clean();
                fake::reset();fake::state.supported_rates={48000};fake::state.supported_channels={hardware_channels};
                audio::play(tone,rate,"7",{},{},channels,{1.,false});
                require(fake::state.played==original,"100% changed existing hardware PCM after resampling");clean();
            }
    fake::reset();const auto quiet=audio::record(.01,48000,"7",1024*1024,{},{},{.0001,false});clean();
    fake::reset();const auto loud=audio::record(.01,48000,"7",1024*1024,{},{},{1.75,false});clean();
    require(quiet==loud,"transmit volume scaled captured PCM");
    for(const double gain:{0.,-.01,.00001,1.75001,std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN()}) {
        fake::reset();rejects([&]{audio::play(samples,48000,"default",{},{},audio::ChannelMode::left_mono,{gain,false});});
        require(fake::state.open_calls==0,"invalid gain opened hardware");
    }
    fake::reset();rejects([&]{audio::play(samples,48000,"default",{},{},audio::ChannelMode::left_mono,{1.,true});});
    require(fake::state.open_calls==0,"unsupported exclusive playback opened shared audio");
    fake::reset();rejects([&]{audio::record(.01,48000,"default",1024*1024,{},{},{1.,true});});
    require(fake::state.open_calls==0,"unsupported exclusive capture opened shared audio");
}
void passive_capture_is_explicitly_unavailable() {
    constexpr unsigned logical=16000;
    const auto setup=[] {
        fake::reset();fake::state.supported_rates={48000};
        fake::state.sample=[](std::size_t n,unsigned){return static_cast<std::int16_t>((n*37)%19001-9500);};
    };
    setup();const auto ordinary=audio::record(.05,logical,"7",1024*1024);clean();
    setup();audio::Options options;options.request_capture_timing=true;options.maximum_utc_error_seconds=0;
    unsigned statuses=0,dates=0,queries=0;bool formatted=false;
    options.timing_status=[&](const auto& value) {
        require(!value.following_system_clock && value.requested_error_seconds==0 &&
            !std::isfinite(value.modeled_uncertainty_seconds),"WinMM passive request invented a timing bound");++statuses;
    };
    options.capture_timing=[&](const auto&){++dates;};
    options.frame_timestamp=[&](std::uint64_t,bool) {++queries;return audio::FrameTimestamp{};};
    const auto captured=audio::record(.05,logical,"7",1024*1024,{},[&](const auto& value) {
        formatted=true;require(value.timing_quality==audio::TimingQuality::unavailable,
            "WinMM passive format invented provider timestamp support");
    },options);
    require(captured==ordinary && formatted && statuses==1 && !dates && !queries,
        "unsupported passive timing changed WinMM PCM or emitted fabricated evidence");clean();
}
void minimum_hardware_rate() {
    constexpr std::uint32_t logical=6000;
    for(const auto minimum:{0u,64u,12000u}) {
        audio::Options options;options.minimum_hardware_rate=minimum;
        const auto expected=minimum>8000?16000u:8000u;
        fake::reset();fake::state.supported_rates={8000,16000};
        const std::vector<float> input(121,.25f);bool formatted=false;
        audio::play(input,logical,"7",{},[&](const auto& format) {
            require(format.logical_rate==logical && format.hardware_rate==expected,"minimum playback rate changed logical format or selected a slow card rate");formatted=true;
        },audio::ChannelMode::left_mono,options);
        require(formatted && fake::state.played.size()==(input.size()*expected+logical-1)/logical,"minimum playback rate changed logical duration");
        require(std::all_of(fake::state.attempted_rates.begin(),fake::state.attempted_rates.end(),[&](auto rate){return rate>=minimum;}),"Windows playback attempted a rate below its minimum");clean();
        fake::reset();fake::state.supported_rates={8000,16000};formatted=false;
        const auto pcm=audio::record(.02,logical,"7",1024*1024,{},[&](const auto& format) {
            require(format.logical_rate==logical && format.hardware_rate==expected,"minimum capture rate changed logical format or selected a slow card rate");formatted=true;
        },options);
        require(formatted && pcm.size()==120,"minimum capture rate changed logical duration");
        require(std::all_of(fake::state.attempted_rates.begin(),fake::state.attempted_rates.end(),[&](auto rate){return rate>=minimum;}),"Windows capture attempted a rate below its minimum");clean();
    }
    for(bool capture:{false,true}) {
        fake::reset();fake::state.supported_rates={8000};unsigned callbacks=0,formats=0;
        audio::Options options;options.minimum_hardware_rate=12000;
        rejects([&] {
            const auto format=[&](const auto&){++formats;};
            if(capture)audio::capture(logical,"7",[&](auto){++callbacks;return false;},{},format,options);
            else audio::playback(logical,"7",[&](auto){++callbacks;return std::size_t{0};},{},format,audio::ChannelMode::left_mono,options);
        });
        require(!callbacks && !formats && fake::state.played.empty() && !fake::state.captured,"unsupported Windows minimum reached PCM");
    }
    for(const auto invalid:{63u,120000001u}) {
        fake::reset();audio::Options options;options.minimum_hardware_rate=invalid;
        rejects([&]{audio::playback(logical,"7",[](auto){return std::size_t{0};},{},{},audio::ChannelMode::left_mono,options);});
        require(!fake::state.open_calls,"invalid minimum rate opened Windows hardware");
    }
}
int main() {
    try {
        minimum_hardware_rate();
        passive_capture_is_explicitly_unavailable();
        channel_routing();audio_options();full_rate_background_noise();
        std::vector<float> samples(30000);
        for(std::size_t i=0;i<samples.size();++i)samples[i]=static_cast<float>(i%1000)/1000;
        fake::reset();audio::play(samples,48000,"default");direct_format();
        require(fake::state.initial_queue==2 && !fake::state.gap,"playback did not keep two buffers queued");
        require(fake::state.played.size()==samples.size(),"playback changed sample count");
        for(std::size_t i=0;i<samples.size();++i)
            require(fake::state.played[i]==static_cast<std::int16_t>(samples[i]*32767),"playback reordered samples");
        clean();
        fake::reset();std::size_t generated=0;
        audio::playback(48000,"default",[&](std::span<float> chunk) {
            require(chunk.size()<=2400,"stream playback chunk exceeds 50ms");
            const auto count=std::min(chunk.size(),samples.size()-generated);
            std::copy_n(samples.begin()+static_cast<std::ptrdiff_t>(generated),count,chunk.begin());
            generated+=count;return count;
        });
        require(fake::state.open_calls==1 && fake::state.initial_queue==2 && !fake::state.gap,"stream playback must keep one device and two queued buffers");
        require(fake::state.played.size()==samples.size(),"stream playback lost samples");clean();
        fake::reset();unsigned generated_blocks=0;
        rejects([&]{audio::playback(48000,"default",[&](std::span<float> chunk) {
            if(++generated_blocks==3)WaitForSingleObject(reinterpret_cast<HANDLE>(1),1);
            if(generated_blocks>3)return std::size_t{0};
            std::fill(chunk.begin(),chunk.end(),.25f);return chunk.size();
        });});
        require(!fake::state.gap,"a slow generator must report underrun before queueing discontinuous output");
        fake::reset();auto captured=audio::record(1,16000,"default",1024*1024);direct_format();
        require(fake::state.initial_queue==2 && !fake::state.gap,"capture buffers not continuous");
        require(captured.size()==16000,"capture duration changed");
        for(std::size_t i=0;i<captured.size();++i)require(captured[i]==static_cast<float>(i)/32768,"capture reordered samples");
        clean();
        fake::reset();std::size_t streamed=0,chunks=0;
        audio::capture(16000,"default",[&](std::span<const float> chunk) {
            require(chunk.size()<=800,"continuous capture chunk exceeds 50ms");
            require(fake::state.opened==1 && fake::state.open_calls==1,"continuous capture reopened the device");
            require(fake::state.pending.size()==2,"capture callback ran without two queued buffers");
            for(auto value:chunk)require(value==static_cast<float>((streamed++)%32768)/32768,"streaming capture lost/reordered samples");
            return ++chunks<80;
        });
        require(fake::state.selected_device==WAVE_MAPPER,"default capture did not use the OS default device");
        require(streamed==64000 && !fake::state.gap,"continuous capture inserted a gap");clean();
        fake::reset();rejects([&]{audio::capture(16000,"default",[](std::span<const float>)->bool {throw datapump::Error("callback failed");});});
        for(auto failure:{fake::Failure::Prepare,fake::Failure::Write,fake::Failure::Restart,fake::Failure::Release,fake::Failure::Close}) {
            fake::reset();fake::state.failure=failure;rejects([&]{audio::play(samples,48000,"default");});
        }
        for(auto failure:{fake::Failure::Prepare,fake::Failure::Add,fake::Failure::Start,fake::Failure::Stop,fake::Failure::Release,fake::Failure::Close}) {
            fake::reset();fake::state.failure=failure;rejects([&]{(void)audio::record(1,16000,"default",1024*1024);});
        }
        fake::reset();fake::state.timeout=true;rejects([&]{audio::play(samples,48000,"default");});
        fake::reset();fake::state.timeout=true;rejects([&]{(void)audio::record(1,16000,"default",1024*1024);});
        fake::reset();fake::state.bad_capture_length=true;rejects([&]{(void)audio::record(1,16000,"default",1024*1024);});
        std::stop_source already_cancelled;
        already_cancelled.request_stop();
        fake::reset();rejects([&]{audio::play(samples,48000,"default",already_cancelled.get_token());});
        require(fake::state.writes==0,"cancelled playback queued audio");
        fake::reset();rejects([&]{(void)audio::record(1,16000,"default",1024*1024,already_cancelled.get_token());});
        require(fake::state.captured==0,"cancelled recording captured audio");
        std::stop_source playback_cancel;
        fake::reset();fake::state.before_wait=[&]{playback_cancel.request_stop();};
        rejects([&]{audio::play(samples,48000,"default",playback_cancel.get_token());});
        require(fake::state.writes==2 && fake::state.resets>0,"mid-playback cancellation did not release initial queued buffers");
        require(fake::state.maximum_wait<=50,"audio cancellation wait exceeded 50ms");
        std::stop_source capture_cancel;
        fake::reset();fake::state.before_wait=[&]{capture_cancel.request_stop();};
        rejects([&]{(void)audio::record(1,16000,"default",1024*1024,capture_cancel.get_token());});
        require(fake::state.captured<=4096 && fake::state.resets>0,"mid-capture cancellation consumed subsequent buffers");
        require(fake::state.maximum_wait<=50,"capture cancellation wait exceeded 50ms");
        fake::reset();rejects([&]{audio::play(samples,48000,"invalid");});
        fake::reset();samples.back()=std::numeric_limits<float>::quiet_NaN();
        rejects([&]{audio::play(samples,48000,"default");});
        require(fake::state.played.empty(),"invalid samples partially transmitted");
        for(const unsigned hardware:{44100u,48000u,96000u}) {
            fake::reset();fake::state.supported_rates={hardware};
            std::vector<float> tone(9600+17);
            for(std::size_t i=0;i<tone.size();++i)tone[i]=static_cast<float>(.4*std::sin(2*std::numbers::pi*2300*static_cast<double>(i)/96000));
            audio::StreamFormat observed;
            audio::play(tone,96000,"7",{},[&](const auto& info){observed=info;});
            direct_format();
            require(observed.logical_rate==96000 && observed.hardware_rate==hardware,"Windows rate metadata missing");
            require(observed.workspace_bytes>0 && datapump::testing::benchmark_below(observed.workspace_bytes,std::size_t{512*1024},"test_windows_audio.observed_workspace_bytes","workspace_bytes"),"Windows converter workspace metadata invalid");
            require(fake::state.selected_device==7,"sample-rate fallback changed selected Windows device");
            require(fake::state.played.size()==(tone.size()*hardware+95999)/96000,"Windows resampled playback duration changed");
            require(fake::state.initial_queue==2 && !fake::state.gap,"resampled output did not keep buffers queued");
            double error=0;
            for(std::size_t i=100;i+100<fake::state.played.size();++i)
                error=std::max(error,std::abs(fake::state.played[i]/32767.-.4*std::sin(2*std::numbers::pi*2300*static_cast<double>(i)/hardware)));
            require(error<.00015,"Windows rate conversion damaged playback phase/amplitude");clean();
            fake::reset();fake::state.supported_rates={hardware};
            fake::state.sample=[](std::size_t index,unsigned clock){return static_cast<std::int16_t>(15000*std::sin(2*std::numbers::pi*1300*static_cast<double>(index)/clock));};
            const auto converted=audio::record(.1,96000,"7",1024*1024,{},[&](const auto& info){observed=info;});
            direct_format();
            require(converted.size()==9600 && observed.hardware_rate==hardware,"Windows capture logical sample rate changed");
            error=0;
            for(std::size_t i=200;i<converted.size();++i)
                error=std::max(error,std::abs(converted[i]-(15000./32768)*std::sin(2*std::numbers::pi*1300*static_cast<double>(i)/96000)));
            require(error<.00015,"Windows capture resampling timestamps changed");clean();
        }
        for(const unsigned logical:{64u,4800u}) {
            constexpr unsigned hardware=48000;
            const double frequency=logical/8.;
            fake::reset();fake::state.supported_rates={hardware};
            std::vector<float> tone(logical*4+1);
            for(std::size_t i=0;i<tone.size();++i)tone[i]=static_cast<float>(.4*std::sin(2*std::numbers::pi*frequency*static_cast<double>(i)/logical));
            audio::StreamFormat observed;
            audio::play(tone,logical,"7",{},[&](const auto& info){observed=info;});
            direct_format();
            require(observed.logical_rate==logical && observed.hardware_rate==hardware,"Windows low DSP clock leaked into hardware negotiation");
            require(fake::state.selected_device==7 && fake::state.initial_queue==2 && !fake::state.gap,"low-rate playback changed endpoint or lost double buffering");
            require(fake::state.played.size()==(tone.size()*hardware+logical-1)/logical,"Windows low-rate playback duration changed");
            double error=0;
            for(std::size_t i=hardware;i+hardware<fake::state.played.size();++i)
                error=std::max(error,std::abs(fake::state.played[i]/32767.-.4*std::sin(2*std::numbers::pi*frequency*static_cast<double>(i)/hardware)));
            require(error<.00015,"Windows low-rate playback phase or amplitude changed");clean();
            fake::reset();fake::state.supported_rates={hardware};
            fake::state.sample=[&](std::size_t index,unsigned clock){return static_cast<std::int16_t>(15000*std::sin(2*std::numbers::pi*frequency*static_cast<double>(index)/clock));};
            const auto converted=audio::record(4,logical,"7",1024*1024,{},[&](const auto& info){observed=info;});
            direct_format();
            require(converted.size()==logical*4 && observed.hardware_rate==hardware && datapump::testing::benchmark_below(observed.workspace_bytes,std::size_t{5*1024*1024},"test_windows_audio.observed_workspace_bytes","workspace_bytes"),"Windows bounded low-rate capture contract failed");
            error=0;
            for(std::size_t i=logical;i<converted.size();++i)
                error=std::max(error,std::abs(converted[i]-(15000./32768)*std::sin(2*std::numbers::pi*frequency*static_cast<double>(i)/logical)));
            require(error<.00015,"Windows multistage capture phase or amplitude changed");clean();
            fake::state.captured=0;std::size_t monitored=0;bool format_seen=false;
            audio::Options monitor;
            monitor.capture_monitor=[&](std::span<const float> raw,std::uint32_t clock) {
                require(format_seen && clock==hardware,"Windows monitor lost physical rate or format ordering");
                for(auto sample:raw)require(sample==fake::state.sample(monitored++,clock)/32768.f,"Windows monitor lost raw PCM continuity");
            };
            const auto paired=audio::record(4,logical,"7",1024*1024,{},[&](const auto&){format_seen=true;},monitor);
            require(paired==converted && monitored==fake::state.captured && monitored>paired.size(),
                    "Windows monitor altered receiver PCM or lost physical input");clean();
            monitor.capture_monitor=[](auto,auto){throw datapump::Error("monitor failed");};
            rejects([&]{audio::record(1,logical,"7",1024*1024,{},{},monitor);});
            clean();

        }
        std::cout<<"Windows audio lifecycle tests passed\n";return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}

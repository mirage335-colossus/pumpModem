#include "datapump/host/audio.hpp"
#include <atomic>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <future>
#include <iostream>
#include <limits>
#include <numbers>
#include <thread>

namespace {
using namespace datapump;using namespace datapump::host;using namespace std::chrono_literals;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
template<class Function>void fails(Function function){bool failed=false;try{function();}catch(const std::exception&){failed=true;}require(failed,"invalid operation was accepted");}
template<class Predicate>void until(AudioEndpoint& endpoint,Predicate consume) {
    const auto deadline=std::chrono::steady_clock::now()+2s;
    while(std::chrono::steady_clock::now()<deadline) {
        for(const auto& e:endpoint.take_events())if(consume(e))return;
        std::this_thread::sleep_for(1ms);
    }
    throw std::runtime_error("audio event deadline expired");
}
double upper_band_periodogram(std::span<const float> samples,std::uint32_t rate) {
    const auto count=samples.size();
    long double power=0;std::size_t bins=0;
    // Use separated exact DFT bins well beyond the 8-kHz logical source
    // passband. Noise added before rate conversion is removed by its filter.
    const auto first=static_cast<std::size_t>(std::ceil(14000.0*count/rate));
    const auto last=static_cast<std::size_t>(std::floor(22000.0*count/rate));
    for(std::size_t bin=first;bin<=last;bin+=512) {
        const double step=2*std::numbers::pi*static_cast<double>(bin)/count;
        const double cs=std::cos(step),ss=std::sin(step);
        double phase_c=1,phase_s=0;long double real=0,imag=0;
        for(float sample:samples) {
            real+=sample*phase_c;imag-=sample*phase_s;
            const auto next_c=phase_c*cs-phase_s*ss;
            phase_s=phase_s*cs+phase_c*ss;phase_c=next_c;
        }
        power+=(real*real+imag*imag)/count;++bins;
    }
    return bins?static_cast<double>(power/bins):0;
}
void playback(std::uint32_t output_rate,bool composed=false) {
    AudioEndpoint endpoint;endpoint.configure(1,output_rate);std::atomic<unsigned> calls=0;std::size_t source=0;
    audio::Options options;options.transmit_gain=1.5;
    if(composed)options.minimum_hardware_rate=output_rate;
    std::uint64_t transformed=0;bool formatted=false;
    if(composed) {
        options.playback_output_gain=[](long double){return 0.;};
        options.playback_output_transform=[&](float payload,long double seconds,std::uint32_t rate) {
            require(formatted,"host output composition preceded format notification");
            require(payload==0,"host output composition preceded the payload safety gain");
            require(rate==output_rate && std::abs(seconds-static_cast<long double>(transformed)/output_rate)<1e-15L,
                "host output composition used the wrong rate or source coordinate");
            ++transformed;return .375f;
        };
    }
    auto task=std::async(std::launch::async,[&]{endpoint.playback(8000,[&](std::span<float> out){++calls;const auto n=std::min<std::size_t>(out.size(),1001-source);std::fill_n(out.begin(),n,.125f);source+=n;return n;},{},[&](const auto&){formatted=true;},audio::ChannelMode::right_mono,options);});
    std::uint64_t stream=0,frames=0;bool started=false;
    until(endpoint,[&](const AudioEndpoint::Event& e){
        if(e.kind==AudioEndpoint::Kind::playback_start){stream=e.stream;require(calls==0,"callback ran before device readiness");require(e.channels==audio::ChannelMode::right_mono&&e.gain==1.5,"output routing/gain lost");endpoint.playback_ready(1,stream);}
        if(e.kind==AudioEndpoint::Kind::playback_pcm){require(e.position==frames,"output PCM discontinuity");if(!started){require(e.presentation_epoch>0,"first output lacks presentation time");started=true;}if(composed)require(std::all_of(e.samples.begin(),e.samples.end(),[](float sample){return sample==.375f;}),"host lost or scaled the composed output before final volume");frames+=e.samples.size();endpoint.playback_progress(1,stream,frames,false);}
        if(e.kind==AudioEndpoint::Kind::playback_end){require(e.position==frames,"wrong final output count");return true;}return false;
    });
    require(frames==(1001ULL*output_rate+7999)/8000,"resampling changed finite-stream duration");
    require(task.wait_for(10ms)==std::future_status::timeout,"playback returned before device drain");
    fails([&]{endpoint.playback_progress(1,stream,frames+1,true);});
    endpoint.playback_progress(1,stream,frames,true);require(task.wait_for(2s)==std::future_status::ready,"playback did not finish after drain");task.get();
    require(!composed || transformed==frames,"host composition did not run once per hardware frame");
}
void full_rate_background_noise() {
    const auto run=[] {
        constexpr std::size_t frames=8192;
        constexpr std::size_t output_frames=(frames*48000+8000-1)/8000;
        AudioEndpoint endpoint;endpoint.configure(1,48000);std::size_t source=0;
        audio::Options options;options.transmit_gain=.25;
        options.background_noise.mode=background_noise::Mode::EffectiveBits;
        options.background_noise.value=5;
        audio::BackgroundNoiseReport report;bool reported=false;
        options.background_noise_report=[&](const auto& value){report=value;reported=true;};
        auto task=std::async(std::launch::async,[&]{endpoint.playback(8000,[&](std::span<float> out) {
            const auto n=std::min(out.size(),frames-source);std::fill_n(out.begin(),n,0.f);source+=n;return n;
        },{},{},audio::ChannelMode::left_mono,options);});
        std::vector<float> received;std::uint64_t stream=0;bool started=false;
        until(endpoint,[&](const AudioEndpoint::Event& e) {
            if(e.kind==AudioEndpoint::Kind::playback_start) {
                stream=e.stream;require(e.gain==1,"noise-enabled float output left a second gain for the provider");
                endpoint.playback_ready(1,stream);
            }
            if(e.kind==AudioEndpoint::Kind::playback_pcm) {
                require(e.gain==1,"noise-enabled float PCM gain metadata is not unity");
                started=true;received.insert(received.end(),e.samples.begin(),e.samples.end());
                endpoint.playback_progress(1,stream,received.size(),false);
            }
            if(e.kind==AudioEndpoint::Kind::playback_end) {
                require(e.gain==1 && e.position==received.size(),"float output end metadata mismatch");return true;
            }
            return false;
        });
        require(started && received.size()==output_frames,"full-rate host output lost or miscounted resampled samples");
        require(std::any_of(received.begin(),received.end(),[](float x){return x!=0;}),
            "full-rate audio stage did not add noise to silence");
        require(task.wait_for(10ms)==std::future_status::timeout,"noise report preceded host drain");
        endpoint.playback_progress(1,stream,received.size(),true);
        require(task.wait_for(2s)==std::future_status::ready,"noise-enabled host playback did not drain");task.get();
        require(reported && report.enabled && report.sample_rate_hz==48000 && report.active_samples==output_frames,
            "host noise report omitted final-rate output accounting");
        require(report.measured_variance>0 && report.measured_mean<.02 && report.measured_mean>-.02,
            "host noise report did not measure its generated stream");
        require(upper_band_periodogram(received,48000)>report.expected_variance*.2,
            "host output lacks broadband noise above the upsampled logical passband");
        return received;
    };
    const auto first=run(),second=run();
    require(first!=second,"separate host transmissions reused the same background-noise stream");
}
void gap_and_close() {
    AudioEndpoint endpoint;endpoint.configure(1,48000);std::atomic<std::size_t> frames=0;
    auto capture=std::async(std::launch::async,[&]{fails([&]{endpoint.capture(48000,[&](std::span<const float> in){frames+=in.size();return true;},{},{});});});
    std::uint64_t stream=0;until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::capture_start)return false;stream=e.stream;return true;});
    std::vector<float> pcm(128,.5f);endpoint.capture_samples(1,stream,0,pcm);
    const auto deadline=std::chrono::steady_clock::now()+2s;while(!frames&&std::chrono::steady_clock::now()<deadline)std::this_thread::sleep_for(1ms);
    require(frames==128,"accepted PCM was not delivered promptly");
    fails([&]{endpoint.capture_samples(1,stream,129,pcm);});
    require(capture.wait_for(2s)==std::future_status::ready,"capture gap failed to unblock receiver");capture.get();
    require(frames==128,"capture gap manufactured silence or accepted a broken timeline");
    endpoint.configure(2,44100);fails([&]{endpoint.capture_samples(1,stream,0,pcm);});pcm[0]=std::numeric_limits<float>::quiet_NaN();fails([&]{endpoint.capture_samples(2,stream,0,pcm);});
    AudioEndpoint waiting;auto blocked=std::async(std::launch::async,[&]{fails([&]{waiting.capture(8000,[](auto){return true;},{},{});});});waiting.close();require(blocked.wait_for(2s)==std::future_status::ready,"close failed to wake unconfigured capture");blocked.get();
}
void minimum_hardware_rate() {
    AudioEndpoint endpoint;endpoint.configure(1,8000);
    audio::Options options;options.minimum_hardware_rate=12000;
    unsigned callbacks=0,formats=0;
    fails([&]{endpoint.playback(6000,[&](auto){++callbacks;return std::size_t{0};},{},[&](const auto&){++formats;},audio::ChannelMode::left_mono,options);});
    require(!callbacks && !formats && endpoint.take_events().empty(),"insufficient browser output started a stream or requested PCM");
    auto& shared=audio_endpoint();shared.configure(1,8000);
    unsigned monitors=0;options.capture_monitor=[&](auto,auto){++monitors;};
    fails([&]{audio::capture(6000,"default",[&](auto){++callbacks;return false;},{},[&](const auto&){++formats;},options);});
    require(!callbacks && !formats && !monitors,"insufficient browser capture delivered PCM or published a format");
    const auto events=shared.take_events();
    require(events.size()==2 && events.front().kind==AudioEndpoint::Kind::capture_start && events.back().kind==AudioEndpoint::Kind::capture_stop,
        "failed browser capture left an active subscription");
    for(const auto invalid:{63u,120000001u}) {
        options.minimum_hardware_rate=invalid;
        fails([&]{endpoint.playback(6000,[](auto){return std::size_t{0};},{},{},audio::ChannelMode::left_mono,options);});
        require(endpoint.take_events().empty(),"invalid browser hardware floor started a stream");
    }
}
void capture_monitor_pair() {
    constexpr std::uint32_t hardware=8000,logical=1000;
    std::vector<float> pcm(3200);
    for(std::size_t i=0;i<pcm.size();++i)pcm[i]=i%4==1?.5f:i%4==3?-.5f:0.f;
    struct Result {std::vector<float> logical,raw;std::vector<std::size_t> chunks;};
    const auto run=[&](bool observed) {
        AudioEndpoint endpoint;endpoint.configure(1,hardware);Result result;bool formatted=false;
        audio::CaptureMonitor monitor;
        if(observed)monitor=[&](std::span<const float> input,std::uint32_t rate) {
            require(formatted && rate==hardware,"host monitor lost physical format ordering");
            require(result.raw.size()+input.size()<=pcm.size(),"host monitor duplicated PCM");
            result.raw.insert(result.raw.end(),input.begin(),input.end());
        };
        auto task=std::async(std::launch::async,[&] {
            endpoint.capture(logical,[&](std::span<const float> input) {
                result.chunks.push_back(input.size());result.logical.insert(result.logical.end(),input.begin(),input.end());
                return result.logical.size()<256;
            },{},[&](const auto&){formatted=true;},monitor);
        });
        std::uint64_t stream=0;
        until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::capture_start)return false;stream=e.stream;return true;});
        for(std::size_t offset=0;offset<pcm.size();offset+=400)
            endpoint.capture_samples(1,stream,offset,std::span<const float>(pcm).subspan(offset,400));
        if(task.wait_for(2s)!=std::future_status::ready) {endpoint.close();task.wait();throw std::runtime_error("host monitored capture stalled");}
        task.get();return result;
    };
    const auto plain=run(false),observed=run(true);
    require(plain.logical==observed.logical && plain.chunks==observed.chunks,"host monitor changed decoder PCM or chunk boundaries");
    require(observed.raw.size()>=2048 && observed.raw.size()<=pcm.size() &&
            std::equal(observed.raw.begin(),observed.raw.end(),pcm.begin()),"host monitor changed or repeated raw out-of-band input");
}
void capture_restart() {
    AudioEndpoint endpoint;endpoint.configure(1,48000);std::vector<float> pcm(128,.25f);
    std::uint64_t retired=0;
    for(unsigned round=0;round<3;++round) {
        std::atomic<std::size_t> frames=0;
        auto task=std::async(std::launch::async,[&]{endpoint.capture(48000,[&](auto in){frames+=in.size();return false;},{},{});});
        std::uint64_t stream=0;until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::capture_start)return false;stream=e.stream;return true;});
        require(stream>retired,"capture subscription was reused");
        if(retired)endpoint.capture_samples(1,retired,128,pcm);
        endpoint.capture_samples(1,stream,10000ULL*round,pcm);
        require(task.wait_for(2s)==std::future_status::ready,"restarted capture did not accept its own timeline");task.get();
        require(frames==128,"retired capture crossed subscription boundary");
        until(endpoint,[&](const auto& e){return e.kind==AudioEndpoint::Kind::capture_stop&&e.stream==stream;});
        endpoint.capture_samples(1,stream,10000ULL*round+128,pcm);
        retired=stream;
    }
}
void stopped_capture() {
    AudioEndpoint endpoint;endpoint.configure(1,8000);
    auto task=std::async(std::launch::async,[&]{fails([&]{endpoint.capture(8000,[](auto){return true;},{},{});});});
    until(endpoint,[](const auto& e){return e.kind==AudioEndpoint::Kind::capture_start;});
    endpoint.interrupted(1,"browser closed input");
    until(endpoint,[](const auto& e){return e.kind==AudioEndpoint::Kind::stopped;});
    require(task.wait_for(2s)==std::future_status::ready,"idle acknowledgment preceded capture shutdown");task.get();
    endpoint.configure(2,8000);
}
void cancellation() {
    AudioEndpoint endpoint;endpoint.configure(1,8000);std::stop_source stop;
    auto task=std::async(std::launch::async,[&]{fails([&]{endpoint.playback(8000,[](std::span<float> out){std::fill(out.begin(),out.end(),.25f);return out.size();},stop.get_token(),{},audio::ChannelMode::left_mono,{});});});
    std::uint64_t stream=0;
    until(endpoint,[&](const auto& e){if(e.kind==AudioEndpoint::Kind::playback_start){stream=e.stream;endpoint.playback_ready(1,stream);}if(e.kind==AudioEndpoint::Kind::playback_pcm){stop.request_stop();endpoint.interrupted(1,"browser stopped");return true;}return false;});
    until(endpoint,[](const auto& e){return e.kind==AudioEndpoint::Kind::playback_cancel;});
    require(task.wait_for(10ms)==std::future_status::timeout,"cancel returned before old samples were flushed");
    fails([&]{endpoint.configure(2,8000);});fails([&]{endpoint.playback_cancelled(1,stream+1);});
    endpoint.playback_cancelled(1,stream);require(task.wait_for(2s)==std::future_status::ready,"flush acknowledgment failed to release cancellation");task.get();until(endpoint,[](const auto& e){return e.kind==AudioEndpoint::Kind::stopped;});endpoint.configure(2,8000);
}
void failed_output_keeps_capture() {
    AudioEndpoint endpoint;endpoint.configure(1,48000);
    std::atomic<std::size_t> captured=0;std::atomic<bool> done=false;
    auto input=std::async(std::launch::async,[&]{endpoint.capture(48000,[&](auto samples){captured+=samples.size();return !done;},{},{});});
    std::uint64_t capture=0;
    until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::capture_start)return false;capture=e.stream;return true;});
    const std::vector<float> pcm(128,.25f);
    endpoint.capture_samples(1,capture,0,pcm);
    auto output=std::async(std::launch::async,[&]{fails([&]{endpoint.playback(48000,[](auto samples){std::fill(samples.begin(),samples.end(),.25f);return samples.size();},{},{},audio::ChannelMode::left_mono,{});});});
    std::uint64_t playback=0;
    until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::playback_start)return false;playback=e.stream;endpoint.playback_failed(1,playback,"output clock unavailable");return true;});
    until(endpoint,[&](const auto& e){return e.kind==AudioEndpoint::Kind::playback_cancel&&e.stream==playback;});
    require(output.wait_for(10ms)==std::future_status::timeout,"failed output returned before device flush");
    endpoint.capture_samples(1,capture,128,pcm);
    endpoint.playback_cancelled(1,playback);
    require(output.wait_for(2s)==std::future_status::ready,"failed output did not finish after flush");output.get();
    // A fresh output in the same audio generation must succeed, while input
    // retains its exact original stream and contiguous sample positions.
    auto retry=std::async(std::launch::async,[&]{endpoint.playback(48000,[](auto){return std::size_t(0);},{},{},audio::ChannelMode::left_mono,{});});
    until(endpoint,[&](const auto& e){
        if(e.kind==AudioEndpoint::Kind::playback_start){require(e.stream>playback,"output stream reused");endpoint.playback_ready(1,e.stream);}
        if(e.kind==AudioEndpoint::Kind::playback_end){endpoint.playback_progress(1,e.stream,e.position,true);return true;}
        return false;
    });
    require(retry.wait_for(2s)==std::future_status::ready,"output retry failed");retry.get();
    const auto deadline=std::chrono::steady_clock::now()+2s;
    while(captured<256&&std::chrono::steady_clock::now()<deadline)std::this_thread::sleep_for(1ms);
    require(captured==256,"continuous capture stalled after output failure");
    done=true;endpoint.capture_samples(1,capture,256,pcm);
    require(input.wait_for(2s)==std::future_status::ready,"output failure interrupted capture");input.get();
    require(captured==384,"output failure lost or manufactured input samples");
}
void paced_capture_stops() {
    for(bool interrupted:{false,true}) {
        AudioEndpoint endpoint;endpoint.configure(1,8000);std::stop_source stop;
        std::atomic<std::size_t> frames=0;std::string error;
        auto task=std::async(std::launch::async,[&]{
            try {endpoint.capture(8000,[&](auto samples){frames+=samples.size();return true;},stop.get_token(),{});}
            catch(const std::exception& e){error=e.what();}
        });
        std::uint64_t stream=0;
        until(endpoint,[&](const auto& e){if(e.kind!=AudioEndpoint::Kind::capture_start)return false;stream=e.stream;return true;});
        const std::vector<float> pcm(400,.25f);
        for(std::uint64_t position=0;position<8000;position+=pcm.size())endpoint.capture_samples(1,stream,position,pcm);
        const auto deadline=std::chrono::steady_clock::now()+2s;
        while(frames<1200&&std::chrono::steady_clock::now()<deadline)std::this_thread::sleep_for(1ms);
        const auto before=frames.load();
        if(interrupted)endpoint.interrupted(1,"fixture input interrupted");else stop.request_stop();
        require(task.wait_for(2s)==std::future_status::ready,"paced capture did not wake on cancellation/interruption");task.get();
        require(before>=1200&&before<8000,"host forwarded the entire delayed capture burst immediately");
        require(error==(interrupted?"fixture input interrupted":"audio operation cancelled"),"paced capture reported the wrong stop reason");
    }
}
}
int main(){try{playback(8000);playback(44100);playback(48000);playback(8000,true);playback(44100,true);playback(48000,true);full_rate_background_noise();minimum_hardware_rate();gap_and_close();capture_monitor_pair();capture_restart();stopped_capture();cancellation();failed_output_keeps_capture();paced_capture_stops();std::cout<<"Host audio bounds, continuity, resampling, readiness, drain, cancellation and output recovery passed\n";return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}

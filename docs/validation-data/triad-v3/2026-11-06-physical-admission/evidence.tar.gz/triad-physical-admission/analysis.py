"""Posthoc cable signal-energy diagnostic, never used by admission.

Uses the evaluation bit only after complete frozen-profile receiver decisions.
The public arrival grid is reused; no variance, threshold, waveform or duration
is changed. Noise density comes from a separate validation recording.
"""
import hashlib
import json
import math
from pathlib import Path
import resource
import sys
import time

import numpy as np
from scipy import signal
from scipy.optimize import brentq
from scipy.stats import ncx2

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT/'tools'))
from triad_continuous import NativeStream

OUT = ROOT/'local-evidence/triad-physical-admission'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def nc_interval(value, alpha):
    def root(q):
        if ncx2.cdf(value, 2, 0) <= q:
            return 0.
        hi = max(1., value*2)
        while ncx2.cdf(value, 2, hi) > q:
            hi *= 2
        return brentq(lambda nc: ncx2.cdf(value, 2, nc)-q, 0, hi)
    return [root(1-alpha/2), root(alpha/2)]


def main():
    start, cpu = time.perf_counter(), time.process_time()
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    spec = json.loads((OUT/'spec.json').read_text())
    bank = json.loads((OUT/'bank.json').read_text())
    fs_adc = 48000
    # The real DATA/no-DATA trials negotiate a 44.1-kHz DAC, whereas the
    # calibration-only native-rate playback used 48 kHz. Use the independent
    # same-playback-path null for signal-margin diagnostics.
    noise_path = OUT/'null/adc.f32'
    noise = np.fromfile(noise_path, '<f4').astype(float)
    noise_seconds = len(noise)/fs_adc
    # Interior for the separate SNR estimate only. The admission profile used
    # the COMPLETE validation interval, including startup and tail.
    noise = noise[2*fs_adc:-2*fs_adc]
    frequency, psd = signal.welch(noise, fs=fs_adc, nperseg=8192, noverlap=4096)
    band = (frequency>=1575)&(frequency<=1875)
    n0 = float(np.mean(psd[band]))
    rows = []
    for name in ('bit0', 'bit1', 'null'):
        path = OUT/name/'result.json'
        if not path.exists():
            continue
        r = json.loads(path.read_text())
        row = {key:r.get(key) for key in ('complete','admitted','candidate_bit','log_e',
            'preparation_wall_seconds','wall_seconds','python_cpu_seconds','child_cpu_seconds',
            'all_process_cpu_seconds_per_input_second','errors','expected_bit_evaluation_only')}
        row.update(name=name, result_sha256=sha(path), adc_sha256=sha(OUT/name/'adc.f32'),
            receiver_cpu_seconds=r['receiver']['push_process_cpu_seconds'],
            workspace_estimate_bytes=r['receiver']['working_bytes_estimate'],
            template_cache_peak_bytes=r['template_cache']['peak_cache_bytes'],
            capture_clock_peak_applied_ppm=r['audio_receipt']['clock_discipline']['peak_applied_ppm'],
            playback_clock_peak_applied_ppm=r['playback_receipt']['clock_discipline']['peak_applied_ppm'],
            block_count=r['receiver']['block_updates'],
            maximum_block_wall_seconds=r['receiver']['maximum_block_wall_seconds'])
        if r['expected_bit_evaluation_only'] is None:
            rows.append(row)
            continue
        native = ['--bit',str(r['expected_bit_evaluation_only']),*spec['native_arguments']]
        source = NativeStream(ROOT/'build/dev-cli/triad_helper_export',native,kind='emitted')
        try:
            d = source.descriptor
            fs = int(d['sample_rate_hz'])
            total = int(d['total_samples'])
            pieces = []
            while source.next_sample < total:
                values, _ = source.next(min(8192,total-source.next_sample))
                pieces.append(values)
            template = np.concatenate(pieces)
        finally:
            source.close()
        adc = np.fromfile(OUT/name/'adc.f32','<f4').astype(float)
        # Polyphase anti-alias filter is flat through 1875 Hz. Its symmetric
        # compensated time origin preserves the fixed ADC clock and source lag.
        low = signal.resample_poly(adc, 1, fs_adc//fs)
        observed = signal.hilbert(low)/math.sqrt(2)*np.exp(
            -2j*np.pi*d['data_if_hz']*np.arange(len(low))/fs)
        lags = np.asarray([round(coordinate[1]*fs) for coordinate in bank['coordinates']])
        correlation = signal.correlate(observed,template,mode='full',method='fft')
        energy_samples = float(np.vdot(template,template).real)
        fits = correlation[len(template)-1+lags]/energy_samples
        best = int(np.argmax(abs(fits)))
        fit = fits[best]
        variance_h = fs*n0/energy_samples
        amplitude_power = max(0., float(abs(fit)**2-variance_h))
        useful_seconds = d['power']['data_reference_active_seconds']
        template_energy_seconds = energy_samples/fs
        rx_energy = amplitude_power*template_energy_seconds
        rx_power = rx_energy/useful_seconds
        cn0 = rx_power/n0
        z = 2*abs(fit)**2/variance_h
        # Simultaneous conditional intervals for the 32 PUBLIC lag atoms.
        # They cover fitted coefficients, not waveform mismatch or uncertain N0.
        nc_lo,nc_hi = nc_interval(float(z), .05/len(lags))
        factor = variance_h/2*template_energy_seconds/useful_seconds/n0
        interval = [10*math.log10(max(x*factor,1e-300)) for x in (nc_lo,nc_hi)]
        # Separate measurement-only refinement, never seen by the live RX.
        # This removes much of the 4-ms public-grid mismatch without rerunning
        # the receiver or choosing a new admission threshold.
        fine_lags = np.arange(lags.min(),lags.max()+1)
        fine_fits = correlation[len(template)-1+fine_lags]/energy_samples
        fine_best = int(np.argmax(abs(fine_fits)))
        fine_h = fine_fits[fine_best]
        fine_power = max(0.,float(abs(fine_h)**2-variance_h))
        fine_cn0 = fine_power*template_energy_seconds/useful_seconds/n0
        fine_nc = nc_interval(float(2*abs(fine_h)**2/variance_h),.05/len(fine_lags))
        fine_interval = [10*math.log10(max(x*factor,1e-300)) for x in fine_nc]
        row['posthoc_snr'] = dict(selected_public_arrival_seconds=float(lags[best]/fs),
            complex_gain_real=float(fit.real),complex_gain_imag=float(fit.imag),
            fitted_voltage_gain_relative_to_DAC=float(abs(fit)/spec['transmit_gain']),
            known_noise_complex_gain_variance=variance_h,
            selected_public_candidates=len(lags),
            noise_bias_subtracted_from_coefficient_power=variance_h,
            native_source_energy_seconds=template_energy_seconds,
            native_useful_seconds=useful_seconds,
            estimated_received_signal_energy_fs_squared_seconds=rx_energy,
            estimated_received_signal_power_fs_squared=rx_power,
            estimated_cn0_db_hz=10*math.log10(cn0),
            fitted_coefficient_conditional_95_percent_simultaneous_cn0_interval_db_hz=interval,
            fine_lag_diagnostic=dict(arrival_seconds=float(fine_lags[fine_best]/fs),
                measurement_only_candidates=len(fine_lags),
                fitted_voltage_gain_relative_to_DAC=float(abs(fine_h)/spec['transmit_gain']),
                estimated_cn0_db_hz=10*math.log10(fine_cn0),
                grid_mismatch_component_db=10*math.log10(fine_cn0/cn0),
                conditional_95_percent_simultaneous_cn0_interval_db_hz=fine_interval,
                scope='Additional posthoc sample-spaced lag measurement, not a receiver/admission bank. Interval has the same explicit conditional limits and includes selection over these fixed fine lag atoms.'),
            scope='Posthoc known-bit fixed-public-lag matched component. Interval assumes known independent measured N0, proper Gaussian noise after analytic projection and exact waveform; PSD estimation error, phase drift, filtering/channel mismatch and physical-model uncertainty are not included. Selection covered only across the 32 fixed public lag atoms. This is not a calibrated physical C/N0 confidence interval or admission input.')
        rows.append(row)
    child_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    report = dict(schema='triad-physical-admission-posthoc-energy-v1',
        source_sha256=sha(__file__), adc_rate_hz=fs_adc,
        noise_reference_sha256=sha(noise_path),
        noise_reference='independent full-duration no-DATA cable run with same 6000-Hz logical playback / negotiated 44100-Hz DAC path',
        measured_independent_noise_density_one_sided_fs_squared_per_hz=n0,
        noise_snr_estimate_interval_seconds=[2,noise_seconds-2],
        band_hz=[1575,1875], results=rows,
        wall_seconds=time.perf_counter()-start,python_cpu_seconds=time.process_time()-cpu,
        child_cpu_seconds=child_after.ru_utime+child_after.ru_stime-children.ru_utime-children.ru_stime,
        scope='Posthoc evaluation only; all admission settings and decisions were frozen beforehand.')
    (OUT/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()

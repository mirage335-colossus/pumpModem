import json,sys
from pathlib import Path
sys.path.insert(0,'tools')
from triad_continuous import parser,NativeStream
from triad_physical_run import collect_binding,observation_geometry
from triad_physical_noise_profile import prepare
out=Path('local-evidence/triad-physical-admission')
bank=dict(coordinates=[[0,1+.004*k,0,0] for k in range(32)],taps=[[0,0]],projection={'required_bands_hz':[[-150,150]]})
(out/'bank.json').write_text(json.dumps(bank,indent=2)+'\n')
rx=['--bank',str(out/'bank.json'),'--physical-noise-profile',str(out/'profile.json'),'--fixed-gain','.00012','--coherences','.5,inf','--device','hw:1,0','--chunk-samples','4096']
native=['--case','hf','--sample-rate','6000','--rate','36','--added-symbols','10','--seconds','32','--key-seed','73005','--epoch','1793850000','--spread-preset','none','--selective-perturbation','off','--base-oscillator','gpsdo-ocxo','--shift-oscillator','gpsdo-ocxo','--oscillator-effects','off','--arrival-seconds','0','--helper','off']
spec=dict(receiver_arguments=rx,native_arguments=native,transmit_gain=.00012,background_noise_db=40.,play_after_seconds=1.)
(out/'spec.json').write_text(json.dumps(spec,indent=2)+'\n')
a=parser().parse_args([*rx,'--mode','receive','--report',str(out/'unused.json')]);a.follow_system_clock='continuous'
binding=collect_binding(a,dict(hardware_rate_hz=48000,hardware_channels=2,selected_channel=0,operating_condition='ALC257 headphone-to-microphone cable; full-DAC temporary-key AES noise at 40 dB below full scale; unchanged mixer; no Helper or other transmission'))
s=NativeStream(a.native,native,kind='emitted');g=observation_geometry(a,s.descriptor,bank,48000);s.close()
geometry={k:g[k] for k in ('block_samples','data_if_hz','required_bands_hz','fixed_gain')};geometry.update(sample_rate_hz=48000,maximum_capture_seconds=90.)
r=prepare(out/'aes40-raw.f32',out/'aes40.json',binding=binding,geometry=geometry,variance_proxy=1e-4,trim_seconds=0.,assumptions=['Complete projected zero-mean real ADC noise has global joint sub-Gaussian proxy 1e-4 times identity, including cross-block dependence; constant DC is excluded by exact projection.','Noise spectrum and higher-order joint behavior remain bounded by this engineering envelope during the entire capture. Finite PSD/tail tests do not prove this future assumption.','Controlled loopback, unchanged mixer and hardware, no deterministic non-DC interference, no clipping or discontinuity. AES40 setting is an operating condition, not inferred from payload.'])
with (out/'preparation.json').open('x') as f:json.dump(r,f,indent=2)
print(json.dumps(dict(geometry=g,binding=binding,checks=r['calibration_checks']),indent=2))

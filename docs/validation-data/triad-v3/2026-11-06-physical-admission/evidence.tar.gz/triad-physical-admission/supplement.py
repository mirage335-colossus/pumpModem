import hashlib,json,sys,copy
from pathlib import Path
sys.path.insert(0,'tools')
from triad_physical_qualification import playback_receipt
from triad_physical_admission import validate_profile,physical_decision
from triad_physical_run import collect_binding
from triad_continuous import parser
p=Path('local-evidence/triad-physical-admission');original=json.load(open(p/'profile.json'));profile=copy.deepcopy(original)
profile['binding']['allowed_noise_dac_rates_hz']=[44100,48000]
supplement=json.load(open(p/'null-noise-validation.json'))
assert all(x['passed'] for x in supplement['checks'])
profile['qualification']['supplemental_noise_dac_validation']=dict(original_profile_sha256=hashlib.sha256((p/'profile.json').read_bytes()).hexdigest(),**supplement,
 measured_noise_dac_hz=44100,adc_hz=48000,note='Posthoc supplemental scope check against unchanged prospectively frozen variance proxy; this adds a stricter hardware-rate requirement. Scores, priors and thresholds were not refitted. Original DATA reports and preparation remain intact.')
profile['qualification']['checks'] += [dict(name='supplemental_44100_dac:'+c['name'],passed=c['passed']) for c in supplement['checks']]
profile['null_model']['assumptions'].append('During controlled cable use, allowed full-rate noise DACs are 44100 or 48000 Hz. The duplex driver verifies actual playback; a generic remote receiver cannot observe this and relies on the operator-supplied physical profile.')
(p/'profile-dac-rates.json').write_text(json.dumps(profile,indent=2)+'\n')
spec=json.load(open(p/'spec.json'));spec['receiver_arguments']=[str(p/'profile-dac-rates.json') if x==str(p/'profile.json') else x for x in spec['receiver_arguments']]
(p/'spec-qualified.json').write_text(json.dumps(spec,indent=2)+'\n')
a=parser().parse_args([*spec['receiver_arguments'],'--mode','receive','--report',str(p/'unused.json')]);a.follow_system_clock='continuous'
binding=collect_binding(a,profile['binding']);summary=[]
for name in ['bit0','bit1','null']:
 r=json.load(open(p/name/'result.json'));g=r['observation_geometry'];v=validate_profile(profile,binding,**{k:x for k,x in g.items() if k!='samples'})
 play=playback_receipt(p/name/'playback.log',frames=r['transmitted_samples'],sample_rate=6000,noise_db=40,signal_peak=r['transmitted_signal_peak'],hardware_rates=[44100,48000])
 decision=physical_decision(r['receiver']['bit_scores'],complete=r['complete'],profile=v,log_threshold=r['admission_policy']['log_e_threshold'])
 assert decision['admitted']==r['admitted'] and decision['log_e']==r['log_e']
 summary.append(dict(name=name,original_report_sha256=hashlib.sha256((p/name/'result.json').read_bytes()).hexdigest(),noise_dac_hz=play['background_noise']['sample_rate_hz'],same_score_same_decision=True,**decision))
(p/'supplemental-compatibility.json').write_text(json.dumps(dict(scope='Metadata/operating-scope compatibility verification using retained scores; not new receptions or independent trials.',trials=summary),indent=2)+'\n')
print(json.dumps([dict(name=x['name'],noise_dac_hz=x['noise_dac_hz'],admitted=x['admitted'],log_e=x['log_e']) for x in summary],indent=2))

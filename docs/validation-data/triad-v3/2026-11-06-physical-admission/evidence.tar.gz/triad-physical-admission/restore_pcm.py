"""Restore exact native float32 PCM; verifies retained hashes."""
import hashlib,json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
for row in json.loads((root/'pcm-manifest.json').read_text()):
 raw=(root/row['integer_path']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['integer_sha256']
 value=(np.frombuffer(raw,dtype='<i2').astype('<f4')/np.float32(row['scale'])).astype('<f4').tobytes()
 assert hashlib.sha256(value).hexdigest()==row['float_sha256']
 target=root/row['float_path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
print('Restored and verified',len(json.loads((root/'pcm-manifest.json').read_text())),'captures')

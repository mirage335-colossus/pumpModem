import sys,json,subprocess
from pathlib import Path
sys.path.insert(0,'tools')
from triad_audio_mapping import MappedCaptureReader
from triad_physical_run import read_receipt
from triad_physical_noise_profile import finalize
p=Path('local-evidence/triad-physical-admission');fs=48000;n=26*fs;audio='build/dev-cli/triad_audio_stream';capture=play=None
with (p/'validation.log').open('x') as log,(p/'validation-play.log').open('x') as plog,(p/'validation-raw.f32').open('xb') as out, (p/'quiet-24s.f32').open('rb') as inp:
 try:
  capture=subprocess.Popen([audio,'--mode','capture','--sample-rate',str(fs),'--frames',str(n),'--device','hw:1,0','--exclusive','--capture-format','adc-v1'],stdout=subprocess.PIPE,stderr=log)
  reader=MappedCaptureReader(capture.stdout);first=0
  while first<n:
   count=min(4096,n-first,fs-first if first<fs else n-first)
   pcm,origin,offsets,rate=reader.read(count);out.write(pcm.astype('<f4').tobytes());first+=count
   if play is None and first>=fs:play=subprocess.Popen([audio,'--mode','play','--sample-rate',str(fs),'--frames',str(24*fs),'--device','hw:1,0','--exclusive','--background-noise-db','40'],stdin=inp,stderr=plog)
  assert capture.wait(timeout=10)==0 and play.wait(timeout=10)==0
 finally:
  for proc in (capture,play):
   if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=3)
(p/'validation.json').write_text(json.dumps(read_receipt(p/'validation.log'),indent=2)+'\n')
r=finalize(p/'preparation.json',p/'validation-raw.f32',p/'validation.json')
(p/'profile.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['qualification'],indent=2))

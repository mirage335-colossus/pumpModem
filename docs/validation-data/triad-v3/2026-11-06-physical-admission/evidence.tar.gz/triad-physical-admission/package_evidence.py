import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
import numpy as np
root=Path.cwd(); p=root/'local-evidence/triad-physical-admission'; stage=root/'local-evidence/physical-admission-package/triad-physical-admission';stage.mkdir(parents=True,exist_ok=True)
manifest=[]
for path in sorted(p.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.name in ['quiet-24s.f32','adc-smoke.mapped']:continue
 relative=path.relative_to(p);dest=stage/relative;dest.parent.mkdir(parents=True,exist_ok=True)
 if path.suffix=='.f32':
  x=np.fromfile(path,dtype='<f4');ints=np.rint(x.astype(np.float64)*32768).astype('<i2');recovered=(ints.astype('<f4')/np.float32(32768)).astype('<f4')
  if not np.array_equal(x,recovered):raise RuntimeError('not losslessly S16 '+str(path))
  dest=dest.with_suffix('.s16');ints.tofile(dest)
  manifest.append(dict(float_path=str(relative),integer_path=str(dest.relative_to(stage)),samples=len(x),float_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),integer_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),scale=32768))
 else:shutil.copy2(path,dest)
(stage/'pcm-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(stage/'restore_pcm.py').write_text('''"""Restore exact native float32 PCM; verifies retained hashes."""
import hashlib,json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
for row in json.loads((root/'pcm-manifest.json').read_text()):
 raw=(root/row['integer_path']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['integer_sha256']
 value=(np.frombuffer(raw,dtype='<i2').astype('<f4')/np.float32(row['scale'])).astype('<f4').tobytes()
 assert hashlib.sha256(value).hexdigest()==row['float_sha256']
 target=root/row['float_path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
print('Restored and verified',len(json.loads((root/'pcm-manifest.json').read_text())),'captures')
''')
files=['tools/triad_physical_admission.py','tools/triad_physical_noise_profile.py','tools/triad_physical_run.py','tools/triad_physical_qualification.py','tools/triad_continuous.py','tools/triad-audio-stream.cpp','tools/triad_audio_mapping.py','tools/triad_tracking_basis.py','tools/triad_gaussian_state.py','tools/triad_operational_admission.py','tests/test_triad_audio_stream.py',*map(str,Path('tests').glob('test_triad_physical*.py'))]
identities={}
for name in files:
 dest=stage/'source-snapshot'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dest);identities[name]=hashlib.sha256(dest.read_bytes()).hexdigest()
(stage/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
(stage/'tracked-source.patch').write_bytes(subprocess.check_output(['git','diff','--','tools/triad_continuous.py','tools/triad-audio-stream.cpp','tests/test_triad_audio_stream.py']))
destination=root/'docs/validation-data/triad-v3/2026-11-06-physical-admission';archive=destination/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:tar.add(stage,arcname=stage.name)
(destination/'evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
print('archive bytes',archive.stat().st_size,'PCM captures',len(manifest))

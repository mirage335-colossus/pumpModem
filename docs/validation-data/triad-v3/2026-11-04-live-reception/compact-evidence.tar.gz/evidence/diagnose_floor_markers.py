#!/usr/bin/env python3
import json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
import triad_live_model as model
HERE=Path(__file__).resolve().parent
p=json.loads((HERE/'floor/plan.json').read_text());x=np.memmap(HERE/'floor/stimulus.f32',dtype='<f4',mode='r');out={}
for folder in ['floor','floor-repeat']:
 start=time.perf_counter();y=np.memmap(HERE/folder/'capture.f32',dtype='<f4',mode='r');delay=None;rows=[]
 for r in p['records']:
  off,n=r['offset'],r['samples'];tx=np.asarray(x[off:off+n],dtype=np.float64)
  a=max(0,off+int(delay or 0)-48000);b=min(len(y),off+int(delay or 0)+n+5*48000)
  rx=np.asarray(y[a:b],dtype=np.float64);local=[]
  for marker in r['markers']['markers']:
   v=model._marker_delay(tx,rx,48000,marker,expected=None if not local else local[0]['delay_samples']);local.append(v)
  values=[a+v['delay_samples']-off for v in local];delay=values[-1]
  rows.append(dict(index=r['index'],global_delay_samples=values,within_record_delay_change_samples=values[1]-values[0],marker_correlation=[v['squared_correlation'] for v in local]))
 out[folder]=dict(rows=rows,wall_seconds=time.perf_counter()-start,minimum_delay=min(z for r in rows for z in r['global_delay_samples']),maximum_delay=max(z for r in rows for z in r['global_delay_samples']),scope='public marker timing diagnostic on invalid captures, not reception/admission qualification')
 print(folder,out[folder]['minimum_delay'],out[folder]['maximum_delay'],out[folder]['wall_seconds'])
(HERE/'floor-marker-diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')

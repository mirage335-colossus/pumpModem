#!/usr/bin/env python3
"""Package compact scientific receipts and source; keep raw PCM local."""
import gzip,hashlib,io,json,tarfile,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
DEST=ROOT/'docs/validation-data/triad-v3/2026-11-04-live-reception'
archive=DEST/'compact-evidence.tar.gz'
if archive.exists():raise FileExistsError(archive)
files={}
# No raw PCM, native basis arrays or recordings are copied into Git.
for p in HERE.rglob('*'):
 if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
 if p.suffix in ('.json','.py','.log','.txt','.md','.npz'):
  files['evidence/'+p.relative_to(HERE).as_posix()]=p
pilot=ROOT/'local-evidence/triad-live-margin-preparer-smoke'
for name in ['plan.json','capture.json']:
 files['evidence/pilot/'+name]=pilot/name
for name in ['tools/triad_live_margins.py','tools/triad_live_receiver.py','tools/triad_live_model.py','tools/triad_live_waveforms.py','tools/triad_fft_acquire.py','tools/triad_group_acquire.py','tools/triad_gaussian_window.py','tools/triad_noise_likelihood.py','tools/triad_gaussian_state.py','tools/triad_state_workspace.py','tools/triad_audio_capture.cpp','tools/triad-long.cpp','src/audio.cpp','include/datapump/audio.hpp','tests/test_triad_live_receiver.py','tests/test_triad_live_margins.py']:
 files['snapshot/'+name]=ROOT/name
for pattern in ['src/triad*','include/datapump/triad*','src/channel_*.hpp']:
 for p in ROOT.glob(pattern):
  if p.is_file():files['snapshot/'+p.relative_to(ROOT).as_posix()]=p
entries=[]
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(files.items()):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'format':'triad-live-reception-evidence-v1','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':entries,'raw_pcm_scope':'Original physical PCM, exact full stimuli and native/public array fixtures remain in ignored local-evidence/triad-live-reception-001 and pilot source directory; filenames/hashes and recipe metadata are retained, but these large files are not embedded. Historical PCM cannot be regenerated from a seed; new hardware records are independent repetitions.','source_head_at_packaging':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
(DEST/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'audio-profile-upper-edge.json').write_bytes((HERE/'upper-edge/profile.json').read_bytes())
print(json.dumps({k:v for k,v in manifest.items() if k not in ('entries','raw_pcm_scope')}));print('entries',len(entries))

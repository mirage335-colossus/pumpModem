#!/usr/bin/env python3
"""Recount retained actual cable outcomes; no refitting or receiver changes."""
import hashlib,json,math
from pathlib import Path
import numpy as np
from scipy.stats import beta
HERE=Path(__file__).resolve().parent

def cp(k,n):
 return [0. if k==0 else float(beta.ppf(.025,k,n-k+1)),1. if k==n else float(beta.ppf(.975,k+1,n-k))]

def analyze(name):
 p=HERE/(name+'-analysis')/'results.json'; r=json.loads(p.read_text()); rows=r['rows']; pairs=[]
 for a in rows:
  if a['kind']!='physical' or a['calibration_record']: continue
  b=next(x for x in rows if x['kind']=='simulated' and x['index']==a['index'] and x['case']==a['case'])
  pairs.append({'case':a['case'],'index':a['index'],'truth':a['truth'],'gain':a['gain'],'cn0_db_hz':a['cn0_db_hz'],'physical':a.get('classification'),'simulated':b.get('classification'),'bit_disagrees':a['bit']!=b['bit'],'admission_disagrees':a.get('decision',{}).get('accepted')!=b.get('decision',{}).get('accepted'),'score_difference':a['score']-b['score']})
 summaries=[]
 for case in sorted(set(x['case'] for x in pairs)):
  for null in [False,True]:
   s=[x for x in pairs if x['case']==case and (x['truth'] is None)==null]
   if not s:continue
   d=sum(x['admission_disagrees'] for x in s); bit=sum(x['bit_disagrees'] for x in s)
   summaries.append({'case':case,'null':null,'pairs':len(s),'admission_disagreements':d,'admission_disagreement_interval95':cp(d,len(s)),'candidate_bit_disagreements':bit,'score_difference_percentiles':np.percentile([x['score_difference'] for x in s],[0,50,100]).tolist()})
 return {'source_result_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'analysis_wall_seconds':r['wall_seconds'],'outcomes':r['summaries'],'paired_summary':summaries,'pairs':pairs}

result={name:analyze(name) for name in ['validation','stress']}
result['floor']={'status':'unqualified','admission_results':None,
 'reason':'Both physical capture receipts report playback discontinuity. No floor receiver scoring performed; failed records excluded.',
 'capture_receipts':{name:json.loads((HERE/name/'capture.json').read_text()) for name in ['floor','floor-repeat']},
 'marker_diagnosis':json.loads((HERE/'floor-marker-diagnosis.json').read_text())}
result['interval_scope']='Pointwise Clopper-Pearson under independent Bernoulli trial assumptions; repeated same codec and shared null reuse preclude a claim of unconditional independent hardware populations. No suite-wide or rare-operational guarantee.'
(HERE/'comparison-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for stage,r in result.items():
 if not isinstance(r,dict):continue
 print(stage)
 for x in r.get('outcomes',[]):
  print(x['case'],x['kind'],x['cn0_db_hz'] if x['cn0_db_hz'] is not None else x['gain'],x['trials'],x['counts'])

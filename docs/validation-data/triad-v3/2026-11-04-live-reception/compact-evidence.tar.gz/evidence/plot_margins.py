#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
DOC=HERE.parents[1]/'docs/validation-data/triad-v3/2026-11-04-live-reception'
r=json.loads((HERE/'validation-analysis/results.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(11,4),sharey=True)
for ax,case,title in zip(axes,['baseline','edge','spreading'],['Rate 3600 · center 1725 Hz','Rate 24000 · center 15500 Hz','Rate 36 · Added ×100']):
 for kind,shift,color,marker in [('physical',0.,'#1764ab','o'),('simulated',0.,'#d37a22','s')]:
  rows=sorted([x for x in r['summaries'] if x['case']==case and x['kind']==kind and x['cn0_db_hz'] is not None],key=lambda x:x['cn0_db_hz'])
  x=np.array([a['cn0_db_hz'] for a in rows]); y=np.array([a['counts']['correct_admission']/a['trials'] for a in rows]); ci=np.array([a['intervals_95']['correct_admission'] for a in rows])
  ax.plot(x+shift,y,marker=marker,color=color,label='Physical cable' if kind=='physical' else 'Original simulation',mfc='none' if kind=='simulated' else color,lw=1.3,ls='--' if kind=='simulated' else '-')
  if kind=='physical': ax.errorbar(x+shift,y,yerr=np.array([y-ci[:,0],ci[:,1]-y]),fmt='none',ecolor=color,alpha=.5,capsize=3)
 ax.set_title(title,fontsize=10); ax.set_xticks([-4,-1,2,5]); ax.set_ylim(-.05,1.05); ax.grid(alpha=.18);ax.set_xlabel('Nominal C/N₀ (dB-Hz)')
axes[0].set_ylabel('Correct admissions / transmissions')
axes[0].legend(loc='upper left',fontsize=8)
fig.suptitle('Complete physical transmissions vs matched simulation',fontsize=13)
fig.text(.5,.02,'Six trials per level; pointwise 95% binomial intervals under stated assumptions. Experimental per-capture rank gate.\nShared null admissions: 2/32, 3/32, 2/32. One edge wrong-bit admission at −4 dB-Hz. No rare-error qualification.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.12,1,.94));fig.savefig(DOC/'reception-margins.png',dpi=160);plt.close(fig)

#!/usr/bin/env python3
"""Stream hashes of retained raw inputs and record the bounded underrun audit."""
import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PILOT = ROOT / "local-evidence/triad-live-margin-preparer-smoke"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    started = time.perf_counter()
    suffixes = {".f32", ".c64", ".c128", ".npy", ".u8", ".npz"}
    entries = []
    for base in (HERE, PILOT):
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.is_symlink() or path.suffix not in suffixes:
                continue
            before = path.stat()
            sha = digest(path)
            after = path.stat()
            if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
                raise RuntimeError(f"input changed during hashing: {path}")
            if path.name in ("capture.f32", "provider.f32"):
                role = "recorded PCM; failed/incomplete status remains in adjacent capture receipt"
            elif path.name == "stimulus.f32":
                role = "exact prepared DAC stimulus"
            elif "basis" in path.name:
                role = "native or audio-profile-transformed public template array"
            elif path.name.startswith("signal"):
                role = "native complete waveform or bridged source signal array"
            else:
                role = "retained numerical diagnostic array"
            entries.append(dict(path=path.relative_to(ROOT).as_posix(), bytes=before.st_size,
                sha256=sha, role=role, compact_archive_inclusion=path.suffix == ".npz"))
    write(HERE / "raw-input-inventory.json", dict(schema="triad-live-raw-input-inventory-v1",
        roots=[HERE.relative_to(ROOT).as_posix(), PILOT.relative_to(ROOT).as_posix()],
        entries=entries, files=len(entries), total_bytes=sum(e["bytes"] for e in entries),
        hash_wall_seconds=time.perf_counter() - started,
        scope="Hashes were streamed without decoding or expanding arrays. Raw PCM/stimuli/native templates remain local; compact .npz diagnostics are also packaged. File presence never establishes a successful physical capture; adjacent receipts and maintained study classify incomplete records. Physical PCM is irreplaceable historical evidence, not regenerable from seeds."))
    diagnosis = read(HERE / "floor-marker-diagnosis.json")
    audio_path = ROOT / "src/audio.cpp"
    capture_source = ROOT / "tools/triad_audio_capture.cpp"
    audio = audio_path.read_text().splitlines()
    native = capture_source.read_text().splitlines()
    def excerpt(lines, needle, before=0, after=0):
        match = [i for i, line in enumerate(lines) if needle in line]
        if len(match) != 1:
            raise ValueError(f"expected unique source anchor {needle}")
        i = match[0]
        lo, hi = max(0, i-before), min(len(lines), i+after+1)
        return dict(start_line=lo+1, end_line=hi, text="\n".join(lines[lo:hi]))
    observations = []
    for name in ("floor", "floor-repeat"):
        receipt_path = HERE / name / "capture.json"
        receipt = read(receipt_path)
        jumps = [r for r in diagnosis[name]["rows"] if abs(r["within_record_delay_change_samples"]) > .5]
        observations.append(dict(capture=name, receipt_sha256=digest(receipt_path), status=receipt["status"],
            failure=receipt["failure"], discontinuity=receipt["discontinuity"],
            peak=receipt["capture"]["logical_peak"],
            marker_steps=[dict(record_index=r["index"], change_samples=r["within_record_delay_change_samples"],
                change_ms=1000*r["within_record_delay_change_samples"]/48000,
                correlation=r["marker_correlation"]) for r in jumps],
            interpretation="These captures remain excluded from receiver-margin denominators; public marker steps independently corroborate playback timeline discontinuity."))
    write(HERE / "floor-underrun-source-audit.json", dict(schema="triad-live-underrun-source-audit-v1",
        observations=observations,
        sources={audio_path.relative_to(ROOT).as_posix():digest(audio_path),
                 capture_source.relative_to(ROOT).as_posix():digest(capture_source)},
        marker_diagnosis_sha256=digest(HERE / "floor-marker-diagnosis.json"),
        source_evidence={
            "untimed_vs_utc_route":excerpt(audio, "const bool timed=options && options->follow_system_clock;", before=0, after=2),
            "playback_chunk":excerpt(audio, "std::vector<std::int16_t> block(chunk_limit*stream.channels);", before=1, after=1) if sum("std::vector<std::int16_t> block(chunk_limit*stream.channels);" in line for line in audio)==1 else excerpt(audio, "std::vector<float> samples(chunk_limit);", before=2, after=0),
            "ordinary_alsa_recovery_and_notice":excerpt(audio, "if(timed || ++failures>8 || api.recover", before=1, after=6),
            "native_receipt_latches_playback_gap":excerpt(native, "playback_options.playback_discontinuity =", before=2, after=8)},
        interpretation=[
            "At the reported 48000 hardware frames/s, min(4096, hardware_rate/20) is a 2400-frame/50-ms source/write chunk. This is not a measurement of hardware queue occupancy or an underrun timestamp.",
            "Ordinary ALSA playback attempts recovery after a negative write and reports EPIPE as output underrun through the installed callback; the native recorder latches this and marks the complete capture invalid for continuity evidence.",
            "The callback records a boolean and first reason, not an event count. Marker steps identify at least one affected record in floor and two in floor-repeat; they must not be relabeled exact counted driver-underrun events.",
            "These observations do not determine whether scheduling, allocator/page faults, provider/device behavior or another stall caused starvation. No kernel scheduling trace or per-write latency trace was retained. No claim of fundamentally unmodelable analog behavior is warranted.",
            "No audio source code was changed, no hardware rerun was performed, and no invalid-capture prefix was admitted into reception success statistics by this audit."] ))
    print(json.dumps(dict(raw_files=len(entries), raw_bytes=sum(e["bytes"] for e in entries), wall_seconds=time.perf_counter()-started)))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Evaluation only: frozen-model response on first calibration null record."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy import signal
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_model as model
HERE=Path(__file__).resolve().parent
src=HERE/'calibration-002'; plan=json.loads((src/'plan.json').read_text()); r=plan['records'][0]
x=np.fromfile(src/'stimulus.f32',dtype='<f4',count=r['samples'])
y=np.fromfile(src/'capture.f32',dtype='<f4',count=r['samples']+2*48000)
a,valid,alignment=model.align_capture(x,y,48000,r['markers']['markers'])
p=json.loads((src/'profile.json').read_text()); pred=model.simulate_audio_profile(x,p,include_noise=False,production_s16=True)
pay=r['markers']['payload']; sl=slice(pay['start']+4800,pay['start']+pay['samples']-4800)
a=a[sl]; pred=pred[sl]; xx=model.quantize_production_playback(x)[sl]
f,px=signal.welch(xx,48000,nperseg=16384)
_,hxy=signal.csd(xx,a,48000,nperseg=16384)
_,hxp=signal.csd(xx,pred,48000,nperseg=16384)
_,py=signal.welch(a,48000,nperseg=16384)
_,pe=signal.welch(a-pred,48000,nperseg=16384)
h=hxy/np.maximum(px,1e-30); hp=hxp/np.maximum(px,1e-30)
err=h/hp; gain=20*np.log10(np.maximum(abs(err),1e-30)); phase=np.angle(err)
bands=[]
for lo,hi in [(600,2850),(8000,23000),(8000,16000),(16000,20000),(20000,23000),(23000,23900)]:
 q=(f>=lo)&(f<=hi)
 bands.append(dict(hz=[lo,hi],median_gain_error_db=float(np.median(gain[q])),median_phase_error_rad=float(np.median(phase[q])),residual_to_actual_db=float(10*np.log10(pe[q].sum()/py[q].sum())),mean_adc_noise_psd=float(np.mean(py[q]))))
out=dict(record=0,bands=bands,alignment=alignment,profile_refitted=False,scope='independent null diagnostic; matched complete transmitted broadband-noise realization, first calibration record; finite Welch estimates, not confidence bounds; no receiver/template update',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(HERE/'noise-response.json').write_text(json.dumps(out,indent=2)+'\n')
np.savez_compressed(HERE/'noise-response.npz',frequency_hz=f,gain_error_db=gain,phase_error_rad=phase,adc_psd=py,residual_psd=pe)
print(json.dumps(bands,indent=2))

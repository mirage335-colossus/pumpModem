#!/usr/bin/env python3
"""Post-decision clean-shape diagnosis only; never a practical receiver input."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['OMP_NUM_THREADS']='2'
import sys,time,json,math,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_margins as margins
import triad_live_model as model

start=time.perf_counter()
root=ROOT/'local-evidence/triad-live-reception-001'
src=root/'stress-screen'; previous=root/'stress-analysis'
out=Path(__file__).parent
read=lambda p: json.loads(p.read_text())
plan=read(src/'plan.json'); profile=read(src/'profile.json'); original=read(previous/'results.json')
fd=Path(plan['fixtures_directory'])/'stress'; f=read(fd/'fixture.json')
margins.verify_fixture(fd,f)
tx=np.memmap(src/'stimulus.f32',dtype='<f4',mode='r')
rx=np.memmap(src/'capture.f32',dtype='<f4',mode='r')
assert margins.digest(src/'stimulus.f32')==plan['stimulus_sha256']
assert margins.digest(src/'capture.f32')==original['capture_sha256']
record=plan['records'][3]
assert record['truth']==0
# Reconstruct the exact local capture aperture from retained marker fits.
delay=original['alignments'][0]['offset_samples']
for r,alignment in zip(plan['records'][1:3],original['alignments'][1:3]):
    a=max(0,int(r['offset']+delay-margins.FS))
    delay=a+alignment['offset_samples']-r['offset']
offset,n=record['offset'],record['samples']
a=max(0,int(offset+delay-margins.FS)); b=min(len(rx),int(offset+delay+n+margins.FS))
chunk=np.asarray(tx[offset:offset+n])
aligned,mask,alignment=model.align_capture(chunk,np.asarray(rx[a:b]),margins.FS,record['markers']['markers'])
assert abs(alignment['offset_samples']-original['alignments'][3]['offset_samples'])<1e-7
state=model.AudioModelState(profile)
for r in plan['records']:
    seg=np.asarray(tx[r['offset']:r['offset']+r['samples']])
    predicted=state.process(model.quantize_production_playback(seg))
    predicted+=margins.fixed_noise(profile,r['samples'],r['noise_seed']+991000)
pa=record['markers']['payload']['start']; pb=pa+f['payload_audio_samples']
physical,valid,_=margins.convert(aligned[pa:pb],f)
simulated,_,_=margins.convert(predicted[pa:pb],f)
assert mask[pa:pb].all()
# Oracle diagnostics use complete clean propagated waveforms generated with
# the same physical channel seed for each bit. Actual measured observations
# and all previous practical decisions remain untouched.
clean=[]
for bit in (0,1):
    s=np.fromfile(fd/f'signal-{bit}.f32',dtype='<f4')
    audio=np.zeros(n)
    audio[pa:pa+len(s)]=record['gain']*s
    # Linear clean waveform, deliberately no nonlinear per-column quantizer.
    filtered=model.apply_audio_profile(audio,profile)
    z,_,_=margins.convert(filtered[pa:pb],f)
    clean.append(np.asarray(z,np.complex128))
bank=np.load(fd/'basis.npy')
fs=f['receiver_sample_rate']; times=np.arange(f['receiver_samples'])/fs
old=read(previous/'record-0003-stress.json')
best=old['scores']['physical']['best_group_public_parameters']
chosen_lag=round((best['arrival_seconds']-f['public_key']['arrival_seconds'])*fs)
def shifted_basis(lag,frequency):
    x=np.zeros_like(bank)
    if lag: x[:,lag:,:]=bank[:,:-lag,:]
    else: x[:]=bank
    x*=np.exp(2j*np.pi*frequency*times)[None,:,None]
    return x
def projection(y,A):
    A=np.asarray(A[valid],np.complex128); y=np.asarray(y[valid],np.complex128)
    u,s,_=np.linalg.svd(A,full_matrices=False)
    keep=s>s[0]*1e-10
    z=u[:,keep].conj().T@y
    e=float(np.vdot(y,y).real); retained=float(np.vdot(z,z).real)
    return dict(rank=int(keep.sum()),retained_fraction=retained/e,energy=e,
                retained_energy=retained,representation_loss_db=-10*math.log10(max(retained/e,1e-300)))
public=[]; observed_public=[]
for label,lag,frequency in [('nominal',len(f['lags'])//2,0.),('previous_practical_winner',chosen_lag,best['frequency_hz'])]:
    basis=shifted_basis(lag,frequency)
    for kind,y in [('physical',physical),('simulated',simulated)]:
        observed_public.append(dict(group=label,kind=kind,lag_samples=lag,frequency_hz=frequency,
            projections_by_candidate_bit=[projection(y,basis[c]) for c in (0,1)]))
    for bit in (0,1):
        public.append(dict(group=label,lag_samples=lag,frequency_hz=frequency,clean_bit=bit,
            projections_by_candidate_bit=[projection(clean[bit],basis[c]) for c in (0,1)],
            union=projection(clean[bit],basis.transpose(1,0,2).reshape(len(times),4))))
oracle={}
for kind,y in [('physical',physical),('simulated',simulated)]:
    # Unknown complex gain but exact hidden channel shape. This unwhitened
    # Euclidean projection is a diagnostic, not a calibrated colored-noise LR.
    scores=[projection(y,z[:,None]) for z in clean]
    matched=[s['retained_energy'] for s in scores]
    oracle[kind]=dict(projections=scores,bit=int(np.argmax(matched)),
        retained_energy_difference_true_minus_other=matched[0]-matched[1],
        scope='hidden complete clean channel shape, public marker alignment, fitted common complex gain; unwhitened diagnostic only, no admission')
result=dict(schema='triad-live-stress-clean-diagnosis-v1',record_index=3,truth=0,
    public_projections=public,observed_public_projections=observed_public,known_channel_shape_diagnostic=oracle,
    clean_codeword_cross_projection=projection(clean[0],clean[1][:,None]),
    alignment=alignment,physical_aperture_samples=[a,b],
    source_sha256={p.name:margins.digest(p) for p in [Path(__file__),ROOT/'tools/triad_live_margins.py',ROOT/'tools/triad_live_model.py',ROOT/'tools/triad_live_waveforms.py']},
    input_sha256={str(p.relative_to(root)):margins.digest(p) for p in [src/'plan.json',src/'profile.json',src/'stimulus.f32',src/'capture.f32',fd/'basis.npy',fd/'signal-0.f32',fd/'signal-1.f32',previous/'results.json']},
    limitations=['One selected failure is diagnosis, not a reliability estimate.','No whitening, optimal known-channel likelihood or calibrated oracle admission is claimed.','Clean hidden propagation waveforms are evaluation-only and must never enter practical acquisition.','No gate, practical basis, or model was changed.','Physical and modeled observations share transmitted noise; agreement is not independent reception evidence.'],
    wall_seconds=time.perf_counter()-start)
margins.write_json(out/'results.json',result)
print(json.dumps(dict(public=public,oracle=oracle,wall_seconds=result['wall_seconds']),indent=2))

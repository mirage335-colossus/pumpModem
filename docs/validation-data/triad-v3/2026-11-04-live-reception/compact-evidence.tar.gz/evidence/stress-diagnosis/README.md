# Selected stress failure: post-decision clean-shape diagnosis

Run from the repository root:

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 /tmp/triad-weak-env/bin/python local-evidence/triad-live-reception-001/stress-diagnosis/diagnose.py
```

The final calculation took 2.416 seconds. `results.json` binds script,
preprocessing, public basis, clean propagated sources, original observations,
plan, profile and prior results by SHA-256. The script reconstructs the original
record-3 physical aperture using retained earlier public-marker alignments,
reruns that record's two public marker measurements, and checks their offset
against the frozen result. Simulated audio is reconstructed with continuous
filter state across all four records and the original independent residual
seeds. No device access, threshold adjustment or practical receiver change occurs.

Record 3 transmits bit 0 at nominal +2 dB-Hz with the 21-ms / 90-Hz two-ray
channel and Each65 selective modulation. The existing practical receiver
admitted bit 1 on both physical and simulated observations. Clean channel
realizations below are **simulation truth used only after that decision**.

| Diagnostic | Result |
|---|---:|
| Clean bit 0 represented by its nominal static two-ray public basis | 70.4086% (1.524 dB representation loss) |
| Clean bit 1 represented by its nominal static two-ray public basis | 70.3589% (1.527 dB loss) |
| Clean bit 0 represented by nominal wrong-bit public basis | 0.0239% |
| Clean bit 0 represented by nominal union of both public bases | 70.4113% |
| Clean bit 0 represented by its public basis at previously selected wrong winner's lag/CFO | 1.2940% |
| Clean bit 0 projected onto complete hidden-channel bit 1 waveform | 0.0320% |

The practical winning nuisance point is lag 53 / +0.03 Hz, compared with
nominal lag 48 / 0 Hz. At this selected point, raw explained observation energy
is 0.00340534 for the wrong bit and 0.00025882 for the true bit on physical
data. At the nominal public point those energies are 0.00014790 and
0.00235896 respectively. These are post-selection explanations, not new
decisions or a proposal to prune acquisition to the nominal point.

Using each bit's complete hidden channel-shaped waveform with an independently
fitted common complex gain gives physical explained energies
`[0.00362048, 0.0000897642]` for bits `[0,1]`; matched simulated energies are
`[0.00362689, 0.0000894782]`. Both prefer the true bit. This is an **unwhitened
Euclidean shape diagnostic**, not an optimal colored-noise likelihood, a
calibrated admission or a deployable receiver with access to channel truth.

The selected result therefore exposes a modest static-basis representation
loss and a competing noise-favored acquisition alternative. It does not
demonstrate an enormous irrecoverable waveform loss or an unexplained physical
hardware failure. One selected failure cannot estimate its frequency, separate
the complete contributions of representation, nuisance search and noise, or
establish that a practical replacement receiver will realize the hidden-shape
diagnostic's preference. Physical and simulated observations share transmitted
noise and are not independent reception trials. A null-admission gate alone
does not guarantee correct-bit reception.

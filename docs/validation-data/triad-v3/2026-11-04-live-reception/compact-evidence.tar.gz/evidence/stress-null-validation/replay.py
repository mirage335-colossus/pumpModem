#!/usr/bin/env python3
"""One fixed-gate pass over the already captured 32 independent validation nulls.

No signal record is scored, and no receiver, gate or forward model is changed.
This augments the original validation's missing stress-receiver null evidence.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
import scipy
from scipy.stats import beta
import torch

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import triad_live_margins as campaign
import triad_live_model as model
from triad_live_receiver import EmpiricalReceiver, empirical_decision, evaluate, binomial_interval


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    started = time.perf_counter()
    torch.set_num_threads(2)
    if (HERE / "results.json").exists() or (HERE / "freeze.json").exists():
        raise ValueError("one-pass output already exists; do not overwrite or rerun")
    prepared = BASE / "validation"
    analysis = BASE / "validation-analysis"
    calibration = BASE / "calibration-002"
    gate_path = BASE / "calibration-analysis" / "gates.json"
    fixture_dir = calibration / "fixtures" / "stress"
    plan = read(prepared / "plan.json")
    primary = read(analysis / "results.json")
    calibration_plan = read(calibration / "plan.json")
    profile = read(prepared / "profile.json")
    f = read(fixture_dir / "fixture.json")
    gate = read(gate_path)["stress"]
    if plan["phase"] != "validation" or primary.get("synthetic_only", True):
        raise ValueError("requires completed physical independent validation")
    if campaign.digest(prepared / "plan.json") != primary["plan_sha256"]:
        raise ValueError("primary plan changed")
    if campaign.digest(prepared / "stimulus.f32") != plan["stimulus_sha256"]:
        raise ValueError("validation stimulus changed")
    if campaign.digest(prepared / "profile.json") != primary["profile_copy_sha256"]:
        raise ValueError("original profile changed")
    if plan["profile_sha256"] != f["profile_sha256"] or plan["noise_rms"] != f["noise_rms"]:
        raise ValueError("stress calibration and validation noise/profile conditions differ")
    if campaign.digest(fixture_dir / "fixture.json") != calibration_plan["fixture_json_sha256"]["stress"]:
        raise ValueError("original calibrated stress fixture changed")
    campaign.verify_fixture(fixture_dir, f)
    if campaign.digest(gate_path) != campaign.digest(analysis / "gates.json"):
        raise ValueError("original primary gate package differs from calibration")
    capture_path = prepared / "capture.f32"
    metadata_path = prepared / "capture.json"
    if campaign.digest(capture_path) != primary["capture_sha256"]:
        raise ValueError("physical capture changed")
    if campaign.digest(metadata_path) != primary["capture_metadata_sha256"]:
        raise ValueError("capture receipt changed")
    receipt = read(metadata_path)
    if receipt.get("synthetic_only", False):
        raise ValueError("synthetic receipt cannot establish physical null validation")
    tx = np.memmap(prepared / "stimulus.f32", dtype="<f4", mode="r")
    rx = np.memmap(capture_path, dtype="<f4", mode="r")
    campaign.validate_capture(receipt, len(rx))
    alignments = primary["alignments"]
    if len(alignments) != len(plan["records"]) or any(a["index"] != r["index"] for a, r in zip(alignments, plan["records"])):
        raise ValueError("primary public alignment sequence differs from plan")
    null_indices = [r["index"] for r in plan["records"] if r["case"] is None]
    if len(null_indices) != 32 or null_indices != sorted(null_indices):
        raise ValueError("expected exactly 32 predeclared validation null records in original order")
    for r in plan["records"]:
        if r["case"] is None and (r["truth"] is not None or r["calibration"] or r["gain"] != 0):
            raise ValueError("null record is not an untouched independent holdout")
    _, valid, _ = campaign.convert(np.zeros(f["payload_audio_samples"]), f)
    receiver = EmpiricalReceiver(np.load(fixture_dir / "basis.npy"), f["receiver_sample_rate"], np.asarray(f["lags"]),
        key=f["public_key"], valid=valid, reference_variance=f["reference_variance"],
        frequency_offsets=tuple(f["frequency_offsets_hz"]), precision="fp32",
        preprocessing_identity=json.dumps(dict(fixture=f["preprocessing_identity"], sources=campaign.preprocessing_sources(),
            campaign_source=campaign.digest(campaign.__file__), numpy=np.__version__, scipy=scipy.__version__), sort_keys=True))
    if receiver.receiver_id != gate["receiver_id"]:
        raise ValueError("original stress receiver identity differs from frozen gate")
    files = [prepared / "plan.json", prepared / "stimulus.f32", prepared / "profile.json", capture_path,
             metadata_path, analysis / "results.json", gate_path, fixture_dir / "fixture.json", fixture_dir / "basis.npy",
             Path(__file__), ROOT / "tools" / "triad_live_margins.py", ROOT / "tools" / "triad_live_receiver.py",
             ROOT / "tools" / "triad_live_model.py", ROOT / "tools" / "triad_live_waveforms.py"]
    identities = {str(path.relative_to(ROOT)): campaign.digest(path) for path in files}
    write(HERE / "freeze.json", dict(schema="triad-stress-null-validation-freeze-v1", identities=identities,
        receiver_id=receiver.receiver_id, original_record_indices=null_indices,
        selection="all and only original plan case=None; no signal scoring or tuning",
        cpu_threads=2, environment=dict(numpy=np.__version__, scipy=scipy.__version__, torch=torch.__version__,
            openblas_threads=os.environ.get("OPENBLAS_NUM_THREADS"), omp_threads=os.environ.get("OMP_NUM_THREADS"))))
    first = plan["records"][0]
    initial = model._marker_delay(np.asarray(tx[:first["samples"]]), np.asarray(rx[:first["samples"] + 2 * campaign.FS]),
        campaign.FS, first["markers"]["markers"][0])
    delay = initial["delay_samples"]
    state = model.AudioModelState(profile)
    rows = []
    for rec, alignment in zip(plan["records"], alignments):
        off, n = rec["offset"], rec["samples"]
        chunk = np.asarray(tx[off:off + n])
        if hashlib.sha256(chunk.tobytes()).hexdigest() != rec["stimulus_sha256"]:
            raise ValueError("validation record changed")
        # Every record, including skipped signals, advances the continuous
        # original forward-model filter state and public alignment recurrence.
        predicted = state.process(model.quantize_production_playback(chunk))
        a = max(0, int(off + delay - campaign.FS))
        b = min(len(rx), int(off + delay + n + campaign.FS))
        delay = a + alignment["offset_samples"] - off
        if rec["case"] is not None:
            continue
        predicted += campaign.fixed_noise(profile, n, rec["noise_seed"] + 991000)
        positions = np.arange(n, dtype=float) * alignment["sample_rate_ratio"] + alignment["offset_samples"] - alignment["causal_guard_samples"]
        # Match align_capture's float64 promotion before sinc interpolation;
        # the interpolator intentionally preserves its input dtype.
        physical, physical_valid = model._sinc_sample(model._samples(np.asarray(rx[a:b])), positions)
        lo = rec["markers"]["payload"]["start"]
        hi = lo + f["payload_audio_samples"]
        if hi > len(physical) or not physical_valid[lo:hi].all():
            raise ValueError("incomplete physical stress-null payload")
        for kind, pcm in (("physical", physical[lo:hi]), ("simulated", predicted[lo:hi])):
            y, _, ddc = campaign.convert(pcm, f)
            score = receiver.score(y)
            decision = empirical_decision(score, gate)
            rows.append(dict(index=rec["index"], case="stress", kind=kind, truth=None, gain=0.,
                **score, decision=decision, classification=evaluate(decision, None),
                public_alignment_source="unchanged primary fit; absolute slice origin reconstructed from initial public marker",
                payload_audio_samples=f["payload_audio_samples"], ddc=ddc))
        if len(rows) % 8 == 0:
            print(f"scored {len(rows)//2}/32 physical/simulated null pairs", flush=True)
    summaries = []
    for kind in ("physical", "simulated"):
        selected = [r for r in rows if r["kind"] == kind]
        if [r["index"] for r in selected] != null_indices:
            raise ValueError("incomplete ordered null denominator")
        counts = {label: sum(r["classification"] == label for r in selected)
                  for label in ("correct_admission", "wrong_admission", "miss", "false_admission", "correct_rejection")}
        failures = counts["false_admission"]
        summaries.append(dict(kind=kind, trials=len(selected), counts=counts,
            intervals_95={label: binomial_interval(value, len(selected))["interval"] for label, value in counts.items()},
            false_admission_upper_one_sided_95=float(beta.ppf(.95, failures + 1, len(selected) - failures)) if failures < len(selected) else 1.,
            score_range=[min(r["score"] for r in selected), max(r["score"] for r in selected)],
            uncertainty_scope="pointwise independent Bernoulli interval; common physical device/path may violate independence or stationarity"))
    write(HERE / "results.json", dict(schema="triad-stress-null-validation-v1", rows=rows, summaries=summaries,
        original_record_indices=null_indices, receiver_id=receiver.receiver_id, original_gate=gate,
        freeze_sha256=campaign.digest(HERE / "freeze.json"), source_sha256=campaign.digest(__file__),
        original_primary_result_sha256=campaign.digest(analysis / "results.json"), initial_public_marker=initial,
        wall_seconds=time.perf_counter() - started, scored_signal_records=0,
        receiver_or_gate_changed=False, forward_model_changed=False, synthetic_only=False,
        scope="additional actual cable null validation with original stress receiver/gate; same recorded nulls as primary baseline/edge/spreading tests, not additional physical trials; marker-conditioned offline reception, no operational rare-admission qualification"))
    print(json.dumps(summaries, indent=2))
    print("wall_seconds", time.perf_counter() - started)


if __name__ == "__main__":
    main()

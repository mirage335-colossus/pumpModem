#!/usr/bin/env python3
"""Same-order upper audio edge correction, with disjoint null holdout records.
This is a forward-model experiment; receiver templates/gates never change.
"""
import copy,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from scipy import signal,ndimage
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_model as model
import triad_live_waveforms as wave
HERE=Path(__file__).resolve().parent
BASE=HERE.parent; SRC=BASE/'calibration-002'
FS=48000; TRAIN=tuple(range(20)); HOLD=tuple(range(20,39)); NFFT=32768

def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def write(p,v):
 if p.exists(): raise FileExistsError(p)
 p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def inputs():
 plan=read(SRC/'plan.json'); old=read(SRC/'profile.json')
 assert len(plan['records'])==39 and all(r['truth'] is None for r in plan['records'])
 assert len(old['fir'])==1025 and old['input_pcm_contract']=='s16-native'
 tx=np.memmap(SRC/'stimulus.f32',dtype='<f4',mode='r')
 rx=np.memmap(SRC/'capture.f32',dtype='<f4',mode='r')
 align=read(BASE/'calibration-analysis/results.json')['alignments']
 if digest(SRC/'stimulus.f32')!=plan['stimulus_sha256']: raise ValueError('stimulus changed')
 return plan,old,tx,rx,align

def records(plan,tx,rx,align,selected):
 # Reuse exact public-marker fits from the frozen receiver analysis. Each fit
 # was estimated without payload knowledge. Recover its original local origin.
 delay=align[0]['markers'][0]['delay_samples']
 for r,al in zip(plan['records'],align):
  off,n=r['offset'],r['samples']; a=max(0,int(off+delay-FS)); b=min(len(rx),int(off+delay+n+FS))
  delay=a+al['offset_samples']-off
  chunk=np.asarray(tx[off:off+n])
  actual=None
  if r['index'] in selected:
   pos=np.arange(n,dtype=float)*al['sample_rate_ratio']+al['offset_samples']-al['causal_guard_samples']
   actual,valid=model._sinc_sample(np.asarray(rx[a:b]),pos)
   pay=r['markers']['payload']
   if not valid[pay['start']:pay['start']+pay['samples']].all(): raise ValueError('invalid aligned payload')
  yield r,chunk,actual

def identities():
 return {str(p.relative_to(ROOT)):digest(p) for p in [SRC/'plan.json',SRC/'stimulus.f32',SRC/'capture.f32',SRC/'profile.json',BASE/'calibration-analysis/results.json',Path(__file__),ROOT/'tools/triad_live_model.py',ROOT/'tools/triad_live_waveforms.py']}

def train():
 start=time.perf_counter(); plan,old,tx,rx,align=inputs(); state=model.AudioModelState(old)
 sums=None; train_rows=[]
 for r,x,a in records(plan,tx,rx,align,TRAIN):
  if r['index'] not in TRAIN: break
  q=model.quantize_production_playback(x); pred=state.process(q)
  p=r['markers']['payload']; lo=p['start']+4800; hi=p['start']+p['samples']-4800
  guard=align[r['index']]['causal_guard_samples']
  # Remove the known integer causal guard before estimating the response, so
  # Welch windows do not attenuate a 256-sample delayed CSD. Remaining path
  # delay is small; its complex response is retained rather than magnitude-fit.
  xx=q[lo:hi-guard]; yy=a[lo+guard:hi]
  f,px=signal.welch(xx,FS,nperseg=NFFT)
  _,cross=signal.csd(xx,yy,FS,nperseg=NFFT)
  if sums is None: sums=[px,cross]
  else: sums[0]+=px; sums[1]+=cross
  train_rows.append(dict(index=r['index'],noise_seed=r['noise_seed'],stimulus_sha256=r['stimulus_sha256']))
 h=sums[1]/np.maximum(sums[0],1e-30)
 sos=model._profile_sos(old,FS,old['highpass_cutoff_hz'])
 _,low=signal.sosfreqz(sos,worN=2*np.pi*f/FS)
 # At high frequencies the LF4 response has no numerical near-zero mode.
 selected=f>=19000
 residual=np.zeros_like(h)
 residual[selected]=h[selected]/low[selected]
 # Smooth only the de-guarded complex high-frequency transfer over 5.9 Hz.
 # No new model order or state is introduced.
 smooth=ndimage.gaussian_filter1d(residual.real,4,mode='nearest')+1j*ndimage.gaussian_filter1d(residual.imag,4,mode='nearest')
 oldfir=np.fft.rfft(np.asarray(old['fir']),n=NFFT)
 guard=256
 target=smooth*np.exp(-2j*np.pi*f*guard/FS)
 weight=.5-.5*np.cos(np.pi*np.clip((f-20000)/1000,0,1))
 full=oldfir*(1-weight)+target*weight
 full[0]=oldfir[0].real; full[-1]=full[-1].real
 impulse=np.fft.irfft(full,n=NFFT)
 fir=impulse[:1025].copy()
 taper=len(fir)//8
 fir[-taper:]*=.5*(1+np.cos(np.linspace(0,np.pi,taper)))
 new=copy.deepcopy(old); new['fir']=fir.tolist()
 new['validation_status']='frozen upper-edge training candidate; independent null holdout not read'
 new['upper_edge_refinement']=dict(schema='triad-live-upper-edge-refinement-v1',training_records=list(TRAIN),
  training_rows=train_rows,training_input='same physical cable, pre-DAC independent broadband noise, 0.03 RMS',
  estimated_response='Welch CSD after removing exact 256-sample guard; divide unchanged LF4; restore guard',
  smoothing_hz=4*FS/NFFT,blend_hz=[20000,21000],preserved_model_below_hz=20000,
  fir_taps=len(fir),lf4_unchanged=True,noise_surrogate_unchanged=True,
  receiver_and_gate_changed=False,finite_ir_omitted_energy_fraction=float(np.sum(impulse[1025:]**2)/np.sum(impulse**2)),
  scope='forward prediction only; conditional on marker interpolation and this device/level; Nyquist endpoint response is constrained real')
 write(HERE/'profile.json',new)
 freq=np.linspace(100,20000,2000); oldr=model.spectral_response(old,freq); newr=model.spectral_response(new,freq)
 ratios=newr/oldr
 preservation=dict(maximum_gain_change_db=float(np.max(abs(20*np.log10(abs(ratios))))),maximum_phase_change_rad=float(np.max(abs(np.angle(ratios)))))
 freeze=dict(profile_sha256=digest(HERE/'profile.json'),identities=identities(),training_records=list(TRAIN),
  heldout_records=list(HOLD),before_holdout=True,unchanged_lf4=old['low_frequency_section']==new['low_frequency_section'],
  unchanged_noise=old['noise']==new['noise'],mainband_preservation=preservation,wall_seconds=time.perf_counter()-start)
 write(HERE/'freeze.json',freeze)
 np.savez_compressed(HERE/'training-response.npz',frequency_hz=f,estimated_guard_removed_response=h,old_fir_response=oldfir,new_fir_response=np.fft.rfft(fir,n=NFFT),target_fir_response=full)
 print(json.dumps(freeze,indent=2))

def validate():
 start=time.perf_counter(); freeze=read(HERE/'freeze.json')
 if digest(HERE/'profile.json')!=freeze['profile_sha256'] or identities()!=freeze['identities']: raise ValueError('frozen inputs or source changed')
 plan,old,tx,rx,align=inputs(); new=read(HERE/'profile.json')
 states=[model.AudioModelState(old),model.AudioModelState(new)]
 fixtures={n:read(SRC/'fixtures'/n/'fixture.json') for n in ['baseline','edge']}
 results=[]
 for r,x,a in records(plan,tx,rx,align,HOLD):
  q=model.quantize_production_playback(x)
  preds=[s.process(q) for s in states] # Continuous state through ALL records.
  if r['index'] not in HOLD: continue
  p=r['markers']['payload']; lo=p['start']; hi=lo+p['samples']
  row=dict(index=r['index'],noise_seed=r['noise_seed'],bands={})
  for name,f in fixtures.items():
   end=lo+f['payload_audio_samples']
   def ddc(y):return wave.from_audio(y[lo:end],FS,f['receiver_sample_rate'],f['carrier'],occupied_bandwidth_hz=f['bandwidth'],expected_samples=f['receiver_samples'])[0]
   actual=ddc(a); ea=float(np.sum(abs(actual.astype(complex))**2))
   row['bands'][name]={}
   for label,pred in zip(['old','corrected'],preds):
    z=ddc(pred); ep=float(np.sum(abs(z.astype(complex))**2)); er=float(np.sum(abs(actual.astype(complex)-z)**2))
    row['bands'][name][label]=dict(energy_error_db=10*np.log10(ea/ep),residual_to_actual_db=10*np.log10(er/ea))
  results.append(row)
 summary={}
 for name in fixtures:
  summary[name]={}
  for label in ['old','corrected']:
   summary[name][label]={k:{'minimum':float(np.min(v:=[r['bands'][name][label][k] for r in results])),'median':float(np.median(v)),'maximum':float(np.max(v))} for k in ['energy_error_db','residual_to_actual_db']}
 out=dict(schema='triad-live-upper-edge-holdout-v1',rows=results,summary=summary,freeze_sha256=digest(HERE/'freeze.json'),profile_sha256=digest(HERE/'profile.json'),
  holdout_records=list(HOLD),wall_seconds=time.perf_counter()-start,forward_model_only=True,
  empirical_receiver_or_gates_changed=False,fit_performed_on_holdout=False,
  scope='19 disjoint physical null records on the same codec/time campaign; uncertainty from correlated device state not bounded; actual residual includes hardware noise, deterministic predictions omit independent residual draws')
 write(HERE/'validation.json',out)
 print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))

if __name__=='__main__':
 if len(sys.argv)!=2 or sys.argv[1] not in ('train','validate'):raise SystemExit('usage: refine.py train|validate')
 (train if sys.argv[1]=='train' else validate)()

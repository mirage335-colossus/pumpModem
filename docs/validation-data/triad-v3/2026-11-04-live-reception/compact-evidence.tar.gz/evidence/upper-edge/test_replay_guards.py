#!/usr/bin/env python3
"""Synthetic provenance checks only; opens no primary experiment files."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('replay_forward',HERE/'replay_forward.py')
replay=importlib.util.module_from_spec(spec);spec.loader.exec_module(replay)
class GuardTests(unittest.TestCase):
 def test_gate_content_and_row_identity(self):
  with tempfile.TemporaryDirectory(dir=HERE) as directory:
   a,b=[Path(directory)/n for n in ('calibration.json','primary.json')]
   gate=dict(receiver_id='fixed',alpha=.05,sorted_null_scores=[1.,2.])
   a.write_text(json.dumps(gate)); b.write_text(a.read_text())
   receivers={'baseline':SimpleNamespace(receiver_id='fixed')}
   rows=[dict(kind=k,case='baseline',receiver_id='fixed') for k in ('physical','simulated')]
   replay.verify_primary_gate_binding(a,b,receivers,rows)
   gate['sorted_null_scores'][-1]=20.
   b.write_text(json.dumps(gate))
   with self.assertRaisesRegex(ValueError,'gate content'):
    replay.verify_primary_gate_binding(a,b,receivers,rows)
   b.write_text(a.read_text())
   for i in range(2):
    changed=[dict(r) for r in rows]; changed[i]['receiver_id']='different'
    with self.assertRaisesRegex(ValueError,'row receiver identity'):
     replay.verify_primary_gate_binding(a,b,receivers,changed)
   with self.assertRaisesRegex(ValueError,'unexpected original'):
    replay.verify_primary_gate_binding(a,b,receivers,[dict(kind='physical',case='unknown',receiver_id='fixed')])
if __name__=='__main__':unittest.main()

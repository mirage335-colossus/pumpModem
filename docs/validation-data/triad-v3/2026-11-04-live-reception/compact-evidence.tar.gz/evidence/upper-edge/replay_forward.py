#!/usr/bin/env python3
"""Score corrected FORWARD predictions using the ORIGINAL physical receiver.

Run only after the primary physical/old-model analysis has completed. Optional
physical metrics read PCM but never rescore the physical receiver. No template
or admission gate changes.
"""
import argparse,hashlib,json,sys,time
from pathlib import Path
import numpy as np
import scipy
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_margins as campaign
import triad_live_model as model
from triad_live_receiver import EmpiricalReceiver,empirical_decision,evaluate,binomial_interval
HERE=Path(__file__).resolve().parent; BASE=HERE.parent

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')

def verify_primary_gate_binding(calibration_gates,primary_gates,receivers,rows):
 if digest(calibration_gates)!=digest(primary_gates):
  raise ValueError('calibration gate content differs from primary frozen decisions')
 for row in rows:
  if row.get('kind') not in ('physical','simulated') or row.get('case') not in receivers:
   raise ValueError('unexpected original primary score row')
  if row.get('receiver_id')!=receivers[row['case']].receiver_id:
   raise ValueError('original primary score row receiver identity differs')

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--prepared',type=Path,required=True)
 p.add_argument('--original-analysis',type=Path,required=True)
 p.add_argument('--calibration',type=Path,default=BASE/'calibration-analysis')
 p.add_argument('--output',type=Path,required=True)
 p.add_argument('--physical-metrics',action='store_true')
 p.add_argument('--capture',type=Path)
 p.add_argument('--capture-metadata',type=Path)
 args=p.parse_args(); start=time.perf_counter()
 # Require a completed primary result before even reading its stimulus/labels.
 primary=read(args.original_analysis/'results.json')
 if primary.get('synthetic_only',True):raise ValueError('requires completed real physical primary analysis')
 freeze=read(HERE/'freeze.json'); refined=read(HERE/'profile.json')
 if digest(HERE/'profile.json')!=freeze['profile_sha256']:raise ValueError('corrected profile changed')
 for name,wanted in freeze['identities'].items():
  if digest(ROOT/name)!=wanted:raise ValueError('upper-edge training identity changed: '+name)
 plan=read(args.prepared/'plan.json')
 if plan['phase']!='validation':raise ValueError('forward replay requires independent validation phase')
 if primary['plan_sha256']!=digest(args.prepared/'plan.json'):raise ValueError('primary plan changed')
 if digest(args.prepared/'stimulus.f32')!=plan['stimulus_sha256']:raise ValueError('stimulus changed')
 if digest(args.prepared/'profile.json')!=primary['profile_copy_sha256']:raise ValueError('original forward profile differs from primary analysis')
 old=read(args.prepared/'profile.json')
 if old['noise']!=refined['noise'] or old['low_frequency_section']!=refined['low_frequency_section']:raise ValueError('only existing FIR may change')
 args.output.mkdir(parents=True,exist_ok=False)
 fixtures_dir=Path(plan['fixtures_directory']); gates=read(args.calibration/'gates.json')
 receivers={}; fixtures={}
 for name in plan['cases']:
  f=read(fixtures_dir/name/'fixture.json'); fixtures[name]=f
  if digest(fixtures_dir/name/'fixture.json')!=plan['fixture_json_sha256'][name]:raise ValueError('fixture metadata changed')
  campaign.verify_fixture(fixtures_dir/name,f)
  _,valid,_=campaign.convert(np.zeros(f['payload_audio_samples']),f)
  receivers[name]=EmpiricalReceiver(np.load(fixtures_dir/name/'basis.npy'),f['receiver_sample_rate'],np.asarray(f['lags']),
   key=f['public_key'],valid=valid,reference_variance=f['reference_variance'],frequency_offsets=tuple(f['frequency_offsets_hz']),precision='fp32',
   preprocessing_identity=json.dumps(dict(fixture=f['preprocessing_identity'],sources=campaign.preprocessing_sources(),campaign_source=digest(campaign.__file__),numpy=np.__version__,scipy=scipy.__version__),sort_keys=True))
  if receivers[name].receiver_id!=gates[name]['receiver_id']:raise ValueError('original frozen receiver identity changed')
 verify_primary_gate_binding(args.calibration/'gates.json',args.original_analysis/'gates.json',receivers,primary['rows'])
 tx=np.memmap(args.prepared/'stimulus.f32',dtype='<f4',mode='r')
 state=model.AudioModelState(refined); rows=[]
 physical_receipt=None; alignment_seconds=0.
 if args.physical_metrics:
  capture=args.capture or args.prepared/'capture.f32'
  metadata=args.capture_metadata or args.prepared/'capture.json'
  if digest(capture)!=primary['capture_sha256'] or digest(metadata)!=primary['capture_metadata_sha256']:
   raise ValueError('physical capture differs from completed primary analysis')
  receipt=read(metadata)
  if receipt.get('synthetic_only',False):raise ValueError('synthetic capture cannot establish physical metrics')
  rx=np.memmap(capture,dtype='<f4',mode='r')
  campaign.validate_capture(receipt,len(rx))
  alignments=primary['alignments']
  if len(alignments)!=len(plan['records']) or any(a['index']!=r['index'] for a,r in zip(alignments,plan['records'])):
   raise ValueError('public alignment record mismatch')
  # The primary output retains local affine fits, not local slice origins.
  # Recheck only the first PUBLIC marker to recover its absolute initial
  # transport offset, then reconstruct exactly the original origin recurrence.
  mark=time.perf_counter(); first=plan['records'][0]
  initial=model._marker_delay(np.asarray(tx[:first['samples']]),np.asarray(rx[:first['samples']+2*campaign.FS]),
   campaign.FS,first['markers']['markers'][0])
  delay=initial['delay_samples']; alignment_seconds+=time.perf_counter()-mark
  old_state=model.AudioModelState(old)
  physical_receipt=dict(capture_sha256=digest(capture),metadata_sha256=digest(metadata),
   initial_public_marker=initial,alignment_source='unchanged primary two-marker affine fits; first public marker checked again to recover local slice origins',
   payload_fitted=False,physical_receiver_rescored=False)
 elif args.capture is not None or args.capture_metadata is not None:
  raise ValueError('physical capture arguments require --physical-metrics')
 lookup={(r['index'],r['case'],r['kind']):r for r in primary['rows']}
 for rec in plan['records']:
  off,n=rec['offset'],rec['samples']; x=np.asarray(tx[off:off+n])
  if hashlib.sha256(x.tobytes()).hexdigest()!=rec['stimulus_sha256']:raise ValueError('record changed')
  q=model.quantize_production_playback(x)
  predicted=state.process(q)
  # Identical PSD and seed to the original forward model: the independent
  # residual draw is paired; only the continuous deterministic FIR changes.
  residual_noise=campaign.fixed_noise(refined,n,rec['noise_seed']+991000)
  predicted+=residual_noise
  if args.physical_metrics:
   original_prediction=old_state.process(q)+residual_noise
   al=alignments[rec['index']]
   a=max(0,int(off+delay-campaign.FS)); b=min(len(rx),int(off+delay+n+campaign.FS))
   delay=a+al['offset_samples']-off
   mark=time.perf_counter()
   positions=np.arange(n,dtype=float)*al['sample_rate_ratio']+al['offset_samples']-al['causal_guard_samples']
   # align_capture promotes PCM through _samples before sinc interpolation;
   # preserve that exact boundary, including the interpolator output dtype.
   physical_pcm,physical_valid=model._sinc_sample(model._samples(np.asarray(rx[a:b])),positions)
   alignment_seconds+=time.perf_counter()-mark
  lo=rec['markers']['payload']['start']
  for name in ([rec['case']] if rec['case'] else plan['cases']):
   f=fixtures[name]; z,_,_=campaign.convert(predicted[lo:lo+f['payload_audio_samples']],f)
   score=receivers[name].score(z); dec=empirical_decision(score,gates[name])
   actual=lookup[(rec['index'],name,'physical')]; original=lookup[(rec['index'],name,'simulated')]
   row=dict(index=rec['index'],case=name,kind='simulated_upper_edge_corrected',truth=rec['truth'],gain=rec['gain'],cn0_db_hz=rec['cn0_db_hz'],
    **score,decision=dec,classification=evaluate(dec,rec['truth']),
    comparison=dict(physical_score=actual['score'],original_model_score=original['score'],physical_classification=actual['classification'],original_model_classification=original['classification']))
   if args.physical_metrics:
    end=lo+f['payload_audio_samples']
    if not physical_valid[lo:end].all():raise ValueError('invalid aligned physical payload')
    y,_,_=campaign.convert(physical_pcm[lo:end],f)
    original_z,_,_=campaign.convert(original_prediction[lo:end],f)
    ea=float(np.sum(abs(y)**2)); metrics={}
    for label,zz in [('original',original_z),('corrected',z)]:
     ep=float(np.sum(abs(zz)**2)); er=float(np.sum(abs(y-zz)**2))
     metrics[label]=dict(total_energy_ratio_db=float(10*np.log10(ea/ep)),
      residual_to_prediction_db=float(10*np.log10(er/ep)),residual_to_actual_db=float(10*np.log10(er/ea)))
    # This is a cheap replay consistency check, not another physical receiver
    # evaluation. The primary stored these same full-DDC-array metrics.
    prior_path=args.original_analysis/f"record-{rec['index']:04d}-{name}.json"
    prior=read(prior_path)
    if not np.allclose([metrics['original']['total_energy_ratio_db'],metrics['original']['residual_to_prediction_db']],
     [prior['total_energy_ratio_db'],prior['composite_prediction_residual_ratio_db']],rtol=0,atol=1e-7):
     raise ValueError(f"original public alignment/model replay does not reproduce retained metrics: record={rec['index']} case={name} current={metrics['original']} prior_energy={prior['total_energy_ratio_db']} prior_residual={prior['composite_prediction_residual_ratio_db']}")
    row['physical_metrics']=dict(**metrics,prior_record_sha256=digest(prior_path),
     scope='unchanged public marker alignment, full fixed DDC arrays; residual includes independent observed/model noise; no payload fitting')
   rows.append(row)
  print(f"forward scored {rec['index']+1}/{len(plan['records'])}",flush=True)
 summaries=[]
 for name in plan['cases']:
  levels=sorted(set((r['gain'],r['cn0_db_hz']) for r in rows if r['case']==name))
  for gain,cn0 in levels:
   selected=[r for r in rows if r['case']==name and r['gain']==gain and r['cn0_db_hz']==cn0]
   counts={k:sum(r['classification']==k for r in selected) for k in ['correct_admission','wrong_admission','miss','false_admission','correct_rejection']}
   summaries.append(dict(case=name,gain=gain,cn0_db_hz=cn0,trials=len(selected),counts=counts,
    intervals_95={k:binomial_interval(v,len(selected))['interval'] for k,v in counts.items()}))
 comparison={}
 for name in plan['cases']:
  selected=[r for r in rows if r['case']==name]
  comparison[name]=dict(records=len(selected),original_outcome_disagreements=sum(r['comparison']['physical_classification']!=r['comparison']['original_model_classification'] for r in selected),
   corrected_outcome_disagreements=sum(r['comparison']['physical_classification']!=r['classification'] for r in selected),
   original_absolute_score_difference_percentiles=np.percentile([abs(r['comparison']['physical_score']-r['comparison']['original_model_score']) for r in selected],[0,50,95,100]).tolist(),
   corrected_absolute_score_difference_percentiles=np.percentile([abs(r['comparison']['physical_score']-r['score']) for r in selected],[0,50,95,100]).tolist())
  if args.physical_metrics:
   comparison[name]['physical_metrics']={label:{key:dict(minimum=float(np.min(v:=[r['physical_metrics'][label][key] for r in selected])),median=float(np.median(v)),maximum=float(np.max(v)))
    for key in ['total_energy_ratio_db','residual_to_prediction_db','residual_to_actual_db']} for label in ['original','corrected']}
 if physical_receipt is not None:
  physical_receipt['alignment_reconstruction_wall_seconds']=alignment_seconds
  physical_receipt['local_affine_offset_fraction_range']=[float(min(a['offset_samples']%1 for a in alignments)),float(max(a['offset_samples']%1 for a in alignments))]
 write(args.output/'results.json',dict(format='triad-live-forward-replay-v1',rows=rows,summaries=summaries,comparison=comparison,
  primary_results_sha256=digest(args.original_analysis/'results.json'),corrected_profile_sha256=digest(HERE/'profile.json'),profile_freeze_sha256=digest(HERE/'freeze.json'),
  original_gates_sha256=digest(args.calibration/'gates.json'),source_sha256=digest(__file__),wall_seconds=time.perf_counter()-start,
  receiver_or_gate_changed=False,physical_capture_rescored=False,forward_model_only=True,
  physical_metrics_receipt=physical_receipt,
  scope='independent primary capture comparison; corrected profile trained only prior calibration nulls0–19; original physical and original simulated decisions preserved; no operational rare-admission or blind-acquisition claim'))
 print(json.dumps(comparison,indent=2))

if __name__=='__main__':main()

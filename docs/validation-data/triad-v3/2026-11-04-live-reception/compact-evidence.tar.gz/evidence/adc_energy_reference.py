#!/usr/bin/env python3
"""Evaluation-only ADC-referred energy estimates; never supplies receiver truth."""
import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'tools'))
import triad_live_model as model
p=json.loads((HERE/'upper-edge/profile.json').read_text())
psd=np.load(HERE/'noise-response.npz'); ff=psd['frequency_hz']; pp=psd['adc_psd']
rows=[]
for case in ['baseline','edge','spreading','stress']:
 d=HERE/'calibration-002/fixtures'/case; f=json.loads((d/'fixture.json').read_text())
 band=(ff>=f['carrier']-f['bandwidth']/2)&(ff<=f['carrier']+f['bandwidth']/2)
 n0=float(np.mean(pp[band])); vals=[]
 for bit in [0,1]:
  x=np.fromfile(d/f'signal-{bit}.f32',dtype='<f4'); y=model.apply_audio_profile(x,p,full_tail=True)
  e=float(np.dot(y,y)/48000); avg=e/f['useful_duration_seconds']
  correction=10*np.log10(avg*(2*.03**2/48000)/n0)
  vals.append({'bit':bit,'model_adc_energy_per_gain_squared_seconds':e,'cn0_correction_to_nominal_db':float(correction)})
 rows.append({'case':case,'nominal_band_hz':[float(ff[band][0]),float(ff[band][-1])],'measured_adc_noise_density_fs_squared_per_hz':n0,'bits':vals})
result={'rows':rows,'scope':'Evaluation-only hybrid estimate: independently trained upper-edge forward profile predicts isolated useful signal energy; measured first-null one-sided ADC PSD averaged over nominal occupied band defines N0. Colored noise has no unique scalar C/N0; this convention is not a white-noise guarantee, RF input noise figure or direct signal measurement inside the noisy capture. No normalizing compensation was applied to receiver data.'}
(HERE/'adc-energy-reference.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(rows,indent=2))

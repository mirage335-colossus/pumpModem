import json,sys,math,hashlib
from pathlib import Path
sys.path.insert(0,'tools')
from triad_hf_noise_measure import quiet_noise_metrology
p=Path(__file__).parent
def read(f):return json.loads(f.read_text())
initial=read(p/'summary.json')
if not (p/'initial-summary.json').exists():(p/'initial-summary.json').write_text(json.dumps(initial,indent=2)+'\n')
else:initial=read(p/'initial-summary.json')
rows=initial['rows'];failures=[]
for row in rows:
 if row['case']!='flat':continue
 failures.append(dict(case='flat',variant=row['variant'],status='unresolved',reason='Helper flat_profile caused an unconditional early return before DATA acquisition',correct_admissions=0,wrong_admissions=0,misses=1,source_evidence=f"flat-{row['variant']}-replay/receiver/slot-0-receiver.json"))
 d=p/f"flat-{row['variant']}-replay-fixed";rx=read(d/'slot-0-receiver.json');r=read(d/'report.json');op=rx['operational'];passed=op['passes_conditional_bound'];bit=rx['bit']
 row.update(candidate_bit=bit,correct_admissions=int(passed and bit==0),wrong_admissions=int(passed and bit!=0),misses=int(not passed),log_e=op['log_e_lower_bound'],threshold=op['log_e_threshold'],cpu_seconds=r['total_cpu_seconds'],timing_scope='Entire stream-run processing including preparation, excluding Python imports and previously generated PCM',frequency_search_source=rx['frequency_search_source'],original_pcm_reused=True,source_evidence=str(d.relative_to(p)))
 row.pop('preparation_cpu_seconds',None)
m=read(p/'flat-planned-signal/manifest.json');d=p/'flat-planned-live';r=read(d/'report.json');rx=read(d/'slot-0-receiver.json');op=rx['operational'];passed=op['passes_conditional_bound'];bit=rx['bit'];ref=next(x for x in rows if x['case']=='flat' and x['variant']=='planned')
met=quiet_noise_metrology(d/'capture.stereo.s16le',m,gain=.003,analog_gain=.8414025015631204,offset_frames=48000);(p/'flat-live-metrology.json').write_text(json.dumps(met,indent=2)+'\n')
cn=met['bands'][0]['nominal_data_equivalent_cn0_db_hz']
assert r['bridge']['sha256']==read(p/'flat-planned-replay/report.json')['playback_sha256']
rows.append(dict(case='flat',variant='planned',mode='live',active_seconds=ref['active_seconds'],tx_helper_data_seconds=ref['tx_helper_data_seconds'],nominal_psd_cn0_db_hz=cn,matched_data_mean_power=ref['matched_data_mean_power'],realized_data_cn0_estimate_db_hz=cn+10*math.log10(ref['matched_data_mean_power']),expected_bit=0,candidate_bit=bit,correct_admissions=int(passed and bit==0),wrong_admissions=int(passed and bit!=0),misses=int(not passed),log_e=op['log_e_lower_bound'],threshold=op['log_e_threshold'],cpu_seconds=r['total_cpu_seconds'],wall_seconds=r['total_wall_seconds'],audio_discontinuity=r['transport']['discontinuity'],adc_near_fullscale=r['stream']['capture']['stereo_near_fullscale'],frequency_search_source=rx['frequency_search_source'],identical_transmit_pcm_sha256=r['bridge']['sha256']))
null=read(p/'flat-planned-null/receiver/slot-0-receiver.json')
result=dict(initial,rows=rows,pre_fix_failures=failures,false_admission_trials=1,false_admissions=int(null['operational']['passes_conditional_bound']),null_log_e=null['operational']['log_e_lower_bound'],one_sided_95_false_admission_upper_bound=.95,uncertainty='One independent channel seed per configuration, reused across two durations. At one success out of one independent trial, exact two-sided95% binomial detection interval is[.025,1]. Software/live pairs share the same transmitted observation and are not independent channel trials. Different configurations are not pooled for a reliability claim.',source_transfer='HF measured before fallback correction; its narrowed-Helper branch is unchanged, verified by focused tests/review. Stable replays and live measured with corrected receiver. Exact pre-fix receiver and frozen planner sources are retained; only approximate calendar reporting changed in planner after forecasts were frozen.')
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:print(row['case'],row['variant'],row['mode'],'T',row['active_seconds'],'nominal',round(row['nominal_psd_cn0_db_hz'],3),'realized',round(row['realized_data_cn0_estimate_db_hz'],3),'loge',round(row['log_e'],3),'C/W/M',row['correct_admissions'],row['wrong_admissions'],row['misses'])
print('null',result['false_admissions'],'of',result['false_admission_trials'],result['null_log_e'])

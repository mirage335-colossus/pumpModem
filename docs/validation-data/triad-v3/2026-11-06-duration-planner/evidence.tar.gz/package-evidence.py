import hashlib,json,subprocess,tarfile,platform,sys
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/validation-data/triad-v3/2026-11-06-duration-planner';dest.mkdir(parents=True,exist_ok=True)
def digest(f):
 h=hashlib.sha256()
 with f.open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name!='evidence-index.json')
sources=[Path(x) for x in ['tools/triad_duration_model.py','tools/triad_weak_plan.py','tools/triad_weak_receiver.py','tools/triad_operational_admission.py','tools/triad_hf_noise_measure.py','tools/triad_stream_run.py','tests/test_triad_duration_model.py','tests/test_triad_weak_plan.py','tests/test_triad_weak_receiver.py','tests/test_triad_operational_admission.py']]
index=dict(base_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),python=sys.version,platform=platform.platform(),source_sha256={str(f):digest(f) for f in sources},binary_sha256={str(f):digest(f) for f in [Path('build/dev-cli/triad_helper_export'),Path('build/dev-cli/background_noise')]},files=[dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=digest(f),archived=f.suffix in ('.json','.py','.log','.txt')) for f in files],scope='Raw small receipts and source snapshots archived. Large I/Q and audio remain local; no AES key retained. Forecasts predate only a calendar-reporting correction, and HF precedes the stable fallback correction. See README and frozen sources.')
(p/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
(dest/'summary.json').write_text((p/'summary.json').read_text())
with tarfile.open(dest/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for f in files+[p/'evidence-index.json']:
  if f.suffix in ('.json','.py','.log','.txt'):tar.add(f,arcname=str(f.relative_to(p)))
 for f in sources:tar.add(f,arcname='source-current/'+str(f))
 gain=Path('local-evidence/triad-hf-background-target/cable-gain/report.json');tar.add(gain,arcname='prior-cable-gain/report.json')
(dest/'SHA256SUMS').write_text('\n'.join(digest(dest/f)+'  '+f for f in ['summary.json','evidence.tar.gz'])+'\n')
print('archive bytes', (dest/'evidence.tar.gz').stat().st_size,'large locally retained bytes',sum(f['bytes'] for f in index['files'] if not f['archived']))

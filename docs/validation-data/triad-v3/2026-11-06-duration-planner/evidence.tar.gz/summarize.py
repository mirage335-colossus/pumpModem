import hashlib,json,math,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'tools')
from triad_hf_noise_measure import quiet_noise_metrology
p=Path(__file__).parent
rows=[]
def read(path):return json.loads(path.read_text())
for case,variant in [('hf','planned'),('hf','neighbor'),('flat','planned'),('flat','neighbor')]:
 signal=p/f'{case}-{variant}-signal';control=p/f'{case}-{variant}-helper-only'
 m=read(signal/'manifest.json');a=np.memmap(signal/'observation.c128',dtype='<c16',mode='r');b=np.memmap(control/'observation.c128',dtype='<c16',mode='r')
 assert a.shape==b.shape
 delta=a-b;fs=m['sample_rate_hz'];slot=m['whole_bit_calendar']['slots'][0]
 prefix=math.floor((slot['support_begin_sample']/fs+m['calendar']['capture_lead_seconds']+m['calendar']['arrival_prior_seconds'][0]-2)*fs)
 prefix_error=float(np.max(np.abs(delta[:prefix])))
 if prefix_error>1e-12:raise ValueError('component subtraction did not preserve quiet channel/noise prefix')
 energy=float(np.vdot(delta,delta).real/fs);active=m['power']['data_reference_active_seconds'];mean=energy/active
 d=p/f'{case}-{variant}-replay';r=read(d/'report.json');rx=read(d/'receiver/slot-0-receiver.json');nominal=r['metrology']['bands'][0]['nominal_data_equivalent_cn0_db_hz'];op=rx.get('operational',{})
 truth=read(signal/'evaluator-truth.json') if (signal/'evaluator-truth.json').exists() else None
 expected={'hf':1,'flat':0}[case];passed=bool(op.get('passes_conditional_bound',False));bit=rx.get('bit')
 rows.append(dict(case=case,variant=variant,mode='replay',active_seconds=active,tx_helper_data_seconds=(slot['helper_end_sample']-slot['helper_begin_sample'])/fs,
  nominal_psd_cn0_db_hz=nominal,matched_data_mean_power=mean,matched_energy=energy,realized_data_cn0_estimate_db_hz=nominal+10*math.log10(mean),
  quiet_prefix_identical_seconds=prefix/fs,quiet_prefix_max_error=prefix_error,expected_bit=expected,candidate_bit=bit,correct_admissions=int(passed and bit==expected),wrong_admissions=int(passed and bit!=expected),misses=int(not passed),log_e=op.get('log_e_lower_bound'),threshold=op.get('log_e_threshold'),cpu_seconds=r['reception']['cpu_seconds'],preparation_cpu_seconds=r['receiver_preparation']['cpu_seconds'],noise_clipped_samples=r['noise_receipt']['clipped_samples'],execution_pass=r['measurement_execution_pass']))
 if case=='hf' and variant=='planned':
  live=p/'hf-planned-live';lr=read(live/'report.json');lx=read(live/'slot-0-receiver.json');lm=quiet_noise_metrology(live/'capture.stereo.s16le',m,gain=.003,analog_gain=.8414025015631204,offset_frames=48000)
  (p/'live-metrology.json').write_text(json.dumps(lm,indent=2)+'\n')
  ln=lm['bands'][0]['nominal_data_equivalent_cn0_db_hz'];lop=lx['operational'];lb=lx['bit'];passed=lop['passes_conditional_bound']
  assert lr['bridge']['sha256']==r['playback_sha256']
  rows.append(dict(case=case,variant=variant,mode='live',active_seconds=active,tx_helper_data_seconds=rows[-1]['tx_helper_data_seconds'],nominal_psd_cn0_db_hz=ln,matched_data_mean_power=mean,realized_data_cn0_estimate_db_hz=ln+10*math.log10(mean),expected_bit=expected,candidate_bit=lb,correct_admissions=int(passed and lb==expected),wrong_admissions=int(passed and lb!=expected),misses=int(not passed),log_e=lop['log_e_lower_bound'],threshold=lop['log_e_threshold'],cpu_seconds=lr['total_cpu_seconds'],wall_seconds=lr['total_wall_seconds'],audio_discontinuity=lr['transport']['discontinuity'],adc_near_fullscale=lr['stream']['capture']['stereo_near_fullscale'],identical_transmit_pcm_sha256=lr['bridge']['sha256']))
result=dict(schema='triad-duration-brief-comparison-v1',rows=rows,scope='Independent validation seeds; conditional receiver admissions, not physical-null or 99% correct-reception qualification. Different-duration source patterns/calendars and fresh AES draws are not identical waveforms; paired channel seeds alone do not isolate a causal duration effect. Identical saved PCM was used for the HF planned software/live pair.',energy_metrology_scope='Post-score full-signal minus matched Helper-only simulation, including all tails. Live C/N0 uses this known component energy and previously independently measured scalar cable gain 0.8414025015631204 at 1737Hz; frequency response/calibration drift/distortion uncertainty remains. No evaluator component data entered reception.',false_admission_trials=0)
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:print(json.dumps(row))

import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'local-evidence/triad-duration-planner';py='/tmp/triad-weak-env/bin/python'
env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
common=['--case','hf','--sample-rate','6000','--data-if','1725','--data-power-w','4','--helper-power-w','40','--fhss','off','--shaping','auto','--key-seed','2417','--epoch','1793850000']
cases={
 'hf':common+['--base-oscillator','crystal','--shift-oscillator','ic-7100','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--timing-policy','broad','--rf-hz','30000000','--spread-preset','hf-worst','--margin','3','--selective-perturbation','each-65','--rate','36','--added-symbols','10'],
 'flat':common+['--base-oscillator','gpsdo-ocxo','--shift-oscillator','gpsdo-ocxo','--channel-evolution','legacy','--timing-policy','bounded','--rf-hz','500000','--spread-preset','none','--margin','1','--selective-perturbation','off','--rate','100','--added-symbols','1']}
protocol=dict(target_cn0_db_hz=8.,duration_alternatives=2,independent_seeds={'hf':2026112601,'flat':2026112602},bits={'hf':1,'flat':0},arrivals={'hf':-2.2,'flat':.04},cases=cases,scope='Freeze selection and neighbor comparison before waveform/receiver outcomes. Independent public template generation. Same channel seed within duration pair. Fresh AES noise per transmission; exact saved PCM replayed and then transmitted once in live comparison.',source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('tools/triad_duration_model.py'),Path('tools/triad_weak_plan.py'),Path('tools/triad_weak_receiver.py')]})
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
# All forecasts are frozen before any observation is generated.
for name,args in cases.items():
 command=[py,'tools/triad_weak_plan.py','--target-cn0','8','--duration-alternatives','2','--report',str(out/f'{name}-forecast.json'),'--',*args]
 subprocess.run(command,env=env,check=True,timeout=180)
for name,args in cases.items():
 plan=json.loads((out/f'{name}-forecast.json').read_text())['duration_plan']
 for variant in ['planned','neighbor']:
  duration=plan['selected' if variant=='planned' else 'previous_legal']['active_seconds']
  for purpose in ['public','signal']:
   dest=out/f'{name}-{variant}-{purpose}'
   extra=[] if variant=='planned' else ['--seconds',str(duration)]
   if purpose=='public':extra+=['--templates']
   signal=['--seed',str(2026112600 if purpose=='public' else protocol['independent_seeds'][name]),'--bit',str(0 if purpose=='public' else protocol['bits'][name]),'--arrival-seconds',str(0 if purpose=='public' else protocol['arrivals'][name])]
   command=[py,'tools/triad_weak_plan.py','--target-cn0','8','--duration-alternatives','2','--output',str(dest),*extra,'--',*args,*signal]
   started=time.time();r=subprocess.run(command,env=env,text=True,capture_output=True,timeout=360)
   (out/f'{dest.name}-prepare.json').write_text(json.dumps(dict(command=command,wall_seconds=time.time()-started,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n')
   print(dest.name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
   if r.returncode:raise SystemExit(r.returncode)

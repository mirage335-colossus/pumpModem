import json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).parent;env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2');receipts=[]
for case,variant in [('hf','neighbor'),('flat','planned'),('flat','neighbor')]:
 cmd=[sys.executable,'tools/triad_hf_noise_measure.py','--public',str(p/f'{case}-{variant}-public'),'--capture',str(p/f'{case}-{variant}-signal'),'--output',str(p/f'{case}-{variant}-replay'),'--target-cn0','8']
 start=time.time();r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=300)
 receipts.append(dict(case=case,variant=variant,command=cmd,returncode=r.returncode,wall_seconds=time.time()-start,stdout=r.stdout,stderr=r.stderr))
 (p/'sample-run-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(case,variant,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
for row in json.loads((p/'energy-control-commands.json').read_text()):
 r=subprocess.run(row['command'],env=env,capture_output=True,text=True,timeout=120);row.update(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 print('energy control',row['case'],row['variant'],r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.stderr)
 receipts.append(row)
(p/'sample-run-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')

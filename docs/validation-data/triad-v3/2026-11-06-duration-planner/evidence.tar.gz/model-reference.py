"""Independent Gaussian-covariance diagnostic, not a waveform/channel simulation."""
import json,sys,math,time,hashlib
from pathlib import Path
import numpy as np
from scipy.linalg import toeplitz,eigvalsh
from scipy.stats import beta
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools'))
from triad_duration_model import plan_from_native,gaussian_prediction,effective_modes
r=Path(__file__).parent
p=json.loads((r/'hf-native-plan.json').read_text())
rows=[];rng=np.random.default_rng(20261126000);trials=100000
start=time.process_time()
for cn,t in [(8.,23.2),(8.,34.8),(8.,46.4),(5.,34.8),(5.,81.2),(5.,92.8)]:
 q=plan_from_native(p,cn,duration_alternatives=2)['true_atom_log_lr_threshold']
 n=512;dt=t/n;lag=np.arange(n)*dt
 corr=np.exp(-.5*(np.pi*.5*lag)**2-.5*p['physics']['relative_phase_diffusion_rad_sqrt_s']**2*lag)
 e=np.maximum(0,eigvalsh(toeplitz(corr),check_finite=False))*dt*10**(cn/10)/2
 e=np.tile(e,2);e=e[e>1e-11]
 misses=0;minimum=math.inf
 for off in range(0,trials,2000):
  scores=rng.exponential(size=(min(2000,trials-off),len(e)))@e-np.log1p(e).sum()
  misses+=int(np.count_nonzero(scores<q));minimum=min(minimum,float(scores.min()))
 modes=effective_modes(t,.5,p['physics']['relative_phase_diffusion_rad_sqrt_s'],2)
 pred=gaussian_prediction(t*10**(cn/10),modes,q)
 ci=[float(beta.ppf(.025,misses,trials-misses+1)) if misses else 0.,float(beta.ppf(.975,misses+1,trials-misses)) if misses<trials else 1.]
 rows.append(dict(cn0=cn,data_seconds=t,threshold=q,prediction=pred,reference_eigenvalues=len(e),energy_trace=float(e.sum()),likelihood_mean=float((e-np.log1p(e)).sum()),misses=misses,trials=trials,miss_probability_ci95=ci))
result=dict(schema='triad-duration-Gaussian-reference-v1',scope='Discretized known covariance with two independently resolved Gaussian-spectrum rays; independent exponential draws. No waveform acquisition, selective modulation, moving delay or audio. Seeded PRNG here is statistical quadrature, not transmitted background noise.',seed=20261126000,points=rows,cpu_seconds=time.process_time()-start,source_sha256=hashlib.sha256((r.parents[1]/'tools/triad_duration_model.py').read_bytes()).hexdigest())
(r/'model-reference.json').write_text(json.dumps(result,indent=2)+'\n')
for a in rows:print(a['cn0'],a['data_seconds'],'model_lower',a['prediction']['modeled_detection_lower_bound'],'reference miss',a['misses']/trials,a['miss_probability_ci95'])
print('CPU',result['cpu_seconds'])

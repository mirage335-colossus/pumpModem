from pathlib import Path
import hashlib,json,tarfile
root=Path('/tmp')
exports=sorted(p for p in root.glob('triad-*') if p.is_dir() and (p/'manifest.json').exists())
files=sorted(p for p in root.glob('triad-*') if p.is_file() and p.suffix in ('.jsonl','.log','.py'))
manifest=[]
for directory in exports:
 for p in sorted(directory.iterdir()):
  if p.is_file():manifest.append({'file':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for p in files+[root/'triad_long']:
 manifest.append({'file':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'triad-remote-artifacts-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(root/'triad-remote-metadata.tgz','w:gz') as archive:
 for p in files+[root/'triad-remote-artifacts-manifest.json']:
  archive.add(p,arcname=p.name)
 for directory in exports:
  archive.add(directory/'manifest.json',arcname=directory.name+'/manifest.json')
with tarfile.open(root/'triad-raw-export-backup.tgz','w:gz') as archive:
 for directory in exports:archive.add(directory,arcname=directory.name)
 archive.add(root/'triad_long',arcname='triad_long')
print(json.dumps({'exports':len(exports),'metadata_bytes':(root/'triad-remote-metadata.tgz').stat().st_size,'raw_backup_bytes':(root/'triad-raw-export-backup.tgz').stat().st_size}))

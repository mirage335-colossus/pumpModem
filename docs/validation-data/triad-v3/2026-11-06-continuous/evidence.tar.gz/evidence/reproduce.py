#!/usr/bin/env python3
"""Focused CPU reproductions. Run from the repository root; no automatic campaign.
Use the qualified Python environment with NumPy, SciPy and CPU PyTorch.
"""
import argparse, json, os, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('case', choices=['two-hours','flat-holdout','noise-holdout','hf-random-valid-options','helper-null-valid-options','long-export','vlf38-cn40','vlf38-cn44','vlf38-cn46','vlf38-null'])
p.add_argument('--output', type=Path, required=True)
p.add_argument('--dry-run', action='store_true')
a=p.parse_args(); evidence=Path(__file__).resolve().parent
if a.output.exists(): p.error('use a new output path')
a.output.parent.mkdir(parents=True,exist_ok=True)
if a.case=='long-export' or a.case.startswith('vlf38-'):
    receipt=evidence/('long/export-38d/manifest.json' if a.case=='long-export' else 'long/'+a.case+'.json')
    args=json.loads(receipt.read_text())['command_argv']
    args[0]=str(Path('build/dev-cli/triad_long').resolve())
    if a.case=='long-export': args[args.index('--output')+1]=str(a.output)
else:
    receipt=json.loads((evidence/(a.case+'.json')).read_text())
    native=receipt['command'][1:]; native=native[:native.index('--stream-server')]
    bank=evidence/('bank-hf.json' if a.case in ('hf-random-valid-options','helper-null-valid-options') else 'bank-flat.json')
    args=[sys.executable,'tools/triad_continuous.py','--bank',str(bank),'--report',str(a.output)]
    if a.case=='two-hours': args+=['--coherences','inf','--block-seconds','1','--chunk-samples','8192']
    else: args+=['--block-seconds','.25'] # frozen original holdout block size
    args+=['--',*native]
print(json.dumps(args),flush=True)
if not a.dry_run:
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
    if a.case.startswith('vlf38-'):
        with a.output.open('x') as out: subprocess.run(args,env=env,stdout=out,check=True)
    else: subprocess.run(args,env=env,check=True)

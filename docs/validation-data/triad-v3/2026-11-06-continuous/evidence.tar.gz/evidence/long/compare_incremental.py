import hashlib, json, math, resource, time
from pathlib import Path
import numpy as np
import torch
from triad_dynamic_joint import ProjectedJointReceiver
from triad_incremental_receiver import IncrementalGaussianReceiver

root=Path('local-evidence/triad-multiday/long/export-38d')
m=json.loads((root/'manifest.json').read_text()); n=m['observation_shape'][0]; fs=m['sample_rate']
raw=np.memmap(root/m['observation_file'],dtype='<c16',mode='r',shape=(n,))
valid=np.memmap(root/m['validity_file'],dtype='u1',mode='r',shape=(n,))
allb=np.memmap(root/m['basis_file'],dtype='<c16',mode='r',shape=tuple(m['basis_shape']))
def basis(start,stop):
 x=np.zeros((3,1,2,stop-start),np.complex128)
 x[1,0]=allb[2,start:stop,:].T
 x[2,0]=allb[3,start:stop,:].T
 return x
report=dict(schema='triad-38day-incremental-vs-batch-v1',sample_count=n,sample_rate_hz=fs,physical_duration_seconds=n/fs,block_samples=m['block_samples'],noise_variance=m['noise_variance_pre_frontend'],full_bank=['known public epoch, arrival0.05s,CFO0,clock0; matched two-ray basis delay5us/Doppler.001Hz; both bits'],source_status='native encrypted waveform and sampled path; one public timing/CFO/clock/epoch position, not blind acquisition',results=[])
torch.set_num_threads(1);torch.backends.cuda.matmul.allow_tf32=False;torch.set_float32_matmul_precision('highest')
for precision in ('fp32','fp64'):
 common=dict(sample_rate=fs,samples=n,block_samples=m['block_samples'],basis=basis,required_bands=((-0.0015,0.0015),),noise_variance=m['noise_variance_pre_frontend'],stationary_power=(.5,.5),coherence_seconds=(.5,2.,math.inf),candidate_count=1,projection_mode='valid-rows',precision=precision,memory_limit_bytes=256*1024**2)
 t=time.perf_counter(); batch=ProjectedJointReceiver(**common); prepared=time.perf_counter()-t
 t=time.perf_counter(); expected=batch.score(raw); batch_elapsed=time.perf_counter()-t
 stream=IncrementalGaussianReceiver(**common,maximum_input_chunk_samples=4096)
 cursor=0;t=time.perf_counter()
 while cursor<n:
  stop=min(n,cursor+4096);stream.push(cursor,raw[cursor:stop],valid[cursor:stop]);cursor=stop
 actual=stream.finish();stream_elapsed=time.perf_counter()-t
 batch_bits=np.asarray(expected['bit_scores']).reshape(-1,2)[0]; online_bits=np.asarray(actual['bit_scores']).reshape(2)
 expected_ev=np.asarray(expected['hypothesis_log_evidence']).reshape(-1,3); online_ev=np.asarray(actual['hypothesis_log_evidence']).reshape(-1,3)
 report['results'].append(dict(precision=precision,batch_preparation_seconds=prepared,batch_scoring_seconds=batch_elapsed,incremental_total_seconds=stream_elapsed,incremental_push_cpu_seconds=actual['push_process_cpu_seconds'],block_updates=actual['blocks'],incremental_working_bytes=actual['working_bytes_estimate'],observation_complete=actual['complete_observation'],batch_hypothesis_log_evidence=expected_ev.tolist(),incremental_hypothesis_log_evidence=online_ev.tolist(),batch_bit_scores=batch_bits.tolist(),incremental_bit_scores=online_bits.tolist(),max_absolute_bit_score_difference=float(np.abs(batch_bits-online_bits).max()),max_absolute_evidence_difference=float(np.abs(expected_ev-online_ev).max()),candidate_bit=int(np.argmax(batch_bits)),matched_decision=int(np.argmax(batch_bits))==int(np.argmax(online_bits)),peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
report['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'manifest.json',root/'basis.c128',root/'observation.c128',root/'validity.u8')}
Path('local-evidence/triad-multiday/long/incremental-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

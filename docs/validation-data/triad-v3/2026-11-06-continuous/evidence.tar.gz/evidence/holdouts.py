import json,os,subprocess,sys,time
from pathlib import Path
p=Path('local-evidence/triad-multiday')
bank={'coordinates':[[0,0,0,0]],'taps':[[0,0],[.021,90]],'stationary_power':[.5,.5],'projection':{'required_bands_hz':[[-250,250]],'excluded_bands_hz':[[-1500,-1100]]}}
(p/'bank-hf.json').write_text(json.dumps(bank,indent=2)+'\n')
base=['--case','hf','--sample-rate','6000','--rate','36','--added-symbols','10','--seconds','120','--key-seed','72001','--epoch','1793850000','--base-oscillator','gpsdo-ocxo','--shift-oscillator','gpsdo-ocxo','--oscillator-effects','off','--arrival-seconds','0']
cases=[('flat-holdout','bank-flat.json',['--helper','off','--spread-preset','none','--selective-perturbation','off','--cn0','0','--seed','91001','--bit','1']),('noise-holdout','bank-flat.json',['--helper','off','--data','off','--spread-preset','none','--selective-perturbation','off','--cn0','0','--seed','91002']),('hf-random','bank-hf.json',['--helper','on','--spread-preset','hf-worst','--spread-margin','3','--selective-perturbation','each-65','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--cn0','8','--seed','91003','--bit','1']),('helper-null','bank-hf.json',['--helper','on','--data','off','--spread-preset','hf-worst','--spread-margin','3','--selective-perturbation','each-65','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--cn0','8','--seed','91004'])]
records=[]
for name,b,args in cases:
 command=[sys.executable,'tools/triad_continuous.py','--bank',str(p/b),'--report',str(p/(name+'.json')),'--',*base,*args]
 start=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=120)
 records.append(dict(name=name,command=command,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,wall_seconds=time.perf_counter()-start));print(name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
(p/'holdouts-receipts.json').write_text(json.dumps(records,indent=2)+'\n')

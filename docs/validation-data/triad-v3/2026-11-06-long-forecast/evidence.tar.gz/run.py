import json,sys,os,time,subprocess,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;root=Path.cwd();py='/tmp/triad-weak-env/bin/python'
common=['--case','hf','--sample-rate','6000','--data-if','1725','--data-power-w','4','--helper-power-w','40','--fhss','off','--shaping','auto']
flat=common+['--base-oscillator','gpsdo-ocxo','--shift-oscillator','gpsdo-ocxo','--channel-evolution','legacy','--timing-policy','bounded','--rf-hz','500000','--spread-preset','none','--margin','1','--selective-perturbation','off','--rate','100','--added-symbols','1']
hf=common+['--base-oscillator','crystal','--shift-oscillator','ic-7100','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--timing-policy','broad','--rf-hz','30000000','--spread-preset','hf-worst','--margin','3','--selective-perturbation','each-65','--rate','36','--added-symbols','10']
vlf=['--case','hf','--sample-rate','24000','--data-if','8270','--rf-hz','0','--data-power-w','.001','--helper-power-w','.01','--fhss','off','--shaping','auto','--base-oscillator','gpsdo-ocxo','--shift-oscillator','baseband-clock','--channel-evolution','stochastic','--random-doppler-width-hz','.001','--spread-preset','sub9-best','--margin','1','--selective-perturbation','each-65','--timing-policy','bounded','--rate','.01','--added-symbols','1']
cases=[('stable-40',-40,flat,[]),('stable-50',-50,flat,[]),('stable-60',-60,flat,[]),('hf-16',-16,hf,[]),('hf-20',-20,hf,[]),('hf-30-limit',-30,hf,[]),('vlf-30',-30,vlf,[]),('vlf-60-limit',-60,vlf,[]),('vlf-38days',-60,vlf,['--days','38']),('burst-38days',-60,flat+['--burst-wait-tiles','3'],['--days','38']),('spread1000-38days',-60,vlf+['--added-symbols','1000'],['--days','38']),('ten-years',-60,flat,['--days','3652','--max-active-days','3653'])]
protocol=dict(cases=cases,source_sha256={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path('tools/triad_duration_model.py'),Path('tools/triad_weak_plan.py'),Path('tools/triad-helper-export.cpp')]},scope='Forecast-only, no waveform generation, no receiver/audio/GPU execution. Statistical prior unchanged; long-grid requirements separately reported.')
(p/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');receipts=[]
env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
for name,cn,args,options in cases:
 command=[py,'tools/triad_weak_plan.py','--target-cn0',str(cn),'--duration-alternatives','2','--report',str(p/(name+'.json')),*options,'--',*args]
 start=time.time();r=subprocess.run(command,env=env,capture_output=True,text=True,timeout=90)
 receipts.append(dict(name=name,command=command,returncode=r.returncode,wall_seconds=time.time()-start,stdout=r.stdout,stderr=r.stderr))
 (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)

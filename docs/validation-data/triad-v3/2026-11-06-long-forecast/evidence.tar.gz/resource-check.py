import sys,subprocess,json,time,resource
from pathlib import Path
p=Path(__file__).parent
if len(sys.argv)>1:
 seconds=int(sys.argv[1]);command=['build/dev-cli/triad_helper_export','--case','hf','--plan-only','--seconds',str(seconds),'--sample-rate','6000','--rate','36','--added-symbols','10','--fhss','off']
 start=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=20);usage=resource.getrusage(resource.RUSAGE_CHILDREN);elapsed=time.perf_counter()-start
 out=json.loads(r.stdout);(p/f'native-{seconds}.json').write_text(r.stdout)
 print(json.dumps(dict(requested_active_seconds=seconds,returncode=r.returncode,command=command,timing=dict(wall_seconds=elapsed,user_cpu_seconds=usage.ru_utime,system_cpu_seconds=usage.ru_stime,max_child_rss_kib=usage.ru_maxrss),geometry=out.get('geometry'),geometry_feasible=out.get('geometry_feasible'),serialized_json_bytes=len(r.stdout.encode()),stderr=r.stderr)))
else:
 rows=[]
 for seconds in [3600,86400,3283200,31536000,315576000]:
  r=subprocess.run([sys.executable,__file__,str(seconds)],capture_output=True,text=True,check=True,timeout=25)
  row=json.loads(r.stdout);rows.append(row);print(seconds,row['timing'],row['serialized_json_bytes'])
 (p/'native-resource-check.json').write_text(json.dumps(dict(scope='Separate fresh launcher per case; POSIX child process resource usage, includes executable startup. Single-run engineering observations, not confidence-qualified performance regression.',rows=rows),indent=2)+'\n')

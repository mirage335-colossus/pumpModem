import json,hashlib,shutil,subprocess,tarfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/validation-data/triad-v3/2026-11-06-long-forecast';dest.mkdir(parents=True,exist_ok=True)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
protocol=json.loads((p/'protocol.json').read_text());rows=[]
for name,cn,args,opts in protocol['cases']:
 r=json.loads((p/(name+'.json')).read_text());d=r['duration_plan'];l=d.get('long_span_diagnostics') or {};selected=d.get('selected');native=r['native'].get('selected_duration_plan')or{}
 rows.append(dict(name=name,target_cn0_db_hz=cn,status=d['status'],active_seconds=d['active_seconds'],active_days=l.get('selected_active_days'),elapsed_days=l.get('selected_elapsed_days'),energy_n0=l.get('modeled_active_data_energy_n0'),detection_lower_bound=None if selected is None else selected['modeled_detection_lower_bound'],availability=r['availability'],native_geometry=native.get('geometry'),full_span_grid_resolution_compatible=l.get('full_span_grid_resolution_compatible'),full_coherent_design_reference=l.get('full_coherent_design_reference'),conditional_operation_null_bound=l.get('whole_message_conditional_null_union_bound'),null_accounting_horizon_seconds=l.get('admission_accounting_horizon_seconds')))
for name in ['triad-long-forecast-configure.log','triad-long-forecast-build.log','triad-long-forecast-build-retry.log','triad-long-forecast-configure-final.log','triad-long-forecast-build-final.log']:
 src=Path('/tmp')/name
 if src.exists():shutil.copy2(src,p/name)
notes=dict(initial_build_failure='ccache read-only filesystem; identical build succeeded with CCACHE_DISABLE=1',initial_resource_setup_failure='/usr/bin/time unavailable; fresh-launcher resource.getrusage(RUSAGE_CHILDREN) used instead',initial_native_test_failure='test expected nonzero for1e90; native correctly returned geometry_feasible=false; assertion corrected, source semantics preserved',native_long_ctest=dict(name='triad_helper_plan_long',passed=True,seconds=.74,source='Observed CTest tool output in task; standalone worker rerun0.44s before CTest registration'),scope='No sampled long waveform, receiver, audio or cloud execution. Pre-review reporting changes did not change chosen durations.')
(p/'setup-and-test-notes.json').write_text(json.dumps(notes,indent=2)+'\n')
sources=[Path(x) for x in ['CMakeLists.txt','tools/triad-helper-export.cpp','tools/triad_duration_model.py','tools/triad_weak_plan.py','tests/test_triad_helper_plan_long.py','tests/test_triad_duration_model.py','tests/test_triad_weak_plan.py']]
summary=dict(schema='triad-long-forecast-qualification-v1',base_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256={str(f):digest(f) for f in sources},binary_sha256=digest(Path('build/dev-cli/triad_helper_export')),rows=rows,focused_tests=json.loads((p/'focused-tests.json').read_text()),native_resources=json.loads((p/'native-resource-check.json').read_text()),qualification=dict(native_geometry=True,multi_day_receiver=False,physical_null=False,correct_probability=False),scope='Provisional matched-atom forecasts with checked long native geometry; finer synchronization design counts remain separate from the original charged likelihood grid.')
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(p/'summary.json',dest/'summary.json')
files=sorted(f for f in p.rglob('*') if f.is_file() and f.suffix in ('.json','.py','.log') and '__pycache__' not in f.parts)
with tarfile.open(dest/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)))
 for f in sources:tar.add(f,arcname='source/'+str(f))
(dest/'SHA256SUMS').write_text('\n'.join(digest(dest/f)+'  '+f for f in ['summary.json','evidence.tar.gz'])+'\n')
print('Packaged',len(rows),'forecasts;',len(files),'raw evidence files;', (dest/'evidence.tar.gz').stat().st_size,'archive bytes')

"""Recover two released source-template measurements; never rescore receivers."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspace/broad-raw-v3');output=Path('/workspace/raw-source-energy-recovered')
output.mkdir(exist_ok=False)
for name in ('eme1p5-10ms-independent-raw','eme1200-physical-10ms-raw'):
    old=root/name
    trial=json.loads((old/'trials.jsonl').read_text().splitlines()[0])
    folder=output/name;folder.mkdir()
    target=folder/'calibration-0000';command=list(trial['export_command'])
    command[command.index('--output')+1]=str(target)
    with (folder/'export.log').open('x') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
    m=json.loads((target/'manifest.json').read_text());path=target/m['templates']['file']
    h=hashlib.sha256()
    with path.open('rb')as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    expected=json.loads((old/'prepared.json').read_text())
    if h.hexdigest()!=expected['1']['template_sha256']:raise RuntimeError('source identity mismatch')
    (folder/'prepared.json').write_text(json.dumps(expected))
    (folder/'recovery.json').write_text(json.dumps(dict(original_cohort=name,command=command,template_sha256=h.hexdigest(),scope='Only source-template evidence regenerated after optional observer stopped on a reused-template manifest; original receiver results unchanged.'),indent=2))
subprocess.run(['/workspace/triad-env/bin/python','/workspace/source_energy_v2.py','--campaign',str(output),'--output','/workspace/source-energy-raw-recovered.jsonl'],check=True)
for path in output.rglob('*'):
    if path.suffix in ('.c128','.u8'):path.unlink()

#!/usr/bin/env python3
"""Bounded actual CPU/CUDA receiver parity; synthetic fixture, no admission claim.

Run from the repository (or pass --root) with --output NEW_JSON. --cpu-only
validates the fixture/FP32 reference locally and explicitly leaves CUDA untested.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time


def digest_bytes(value):
    return hashlib.sha256(value).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path.cwd())
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cpu-only', action='store_true')
    args = p.parse_args()
    root = args.root.resolve()
    sys.path.insert(0, str(root / 'tools'))
    import numpy as np
    import scipy
    import torch
    from triad_helper_receiver import HelperDataReceiver, data_fir_taps

    if args.output.exists():
        raise FileExistsError('output already exists')
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    if not args.cpu_only and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but unavailable; no CPU substitution')
    cuda_initialization_seconds=None
    if not args.cpu_only:
        initialize=time.perf_counter(); torch.cuda.init(); torch.cuda.synchronize()
        cuda_initialization_seconds=time.perf_counter()-initialize
    source_paths = ['tools/triad_helper_receiver.py', 'tools/triad_helper_fft.py',
                    'tools/triad_live_receiver.py', 'tools/triad_fft_acquire.py',
                    'tools/triad_gaussian_window.py']
    sources = {name: digest_bytes((root/name).read_bytes()) for name in source_paths}
    result = dict(schema='triad-helper-bounded-cuda-parity-v1',
        script_sha256=digest_bytes(Path(__file__).read_bytes()), source_sha256=sources,
        environment=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
            torch=torch.__version__, cuda_runtime=torch.version.cuda, cpu_threads=torch.get_num_threads(),
            cuda_available=torch.cuda.is_available(), cuda_tested=not args.cpu_only,
            cuda_initialization_seconds=cuda_initialization_seconds,
            gpu=torch.cuda.get_device_name(0) if not args.cpu_only else None),
        arithmetic=dict(bulk=['CPU fp64', 'CPU fp32'] + ([] if args.cpu_only else ['CUDA fp32']),
            fp32_matmul_precision=torch.get_float32_matmul_precision(), tf32_allowed=False,
            sensitive_work='maintained cached FP64 Gram/whitening/residual/evidence; no arithmetic policy change'),
        tolerances=dict(likelihood_absolute=.005, likelihood_relative=5e-5,
            rank_policy='Every hypothesis pair separated in the FP64 reference by more than twice its numerical allowance must preserve order; numerically unresolved pairs are counted, not forced.'),
        scope='Actual maintained batched receiver, continuous full-capture FIR and known ADC masks; synthetic keyed-like two-bit alternatives, finite public epoch/clock/CFO/arrival banks. No Helper estimation, encrypted waveform, calibrated admission, sustained-performance or speedup qualification.',
        initial_stress_diagnostic=dict(cpu_fp64_bit0=6012104.873142817, cpu_fp32_bit0=6010257.282320373, absolute_error=6012104.873142817-6010257.282320373, relative_error=(6012104.873142817-6010257.282320373)/6012104.873142817, original_gate_passed=False, interpretation='High-SNR residual-sensitive working likelihood; retained as a numerical diagnostic, not a communications-reliability or software-failure conclusion.'),
        cases=[])
    fs, raw_rows, source_rows = 18000, 54000, 36000
    source_times = np.arange(source_rows, dtype=np.float64)/fs
    duration = (source_rows-1)/fs
    def analytic(position, epoch, bit):
        support = (position >= 0) & (position <= duration)
        envelope = np.sin(np.pi*position/duration)**2 * support
        frequency = (55., 145.)[bit] + 19*epoch
        return envelope*np.exp(2j*np.pi*frequency*position)*(1+.35*np.cos(2*np.pi*(13+3*epoch)*position))
    templates = np.asarray([[analytic(source_times,e,b) for b in (0,1)] for e in (0,1)])
    lower, upper = -.0003, .0197
    lead, offset, delay, doppler = .1, .2, 9.5/fs, 6.
    arrival = lower + 8/900
    times = np.arange(raw_rows, dtype=np.float64)/fs
    def synchronize(device):
        if device.startswith('cuda'): torch.cuda.synchronize(device)
    def measured(call, device):
        synchronize(device); started=time.perf_counter(); answer=call(); synchronize(device)
        return answer, time.perf_counter()-started
    def compact(score):
        return dict(bit=score['bit'], bit_log_likelihoods=score['bit_log_likelihoods'],
            opposite_bit_margin=score['opposite_bit_margin'], best_epoch_offset_seconds=score['best_epoch_offset_seconds'],
            best_group_public_parameters=score['best_group_public_parameters'],
            hypothesis_bit_log_likelihoods=[{k:v for k,v in h.items() if k in ('epoch','clock_ppm','doppler_scale','bit_log_likelihoods')}
                for h in score['hypothesis_bit_log_likelihoods']],
            arithmetic=score['arithmetic'], geometry=score['geometry'], resources=score['resources'],
            valid_data_output_samples=score['preprocessing']['known_erasure_support']['valid_output_samples']
                if 'known_erasure_support' in score['preprocessing'] else None)
    def compare(reference, candidate, *, enforce):
        x=np.asarray(reference['bit_log_likelihoods']); y=np.asarray(candidate['bit_log_likelihoods'])
        hx=np.asarray([h['bit_log_likelihoods'] for h in reference['hypothesis_bit_log_likelihoods']])
        hy=np.asarray([h['bit_log_likelihoods'] for h in candidate['hypothesis_bit_log_likelihoods']])
        assert np.isfinite(y).all() and np.isfinite(hy).all(), 'nonfinite working likelihood'
        if enforce:
            np.testing.assert_allclose(y,x,atol=.005,rtol=5e-5)
            np.testing.assert_allclose(hy,hx,atol=.005,rtol=5e-5)
        assert candidate['bit']==reference['bit'], 'winning bit changed'
        assert candidate['best_epoch_offset_seconds']==reference['best_epoch_offset_seconds'], 'epoch changed'
        checked=unresolved=disagreements=0
        flat_x,flat_y=hx.ravel(),hy.ravel()
        for i in range(len(flat_x)):
            for j in range(i):
                allowance=.005+5e-5*max(abs(flat_x[i]),abs(flat_x[j]))
                if abs(flat_x[i]-flat_x[j])>2*allowance:
                    same=np.sign(flat_x[i]-flat_x[j])==np.sign(flat_y[i]-flat_y[j])
                    disagreements+=int(not same)
                    if enforce: assert same, 'resolved hypothesis rank reversed'
                    checked+=1
                else: unresolved+=1
        return dict(likelihood_gate_enforced=enforce, maximum_bit_likelihood_relative_error=float(np.max(abs(y-x)/np.maximum(abs(x),1e-30))),
            maximum_bit_likelihood_absolute_error=float(np.max(abs(y-x))),
            maximum_hypothesis_likelihood_absolute_error=float(np.max(abs(hy-hx))),
            checked_resolved_rank_pairs=checked,numerically_unresolved_rank_pairs=unresolved,resolved_rank_disagreements=disagreements,
            same_best_parameters=reference['best_group_public_parameters']==candidate['best_group_public_parameters'])
    start=time.perf_counter()
    try:
        for mask_name, gap_rows, bit, epoch, clock, cfo, angle, noise_amplitude, stress in [
            ('none',0,0,0,0.,-8.,.27,1.,False), ('10ms',180,1,1,-300.,1.234,-1.13,1.,False),
            ('400ms',7200,1,0,300.,8.,2.41,1.,False),
            ('high-snr-stress',0,0,0,0.,-8.,.27,.05,True)]:
            rate=1+clock*1e-6
            direct=analytic((times-lead-arrival-offset/rate)*rate,epoch,bit)
            echo=analytic((times-lead-arrival-delay-offset/rate)*rate,epoch,bit)
            means=((1.2+.3j)*direct+(.6-.4j)*echo*np.exp(2j*np.pi*doppler*(times-lead)))
            rng=np.random.default_rng(88110+gap_rows)
            raw=means*np.exp(1j*angle+2j*np.pi*cfo*(times-lead))+noise_amplitude*(rng.normal(size=raw_rows)+1j*rng.normal(size=raw_rows))
            valid=np.ones(raw_rows,np.uint8)
            if gap_rows:valid[11700:11700+gap_rows]=0
            raw[valid==0]=0
            for lag_step in ((1,) if stress else (1,4)):
                case=dict(mask=mask_name,lag_step=lag_step,raw_rows=raw_rows,source_rows=source_rows,
                    true_bit=bit,true_epoch=epoch,true_clock_ppm=clock,true_cfo_hz=cfo,true_phase_radians=angle,
                    fractional_ray_delay_raw_samples=9.5,raw_erased_rows=int((valid==0).sum()),
                    noise_amplitude_per_real_component=noise_amplitude,numerical_stress=stress,
                    observation_sha256=digest_bytes(raw.tobytes()),validity_sha256=digest_bytes(valid.tobytes()),backends={})
                outcomes={}
                backends=[('cpu-fp64','cpu','fp64'),('cpu-fp32','cpu','fp32')]
                if not args.cpu_only:backends.append(('cuda-fp32','cuda:0','fp32'))
                for name,device,precision in backends:
                    mark=time.perf_counter()
                    rx=HelperDataReceiver(templates,(0,1),source_offset_seconds=offset,capture_lead_seconds=lead,
                        capture_rows=raw_rows,arrival_bounds_seconds=(lower,upper),delay_seconds=delay,doppler_hz=doppler,
                        reference_variance=(.001 if stress else 2*noise_amplitude**2*float(np.sum(data_fir_taps()**2))),frequency_offsets=(-8.,0.,1.234,8.),precision=precision,device=device,
                        fft_backend='batched',lag_step=lag_step,clock_ppm_values=(-300.,0.,300.),
                        frequency_batch_size=3,max_cached_hypotheses=6,memory_limit_bytes=512*1024**2,
                        capture_validity=None if gap_rows==0 else valid)
                    prepared=rx.prepare_observation(raw,valid=None if gap_rows==0 else valid)
                    synchronize(device)
                    construction_and_filter=time.perf_counter()-mark
                    cold,cold_wall=measured(lambda:rx.score_prepared(prepared),device)
                    assert cold['bit']==bit, 'reference fixture bit failure'
                    resident=[]
                    for _ in range(2):
                        replay,wall=measured(lambda:rx.score_prepared(prepared),device)
                        assert replay['bit_log_likelihoods']==cold['bit_log_likelihoods'], 'resident replay changed score'
                        resident.append(wall)
                    case['backends'][name]=dict(construction_and_filter_seconds=construction_and_filter,
                        first_score_including_lazy_preparation_seconds=cold_wall,
                        cold_complete_seconds=construction_and_filter+cold_wall,
                        synchronized_resident_score_seconds=resident,
                        complete_mask_output=rx._validity_metadata,
                        outcome=compact(cold))
                    outcomes[name]=cold
                    del rx,prepared
                case['comparisons']={'cpu-fp32_vs_fp64':compare(outcomes['cpu-fp64'],outcomes['cpu-fp32'],enforce=not stress)}
                if not args.cpu_only:
                    case['comparisons'].update({'cuda-fp32_vs_cpu-fp64':compare(outcomes['cpu-fp64'],outcomes['cuda-fp32'],enforce=not stress),
                        'cuda-fp32_vs_cpu-fp32':compare(outcomes['cpu-fp32'],outcomes['cuda-fp32'],enforce=not stress)})
                result['cases'].append(case)
                print(json.dumps({'mask':mask_name,'lag_step':lag_step,'status':'passed'}),flush=True)
        assert sources=={name:digest_bytes((root/name).read_bytes()) for name in source_paths}, 'source changed during run'
        result.update(status='passed',wall_seconds=time.perf_counter()-start,
            timing_scope='Synchronized construction/FIR, first lazy-preparation scoring, two resident scoring replays separately; excludes Python/library imports and fixture synthesis; one-time CUDA initialization is reported separately. Tiny workloads are not speed benchmarks.')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        with args.output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    except Exception as error:
        result.update(status='failed', wall_seconds=time.perf_counter()-start,
            error_type=type(error).__name__, error=str(error).replace(str(root), '<repo>'))
        if 'case' in locals() and (not result['cases'] or result['cases'][-1] is not case):
            result['incomplete_case']=case
        args.output.parent.mkdir(parents=True,exist_ok=True)
        if not args.output.exists():
            with args.output.open('x') as stream:
                json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
        raise



if __name__=='__main__': main()

import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import sys,json,time,gc
from pathlib import Path
import numpy as np
import torch
torch.set_num_threads(2)
sys.path.insert(0,str(Path.cwd()/'tools'))
from triad_helper_receiver import HelperDataReceiver,data_fir_taps
root=Path.cwd();base=root/'local-evidence/triad-helper-broad/inference';d=root/'local-evidence/triad-shaping/known-channel/wrong-seed98041-auto-1725/bit0';m=json.loads((d/'manifest.json').read_text());tm=json.loads((base/'templates/manifest.json').read_text());tmeta=tm['templates'];templates=np.memmap(base/'templates'/tmeta['file'],mode='r',dtype='<c16',shape=tuple(tmeta['shape']));y=np.memmap(d/m['observation']['file'],mode='r',dtype='<c16',shape=tuple(m['observation']['shape']));prior=json.loads((root/'local-evidence/triad-shaping/gpu/results/auto1725-physical/signal-0022/result.json').read_text());frequencies=prior['assistance']['selected_frequencies'];c=m['calendar'];rows=[]
for step in [4,1]:
 started=time.perf_counter();receiver=HelperDataReceiver(templates,tmeta['epoch_offsets_seconds'],source_offset_seconds=c['data_sample_offset']/m['sample_rate_hz'],capture_lead_seconds=c['capture_lead_seconds'],capture_rows=c['capture_samples'],arrival_bounds_seconds=c['arrival_prior_seconds'],delay_seconds=m['channel']['spread_delay_ms']*.001,doppler_hz=m['channel']['spread_doppler_hz'],reference_variance=m['power']['complex_noise_variance']*float(np.sum(data_fir_taps()**2)),frequency_offsets=frequencies,precision='fp32',device='cpu',fft_backend='batched',lag_step=step,max_cached_hypotheses=1,memory_limit_bytes=2*1024**3)
 prepared=receiver.prepare_observation(y);result=receiver.score_prepared(prepared);rows.append({'lag_step':step,'result':result,'wall_seconds':time.perf_counter()-started});print(json.dumps({'step':step,'bit':result['bit'],'scores':result['bit_log_likelihoods'],'best':result['best_group_public_parameters'],'wall_seconds':rows[-1]['wall_seconds']}),flush=True);del receiver,prepared;gc.collect()
(base/'timing-lattice.json').write_text(json.dumps({'schema':'triad-helper-full13epoch-timing-diagnostic-v1','source':'actual DATA-only native same98041realization; five Helper-selected CFOs copied from frozen composite result, all13epochs','post_outcome_diagnostic':True,'rows':rows},indent=2)+'\n')

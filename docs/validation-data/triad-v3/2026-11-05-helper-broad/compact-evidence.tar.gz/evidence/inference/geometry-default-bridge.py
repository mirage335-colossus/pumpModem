from pathlib import Path
import sys,json,hashlib
import numpy as np
import torch
torch.set_num_threads(1)
sys.path.insert(0,str(Path.cwd()/'tests'));sys.path.insert(0,str(Path.cwd()/'tools'))
from test_triad_helper_receiver import source_templates,receiver,capture
rows=[]
for backend in ['legacy','batched']:
 for precision in ['fp32','fp64']:
  t=source_templates(2,rows=1800);r=receiver(t,fft_backend=backend,precision=precision)
  y=capture(t,r,bit=1,epoch=1,lag=13,frequency=8.);p=r.prepare_observation(y);o=r.score_prepared(p)
  rows.append({'backend':backend,'precision':precision,'samples_sha256':hashlib.sha256(p.samples.tobytes()).hexdigest(),'bit':o['bit'],'scores':o['bit_log_likelihoods'],'best':o['best_group_public_parameters']})
p=Path(sys.argv[1]);p.write_text(json.dumps({'receiver_source':hashlib.sha256(Path('tools/triad_helper_receiver.py').read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')

import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import sys,json,time,hashlib,math
from pathlib import Path
import numpy as np
from scipy import signal,linalg
sys.path.insert(0,str(Path.cwd()/'tools'))
from triad_helper_receiver import fractional_delay,clock_warp,data_fir_taps
from triad_fft_acquire import phase
root=Path.cwd();base=root/'local-evidence/triad-helper-broad/inference';folder=root/'local-evidence/triad-shaping/known-channel/wrong-seed98041-auto-1725'
def load(d):
 m=json.loads((d/'manifest.json').read_text());return m,np.memmap(d/m['observation']['file'],mode='r',dtype='<c16',shape=tuple(m['observation']['shape']))
m,y=load(folder/'bit0');_,noise=load(folder/'both-off');_,alt=load(folder/'bit1');truth=json.loads((folder/'bit0/evaluator-truth.json').read_text());tm=json.loads((base/'templates/manifest.json').read_text());ts=np.memmap(base/'templates'/tm['templates']['file'],mode='r',dtype='<c16',shape=tuple(tm['templates']['shape']))[6]
fs=m['sample_rate_hz'];n=len(y);t=np.arange(n,dtype=np.float64)/fs;taps=data_fir_taps();down=20;D=m['channel']['spread_doppler_hz'];delay=m['channel']['spread_delay_ms']*.001
rx=1+truth['rx']['audio_ppm']*1e-6;a=(1+truth['tx']['audio_ppm']*1e-6)/rx;r=1/rx
cfo=(m['channel']['rf_hz']*(truth['tx']['rf_ppm']-truth['rx']['rf_ppm'])+m['channel']['nominal_conversion_if_hz']*(truth['tx']['audio_ppm']-truth['rx']['audio_ppm']))*1e-6/rx
crop=math.floor((m['calendar']['capture_lead_seconds']+m['calendar']['data_sample_offset']/fs+truth['arrival_seconds']-.1)*fs/down)
observations={k:signal.upfirdn(taps,np.asarray(v),down=down)[:(n-1)//down+1][crop:] for k,v in [('observed',y),('clean0',np.asarray(y)-noise),('clean1',np.asarray(alt)-noise),('noise',noise)]}
variance=m['power']['complex_noise_variance']*np.sum(taps**2);rows=[];started=time.perf_counter()
def columns(bit,arr,freq,extended):
 anchor=((m['calendar']['capture_lead_seconds']+arr)/r + m['calendar']['data_sample_offset']/fs/a)*fs
 x=clock_warp(ts[bit],(a-1)*1e6);cols=[];labels=[]
 for ray in (0,1):
  w=fractional_delay(x,anchor+ray*delay/r*fs);w=w[:n];w=np.pad(w,(0,max(0,n-len(w))))
  w*=phase(ray*D*r,t-m['calendar']['capture_lead_seconds']/r)
  for md in (range(3) if extended else [0]):
   z=fractional_delay(w,md/(3*75)/r*fs)[:n]
   for mod in ([0.,-.1*D*r,.1*D*r,-D*r,D*r] if extended else [0.]):
    if md and mod==0:continue
    v=z*phase(freq+mod,t)
    q=signal.upfirdn(taps,v,down=down)[:(n-1)//down+1][crop:]
    cols.append(q);labels.append([ray,md,mod])
 return np.asarray(cols).T,labels
for arr,freq,label in [(truth['arrival_seconds'],cfo,'exact-sync'),(-.019444444444444445,.3087097692493065,'practical-winner-sync')]:
 for extended in (False,True):
  fits=[]
  for bit in (0,1):
   A,labels=columns(bit,arr,freq,extended);u,s,v=linalg.svd(A,full_matrices=False,lapack_driver='gesdd');keep=s>s[0]*1e-7;Q=u[:,keep];fit={}
   for key,value in observations.items():
    c=Q.conj().T@value;explained=float(np.vdot(c,c).real);total=float(np.vdot(value,value).real)
    fit[key]={'explained':explained,'residual':max(0,total-explained),'fraction':explained/total}
   fits.append({'bit':bit,'rank':int(keep.sum()),'singular_values':s.tolist(),'scores':fit})
  rows.append({'alignment':label,'arrival':arr,'cfo':freq,'model':'full26-linear-dispersive-sidebands' if extended else 'static-two-ray','fits':fits,'observed_projection_bit0_minus_bit1_over_noise':(fits[0]['scores']['observed']['explained']-fits[1]['scores']['observed']['explained'])/variance,'clean0_projection_bit0_minus_bit1_over_noise':(fits[0]['scores']['clean0']['explained']-fits[1]['scores']['clean0']['explained'])/variance})
  print(json.dumps(rows[-1]),flush=True)
result={'schema':'triad-helper-gap-known-sync-diagnostic-v1','seed':98041,'post_outcome_diagnostic':True,'rows':rows,'variance_after_filter':variance,'filtered_samples':len(observations['observed']),'true_audio_ratio':a,'true_rx_inverse':r,'true_cfo':cfo,'wall_seconds':time.perf_counter()-started,'notes':['Uses actual native DATA-only I/Q and exact same-noise control; no noise distribution claim for colored FIR output.','Evaluated channel models fit unknown independent complex coefficients; full26 is a linear supermodel of known deterministic 3-delay periodic-AM family, not an optimized physical prior.','Known arrival/CFO/audio and epoch0 are evaluator-assisted diagnostics only.','No operational admissions/calibration or acquisition-completeness claim.']}
(base/'known-sync-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
print('WALL',result['wall_seconds'],flush=True)

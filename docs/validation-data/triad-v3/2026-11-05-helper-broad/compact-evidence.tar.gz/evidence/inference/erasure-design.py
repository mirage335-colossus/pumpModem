import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
from pathlib import Path
import sys,time,json
import numpy as np
from scipy import signal
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path.cwd()/'tests'))
from triad_helper_receiver import data_fir_taps
from triad_live_receiver import EmpiricalReceiver
from test_triad_helper_receiver import source_templates,receiver,capture
rng=np.random.default_rng(98301);n=18000;x=rng.normal(size=n)+1j*rng.normal(size=n);rows=[]
for profile in ['legacy','wide']:
 taps=data_fir_taps(profile);complete=signal.upfirdn(taps,x,down=20)[:(n-1)//20+1]
 for width in [180,7200]:
  valid=np.ones(n,np.uint8);valid[7200:7200+width]=0;damaged=x.copy();damaged[valid==0]=0;filtered=signal.upfirdn(taps,damaged,down=20)[:len(complete)]
  start=time.perf_counter();prefix=np.r_[0,np.cumsum(valid==0,dtype=np.int64)];ids=np.arange(len(complete))*20;mask=(prefix[ids+1]-prefix[np.maximum(0,ids-len(taps)+1)])==0;duration=time.perf_counter()-start
  rows.append({'profile':profile,'tap_count':len(taps),'raw_missing_rows':width,'raw_missing_seconds':width/18000,'output_invalid_rows':int((~mask).sum()),'output_invalid_seconds':int((~mask).sum())/900,'retained_max_difference':float(np.max(abs(complete[mask]-filtered[mask]))),'prefix_mask_seconds':duration})
# Actual downstream masked Gram/FFT path already works with a fixed mask.
templates=source_templates(rows=1800);rx=receiver(templates,frequency_offsets=(0.,));raw=capture(templates,rx,bit=1,lag=8,frequency=0.);p=rx.prepare_observation(raw);mask=np.ones(rx.samples,np.uint8);mask[150:220]=0;child=rx._receivers[0];start=time.perf_counter();masked=EmpiricalReceiver(child._sampled.array('basis.c128'),900,rx.lags,valid=mask,key=child._sampled.key,frequencies=child._sampled.frequencies,reference_variance=rx.reference_variance,frequency_offsets=(0.,),precision='fp64',device='cpu',memory_limit_bytes=64*1024**2,preprocessing_identity='fixed-known-mask-diagnostic');prep=time.perf_counter()-start;z=np.array(p.samples);z[mask==0]=0;answer=masked.score(z)
result={'schema':'triad-helper-erasure-design-probe-v1','fir_checks':rows,'masked_downstream':{'bit':answer['bit'],'expected_bit':1,'working_scores':answer['bit_log_likelihoods'],'mask_valid_count':int(mask.sum()),'workspace_valid_count':masked._workspace.valid_count,'preparation_seconds':prep,'explicit_workspace_bound':masked._workspace.array_bound},'scope':'Design probe only; no Helper adapter production support or admission qualification.'}
Path('local-evidence/triad-helper-broad/inference/erasure-design.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

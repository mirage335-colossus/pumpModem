from pathlib import Path
import numpy as np,json,hashlib,subprocess,sys
root=Path.cwd();base=root/'local-evidence/triad-helper-broad/mask-diagnosis';work=base/'tiny-fixture';work.mkdir(exist_ok=True);controls=work/'controls';controls.mkdir(exist_ok=True);cohort=work/'campaign/eme-missed-10ms';cohort.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(19272);n=18000;t=np.arange(n)/18000;noise=.1*(rng.normal(size=n)+1j*rng.normal(size=n));h=3*np.exp(2j*np.pi*675*t);d0=np.exp(-((t-.4)/.04)**2);d1=d0*np.exp(2j*np.pi*35*t);c=d0+h+noise;valid=np.ones(n,np.uint8);valid[7200:7380]=0;masked=c.copy();masked[valid==0]=0
sha=lambda x:hashlib.sha256(np.asarray(x).tobytes()).hexdigest()
m={'sample_rate_hz':18000,'observation':{'file':'observation.c128','dtype':'<c16','shape':[n]},'validity':{'file':'validity.u8'},'format':{},'calendar':{'capture_samples':n},'channel':{},'power':{'complex_noise_variance':.02},'key_seed':72001,'public_epoch_seconds':1793850000}
for name,values in [('composite',c),('data0',d0+noise),('data1',d1+noise),('helper',h+noise),('noise',noise)]:
 p=controls/name;p.mkdir(exist_ok=True);np.asarray(values,np.complex128).tofile(p/'observation.c128');(p/'manifest.json').write_text(json.dumps(m));(p/'evaluator-truth.json').write_text(json.dumps({'source_bit':0}))
row={'trial':{'id':'signal-0000'},'erasure':{'intervals_seconds':[[.4,.41]],'native':{'observation_sha256':sha(c)}},'input_sha256':sha(masked),'validity_sha256':sha(valid),'variants':{'1':{'assisted':{'best_group_public_parameters':None}}}}
(cohort/'trials.jsonl').write_text(json.dumps(row)+'\n');(cohort/'protocol.json').write_text(json.dumps({'case':{}}))
output=base/'tiny-replay-check.json'
if output.exists():raise RuntimeError('selfcheck output exists; preserve prior run')
command=[sys.executable,str(base/'replay_profiles.py'),'--repo',str(root),'--campaign',str(work/'campaign'),'--controls',str(controls),'--trial','signal-0000','--output',str(output),'--skip-scores'];subprocess.run(command,check=True)
x=json.loads(output.read_text());assert x['exact_native_and_masked_hashes_verified'];assert x['raw_actual_oracle_bit']==0;assert x['component_relative_linearity']<1e-15
assert all(z['retained_fraction']<1 and z['excluded_output_rows']>0 for z in x['frontends'].values())
print('Tiny retained-control replay selfcheck passed; no native generation, hardware receiver or admission claim.')

#!/usr/bin/env python3
"""Reuse exact retained native controls to diagnose conservative FIR mask loss.

Raw scores are paired diagnostic rankings, not new admissions. Each frontend
needs its own frozen null calibration before admission results can be compared.
"""
import argparse,json,hashlib,math,sys,tempfile,time
from pathlib import Path
import numpy as np
from scipy import signal,linalg,special

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()

def load(folder):
 m=json.loads((folder/'manifest.json').read_text());meta=m['observation']
 return m,np.memmap(folder/meta['file'],mode='r',dtype='<c16',shape=tuple(meta['shape']))

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','campaign','controls','output'):p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--cohort',default='eme-missed-10ms');p.add_argument('--trial',required=True)
 p.add_argument('--device',default='cpu');p.add_argument('--memory-limit-bytes',type=int,default=24*1024**3)
 p.add_argument('--skip-scores',action='store_true');p.add_argument('--raw-fixed-sync',action='store_true')
 a=p.parse_args();started=time.perf_counter()
 if a.output.exists():p.error('output exists; retain original evidence and use a new filename')
 sys.path.insert(0,str(a.repo/'tools'))
 from triad_helper_receiver import data_fir_taps,fractional_delay,clock_warp
 from triad_helper_study import HelperComparison,public_clock_grids
 from triad_fft_acquire import phase
 import torch
 torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False;torch.set_float32_matmul_precision('highest')
 cohort=a.campaign/a.cohort;protocol=json.loads((cohort/'protocol.json').read_text());case=protocol['case']
 original=next(x for x in map(json.loads,(cohort/'trials.jsonl').read_text().splitlines()) if x['trial']['id']==a.trial)
 m,raw=load(a.controls/'composite');fs=m['sample_rate_hz'];mask=np.ones(len(raw),np.uint8)
 for lower,upper in original['erasure']['intervals_seconds']:mask[round(lower*fs):round(upper*fs)]=0
 if sha(a.controls/'composite'/m['observation']['file'])!=original['erasure']['native']['observation_sha256']:raise ValueError('original native composite hash mismatch')
 masked=np.array(raw);masked[mask==0]=0
 if hashlib.sha256(masked.tobytes()).hexdigest()!=original['input_sha256']:raise ValueError('original masked observation hash mismatch')
 if hashlib.sha256(mask.tobytes()).hexdigest()!=original['validity_sha256']:raise ValueError('original known mask hash mismatch')
 outcomes={};helper_reused=False
 if not a.skip_scores:
  with tempfile.TemporaryDirectory(prefix='mask-profile-pair-') as temporary:
   folder=Path(temporary);(folder/'manifest.json').write_text(json.dumps(m));masked.tofile(folder/m['observation']['file']);mask.tofile(folder/m['validity']['file'])
   clocks,scales=public_clock_grids(m,case.get('clock_step_ppm',0.),case.get('doppler_scale_count',1))
   comparisons={profile:HelperComparison(folder,a.controls/'data0',device=a.device,precision='fp32',fft_backend='batched',
       frontend_profile=profile,clock_ppm_values=clocks,doppler_scale_values=scales,lag_step=1,
       aligned_fft_grid=True,frequency_batch_size=32,max_cached_hypotheses=13,memory_limit_bytes=a.memory_limit_bytes)
       for profile in ('legacy','wide')}
   first=comparisons['legacy'].prepare_capture(folder);outcomes['legacy']=comparisons['legacy'].score_capture(first)
   wide=comparisons['wide']
   if np.array_equal(wide.frequencies,comparisons['legacy'].frequencies):
    begin=time.perf_counter();prepared=wide.receiver.prepare_observation(masked,valid=mask)
    shared=dict(first,shared_capture_id=wide.shared_capture_id,prepared=prepared,
       shared_preparation_seconds=first['assistance']['wall_seconds']+time.perf_counter()-begin)
    helper_reused=True
   else:shared=wide.prepare_capture(folder)
   outcomes['wide']=wide.score_capture(shared)
   del comparisons
 # Receiver outcomes above consume no evaluator inputs. Post-outcome oracle data follows.
 truth=json.loads((a.controls/'composite/evaluator-truth.json').read_text());truebit=truth['source_bit']
 nm,noise=load(a.controls/'noise');dm0,d0n=load(a.controls/'data0');dm1,d1n=load(a.controls/'data1');hm,hn=load(a.controls/'helper')
 for cm in (nm,dm0,dm1,hm):
  for key in ('format','calendar','channel','power','key_seed','public_epoch_seconds'):
   if cm[key]!=m[key]:raise ValueError('control identity mismatch: '+key)
 d0=np.asarray(d0n)-noise;d1=np.asarray(d1n)-noise;helper=np.asarray(hn)-noise;delta=d1-d0
 reconstruction=(d0 if truebit==0 else d1)+helper+noise
 residual=float(np.linalg.norm(np.asarray(raw)-reconstruction)/np.linalg.norm(raw))
 if residual>1e-12:raise ValueError('component reconstruction failed')
 raw_energy=float(np.vdot(delta,delta).real);raw_retained=float(np.vdot(delta[mask!=0],delta[mask!=0]).real)
 variance=m['power']['complex_noise_variance'];lam=raw_retained/variance
 projection=2*float(np.vdot(delta[mask!=0],noise[mask!=0]).real)/variance
 actual_llr=projection+(lam if truebit else -lam)
 prefix=np.r_[0,np.cumsum(mask==0,dtype=np.int64)];rows=(len(raw)-1)//20+1;indices=np.arange(rows)*20;frontends={}
 for profile in ('legacy','wide'):
  taps=data_fir_taps(profile);valid=prefix[indices+1]==prefix[np.maximum(0,indices-len(taps)+1)]
  y=signal.upfirdn(taps,delta,down=20)[:rows];whole=float(np.vdot(y,y).real);kept=float(np.vdot(y[valid],y[valid]).real)
  frontends[profile]=dict(tap_count=len(taps),fir_support_seconds=len(taps)/fs,raw_missing_rows=int((mask==0).sum()),
     excluded_output_rows=int((~valid).sum()),filtered_bit_distance=whole,retained_filtered_bit_distance=kept,
     retained_fraction=kept/whole,additional_distance_loss_db=10*math.log10(kept/whole),
     complete_filter_energy_relative_to_raw=whole*20/raw_energy,
     independent_noise_proxy_distance_over_variance=kept/(variance*np.sum(taps*taps)),
     proxy_warning='Filtered noise is colored; this proxy is not a formal known-channel error bound.')
 rawfits=[]
 if a.raw_fixed_sync:
  meta=dm0['templates'];templates=np.memmap(a.controls/'data0'/meta['file'],mode='r',dtype='<c16',shape=tuple(meta['shape']))
  rx=1+truth['rx']['audio_ppm']*1e-6;ratio=(1+truth['tx']['audio_ppm']*1e-6)/rx;scale=1/rx;ch=m['channel'];c=m['calendar'];times=np.arange(len(raw))/fs
  cfo=((truth['tx']['rf_ppm']-truth['rx']['rf_ppm'])*ch['rf_hz']+(truth['tx']['audio_ppm']-truth['rx']['audio_ppm'])*ch['nominal_conversion_if_hz'])*1e-6/rx
  align=[('known-sync',dict(arrival_physical_seconds=truth['arrival_seconds'],frequency_hz=cfo,clock_ppm=(ratio-1)*1e6,doppler_scale=scale,epoch_offset_seconds=0))]
  diagnostic=original['variants']['1']['assisted'].get('best_group_public_parameters')
  if diagnostic is not None:align.append(('original-wide-winner',diagnostic))
  for name,pars in align:
   rate=1+pars.get('clock_ppm',0.)*1e-6;s=pars.get('doppler_scale',1.);arrival=pars.get('arrival_physical_seconds',pars.get('arrival_seconds',0.))
   anchor=((c['capture_lead_seconds']+arrival)/s+c['data_sample_offset']/fs/rate)*fs
   ei=meta['epoch_offsets_seconds'].index(pars.get('epoch_offset_seconds',0));fits=[]
   for bit in (0,1):
    source=clock_warp(templates[ei,bit],pars.get('clock_ppm',0.));cols=[]
    for ray in (0,1):
     x=fractional_delay(source,anchor+ray*ch['spread_delay_ms']*.001/s*fs)[:len(raw)];x=np.pad(x,(0,len(raw)-len(x)))
     cols.append((x*phase(pars['frequency_hz']+ray*ch['spread_doppler_hz']*s,times))[mask!=0])
    basis=np.asarray(cols).T;u,singular,_=linalg.svd(basis,full_matrices=False);q=u[:,singular>singular[0]*1e-10];values={}
    for label,observation in [('composite',raw),('helper-removed',np.asarray(raw)-helper),('clean-true',d0 if truebit==0 else d1)]:
     vector=np.asarray(observation)[mask!=0];z=q.conj().T@vector;energy=float(np.vdot(vector,vector).real);explained=float(np.vdot(z,z).real)
     values[label]=dict(explained=explained,energy=energy,fraction=explained/energy)
    fits.append(dict(bit=bit,rank=q.shape[1],values=values))
   rawfits.append(dict(alignment=name,parameters=pars,fits=fits,
       raw_projection_margin_bit0_minus_bit1_over_noise={k:(fits[0]['values'][k]['explained']-fits[1]['values'][k]['explained'])/variance for k in fits[0]['values']}))
 result=dict(schema='triad-helper-known-gap-frontend-diagnostic-v1',cohort=a.cohort,trial=a.trial,true_bit=truebit,
   exact_native_and_masked_hashes_verified=True,component_relative_linearity=residual,raw_bit_distance=raw_energy,
   raw_masked_bit_distance=raw_retained,raw_distance_loss_db=10*math.log10(raw_retained/raw_energy),
   raw_known_mean_error_probability=.5*math.erfc(.5*math.sqrt(lam)),raw_actual_log_likelihood_bit1_minus_bit0=actual_llr,
   raw_actual_oracle_bit=int(actual_llr>0),frontends=frontends,paired_receiver_outcomes=outcomes,
   common_helper_estimation_reused=helper_reused,raw_fixed_sync_projections=rawfits,wall_seconds=time.perf_counter()-started,
   script_sha256=sha(__file__),receiver_source_sha256=sha(a.repo/'tools/triad_helper_receiver.py'),
   scope='Post-outcome diagnosis of selected failures. Raw oracle knows exact means/synchronization. Paired receiver scores are rankings only; fresh per-frontend null calibration is required for admissions.')
 a.output.parent.mkdir(parents=True,exist_ok=True)
 with a.output.open('x')as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
 print(json.dumps(dict(output=str(a.output),raw_loss_db=result['raw_distance_loss_db'],filtered_losses={k:v['additional_distance_loss_db']for k,v in frontends.items()},receiver_bits={k:{arm:r[arm]['bit']for arm in ('baseline','assisted')}for k,r in outcomes.items()},wall_seconds=result['wall_seconds'])))

if __name__=='__main__':main()

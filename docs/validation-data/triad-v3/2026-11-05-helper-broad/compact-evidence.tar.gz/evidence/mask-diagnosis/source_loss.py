"""Source-only discrimination-energy diagnostic; no new channel/noise realization."""
from pathlib import Path
import sys,json,math,hashlib,time
import numpy as np
from scipy import signal
sys.path.insert(0,str(Path.cwd()/'tools'))
from triad_helper_receiver import data_fir_taps
root=Path.cwd();base=root/'local-evidence/triad-helper-broad/mask-diagnosis';cohort=root/'local-evidence/triad-helper-broad/remote/broad-main/eme-missed-10ms'
source=root/'local-evidence/triad-helper-broad/inference/templates';sm=json.loads((source/'manifest.json').read_text());meta=sm['templates'];template=np.memmap(source/meta['file'],dtype='<c16',mode='r',shape=tuple(meta['shape']));delta=np.asarray(template[6,1])-np.asarray(template[6,0]);rows=[json.loads(line) for line in (cohort/'trials.jsonl').read_text().splitlines()];signals=[x for x in rows if x['trial']['phase']=='signal'];m=json.loads((cohort/signals[0]['trial']['id']/'manifest.json').read_text())
for key in ['key_seed','public_epoch_seconds']:
 assert sm[key]==m[key],key
for key in ['inner_rate_hz','added_symbols','bit_seconds','fine_coefficients','tile_seconds','tile_count','fhss_envelope_only','fhss_center_aligned','pulse_shape','dwell_seconds','quiet_seconds','ramp_seconds','margin_seconds']:
 assert sm['format'][key]==m['format'][key],key
assert sm['power']['template_data_gain']==m['power']['template_data_gain']
fs=m['sample_rate_hz'];n=m['calendar']['capture_samples'];mask=np.ones(n,np.uint8)
for lower,upper in signals[0]['erasure']['intervals_seconds']:mask[round(lower*fs):round(upper*fs)]=0
assert hashlib.sha256(mask.tobytes()).hexdigest()==signals[0]['validity_sha256']
profiles={};outrows=(n-1)//20+1;ids=np.arange(outrows)*20;prefix=np.r_[0,np.cumsum(mask==0,dtype=np.int64)]
for profile in ['legacy','wide']:
 taps=data_fir_taps(profile);valid=prefix[ids+1]==prefix[np.maximum(0,ids-len(taps)+1)]
 profiles[profile]=(taps,valid)
started=time.perf_counter();out=[]
for item in signals+[{'trial':{'id':'zero-arrival-probe'},'variants':{'1':{'evaluator':{'arrival_seconds':0.}}}}]:
 arrival=item['variants']['1']['evaluator']['arrival_seconds'];start=round((m['calendar']['capture_lead_seconds']+arrival)*fs+m['calendar']['data_sample_offset']);x=np.zeros(n,np.complex128);x[start:start+len(delta)]=delta
 energy=float(np.vdot(x,x).real);retained=float(np.vdot(x[mask!=0],x[mask!=0]).real);result={'trial':item['trial']['id'],'arrival_seconds':arrival,'raw_retained_fraction':retained/energy,'raw_distance_loss_db':10*math.log10(retained/energy),'frontends':{}}
 for profile,(taps,valid) in profiles.items():
  y=signal.upfirdn(taps,x,down=20)[:outrows];whole=float(np.vdot(y,y).real);part=float(np.vdot(y[valid],y[valid]).real)
  result['frontends'][profile]={'tap_count':len(taps),'fir_support_seconds':len(taps)/fs,'retained_fraction':part/whole,'distance_loss_db':10*math.log10(part/whole),'missing_output_rows':int((~valid).sum()),'unmasked_filter_energy_relative_to_raw':whole*20/energy}
 out.append(result)
result={'schema':'triad-helper-mask-source-distance-diagnostic-v1','rows':out,'wall_seconds':time.perf_counter()-started,'scope':'Cached actual encrypted bit0/bit1 source templates with matching public source geometry/gain. Arrival is rounded to nearest raw sample. Shared oscillator, delay/Doppler and selective modulation are omitted here; this is a source-only energy diagnostic, not actual-channel sensitivity or admissions.','template_sha256':hashlib.sha256(memoryview(template).cast('B')).hexdigest()}
(base/'source_loss.json').write_text(json.dumps(result,indent=2)+'\n')
for r in out:print(r['trial'],r['arrival_seconds'],r['raw_distance_loss_db'],[(k,v['distance_loss_db'])for k,v in r['frontends'].items()])
print('wall',result['wall_seconds'])

import sys,time,json,hashlib,os
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import torch
from triad_helper_study import HelperComparison, public_clock_grids
torch.set_num_threads(2)
torch.set_float32_matmul_precision('highest')
torch.backends.cuda.matmul.allow_tf32=False
fixture=Path('/workspace/cache-pilot-fixture')
output=Path('/workspace/cache-pilot-results')
output.mkdir(exist_ok=False)
m=json.loads((fixture/'manifest.json').read_text())
clocks,scales=public_clock_grids(m,100,3)
start=time.perf_counter()
c=HelperComparison(fixture,device='cuda:0',precision='fp32',fft_backend='batched',
    frontend_profile='wide',clock_ppm_values=clocks,doppler_scale_values=scales,
    frequency_batch_size=32,max_cached_hypotheses=400,memory_limit_bytes=64*1024**3,
    aligned_fft_grid=True,lag_step=1)
info=dict(clock_values=list(clocks),rate_values=list(scales),
    constructor_wall_seconds=time.perf_counter()-start,procedure_id=c.procedure_id,
    source_hashes=c.sources,template_sha256=c.template_hash,
    scope='Two same-capture CPU-preparation/CUDA-score cache probes, concurrent with a mostly native-generation campaign; descriptive timings, not independent admissions or isolated performance anchors.')
(output/'prepared.json').write_text(json.dumps(info,indent=2))
for i in range(2):
    torch.cuda.synchronize();begin=time.perf_counter()
    r=c.score(fixture)
    torch.cuda.synchronize()
    r['cache_pilot']=dict(replay=i,wall_seconds=time.perf_counter()-begin,
      cuda_allocated=torch.cuda.memory_allocated(),cuda_reserved=torch.cuda.memory_reserved(),
      peak_cuda_allocated=torch.cuda.max_memory_allocated(),peak_cuda_reserved=torch.cuda.max_memory_reserved())
    (output/f'score-{i}.json').write_text(json.dumps(r,indent=2,allow_nan=False))
    print(json.dumps(r['cache_pilot']),flush=True)

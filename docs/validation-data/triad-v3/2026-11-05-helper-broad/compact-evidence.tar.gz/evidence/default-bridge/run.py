from pathlib import Path
import hashlib,json,subprocess,time
root=Path.cwd()
out=root/'local-evidence/triad-helper-broad/default-bridge'
old=root/'local-evidence/triad-helper-broad/bin/exporter-before'
new=root/'build/dev-cli/triad_helper_export'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
source_names=['tools/triad-helper-export.cpp','src/triad_modem_v3.cpp','src/triad_shaping.cpp','src/triad_simulation_stream.cpp','src/helper_carrier.cpp','include/datapump/triad_modem_v3.hpp','include/datapump/triad_shaping.hpp','src/channel_perturbation.hpp','src/channel_spread.hpp','src/tuning_presets.cpp']
start=time.perf_counter()
result={'schema':'triad-helper-generalized-config-default-byte-bridge-v1','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'old_binary_sha256':sha(old),'new_binary_sha256':sha(new),'current_source_sha256':{p:sha(root/p) for p in source_names},'scope':'Same-seed default HF and EME seconds1 exports; raw observation, validity, complete evaluator truth and selected public format/Helper/calendar comparison. New public physics/topology/power metadata is allowed; no reception or sensitivity claim.','captures':[]}
for case,seed in [('hf',91001),('eme',91002)]:
 rows=[]
 for label,binary in [('old',old),('new',new)]:
  folder=out/f'{case}-{label}'
  cmd=[str(binary),'--case',case,'--seconds','1','--seed',str(seed),'--output',str(folder)]
  before=time.perf_counter(); p=subprocess.run(cmd,text=True,capture_output=True,timeout=30)
  row={'label':label,'command':cmd,'wall_seconds':time.perf_counter()-before,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
  assert p.returncode==0,row
  row['sha256']={name:sha(folder/name) for name in ['observation.c128','validity.u8','evaluator-truth.json','manifest.json']}
  row['bytes']={name:(folder/name).stat().st_size for name in row['sha256']}
  rows.append(row)
 old_manifest=json.loads((out/f'{case}-old/manifest.json').read_text())
 new_manifest=json.loads((out/f'{case}-new/manifest.json').read_text())
 truths=[json.loads((out/f'{case}-{label}/evaluator-truth.json').read_text()) for label in ('old','new')]
 identities={name:rows[0]['sha256'][name]==rows[1]['sha256'][name] for name in ['observation.c128','validity.u8','evaluator-truth.json']}
 identities.update({name:old_manifest[name]==new_manifest[name] for name in ['format','calendar','helper_plan','templates']})
 identities['entire_evaluator_truth']=truths[0]==truths[1]
 result['captures'].append({'case':case,'seed':seed,'runs':rows,'identities':identities,'samples':old_manifest['calendar']['capture_samples']})
 if not all(identities.values()):
  (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
  raise AssertionError(identities)
result['old_binary_sha256_after']=sha(old);result['new_binary_sha256_after']=sha(new)
assert result['old_binary_sha256_after']==result['old_binary_sha256'] and result['new_binary_sha256_after']==result['new_binary_sha256']
result['wall_seconds']=time.perf_counter()-start
result['result']='passed'
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'result':result['result'],'cases':len(result['captures']),'captures':4,'wall_seconds':result['wall_seconds'],'identities':[x['identities'] for x in result['captures']]}))
# All arrays are reproducible from the source-bound commands and retained hashes.
# Remove only generated bulky arrays; retain manifests/truth/receipts.
for case in ('hf','eme'):
 for label in ('old','new'):
  for name in ('observation.c128','validity.u8'):(out/f'{case}-{label}'/name).unlink()

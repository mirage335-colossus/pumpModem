from pathlib import Path
import hashlib,json,shutil,subprocess,time
root=Path.cwd();base=root/'local-evidence/triad-helper-broad/power-v5-bridge';base.mkdir(exist_ok=False)
old=root/'local-evidence/triad-helper-broad/bin/exporter-window-v4';new=root/'build/dev-cli/triad_helper_export'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=time.perf_counter();records=[]
for case,seed in [('hf',91001),('eme',91002)]:
 out={}
 for name,binary,extra in [('old',old,[]),('legacy',new,['--power-reference','legacy-window']),('old-helper',old,['--data','off']),('whole-helper',new,['--data','off'])]:
  folder=base/(case+'-'+name);command=[str(binary),'--case',case,'--seconds','1','--seed',str(seed),'--output',str(folder),*extra]
  began=time.perf_counter();subprocess.run(command,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  m=json.loads((folder/'manifest.json').read_text());hashes={key:digest(folder/m[key]['file']) for key in ('observation','validity')}
  hashes['evaluator_truth']=digest(folder/m['evaluator_truth_file']);out[name]=hashes
  (folder/'receipt.json').write_text(json.dumps(dict(command=command,binary_sha256=digest(binary),hashes=hashes,wall_seconds=time.perf_counter()-began),indent=2)+'\n')
  for suffix in ('*.c128','*.u8'):
   for p in folder.glob(suffix):p.unlink()
 checks={'legacy_observation_exact':out['old']['observation']==out['legacy']['observation'],'legacy_validity_exact':out['old']['validity']==out['legacy']['validity'],'helper_only_observation_exact':out['old-helper']['observation']==out['whole-helper']['observation'],'helper_only_validity_exact':out['old-helper']['validity']==out['whole-helper']['validity']}
 records.append(dict(case=case,checks=checks,hashes=out));assert all(checks.values()),records[-1]
result=dict(schema='triad-helper-power-v5-byte-bridge-v1',result='passed',records=records,wall_seconds=time.perf_counter()-start,scope='Exact composite I/Q and validity in legacy mode, and Helper+noise I/Q under default DATA-power correction. Evaluator metadata hashes retained but not required equal; source reference metadata changed. No receiver sensitivity claim.')
(base/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

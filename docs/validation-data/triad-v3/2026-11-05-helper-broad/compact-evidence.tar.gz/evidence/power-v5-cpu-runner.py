from pathlib import Path
import json,os,resource,signal,subprocess,time
base=Path('local-evidence/triad-helper-broad')
command=['/tmp/triad-weak-env/bin/python','tools/triad_helper_broad_campaign.py','--exporter','build/dev-cli/triad_helper_export','--protocol',str(base/'power-v5-protocol.json'),'--output',str(base/'local-power-v5'),'--device','cpu','--memory-limit-bytes',str(7*1024**3),'--frequency-batch-size','8','--max-cached-hypotheses','13','--export-timeout-seconds','240']
env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
start=time.perf_counter();status='completed'
with (base/'power-v5-cpu.log').open('x')as stream:
 p=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  status='timeout';os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
r=resource.getrusage(resource.RUSAGE_CHILDREN)
result=dict(status=status,returncode=code,wall_seconds=time.perf_counter()-start,max_child_rss_kib=r.ru_maxrss,child_user_seconds=r.ru_utime,child_system_seconds=r.ru_stime,command=command,numerical_threads=2,timeout_seconds=1200,scope='Bounded local CPU qualification; source generation, Python startup, preparation, receiver work and finalization included. ru_maxrss is process high-water accounting, not sum of concurrent process RSS.')
(base/'power-v5-cpu-resources.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
raise SystemExit(code if status=='completed' else 124)

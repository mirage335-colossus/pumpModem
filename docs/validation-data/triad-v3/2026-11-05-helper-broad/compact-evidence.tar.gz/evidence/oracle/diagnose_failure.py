#!/usr/bin/env python3
"""Post-outcome exact-noise oracle and projection diagnostic; never an admission receiver.

Five matched native controls reconstruct one previously scored signal capture.
Public known erasures are replayed from retained intervals, independent of truth.
All channel/oscillator truth is used solely in the explicitly labelled diagnostic.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import time
import numpy as np
from scipy import linalg,signal,special,stats


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def array_sha(values):return hashlib.sha256(memoryview(np.ascontiguousarray(values)).cast('B')).hexdigest()

def native_command(original,exporter,output,data,helper,bit,templates=False):
    tail=[];i=1
    while i<len(original):
        flag=original[i]
        if flag in ('--output','--data','--helper','--bit'):i+=2
        elif flag=='--templates':i+=1
        else:tail.append(flag);i+=1
    return [str(exporter),*tail,'--output',str(output),'--data',data,'--helper',helper,'--bit',str(bit)]+(['--templates'] if templates else [])


def load_capture(folder):
    m=json.loads((folder/'manifest.json').read_text());t=json.loads((folder/'evaluator-truth.json').read_text())
    meta=m['observation']
    if meta['dtype']!='<c16' or len(meta['shape'])!=1:raise ValueError('unsupported native raw representation')
    path=folder/meta['file']
    if path.stat().st_size!=meta['shape'][0]*16:raise ValueError('incomplete raw capture')
    return m,t,np.memmap(path,mode='r',dtype='<c16',shape=tuple(meta['shape']))


def replay_mask(manifest,receipt):
    mask=np.ones(manifest['calendar']['capture_samples'],np.uint8);fs=manifest['sample_rate_hz']
    for lower,upper in receipt.get('intervals_seconds',[]):
        first,past=round(lower*fs),round(upper*fs)
        if not 0<=first<past<=len(mask):raise ValueError('retained erasure interval leaves capture')
        mask[first:past]=0
    return mask


def binary_metrics(data0,data1,noise,actual,helper,true_bit,variance,valid):
    """Known complex means, raw independent CN(0,variance), equal bit priors."""
    keep=np.asarray(valid)!=0;delta=np.asarray(data1)[keep]-np.asarray(data0)[keep]
    distance=float(np.vdot(delta,delta).real);lam=distance/variance
    residual=np.asarray(actual)[keep]-np.asarray(data0)[keep]-np.asarray(helper)[keep]
    llr=(2*float(np.vdot(delta,residual).real)-distance)/variance
    theoretical=.5*math.erfc(.5*math.sqrt(lam))
    return dict(valid_rows=int(keep.sum()),distance_energy=distance,distance_over_variance=lam,
        known_mean_error_probability=theoretical,log_known_mean_error_probability=float(special.log_ndtr(-math.sqrt(lam/2))),
        actual_log_likelihood_bit1_minus_bit0=llr,actual_oracle_bit=int(llr>0),actual_oracle_correct=int(llr>0)==true_bit,
        theoretical_99percent_amplitude_energy_multiplier=2*float(stats.norm.ppf(.99))**2/lam if lam else None,
        theoretical_90percent_amplitude_energy_multiplier=2*float(stats.norm.ppf(.90))**2/lam if lam else None,
        noise_projection_twice_over_variance=2*float(np.vdot(delta,np.asarray(noise)[keep]).real)/variance)


def projection_report(root,source_manifest,templates,data0,data1,actual,helper,noise,truth,manifest,variant,arm,raw_mask):
    sys.path.insert(0,str(root/'tools'))
    from triad_helper_receiver import data_fir_taps,clock_warp,fractional_delay
    from triad_fft_acquire import phase
    channel,calendar=manifest['channel'],manifest['calendar'];fs=manifest['sample_rate_hz'];n=len(actual)
    profile=variant.get('preprocessing',{}).get('profile')
    if profile is None:
        profile='wide' if variant['baseline'].get('preprocessing',{}).get('pass_edge_hz')==400 else 'legacy'
    # Compact campaign records omit preprocessing; cohort profile is injected by caller.
    profile=variant.get('diagnostic_frontend_profile',profile)
    taps=data_fir_taps(profile);rows=(n-1)//20+1;times=np.arange(n,dtype=np.float64)/fs
    prefix=np.r_[0,np.cumsum(raw_mask==0,dtype=np.int64)];ids=np.arange(rows)*20
    valid=prefix[ids+1]==prefix[np.maximum(0,ids-len(taps)+1)]
    vectors={name:signal.upfirdn(taps,np.asarray(value),down=20)[:rows][valid]
             for name,value in [('data0',data0),('data1',data1),('actual',actual),('actual_helper_removed',np.asarray(actual)-helper),('noise',noise)]}
    rx=1+truth['rx']['audio_ppm']*1e-6;audio=(1+truth['tx']['audio_ppm']*1e-6)/rx;scale=1/rx
    cfo=((truth['tx']['rf_ppm']-truth['rx']['rf_ppm'])*channel['rf_hz']+
         (truth['tx']['audio_ppm']-truth['rx']['audio_ppm'])*channel['nominal_conversion_if_hz'])*1e-6/rx
    alignments=[('known-sync',dict(arrival_physical_seconds=truth['arrival_seconds'],frequency_hz=cfo,
        clock_ppm=(audio-1)*1e6,doppler_scale=scale,epoch_offset_seconds=truth['source_epoch_offset_seconds']))]
    practical=variant[arm].get('best_group_public_parameters')
    if practical is not None:alignments.append(('practical-winner',practical))
    result=[]
    for label,parameters in alignments:
        epoch=int(parameters.get('epoch_offset_seconds',0));ei=source_manifest['templates']['epoch_offsets_seconds'].index(epoch)
        clock=parameters.get('clock_ppm',0.);rate=1+clock*1e-6;r=parameters.get('doppler_scale',1.)
        arrival=parameters.get('arrival_physical_seconds',parameters.get('arrival_seconds',0.))
        anchor=((calendar['capture_lead_seconds']+arrival)/r+calendar['data_sample_offset']/fs/rate)*fs
        fit=[]
        for bit in (0,1):
            x=clock_warp(templates[ei,bit],clock);columns=[]
            for ray in (0,1):
                wide=fractional_delay(x,anchor+ray*channel['spread_delay_ms']*.001/r*fs)[:n]
                wide=np.pad(wide,(0,max(0,n-len(wide))))
                wide*=phase(parameters['frequency_hz']+ray*channel['spread_doppler_hz']*r,times)
                columns.append(signal.upfirdn(taps,wide,down=20)[:rows][valid])
            basis=np.asarray(columns).T;u,s,_=linalg.svd(basis,full_matrices=False);q=u[:,s>s[0]*1e-10]
            values={}
            for name,value in vectors.items():
                coeff=q.conj().T@value;explained=float(np.vdot(coeff,coeff).real);energy=float(np.vdot(value,value).real)
                values[name]=dict(explained_energy=explained,residual_energy=max(0.,energy-explained),
                    explained_fraction=explained/energy if energy else None)
            fit.append(dict(bit=bit,rank=q.shape[1],projections=values))
        result.append(dict(alignment=label,parameters=parameters,fits=fit))
    return dict(frontend_profile=profile,fir_taps=len(taps),valid_filtered_rows=int(valid.sum()),alignments=result,
        limitations=['Post-outcome synchronization diagnostics; public templates and arbitrary two complex ray coefficients.',
                    'Explained fractions measure model mismatch; reference filtered noise is colored, so projection scores are not formal likelihood or admission bounds.'])


def self_check():
    rng=np.random.default_rng(87301);d0=rng.normal(size=128)+1j*rng.normal(size=128);d1=d0.copy();d1[20:40]+=1j
    noise=.1*(rng.normal(size=128)+1j*rng.normal(size=128));h=3*(rng.normal(size=128)+1j*rng.normal(size=128))
    for bit in (0,1):
        actual=(d0 if bit==0 else d1)+h+noise;mask=np.ones(128,np.uint8);mask[30:35]=0
        result=binary_metrics(d0,d1,noise,actual,h,bit,.02,mask)
        delta=(d1-d0)[mask!=0];a=(actual-d0-h)[mask!=0]
        direct=(np.vdot(a,a).real-np.vdot(a-delta,a-delta).real)/.02
        if abs(result['actual_log_likelihood_bit1_minus_bit0']-direct)>1e-9:raise AssertionError('LLR disagreement')
        if not result['actual_oracle_correct']:raise AssertionError('easy known means incorrectly decoded')
    original=['old','--case','eme','--output','old-dir','--bit','1','--data','on','--helper','on','--templates']
    command=native_command(original,'new',Path('new-dir'),'off','off',0)
    assert command==['new','--case','eme','--output','new-dir','--data','off','--helper','off','--bit','0']
    print(json.dumps(dict(self_check='passed',scope='LLR, mask and command reconstruction arithmetic only; no native capture run.')))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('campaign','exporter','output'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--cohort');parser.add_argument('--trial');parser.add_argument('--lag',default='1');parser.add_argument('--arm',choices=('baseline','assisted'),default='assisted')
    parser.add_argument('--max-wall-seconds',type=float,default=30.);parser.add_argument('--projection',action='store_true')
    parser.add_argument('--retain-arrays',action='store_true');parser.add_argument('--self-check',action='store_true')
    args=parser.parse_args()
    if args.self_check:self_check();return
    if not all((args.campaign,args.exporter,args.output,args.cohort,args.trial)):parser.error('campaign/exporter/output/cohort/trial required')
    if args.output.exists():parser.error('output already exists; refusing overwrite or silent retry')
    if not math.isfinite(args.max_wall_seconds) or args.max_wall_seconds<=0:parser.error('positive finite wall budget required')
    folder=args.campaign/args.cohort;protocol=json.loads((folder/'protocol.json').read_text())
    selected=next(x for x in map(json.loads,(folder/'trials.jsonl').read_text().splitlines()) if x['trial']['id']==args.trial)
    if selected['trial']['phase']!='signal' or 'decisions' not in selected['variants'][args.lag]:raise ValueError('frozen scored signal outcome required')
    # Practical decisions are already persisted; only now inspect source truth.
    original_truth=json.loads((folder/args.trial/'evaluator-truth.json').read_text());true_bit=original_truth['source_bit']
    exporter=args.exporter.resolve(strict=True)
    if sha(exporter)!=protocol['exporter_sha256']:raise ValueError('exporter binary differs from original frozen cohort')
    args.output.mkdir(parents=True);started=time.perf_counter();captures={};receipts=[];stage='exports';current_command=None;current_name=None
    plan=[('composite','on','on',true_bit),('data0','on','off',0),('data1','on','off',1),('helper','off','on',true_bit),('noise','off','off',true_bit)]
    try:
        for name,data,helper,bit in plan:
            target=args.output/name;command=native_command(selected['export_command'],exporter,target,data,helper,bit,args.projection and name=='data0')
            current_command,current_name=command,name
            remaining=args.max_wall_seconds-(time.perf_counter()-started)
            if remaining<=0:raise TimeoutError('planned native observation diagnostic wall budget exhausted')
            begin=time.perf_counter()
            with (args.output/(name+'.log')).open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=remaining)
            m,t,values=load_capture(target);captures[name]=(m,t,values)
            receipts.append(dict(name=name,command=command,wall_seconds=time.perf_counter()-begin,
                templates_sha256=sha(target/m['templates']['file']) if m['templates']['enabled'] else None,
                manifest_sha256=sha(target/'manifest.json'),truth_sha256=sha(target/'evaluator-truth.json'),
                observation_sha256=sha(target/m['observation']['file']),validity_sha256=sha(target/m['validity']['file'])))
        m,t,actual=captures['composite'];sigma=m['power']['complex_noise_variance'];mask=replay_mask(m,selected['erasure'])
        for key in ('format','calendar','channel','power','helper_plan','key_seed','public_epoch_seconds'):
            for cm,_,_ in captures.values():
                if cm[key]!=m[key]:raise ValueError('control public identity mismatch: '+key)
        for key in ('source_epoch_offset_seconds','arrival_seconds','tx','rx','random_seed_roots'):
            for _,ct,_ in captures.values():
                if ct[key]!=t[key]:raise ValueError('control physical/noise identity mismatch: '+key)
            if t[key]!=original_truth[key]:raise ValueError('original physical identity mismatch: '+key)
        native_expected=selected['erasure']['native']['observation_sha256']
        if receipts[0]['observation_sha256']!=native_expected:raise ValueError('actual native composite raw hash does not reproduce')
        replay=np.array(actual);replay[mask==0]=0
        if array_sha(replay)!=selected['input_sha256']:raise ValueError('post-erasure practical raw hash does not reproduce')
        noise=captures['noise'][2];helper=np.asarray(captures['helper'][2])-noise
        data0=np.asarray(captures['data0'][2])-noise;data1=np.asarray(captures['data1'][2])-noise
        rebuilt=(data0 if true_bit==0 else data1)+helper+noise
        linearity=float(np.linalg.norm(np.asarray(actual)-rebuilt)/max(np.linalg.norm(actual),np.finfo(float).tiny))
        if linearity>1e-12:raise ValueError('matched component superposition is not linear')
        stage='analysis';energy=[]
        for bit,data in enumerate((data0,data1)):
            _,dt,_=captures['data'+str(bit)];channel_report=dt['channel_report'];selective=channel_report.get('selective_perturbation')
            emitted=dt['source_energy']['data_energy_samples'];received=float(np.vdot(data,data).real)
            before=selective['pre_selective_energy_samples'] if selective else channel_report['signal_energy_samples']
            energy.append(dict(bit=bit,emitted_data_energy=emitted,pre_selective_data_energy=before,
                received_data_energy=received,reported_post_selective_data_energy=selective['post_selective_energy_samples'] if selective else None,
                selective_energy_change_db=10*math.log10(received/before) if before and received else None,
                full_received_over_emitted_db=10*math.log10(received/emitted) if emitted and received else None))
        variant=dict(selected['variants'][args.lag]);variant['diagnostic_frontend_profile']=protocol['case'].get('frontend_profile','legacy')
        projection=dict(status='not-requested')
        if args.projection:
            remaining=args.max_wall_seconds-(time.perf_counter()-started)
            if remaining<8:projection=dict(status='not-run',reason='less than8seconds of planned wall budget remains')
            else:
                dm=captures['data0'][0];meta=dm['templates'];path=args.output/'data0'/meta['file']
                templates=np.memmap(path,mode='r',dtype='<c16',shape=tuple(meta['shape']))
                root=Path(__file__).resolve().parents[3]
                if not (root/'tools/triad_helper_receiver.py').is_file():
                    root=Path.cwd()
                projection=projection_report(root,dm,templates,data0,data1,actual,helper,noise,t,m,variant,args.arm,mask)
                projection.update(status='completed',template_sha256=sha(path))
        result=dict(schema='triad-helper-broad-post-outcome-oracle-v1',status='completed',selected=dict(cohort=args.cohort,trial=args.trial,lag=args.lag,arm=args.arm),
            selection='Post-outcome focused diagnostic; not independent validation or an operational receiver.',
            practical=selected['variants'],source_bit=true_bit,raw_native_hash_exact=True,post_erasure_hash_exact=True,
            full_capture=binary_metrics(data0,data1,noise,actual,helper,true_bit,sigma,np.ones(len(mask),np.uint8)),
            known_raw_mask=binary_metrics(data0,data1,noise,actual,helper,true_bit,sigma,mask),
            raw_mask_missing_rows=int((mask==0).sum()),component_relative_linearity_residual=linearity,
            data_energy=energy,helper_received_energy=float(np.vdot(helper,helper).real),projection=projection,
            captures=receipts,exporter_sha256=sha(exporter),script_sha256=sha(__file__),wall_seconds=time.perf_counter()-started,
            formula='Pe=Q(sqrt(||mean1-mean0||^2/(2*sigma2))); known complete complex channel/oscillator trajectory and synchronization, equal bit priors, independent raw CN(0,sigma2).',
            limits=['Oracle sees all retained raw rows; practical FIR discards an expanded set around known gaps.',
                    'Energy multipliers scale fixed known means in amplitude; they are not demonstrated transmission durations.',
                    'Selective energy accounting uses actual DATA-only channel reports without renormalizing received fades.',
                    'Control reconstruction and exact noise are diagnostic truth, never practical receiver inputs.'])
    except Exception as error:
        result=dict(schema='triad-helper-broad-post-outcome-oracle-v1',status='failed',stage=stage,current_control=current_name,attempted_command=current_command,error_type=type(error).__name__,error=str(error),captures=receipts,automatic_retry=False,wall_seconds=time.perf_counter()-started)
    (args.output/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    if not args.retain_arrays:
        for target in args.output.iterdir():
            if target.is_dir():
                for path in list(target.glob('*.c128'))+list(target.glob('*.u8')):path.unlink()
    print(json.dumps(dict(status=result['status'],wall_seconds=result['wall_seconds'],output=str(args.output))))
    if result['status']!='completed':raise SystemExit(2)


if __name__=='__main__':main()

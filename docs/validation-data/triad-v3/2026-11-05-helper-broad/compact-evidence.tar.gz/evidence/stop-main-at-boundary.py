"""Bound the paired full-bank campaign before the unqualified crystal-cost regime."""
from pathlib import Path
import datetime,json,os,signal,time
root=Path('/workspace/broad-main');pid=6288
trigger=root/'hf8-each-10-checkpoint.json'
deadline=datetime.datetime(2026,11,5,6,15,tzinfo=datetime.timezone.utc).timestamp()
while not trigger.exists():
    if (root/'summary.json').exists():raise SystemExit('main already completed')
    if time.time()>deadline:raise SystemExit('boundary watch timed out without modifying the campaign')
    time.sleep(1)
command=Path(f'/proc/{pid}/cmdline').read_bytes()
if b'triad_helper_broad_campaign.py' not in command or b'/workspace/broad-main' not in command:
    raise RuntimeError('PID identity changed; no signal sent')
children=[]
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:
        status=(entry/'status').read_text()
        ppid=int(next(x.split()[1] for x in status.splitlines() if x.startswith('PPid:')))
        if ppid==pid and b'triad_helper_export' in (entry/'cmdline').read_bytes():children.append(int(entry.name))
    except (OSError,StopIteration,ValueError):pass
os.kill(pid,signal.SIGTERM)
for child in children:
    try:os.kill(child,signal.SIGTERM)
    except ProcessLookupError:pass
time.sleep(2)
protocol=json.loads((root/'protocol.json').read_text())
summaries={}
for case in protocol['cohorts']:
    path=root/(case['id']+'-checkpoint.json')
    if path.exists():summaries[case['id']]=json.loads(path.read_text())
    else:
        trials=root/case['id']/'trials.jsonl'
        count=len(trials.read_text().splitlines()) if trials.exists() else 0
        summaries[case['id']]=dict(status='interrupted' if (root/case['id']).exists() else 'not-run',
            completed_scored_rows=count,reason='Paired full-bank cost regime stopped before qualification; new assisted-only protocol and measured cache policy required.',
            automatic_retry=False)
result=dict(schema='triad-helper-external-budget-boundary-stop-v1',status='interrupted',
    interrupted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cohorts=summaries,
    trigger=trigger.name,signaled_pid=pid,signaled_native_children=children,
    reason='A bounded full-bank cache pilot exposed substantial runtime; do not repeat unqualified full baseline work for every Helper-enabled capture.',
    scope='External orchestration receipt, not a successful harness completion. Existing completed cohort records and source identities are unchanged.')
(root/'external-interruption.json').write_text(json.dumps(result,indent=2)+'\n')
with (root/'summary.json').open('x') as stream:json.dump(result,stream,indent=2)
print(json.dumps(dict(status='interrupted-at-resource-boundary',cohorts=len(summaries))),flush=True)

# Saved-cohort audit

| Cohort | Lag | Arm | Signal N | Correct | Wrong | Miss | Raw bit errors | Null admitted/N |
|---|---:|---|---:|---:|---:|---:|---:|---:|
| hf-crystal-ic7100-bounded-assisted-only | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| shared-crystal-500k-assisted-only | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 1/4 |
| shift-cb-500k-assisted-only | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| shift-crystal-500k-assisted-only | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 1/4 |
| rate3p6-cache-bound-fixed | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| aurora165-public-spectrum-fixed | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| aurora165-public-spectrum-fixed | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| eme-1p5-independent-key | 1 | baseline | 8 | 7 | 0 | 1 | 0 | 0/8 |
| eme-1p5-independent-key | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-1p5-independent-key | 4 | baseline | 8 | 5 | 0 | 3 | 1 | 0/8 |
| eme-1p5-independent-key | 4 | assisted | 8 | 6 | 0 | 2 | 0 | 0/8 |
| eme-physical-independent-key | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-physical-independent-key | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-physical-independent-key | 4 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-physical-independent-key | 4 | assisted | 8 | 8 | 0 | 0 | 0 | 2/8 |
| eme1200-double | 1 | baseline | 16 | 11 | 0 | 5 | 1 | 1/16 |
| eme1200-double | 1 | assisted | 16 | 12 | 0 | 4 | 2 | 1/16 |
| eme1200-minus6 | 1 | baseline | 16 | 0 | 0 | 16 | 5 | 0/16 |
| eme1200-minus6 | 1 | assisted | 16 | 0 | 1 | 15 | 9 | 3/16 |
| eme1200-short | 1 | baseline | 16 | 6 | 1 | 9 | 9 | 1/16 |
| eme1200-short | 1 | assisted | 16 | 4 | 2 | 10 | 6 | 2/16 |
| eme1p5-duration-105p6 | 1 | baseline | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme1p5-duration-105p6 | 1 | assisted | 16 | 16 | 0 | 0 | 0 | 3/16 |
| eme1p5-duration-158p4 | 1 | baseline | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme1p5-duration-158p4 | 1 | assisted | 16 | 16 | 0 | 0 | 0 | 0/16 |
| hf-minus6-double | 1 | baseline | 8 | 3 | 0 | 5 | 1 | 1/8 |
| hf-minus6-double | 1 | assisted | 8 | 3 | 0 | 5 | 1 | 1/8 |
| hf-minus6-quadruple | 1 | baseline | 8 | 7 | 0 | 1 | 0 | 1/8 |
| hf-minus6-quadruple | 1 | assisted | 8 | 7 | 0 | 1 | 0 | 1/8 |
| hf-minus60-helper6-if4000 | 1 | baseline | 8 | 1 | 1 | 6 | 4 | 0/8 |
| hf-minus60-helper6-if4000 | 1 | assisted | 8 | 1 | 1 | 6 | 4 | 0/8 |
| hf8-independent-key | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| hf8-independent-key | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| rate10-sub9worst-if1725 | 1 | baseline | 8 | 6 | 0 | 2 | 0 | 1/8 |
| rate10-sub9worst-if1725 | 1 | assisted | 8 | 6 | 0 | 2 | 0 | 1/8 |
| rate1200-if2000 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| rate1200-if2000 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| sub9-if8270-rate10 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| sub9-if8270-rate10 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| sub9-if8270-rate3p6 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| sub9-if8270-rate3p6 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| eme-1p5-timing-pair | 1 | baseline | 16 | 9 | 2 | 5 | 4 | 0/16 |
| eme-1p5-timing-pair | 1 | assisted | 16 | 10 | 3 | 3 | 4 | 0/16 |
| eme-1p5-timing-pair | 4 | baseline | 16 | 7 | 1 | 8 | 6 | 1/16 |
| eme-1p5-timing-pair | 4 | assisted | 16 | 9 | 1 | 6 | 4 | 0/16 |
| eme-burst-three-waits | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| eme-burst-three-waits | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| eme-minus60-fixed-helper | 1 | baseline | 4 | 0 | 2 | 2 | 4 | 1/4 |
| eme-minus60-fixed-helper | 1 | assisted | 4 | 0 | 2 | 2 | 4 | 1/4 |
| eme-missed-10ms | 1 | baseline | 8 | 6 | 2 | 0 | 2 | 0/8 |
| eme-missed-10ms | 1 | assisted | 8 | 6 | 2 | 0 | 2 | 0/8 |
| eme-missed-beginning | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-beginning | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-end | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-end | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-middle-pair | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-middle-pair | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| eme-missed-random3 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-missed-random3 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf-minus6-each65 | 1 | baseline | 8 | 0 | 0 | 8 | 4 | 0/8 |
| hf-minus6-each65 | 1 | assisted | 8 | 0 | 0 | 8 | 4 | 0/8 |
| hf-minus60-fixed-helper | 1 | baseline | 4 | 0 | 0 | 4 | 3 | 0/4 |
| hf-minus60-fixed-helper | 1 | assisted | 4 | 0 | 0 | 4 | 3 | 0/4 |
| hf-physical-each65 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf-physical-each65 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf200-dynamic-range | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf200-dynamic-range | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf6-broad-margin1 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| hf6-broad-margin1 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| hf8-each-10 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 1/4 |
| hf8-each-10 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 1/4 |
| hf8-each-5 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-each-5 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-each1 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-each1 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-each25 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-each25 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-each65 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 1/8 |
| hf8-each65 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 1/8 |
| hf8-each65-duration64 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-each65-duration64 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| hf8-fast-1 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-1 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-10 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-10 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-25 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-25 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-5 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-fast-5 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-off | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 1/4 |
| hf8-off | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 1/4 |
| hf8-slow-1 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-1 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-10 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-10 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-25 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-25 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-5 | 1 | baseline | 4 | 4 | 0 | 0 | 0 | 0/4 |
| hf8-slow-5 | 1 | assisted | 4 | 4 | 0 | 0 | 0 | 0/4 |
| none-independent-each65 | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| none-independent-each65 | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| rate360-flat-off | 1 | baseline | 8 | 8 | 0 | 0 | 0 | 0/8 |
| rate360-flat-off | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme-physical-timing-pair | 1 | baseline | 16 | 16 | 0 | 0 | 0 | 1/16 |
| eme-physical-timing-pair | 1 | assisted | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme-physical-timing-pair | 4 | baseline | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme-physical-timing-pair | 4 | assisted | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme1200-1p5-duration26p4 | 1 | assisted | 16 | 14 | 0 | 2 | 2 | 2/16 |
| eme1200-minus6-duration105p6 | 1 | assisted | 8 | 4 | 0 | 4 | 1 | 0/8 |
| eme-no-loss-paired-control-raw | 1 | assisted | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme10ms-independent-raw | 1 | assisted | 16 | 16 | 0 | 0 | 0 | 0/16 |
| eme10ms-paired-raw | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme1200-physical-10ms-raw | 1 | assisted | 8 | 8 | 0 | 0 | 0 | 0/8 |
| eme1p5-10ms-independent-raw | 1 | assisted | 16 | 15 | 1 | 0 | 1 | 2/16 |

Signal/null denominators and uncertainty, paired changes, exact identities, work counts, energy and timings are in `cohort-audit.json`.

- No DSP rerun or hardware timing inference.
- Paired lag and baseline/assisted arms share captures; never pool as independent samples. Assisted-only evidence contains no baseline reception or measured speedup.
- Initial physical and override cohorts use disjoint seeds. Duration extensions may intentionally reuse short-cohort seeds; overlap is dependence, not corruption or independent validation.
- 19 null calibration captures give minimum rank p=.05. Marginal per-capture exchangeability only; neither fixed-gate conditional 5% nor daily qualification.
- Signal intervals use fixed bit strata and conservative balanced-population bounds; null intervals conditional on frozen gate. Bounds are per named metric, not simultaneous.
- Paired transition counts are descriptive and oracle selection is post hoc diagnosis, never independent validation.
- Static CFO interval coverage does not prove coverage of stochastic paths or calibrated Helper lock.
- Native exporter hash is recorded but remote binary/source build linkage is not independently reconstructed here.

Oracle candidates (frozen evidence; post-hoc diagnostic selection):

- eme-1p5-timing-pair/signal-0003, seed 1901022: {'1/baseline': 'wrong_admitted', '1/assisted': 'wrong_admitted', '4/baseline': 'wrong_admitted', '4/assisted': 'wrong_admitted'}
- eme-1p5-timing-pair/signal-0012, seed 1901031: {'1/baseline': 'wrong_admitted', '1/assisted': 'wrong_admitted', '4/baseline': 'correct_admitted', '4/assisted': 'correct_admitted'}
- eme-missed-10ms/signal-0000, seed 1911019: {'1/baseline': 'wrong_admitted', '1/assisted': 'wrong_admitted'}
- eme-missed-10ms/signal-0001, seed 1911020: {'1/baseline': 'wrong_admitted', '1/assisted': 'wrong_admitted'}
- eme-1p5-timing-pair/signal-0000, seed 1901019: {'1/baseline': 'missed', '1/assisted': 'wrong_admitted', '4/baseline': 'missed', '4/assisted': 'missed'}
- eme1200-short/signal-0007, seed 2509026: {'1/baseline': 'missed', '1/assisted': 'wrong_admitted'}

## Campaign snapshot

- broad-assisted-v3: {'completed': 4, 'failed': 1}; receipt: no explicit completed-campaign status.
- broad-cache-v4: {'completed': 1}; receipt: no explicit completed-campaign status.
- broad-extension-v2: {'completed': 16, 'failed': 1}; receipt: no explicit completed-campaign status.
- broad-main: {'completed': 30, 'failed': 3, 'interrupted': 1, 'not-run': 4}; receipt: interrupted.
- broad-pilot: {'completed': 1}; receipt: no explicit completed-campaign status.
- broad-rate-duration-v3: {'completed': 2}; receipt: no explicit completed-campaign status.
- broad-raw-v3: {'completed': 5}; receipt: no explicit completed-campaign status.

## Power-reference limitations

The following successes are excluded from nominal calendar-average C/N0 sensitivity claims. Their actual source energy exceeds the stated fixed-window reference; this is a transmit-energy convention effect, not demonstrated receiver gain.

- rate3p6-cache-bound-fixed: nominal -6 dB-Hz, actual source calendar/reference mean power +28.262 to +28.264 dB; 160.4 s bit.
- sub9-if8270-rate10: nominal -6 dB-Hz, actual source calendar/reference mean power +6.345 to +6.348 dB; 58 s bit.
- sub9-if8270-rate3p6: nominal -6 dB-Hz, actual source calendar/reference mean power +28.262 to +28.264 dB; 160.4 s bit.

## Dependent paired-seed transitions

| Before | After | Arm | Identical I/Q / shared seeds | Signal transitions | Null transitions |
|---|---|---|---:|---|---|
| eme1200-double | eme1200-1p5-duration26p4 | 1/assisted | 0/51 | {'correct_admitted -> correct_admitted': 12, 'missed -> correct_admitted': 2, 'missed -> missed': 2} | {'rejected_null -> false_admitted': 1, 'false_admitted -> false_admitted': 1, 'rejected_null -> rejected_null': 14} |
| eme1p5-duration-105p6 | eme1p5-duration-158p4 | 1/baseline | 0/51 | {'correct_admitted -> correct_admitted': 16} | {'rejected_null -> rejected_null': 16} |
| eme1p5-duration-105p6 | eme1p5-duration-158p4 | 1/assisted | 0/51 | {'correct_admitted -> correct_admitted': 16} | {'rejected_null -> rejected_null': 13, 'false_admitted -> rejected_null': 3} |
| eme-1p5-timing-pair | eme1p5-duration-105p6 | 1/baseline | 0/51 | {'missed -> correct_admitted': 5, 'correct_admitted -> correct_admitted': 9, 'wrong_admitted -> correct_admitted': 2} | {'rejected_null -> rejected_null': 16} |
| eme-1p5-timing-pair | eme1p5-duration-105p6 | 1/assisted | 0/51 | {'wrong_admitted -> correct_admitted': 3, 'correct_admitted -> correct_admitted': 10, 'missed -> correct_admitted': 3} | {'rejected_null -> rejected_null': 13, 'rejected_null -> false_admitted': 3} |
| eme-1p5-timing-pair | eme1p5-duration-158p4 | 1/baseline | 0/51 | {'missed -> correct_admitted': 5, 'correct_admitted -> correct_admitted': 9, 'wrong_admitted -> correct_admitted': 2} | {'rejected_null -> rejected_null': 16} |
| eme-1p5-timing-pair | eme1p5-duration-158p4 | 1/assisted | 0/51 | {'wrong_admitted -> correct_admitted': 3, 'correct_admitted -> correct_admitted': 10, 'missed -> correct_admitted': 3} | {'rejected_null -> rejected_null': 16} |
| hf-minus6-double | hf-minus6-quadruple | 1/baseline | 0/35 | {'missed -> missed': 1, 'missed -> correct_admitted': 4, 'correct_admitted -> correct_admitted': 3} | {'rejected_null -> rejected_null': 6, 'rejected_null -> false_admitted': 1, 'false_admitted -> rejected_null': 1} |
| hf-minus6-double | hf-minus6-quadruple | 1/assisted | 0/35 | {'missed -> missed': 1, 'missed -> correct_admitted': 4, 'correct_admitted -> correct_admitted': 3} | {'rejected_null -> rejected_null': 6, 'rejected_null -> false_admitted': 1, 'false_admitted -> rejected_null': 1} |
| hf-minus6-each65 | hf-minus6-double | 1/baseline | 0/35 | {'missed -> missed': 5, 'missed -> correct_admitted': 3} | {'rejected_null -> rejected_null': 7, 'rejected_null -> false_admitted': 1} |
| hf-minus6-each65 | hf-minus6-double | 1/assisted | 0/35 | {'missed -> missed': 5, 'missed -> correct_admitted': 3} | {'rejected_null -> rejected_null': 7, 'rejected_null -> false_admitted': 1} |
| hf-minus6-each65 | hf-minus6-quadruple | 1/baseline | 0/35 | {'missed -> missed': 1, 'missed -> correct_admitted': 7} | {'rejected_null -> rejected_null': 7, 'rejected_null -> false_admitted': 1} |
| hf-minus6-each65 | hf-minus6-quadruple | 1/assisted | 0/35 | {'missed -> missed': 1, 'missed -> correct_admitted': 7} | {'rejected_null -> rejected_null': 7, 'rejected_null -> false_admitted': 1} |
| eme-missed-10ms | eme10ms-paired-raw | 1/assisted | 35/35 | {'wrong_admitted -> correct_admitted': 2, 'correct_admitted -> correct_admitted': 6} | {'rejected_null -> rejected_null': 8} |
| eme-no-loss-paired-control-raw | eme10ms-independent-raw | 1/assisted | 0/51 | {'correct_admitted -> correct_admitted': 16} | {'rejected_null -> rejected_null': 16} |

## Saved cost-pilot comparison

Same retained capture and template, no new receptions or admission calibration. Compared sources differ in study wrapper; receiver identity, numerical scores and complete selected banks checked exactly. Concurrency and two replays preclude calibrated timing confidence or diagnosis of warm-stage variation. Native generation/export excluded; command timers include Helper/filter/loading/hashing and scoring, cold constructor added only in explicit stage composition. Earlier paired assisted scores follow full baseline preparation and cannot represent standalone cold cost.

Numerical/bank identity problems: 0.

| State | Paired command seconds | Assisted-only command seconds | Ratio |
|---|---:|---:|---:|
| cold | 420.855 | 89.953 | 4.68 |
| warm | 197.376 | 3.968 | 49.75 |

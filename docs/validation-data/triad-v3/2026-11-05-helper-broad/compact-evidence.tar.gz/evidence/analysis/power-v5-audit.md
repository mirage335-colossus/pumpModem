# Supplemental whole-active power v5 audit

Fresh cohort: 35 captures (19calibration,8signal,8validation-null). 8/8 correct admissions, 0 wrong admissions, 0 misses, 0/8 null admissions.

Actual source mean power is 0.999982451–1.000603131 of the active reference over160.4s at nominal−6dB-Hz. Active/calendar durations coincide; the earlier+28.26dB power inflation is absent. Fixed public-bit0 calibration is shared by all trials.

All35 captures fell back:34 flat_profile and1 insufficient_presence_diagnostic. The original and selected frequency banks both contain3points. This corrected-power reception result demonstrates no Helper search narrowing or Helper sensitivity improvement.

95% conservative fixed-bit balanced correct-reception interval: [0.33437015248821106, 1.0]. The conditional one-sided95% null-admission upper bound is 0.312344; no daily or99% reception claim.

CPU command wall time 697.490s, two numerical threads; child RSS high-water 2695028KiB. This is neither total concurrent RSS nor an isolated hardware speedup benchmark.

All seven saved full-sample power checks pass; largest measured active-power deviation 0.0661%. HF/EME legacy composite and Helper-only recorded byte hashes match. Native v5 hash: 41662b4b302d77821353f03245c8c328362cf5e4a88b774adb204273332dff77.

Independent audit discrepancies: 0. All frozen59-cohort artifacts were unchanged. See power-v5-audit.json for source/input/gate identities, fresh-seed checks, energy sums, uncertainty and bridge limits.

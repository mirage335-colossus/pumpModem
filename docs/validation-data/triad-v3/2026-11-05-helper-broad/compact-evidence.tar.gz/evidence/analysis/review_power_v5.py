#!/usr/bin/env python3
"""Supplemental saved-evidence audit; never rewrites the legacy 59-cohort audit."""
import importlib.util,json,math,pathlib,hashlib,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[3]
BASE=ROOT/'local-evidence/triad-helper-broad'
OUT=BASE/'analysis'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def check(ok,label,problems):
    if not ok:problems.append(label)

def main():
    frozen_files=[OUT/n for n in ('review_cohorts.py','cohort-audit.json','cohort-audit.md','source-energy-recovery-audit.json')]
    before={str(p.relative_to(ROOT)):digest(p) for p in frozen_files}
    spec=importlib.util.spec_from_file_location('legacy_audit',OUT/'review_cohorts.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    folder=BASE/'local-power-v5/rate3p6-corrected-power-independent'
    report,rows=mod.review(folder);problems=list(report['integrity']['problems'])
    protocol=load(folder/'protocol.json');top=load(folder.parent/'protocol.json');frozen=load(BASE/'frozen-v5/sources.json')
    binary=ROOT/top['runtime']['exporter']
    check(digest(binary)==protocol['exporter_sha256']==top['exporter_sha256'],'native binary hash mismatch',problems)
    check(top['input_protocol_sha256']==digest(BASE/'power-v5-protocol.json'),'protocol input hash mismatch',problems)
    frozen_checks={p:digest(ROOT/p)==h for p,h in frozen.items()}
    check(all(frozen_checks.values()),'v5 frozen source/current mismatch',problems)
    with tarfile.open(BASE/'frozen-v5/overlay.tar.gz','r:gz') as archive:
        overlay={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive.getmembers() if m.isfile()}
    overlay_checks={p:overlay.get(p)==h or overlay.get('./'+p)==h for p,h in frozen.items()}
    check(all(overlay_checks.values()),'overlay/source digest mismatch',problems)
    for name in frozen:
        if name in protocol['source_hashes']:check(protocol['source_hashes'][name]==frozen[name],'cohort/frozen source mismatch '+name,problems)
    previous_seeds=set()
    for path in (BASE/'remote').glob('broad-*/protocol.json'):
        for case in load(path).get('cohorts',[]):
            count=sum(case.get(k,0) for k in ('calibration_count','signal_count','null_count'))
            previous_seeds.update(range(case['seed_base'],case['seed_base']+count))
    new_seeds={r['trial']['seed'] for r in rows};overlaps=sorted(previous_seeds&new_seeds)
    check(not overlaps,'seed overlap with earlier planned broad campaigns',problems)
    previous_roots={};prior_truth_files=0
    for path in (BASE/'remote').glob('broad-*/*/*/evaluator-truth.json'):
        prior_truth_files+=1
        for name,value in load(path)['random_seed_roots'].items():previous_roots.setdefault(name,set()).add(value)
    root_overlap={};energy=[];power_policies=set();source_calibrations=set()
    for row in rows:
        p=folder/row['trial']['id'];m=load(p/'manifest.json');t=load(p/'evaluator-truth.json');power=m['power'];fmt=m['format'];e=t['source_energy']
        for name,value in t['random_seed_roots'].items():
            if value in previous_roots.get(name,set()):root_overlap.setdefault(name,[]).append(row['trial']['id'])
        check(power['data_power_reference_policy']=='whole-active','wrong power policy '+row['trial']['id'],problems)
        power_policies.add(power['data_power_reference_policy']);source_calibrations.add((power['data_reference_bit'],power['template_data_gain'],power['post_plan_data_calibration_gain']))
        check(power['data_reference_bit']==0,'source calibration follows transmitted bit',problems)
        if row['trial']['phase']=='signal':
            source_seconds=e['data_energy_samples']/m['sample_rate_hz'];active=power['data_reference_active_seconds'];calendar=fmt['bit_seconds']
            active_norm=source_seconds/active;calendar_norm=source_seconds/calendar
            check(math.isclose(active_norm,e['data_active_mean_norm'],rel_tol=1e-12),'active energy accounting mismatch',problems)
            check(math.isclose(calendar_norm,e['data_calendar_mean_norm'],rel_tol=1e-12),'calendar energy accounting mismatch',problems)
            energy.append(dict(trial=row['trial']['id'],seed=row['trial']['seed'],bit=t['source_bit'],
                source_energy_samples=e['data_energy_samples'],source_energy_seconds=source_seconds,
                active_seconds=active,calendar_seconds=calendar,active_mean_norm=active_norm,calendar_mean_norm=calendar_norm,
                active_power_reference_db=10*math.log10(active_norm),calendar_power_reference_db=10*math.log10(calendar_norm),
                data_energy_over_n0_db=10*math.log10(e['data_energy_samples']/power['complex_noise_variance']),
                nominal_cn0_db_hz=power['data_cn0_db_hz']))
    check(not root_overlap,'RNG root reuse with previously retained broad captures',problems)
    check(len(source_calibrations)==1,'calibration changed by trial/source bit',problems)
    report['energy_scope']='v5 whole-active reference: DATA energy divided by complete active DATA duration, including ramps and excluding FHSS quiet/burst waits; fixed public bit0 gain retained for all source bits. This cohort has no waits/quiet, so active and calendar denominators coincide.'
    qualification=load(BASE/'power-v5-qualification.json');qs=qualification['power_qualification']
    qualification_checks=dict(seven_cases=len(qs)==7,all_commands_succeeded=all(c['returncode']==0 for c in qualification['commands']),
        source_bit0_within_declared_0p3pct=all(abs(q['sampled_active_mean_norm']-1)<=.003 for q in qs if q['source_bit']==0),
        refinement_within_0p1pct=all(q['refinement_relative_difference']<=.001 for q in qs),
        calendar_duty_accounted=all(math.isclose(q['sampled_calendar_mean_norm'],q['sampled_active_mean_norm']*q['active_seconds']/q['elapsed_seconds'],rel_tol=1e-12) for q in qs))
    check(all(qualification_checks.values()),'power qualification receipt check failed',problems)
    bridge=load(BASE/'power-v5-bridge/results.json');bridge_audit=[]
    for case in bridge['records']:
        receipts={};entries={}
        for kind in ('old','legacy','old-helper','whole-helper'):
            p=BASE/'power-v5-bridge'/(case['case']+'-'+kind);receipt=load(p/'receipt.json');m=load(p/'manifest.json')
            check(receipt['hashes']==case['hashes'][kind],'bridge hash summary mismatch '+case['case']+'/'+kind,problems)
            check(digest(p/'evaluator-truth.json')==receipt['hashes']['evaluator_truth'],'bridge truth checksum mismatch',problems)
            actual_binary=pathlib.Path(receipt['command'][0]);check(actual_binary.exists() and digest(actual_binary)==receipt['binary_sha256'],'bridge native identity mismatch',problems)
            if kind in ('legacy','whole-helper'):check(receipt['binary_sha256']==top['exporter_sha256'],'bridge v5 native hash mismatch',problems)
            entries[kind]=dict(receipt=receipt,receipt_sha256=digest(p/'receipt.json'),
                manifest_sha256=digest(p/'manifest.json'),power_reference_policy=m['power'].get('data_power_reference_policy','legacy-window-v4'),data_enabled=m['data_enabled'])
            receipts[kind]=receipt
        comparisons={f'{a}_vs_{b}_{name}':receipts[a]['hashes'][name]==receipts[b]['hashes'][name] for a,b in [('old','legacy'),('old-helper','whole-helper')] for name in ('observation','validity')}
        check(all(comparisons.values()),'bridge byte-equivalence failed '+case['case'],problems)
        bridge_audit.append(dict(case=case['case'],checks=comparisons,entries=entries))
    resources=load(BASE/'power-v5-cpu-resources.json');check(resources['status']=='completed' and resources['returncode']==0,'CPU job failed',problems)
    check(all(digest(p)==before[str(p.relative_to(ROOT))] for p in frozen_files),'legacy audit changed',problems)
    outcome=report['arms']['1/assisted'];max_power_error=max(abs(q['sampled_active_mean_norm']-1) for q in qs)
    result=dict(schema='triad-helper-supplemental-power-v5-audit-v1',audit_script_sha256=digest(pathlib.Path(__file__)),problems=problems,
        frozen_legacy_artifacts=before,legacy_scope='Earlier59 completed cohorts/2081captures remain immutable legacy-window evidence; this fresh35-capture v5 cohort is separate.',
        cohort=report,source_identity=dict(native_binary=str(binary.relative_to(ROOT)),native_sha256=digest(binary),
            frozen_sources=frozen,current_source_matches=frozen_checks,overlay_sha256=digest(BASE/'frozen-v5/overlay.tar.gz'),overlay_matches=overlay_checks,
            configure_log_sha256=digest(BASE/'power-v5-configure.log'),build_log_sha256=digest(BASE/'power-v5-build.log')),
        independent_seed_checks=dict(fixture_range=[min(new_seeds),max(new_seeds)],new_capture_count=len(rows),
            previous_planned_seed_count=len(previous_seeds),fixture_overlaps=overlaps,previous_truth_files=prior_truth_files,random_root_overlaps=root_overlap,
            scope='Disjoint from all retained/planned prior broad campaigns. Seed separation supports independent simulated draws; fixed key/epoch and model assumptions remain.'),
        corrected_source_energy=energy,power_policies=sorted(power_policies),fixed_source_calibration=list(source_calibrations),
        helper_scope='All35 captures fell back:34 flat_profile and1 insufficient_presence_diagnostic. The original and selected frequency banks both contain3points. This corrected-power reception result demonstrates no Helper search narrowing or Helper sensitivity improvement.',
        full_sample_power_checks=dict(receipt_sha256=digest(BASE/'power-v5-qualification.json'),checks=qualification_checks,records=qs,
            max_observed_active_mean_deviation=max_power_error,max_refinement_relative_difference=max(q['refinement_relative_difference'] for q in qs),
            scope='Seven previously executed full integer-sample source-energy sums, independent of fractional-node calibration. Evidence is source-power accounting, not seven independent receiver campaigns or a proved integration bound.'),
        legacy_and_helper_bridges=dict(receipt_sha256=digest(BASE/'power-v5-bridge/results.json'),script_sha256=digest(BASE/'power-v5-bridge.py'),cases=bridge_audit,
            scope='HF/EME exact recorded observation+validity digests: new legacy mode vs old binary, and new default DATA-off Helper+noise vs old. Arrays were removed after hashing; this audit checks receipts and retained truth, not a new waveform replay. Metadata differences expected; no corrected-DATA receiver sensitivity inferred.'),
        cpu_resources=resources,cpu_environment=load(BASE/'power-v5-cpu-environment.json'),
        uncertainty_scope='8 signal/8 independent validation-null captures after19Helper-present/DATA-absent calibration.5% rank gate is marginal per-capture, not operational daily or fixed-gate conditional certification. Fixed bit-stratum balanced intervals remain broad; CPU run is not an isolated CPU/GPU comparison.')
    (OUT/'power-v5-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    counts=outcome['counts'];signal=outcome['signal_uncertainty']['balanced_population'];null=outcome['null_uncertainty']
    lo=min(e['active_mean_norm'] for e in energy);hi=max(e['active_mean_norm'] for e in energy)
    lines=['# Supplemental whole-active power v5 audit','',
        f"Fresh cohort: {len(rows)} captures (19calibration,8signal,8validation-null). {counts['correct_admitted']}/8 correct admissions, {counts['wrong_admitted']} wrong admissions, {counts['missed']} misses, {counts['false_admitted']}/8 null admissions.",'',
        f"Actual source mean power is {lo:.9f}–{hi:.9f} of the active reference over160.4s at nominal−6dB-Hz. Active/calendar durations coincide; the earlier+28.26dB power inflation is absent. Fixed public-bit0 calibration is shared by all trials.",'',
        result['helper_scope'],'',
        f"95% conservative fixed-bit balanced correct-reception interval: {signal['correct_admitted']['two_sided']}. The conditional one-sided95% null-admission upper bound is {null['one_sided_upper']:.6f}; no daily or99% reception claim.",'',
        f"CPU command wall time {resources['wall_seconds']:.3f}s, two numerical threads; child RSS high-water {resources['max_child_rss_kib']}KiB. This is neither total concurrent RSS nor an isolated hardware speedup benchmark.",'',
        f"All seven saved full-sample power checks pass; largest measured active-power deviation {max_power_error*100:.4f}%. HF/EME legacy composite and Helper-only recorded byte hashes match. Native v5 hash: {digest(binary)}.",'',
        f"Independent audit discrepancies: {len(problems)}. All frozen59-cohort artifacts were unchanged. See power-v5-audit.json for source/input/gate identities, fresh-seed checks, energy sums, uncertainty and bridge limits."]
    (OUT/'power-v5-audit.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines));return int(bool(problems))
if __name__=='__main__':raise SystemExit(main())

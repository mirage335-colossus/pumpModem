#!/usr/bin/env python3
"""Read-only evidence audit; no DSP. Writes only analysis artifacts in --output."""
import argparse, collections, hashlib, itertools, json, math, pathlib, statistics, sys
ROOT = pathlib.Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
from triad_helper_statistics import signal_outcome_statistics, binomial_interval
ARMS = ('baseline', 'assisted')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def executed(v):return tuple(v.get('executed_arms',[a for a in ARMS if a in v]))
def stats(xs):
    xs = [x for x in xs if x is not None]
    return dict(n=len(xs), min=min(xs), median=statistics.median(xs), max=max(xs), sum=sum(xs)) if xs else None
def selective_gain(truth):
    selective = truth['channel_report'].get('selective_perturbation')
    if selective is None:return None
    return 10*math.log10(selective['post_selective_energy_samples']/selective['pre_selective_energy_samples'])
def state(v, arm, phase):
    d = v['decisions'][arm]
    if phase == 'null': return 'false_admitted' if d['accepted'] else 'rejected_null'
    if not d['accepted']: return 'missed'
    return 'correct_admitted' if d['bit'] == v['evaluator']['source_bit'] else 'wrong_admitted'
def transitions(rows, left, right):
    result = {}
    for phase in ('signal', 'null'):
        selected = [r for r in rows if r['trial']['phase'] == phase]
        counts = collections.Counter()
        changed = []
        for r in selected:
            x, y = r['variants'][left[0]], r['variants'][right[0]]
            a, b = state(x,left[1],phase), state(y,right[1],phase)
            counts[f'{a} -> {b}'] += 1
            if a != b or x[left[1]]['bit'] != y[right[1]]['bit']:
                changed.append(dict(trial=r['trial']['id'], seed=r['trial']['seed'], before=a, after=b,
                    before_bit=x[left[1]]['bit'], after_bit=y[right[1]]['bit']))
        result[phase] = dict(counts=dict(counts), changed=changed)
    return result

def cross_cohort_pairs(reports, rows_by_cohort):
    result=[]
    for left,right in itertools.combinations(reports,2):
        if left['representative_format']['bit_seconds']>right['representative_format']['bit_seconds']:
            left,right=right,left
        x={r['trial']['seed']:r for r in rows_by_cohort[left['cohort']]}
        y={r['trial']['seed']:r for r in rows_by_cohort[right['cohort']]}
        shared=sorted(x.keys()&y.keys())
        if not shared:continue
        phase_matches=all(x[s]['trial']['phase']==y[s]['trial']['phase'] and x[s]['trial']['bit']==y[s]['trial']['bit'] for s in shared)
        comparisons={}
        for lagarm in left['arms'].keys()&right['arms'].keys():
            lag,arm=lagarm.split('/'); phase_counts={};changes=[]
            for phase in ('signal','null'):
                counts=collections.Counter()
                for seed in shared:
                    a,b=x[seed],y[seed]
                    if a['trial']['phase']!=phase or b['trial']['phase']!=phase:continue
                    av,bv=a['variants'][lag],b['variants'][lag]
                    before,after=state(av,arm,phase),state(bv,arm,phase)
                    counts[before+' -> '+after]+=1
                    if before!=after or av[arm]['bit']!=bv[arm]['bit']:
                        changes.append(dict(seed=seed,phase=phase,before=before,after=after,
                            before_bit=av[arm]['bit'],after_bit=bv[arm]['bit']))
                phase_counts[phase]=dict(counts)
            comparisons[lagarm]=dict(transitions=phase_counts,changed=changes)
        sx,sy=left['identity']['source_hashes'],right['identity']['source_hashes']
        result.append(dict(before=left['cohort'],after=right['cohort'],shared_seed_count=len(shared),
            matched_phase_and_bit=phase_matches,identical_observation_hashes=sum(x[s]['input_sha256']==y[s]['input_sha256'] for s in shared),
            identical_truth_hashes=sum(x[s]['truth_sha256']==y[s]['truth_sha256'] for s in shared),
            identical_validity_hashes=sum(x[s]['validity_sha256']==y[s]['validity_sha256'] for s in shared),
            before_case=left['case'],after_case=right['case'],
            changed_source_paths=[k for k in sorted(sx.keys()|sy.keys()) if sx.get(k)!=sy.get(k)],
            comparisons=comparisons,scope='Descriptive dependent paired-seed comparison. Each cohort retains its own frozen gate/procedure. Same seeds do not prove identical observations; source changes prevent attributing differences to one parameter alone.'))
    return result

def cost_pilot_audit(root):
    folders=['cache-pilot-results','assisted-cost-pilot-results']
    if any(not (root/f/'score-1.json').exists() for f in folders):return dict(status='not available in snapshot')
    prepared={f:load(root/f/'prepared.json') for f in folders}
    samples={f'{f}/{i}':load(root/f/f'score-{i}.json') for f in folders for i in range(2)}
    reference=samples['cache-pilot-results/0'];records={};problems=[]
    score_fields=('receiver_id','bit','score','working_presence','bit_log_likelihoods','opposite_bit_margin',
                  'epoch_bit_log_likelihoods','best_group_public_parameters','best_epoch_offset_seconds','geometry')
    def numerical(v):
        a=v['assisted'];result={k:a[k] for k in score_fields}
        result['hypotheses']=[{k:x for k,x in h.items() if k not in ('timing','resources')} for h in a['hypothesis_bit_log_likelihoods']]
        return result
    expected=numerical(reference)
    for name,row in samples.items():
        actual=numerical(row);differing=[k for k in expected if expected[k]!=actual[k]]
        compatible=dict(input_sha256=reference['input_sha256']==row['input_sha256'],
            template_sha256=reference['template_sha256']==row['template_sha256'],
            complete_search_banks=reference['search_banks']==row['search_banks'],
            assisted_numerical_outputs=not differing)
        if not all(compatible.values()):problems.append(dict(sample=name,checks=compatible,differing_numerical_fields=differing))
        f,i=name.split('/');path=root/f/f'score-{i}.json'
        records[name]=dict(file_sha256=digest(path),procedure_id=row['procedure_id'],execution_policy_id=row.get('execution_policy_id'),
            source_hashes=row['source_hashes'],comparisons_to_paired_cold=compatible,differing_numerical_fields=differing,
            input_sha256=row['input_sha256'],template_sha256=row['template_sha256'],timing=row['timing'],cache_pilot=row['cache_pilot'],
            assisted_timing=row['assisted']['timing'],baseline_timing=row['baseline']['timing'] if row.get('baseline') else None,
            arm_presence={'baseline':row.get('baseline') is not None,'assisted':True},
            assisted_geometry=row['assisted']['geometry'],assisted_bit_log_likelihoods=row['assisted']['bit_log_likelihoods'],
            assisted_winner=row['assisted']['best_group_public_parameters'])
    ratios={}
    for i,kind in enumerate(('cold','warm')):
        paired=samples[f'cache-pilot-results/{i}'];only=samples[f'assisted-cost-pilot-results/{i}']
        # This is explicitly stage composition, not a separately executed baseline-only process.
        baseline=paired['baseline']['timing']['total_score_prepared_seconds']+paired['timing']['shared_preparation_seconds']-paired['timing']['helper_seconds']
        assisted=only['cache_pilot']['wall_seconds']
        if not i:
            baseline+=prepared['cache-pilot-results']['constructor_wall_seconds']
            assisted+=prepared['assisted-cost-pilot-results']['constructor_wall_seconds']
        ratios[kind]=dict(paired_command_wall_seconds=paired['cache_pilot']['wall_seconds'],
            assisted_only_command_wall_seconds=only['cache_pilot']['wall_seconds'],
            measured_paired_command_over_assisted_only=paired['cache_pilot']['wall_seconds']/only['cache_pilot']['wall_seconds'],
            composed_unassisted_stage_seconds=baseline,assisted_including_cold_constructor_seconds=assisted,
            composed_unassisted_over_assisted=baseline/assisted,
            assisted_score_stage_ratio_only_over_paired=only['assisted']['timing']['total_score_prepared_seconds']/paired['assisted']['timing']['total_score_prepared_seconds'])
    return dict(status='audited',problems=problems,prepared=prepared,samples=records,ratios=ratios,
        scope='Same retained capture and template, no new receptions or admission calibration. Compared sources differ in study wrapper; receiver identity, numerical scores and complete selected banks checked exactly. Concurrency and two replays preclude calibrated timing confidence or diagnosis of warm-stage variation. Native generation/export excluded; command timers include Helper/filter/loading/hashing and scoring, cold constructor added only in explicit stage composition. Earlier paired assisted scores follow full baseline preparation and cannot represent standalone cold cost.')

def source_energy_recovery_audit(root):
    observer=root/'source-energy-raw-recovered.jsonl'
    if not observer.exists():return dict(status='not available in snapshot')
    base=ROOT/'local-evidence/triad-helper-broad'; old_script=base/'source_energy.py'; new_script=base/'source_energy_v2.py'
    campaign=root/'broad-raw-v3'; recoveries=[]; problems=[]
    for record in map(json.loads,observer.read_text().splitlines()):
        name=record['cohort']; original=campaign/name; recovered=root/'raw-source-energy-recovered'/name
        receipt=load(recovered/'recovery.json'); old_prepared=load(original/'prepared.json'); new_prepared=load(recovered/'prepared.json')
        original_manifest=load(original/'calibration-0000/manifest.json'); regenerated_manifest=load(recovered/'calibration-0000/manifest.json')
        expected={p['template_sha256'] for p in old_prepared.values()}
        checks=dict(template_hash_matches=record['template_sha256']==receipt['template_sha256'] and record['template_sha256'] in expected,
            prepared_identity_unchanged=old_prepared==new_prepared,
            observer_v2_hash_matches=record['script_sha256']==digest(new_script),
            public_manifest_except_cost_matches=all(original_manifest[k]==regenerated_manifest[k] for k in original_manifest if k!='cost'),
            evaluator_truth_bytes_match=(original/'calibration-0000/evaluator-truth.json').read_bytes()==(recovered/'calibration-0000/evaluator-truth.json').read_bytes())
        if not all(checks.values()):problems.append(dict(cohort=name,checks=checks))
        recoveries.append(dict(cohort=name,checks=checks,template_sha256=record['template_sha256'],
            recovery_receipt=receipt,recovery_receipt_sha256=digest(recovered/'recovery.json'),
            original_trials_sha256=digest(original/'trials.jsonl'),original_prepared_sha256=digest(original/'prepared.json'),
            recovered_manifest_sha256=digest(recovered/'calibration-0000/manifest.json'),
            recovered_truth_sha256=digest(recovered/'calibration-0000/evaluator-truth.json')))
    absent=campaign/'eme-no-loss-paired-control-raw'; source=campaign/'eme10ms-independent-raw'
    m=load(absent/'calibration-0000/manifest.json'); other=load(source/'calibration-0000/manifest.json')
    try:
        unused=(absent/'calibration-0000')/m['templates']['file']
        failure=dict(reproduced=False,unexpected_path=str(unused))
    except TypeError as error:failure=dict(reproduced=True,error_type=type(error).__name__,error=str(error))
    reuse_checks=dict(template_hashes_match={p['template_sha256'] for p in load(absent/'prepared.json').values()}=={p['template_sha256'] for p in load(source/'prepared.json').values()},
        format_matches=m['format']==other['format'],key_matches=m['key_seed']==other['key_seed'],epoch_matches=m['public_epoch_seconds']==other['public_epoch_seconds'])
    if not all(reuse_checks.values()):problems.append(dict(reuse_checks=reuse_checks))
    return dict(status='audited',problems=problems,original_observer_sha256=digest(old_script),fixed_observer_sha256=digest(new_script),
        failure=dict(manifest=str((absent/'calibration-0000/manifest.json').relative_to(ROOT)),templates_enabled=m['templates']['enabled'],template_file=m['templates']['file'],**failure),
        fix_scope='Observer now checks enabled and nonempty filename before constructing the path. Original observer remains retained. No numerical accumulation change.',
        recovered_observer_sha256=digest(observer),recoveries=recoveries,
        source_energy_reuse=dict(target=absent.name,source=source.name,checks=reuse_checks,permitted=all(reuse_checks.values()),
            scope='Identical public source-template bytes/key/epoch/format allow source-energy and distance reuse. This does not reuse masked received energy, likelihoods, gates or reception outcomes.'),
        scope='File-only audit and original failing path-expression reproduction; no DSP or receiver scoring. Remote receipt reports only native source-template regeneration. Recovery manifests differ only in measured native cost; evaluator-truth bytes and original prepared identity agree. Source template arrays are not retained here, so hash agreement is against recorded independent prepared/observer identities.')

def cache_repair_audit(root):
    from scipy.fft import next_fast_len
    old=root/'broad-assisted-v3/rate3p6-nospreading-assisted-only'
    new=root/'broad-cache-v4/rate3p6-cache-bound-fixed'
    if not (new/'summary.json').exists():return dict(status='not available in snapshot')
    failed=load(old/'summary.json'); summary=load(new/'summary.json')
    first=json.loads((new/'trials.jsonl').read_text().splitlines()[0]);v=first['variants']['1'];a=v['assisted'];resources=a['resources']
    old_m=load(old/'calibration-0000/manifest.json');m=load(new/'calibration-0000/manifest.json')
    old_p=load(old/'protocol.json');p=load(new/'protocol.json');retained=failed['retained_array_identities']
    checks=dict(original_still_failed=failed['status']=='failed',new_completed=summary['status']=='completed',
        observation_hash_matches=first['input_sha256']==retained['observation.c128']['sha256'],
        validity_hash_matches=first['validity_sha256']==retained['validity.u8']['sha256'],
        native_exporter_hash_matches=old_p['exporter_sha256']==p['exporter_sha256'],
        public_source_specification_matches=all(old_m[k]==m[k] for k in ('format','templates','key_seed','public_epoch_seconds','calendar','power','physics')),
        requested400_effective13=resources['requested_maximum_cached_hypotheses']==400 and resources['maximum_cached_hypotheses']==resources['reachable_cache_key_count']==13)
    samples=a['work']['samples'];lags=a['work']['lag_count'];source_rows=m['templates']['shape'][2]
    nfft=next_fast_len(max(2*samples-1,math.ceil(4*source_rows/20)))
    cpu_key=samples*(81+320)+nfft*320+lags*320+65536+lags*4096+nfft*64+samples*48
    cuda_extra=nfft*192+samples*96;cuda_key=cpu_key+cuda_extra
    batch_unit=nfft*80+samples*48+lags*2048
    actual=resources['explicit_array_bound_bytes'];old_cuda=actual+(400-13)*cuda_key
    return dict(status='audited',checks=checks,problems=[k for k,x in checks.items() if not x],
        original_failure=failed,old_protocol_sha256=digest(old/'protocol.json'),new_protocol_sha256=digest(new/'protocol.json'),
        new_first_row_input_sha256=first['input_sha256'],new_template_sha256=v['template_sha256'],
        original_template_hash_match=None,template_identity_limit='Original failed receipt retained no template digest. Same native exporter/public specification supports deterministic provenance; direct old/new template-byte identity was not measured.',
        new_resources=resources,projection=dict(samples=samples,lag_count=lags,source_rows=source_rows,fft_rows=nfft,
            cpu_bytes_per_cache_key=cpu_key,cuda_bytes_per_cache_key=cuda_key,cfo_batch_transient_bytes=batch_unit,
            actual_cuda_batch32_effective13_bound_bytes=actual,old400_cuda_batch32_projection_bytes=old_cuda,
            actual_cuda_batch32_effective13_GiB=actual/2**30,old400_cuda_batch32_GiB=old_cuda/2**30,
            hypothetical_cuda_batch8_GiB=(actual-24*batch_unit)/2**30,
            hypothetical_cpu_batch8_effective13_GiB=(actual-24*batch_unit-13*cuda_extra)/2**30,
            hypothetical_cpu_batch8_old400_GiB=(actual-24*batch_unit-13*cuda_extra+387*cpu_key)/2**30,
            scope='Public-shape arithmetic only using the retained allocation-bound formula; no FFT execution. Assumes this singleton-clock/rate case. These are conservative explicit-array projections, NOT measured RSS, GPU use, or old allocation attempts.'),
        scope='New v4 repair evidence, paired with the v3 preparation failure; no independent validation claim and no retrospective conversion of failure to pass.')

def campaign_inventory(root):
    result=[]
    for path in sorted(root.glob('broad-*/protocol.json')):
        protocol=load(path); folder=path.parent; receipt=load(folder/'summary.json') if (folder/'summary.json').exists() else {}
        cases=[]
        for case in protocol.get('cohorts',[]):
            location=folder/case['id']; summary=load(location/'summary.json') if (location/'summary.json').exists() else receipt.get('cohorts',{}).get(case['id'],{})
            trial_path=location/'trials.jsonl'; n=sum(1 for _ in trial_path.open()) if trial_path.exists() else 0
            status=summary.get('status', 'partial_records' if n else 'not_available_in_snapshot')
            cases.append(dict(cohort=case['id'],status=status,scored_rows=n,reason=summary.get('reason'),stage=summary.get('stage'),error=summary.get('error')))
        result.append(dict(campaign=folder.name,protocol_sha256=digest(path),
            receipt_schema=receipt.get('schema'),receipt_status=receipt.get('status','no explicit completed-campaign status'),
            wrapper_receipt_present=bool(receipt),all_planned_terminal_states_in_snapshot=all(x['status'] in ('completed','failed','interrupted','not-run') for x in cases),
            planned_cohorts=len(cases),cohort_status_counts=dict(collections.Counter(x['status'] for x in cases)),cases=cases,
            source_hashes=protocol.get('source_hashes'),scope='Downloaded snapshot only. Missing summaries are neither completed nor proof that a running remote cohort was never started.'))
    return result

def review(folder):
    protocol=load(folder/'protocol.json'); prepared=load(folder/'prepared.json')
    rows=[json.loads(x) for x in (folder/'trials.jsonl').read_text().splitlines()]
    summary=load(folder/'summary.json') if (folder/'summary.json').exists() else {}
    steps=[str(s) for s in protocol['case'].get('lag_steps',[1,4])]
    problems=[]; evidence_warnings=[]
    def check(ok,msg):
        if not ok: problems.append(msg)
    check([r['trial'] for r in rows]==protocol['trial_schedule'],'completed schedule differs from frozen protocol')
    check(len({r['trial']['seed'] for r in rows})==len(rows),'duplicate trial seeds')
    sources=protocol['source_hashes']; current_diff=[p for p,h in sources.items() if not (ROOT/p).exists() or digest(ROOT/p)!=h]
    if current_diff: evidence_warnings.append('Current source changed; historical identity retained: '+', '.join(current_diff))
    roots=[]; manifests={}; truth={}; supplemental_sources={}
    for r in rows:
        name=r['trial']['id']; capture=folder/name
        m=load(capture/'manifest.json'); t=load(capture/'evaluator-truth.json'); manifests[name]=m; truth[name]=t
        check(digest(capture/'manifest.json')==r['manifest_sha256'],name+': manifest hash mismatch')
        check(digest(capture/'evaluator-truth.json')==r['truth_sha256'],name+': truth hash mismatch')
        check(t['random_seed_roots']['fixture']==r['trial']['seed'],name+': fixture seed mismatch')
        check(t['source_bit']==r['trial']['bit'],name+': source bit mismatch')
        check(not m['evaluator_truth_is_receiver_input'] and not t['receiver_input'],name+': truth role mismatch')
        check(r['erasure']['observation_sha256']==r['input_sha256'],name+': input receipt mismatch')
        check(r['erasure']['validity_sha256']==r['validity_sha256'],name+': validity receipt mismatch')
        roots.append(t['random_seed_roots'])
        for step,v in r['variants'].items():
            check(v['input_sha256']==r['input_sha256'],name+': paired observations mismatch')
            check(v['procedure_id']==prepared[step]['procedure_id'],name+': procedure mismatch')
            check(v['template_sha256']==prepared[step]['template_sha256'],name+': template mismatch')
            check(v['evaluator']['source_bit']==t['source_bit'],name+': evaluator bit mismatch')
            check(v['evaluator']['source_energy']==t['source_energy'],name+': source energy mismatch')
            check(v['source_hashes']==prepared[step]['source_hashes'],name+': prepared/row sources mismatch')
            for k,h in v['source_hashes'].items():
                if 'tools/'+k in sources:check(sources['tools/'+k]==h,name+': row source mismatch '+k)
                else:
                    choices=[ROOT/'tools'/k,ROOT/'local-evidence/triad-helper-broad/mask-diagnosis'/k]
                    found=next((p for p in choices if p.exists()),None)
                    supplemental_sources[k]=dict(sha256=h,local_file=str(found.relative_to(ROOT)) if found else None,
                        current_local_hash_matches=digest(found)==h if found else None,
                        scope='Supplemental prepared and row identity; absent from generic campaign source inventory. Raw adapter source includes these hashes in procedure identity and checks factory freeze.')
        check(len({json.dumps(v['assistance'],sort_keys=True) for v in r['variants'].values()})==1,name+': Helper estimate differs between lag variants')
    seed_duplicates={k:len(roots)-len({r[k] for r in roots}) for k in roots[0]} if roots else {}
    arms={}; gates={}; executed_by_step={}
    for step in steps:
        gate=load(folder/f'gate-lag-{step}.json');gates[step]=dict(sha256=digest(folder/f'gate-lag-{step}.json'),**gate)
        actual=tuple(gate.get('arms',gate['scores'].keys())); executed_by_step[step]=actual
        check(gate['procedure_id']==prepared[step]['procedure_id'],f'{step}: gate identity mismatch')
        cal=[r['variants'][step] for r in rows if r['trial']['phase']=='calibration']
        check(gate['count']==len(cal),f'{step}: gate count mismatch')
        for r in rows:
            v=r['variants'][step]
            check(executed(v)==actual,f'{step}: executed arms mismatch')
            check(tuple(a for a in ARMS if a in v)==actual,f'{step}: unexecuted arm record present or executed arm absent')
            if gate.get('execution_policy_id') is not None:
                expected=hashlib.sha256(json.dumps(dict(procedure_id=v['procedure_id'],executed_arms=list(actual)),sort_keys=True,separators=(',',':')).encode()).hexdigest()
                check(v.get('execution_policy_id')==gate['execution_policy_id']==expected,f'{step}: execution policy mismatch')
        for arm in actual:
            check(gate['scores'][arm]==[v[arm]['working_presence'] for v in cal],f'{step}/{arm}: calibration mismatch')
        for r in rows:
            if r['trial']['phase']=='calibration':continue
            v=r['variants'][step]
            check(v['calibration_condition_id']==gate['calibration_condition_id'],f'{step}: calibration condition mismatch')
            check(set(v['decisions'])==set(actual),f'{step}: decision arms mismatch')
            for arm in actual:
                d=v['decisions'][arm]; p=(1+sum(x>=v[arm]['working_presence'] for x in gate['scores'][arm]))/(gate['count']+1)
                check(p==d['p_value'] and (p<=gate['alpha'])==d['accepted'] and d['bit']==v[arm]['bit'],f'{step}/{arm}/{r["trial"]["id"]}: decision mismatch')
        for arm in actual:
            vs=[r['variants'][step] for r in rows]
            signal=signal_outcome_statistics(vs,arm)
            null=[v for v in vs if v['trial']['phase']=='null']; false=sum(v['decisions'][arm]['accepted'] for v in null)
            counts=dict(signal['counts'],false_admitted=false,rejected_null=len(null)-false)
            saved=summary.get('outcomes',{}).get(step,{}).get(arm,{}).get('counts')
            if saved is not None:check(counts==saved,f'{step}/{arm}: saved summary counts mismatch')
            arms[f'{step}/{arm}']=dict(counts=counts,signal_uncertainty=signal,null_uncertainty=binomial_interval(false,len(null)),
                score_seconds=stats(v[arm]['timing']['total_score_prepared_seconds'] for v in vs),
                first_score_seconds=vs[0][arm]['timing']['total_score_prepared_seconds'],
                warm_score_seconds=stats(v[arm]['timing']['total_score_prepared_seconds'] for v in vs[1:]),
                score_reused_from_baseline_count=sum(v[arm].get('score_reused_from_baseline',False) for v in vs),
                actually_additional_assisted_scoring_seconds=(stats(v['timing']['additional_assisted_scoring_seconds'] for v in vs) if arm=='assisted' else None),
                assisted_only_scoring_seconds=(stats(v['timing'].get('assisted_score_seconds') for v in vs) if arm=='assisted' else None),
                timer_scope='Reused assisted results retain baseline timing metadata; they are NOT a second measured execution. Use actually_additional_assisted_scoring_seconds and cohort all_lag_score_only_seconds.',
                observed_fft_seconds=stats(v[arm]['timing']['observation_fft_seconds'] for v in vs),
                frequency_count=stats(v[arm]['work']['frequency_count'] for v in vs),
                effective_group_count=stats(v[arm]['work']['effective_group_count'] for v in vs),
                lag_count=sorted({v[arm]['work']['lag_count'] for v in vs}),
                samples=sorted({v[arm]['work']['samples'] for v in vs}),
                arithmetics=list({json.dumps(v[arm]['arithmetic'],sort_keys=True):v[arm]['arithmetic'] for v in vs}.values()))
    first=steps[0];vs=[r['variants'][first] for r in rows]
    paired={}
    for step in steps:
        if set(ARMS).issubset(executed_by_step[step]):paired[f'lag{step}:baseline->assisted']=transitions(rows,(step,'baseline'),(step,'assisted'))
    for a,b in itertools.combinations(steps,2):
        for arm in set(executed_by_step[a])&set(executed_by_step[b]):paired[f'lag{a}->lag{b}:{arm}']=transitions(rows,(a,arm),(b,arm))
    sig=[r for r in rows if r['trial']['phase']=='signal']
    energy={}
    for bit in (0,1):
        rr=[r for r in sig if r['trial']['bit']==bit]
        energy[str(bit)]=dict(
            source_data_energy_samples=stats(truth[r['trial']['id']]['source_energy']['data_energy_samples'] for r in rr),
            source_data_normalized_energy_seconds=stats(truth[r['trial']['id']]['source_energy']['data_energy_samples']/manifests[r['trial']['id']]['sample_rate_hz'] for r in rr),
            source_data_energy_over_n0_db=stats(10*math.log10(truth[r['trial']['id']]['source_energy']['data_energy_samples']/manifests[r['trial']['id']]['power']['complex_noise_variance']) for r in rr),
            source_calendar_mean_power_relative_to_reference_db=stats(10*math.log10(truth[r['trial']['id']]['source_energy']['data_energy_samples']/manifests[r['trial']['id']]['sample_rate_hz']/manifests[r['trial']['id']]['format']['bit_seconds']) for r in rr),
            composite_post_over_pre_selective_energy_db=stats(selective_gain(truth[r['trial']['id']]) for r in rr))
    failures=[]
    for r in sig:
        rowstates={f'{s}/{a}':state(v,a,'signal') for s,v in r['variants'].items() for a in executed(v)}
        raw={f'{s}/{a}':v[a]['bit']!=v['evaluator']['source_bit'] for s,v in r['variants'].items() for a in executed(v)}
        if all(x=='correct_admitted' for x in rowstates.values()):continue
        priority=100*sum(x=='wrong_admitted' for x in rowstates.values())+10*len(set(rowstates.values()))+sum(raw.values())
        failures.append(dict(cohort=protocol['case']['id'],trial=r['trial']['id'],seed=r['trial']['seed'],priority=priority,
            states=rowstates,raw_bit_errors=raw,export_command=r['export_command'],input_sha256=r['input_sha256'],
            source_bit=truth[r['trial']['id']]['source_bit'],arrival_seconds=truth[r['trial']['id']]['arrival_seconds'],
            helper_status=r['variants'][first]['assistance']['status'],
            static_cfo_in_expanded_interval=r['variants'][first]['evaluator']['static_cfo_in_expanded_interval'],
            variants={s:dict(procedure_id=v['procedure_id'],decisions=v['decisions'],
                baseline_best_cfo_retained=v['evaluator']['baseline_best_cfo_retained'],
                winners={a:v[a]['best_group_public_parameters'] for a in executed(v)}) for s,v in r['variants'].items()}))
    report=dict(cohort=protocol['case']['id'],campaign=folder.parent.name,folder=str(folder.relative_to(ROOT)),case=protocol['case'],
        identity=dict(protocol_sha256=digest(folder/'protocol.json'),trials_sha256=digest(folder/'trials.jsonl'),
            summary_sha256=digest(folder/'summary.json') if (folder/'summary.json').exists() else None,
            exporter_sha256=protocol['exporter_sha256'],source_hashes=sources,prepared=prepared,supplemental_prepared_sources=supplemental_sources,
            source_read_order_verified_current_match=not current_diff,
            read_order_scope='Matching runner source scores and freezes all lag/arm decisions before opening truth. Receipts do not independently prove OS-level read chronology.'),
        integrity=dict(problems=problems,warnings=evidence_warnings,seed_duplicates=seed_duplicates,
            iq_scope='Raw observations removed after hashing. Receipts and export command retained; actual I/Q hashes require deterministic regeneration to reverify.'),
        gates=gates,arms=arms,executed_arms_by_lag=executed_by_step,paired_changes=paired,
        helper=dict(status=dict(collections.Counter(v['assistance']['status'] for v in vs)),
            reasons=dict(collections.Counter(v['assistance']['reason'] for v in vs)),
            selected_cfo_count=stats(v['assistance']['selected_count'] for v in vs),
            original_cfo_count=stats(v['assistance']['original_count'] for v in vs),
            static_cfo_in_expanded_interval=sum(v['evaluator']['static_cfo_in_expanded_interval'] for v in vs),
            baseline_best_cfo_retained={s:(sum(r['variants'][s]['evaluator']['baseline_best_cfo_retained'] is True for r in rows) if 'baseline' in executed_by_step[s] else None) for s in steps},
            baseline_best_cfo_retained_signal={s:(sum(r['variants'][s]['evaluator']['baseline_best_cfo_retained'] is True for r in sig) if 'baseline' in executed_by_step[s] else None) for s in steps},
            seconds=stats(v['timing']['helper_seconds'] for v in vs)),
        energy=energy,representative_power=manifests[rows[0]['trial']['id']]['power'],
        representative_format=manifests[rows[0]['trial']['id']]['format'],
        representative_calendar=manifests[rows[0]['trial']['id']]['calendar'],
        representative_physics=manifests[rows[0]['trial']['id']]['physics'],
        sampled_key_seeds=sorted({m['key_seed'] for m in manifests.values()}),
        sampled_public_epochs=sorted({m['public_epoch_seconds'] for m in manifests.values()}),
        sampled_truth_epoch_offsets=sorted({t['source_epoch_offset_seconds'] for t in truth.values()}),
        erasure=dict(recipe=rows[0]['erasure']['recipe'],missing_rows=rows[0]['erasure']['missing_rows'],
            intervals_seconds=rows[0]['erasure']['intervals_seconds']),
        energy_scope='Source DATA energy includes actual finite-calendar pulse energy; E/N0 uses injected complex variance, not codeword discrimination energy. Reported C/N0 refers to the fixed public reference window, not necessarily whole-frame mean power. Large source calendar/reference power ratios invalidate nominal-C/N0 calendar-average sensitivity claims. Composite selective energy is Helper-dominated and does NOT isolate received DATA gain or mismatch.',
        cost=dict(summary.get('timing',{}),export_seconds=stats(r['export_wall_seconds'] for r in rows),
            shared_preparation_seconds=stats(r['shared_preparation_seconds'] for r in rows)),
        failures=sorted(failures,key=lambda x:-x['priority']))
    return report, rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=ROOT/'local-evidence/triad-helper-broad/remote');ap.add_argument('--output',type=pathlib.Path,default=pathlib.Path(__file__).parent);args=ap.parse_args()
    reports=[];seen={};overlaps=[];incomplete=[];rows_by_cohort={}
    for p in sorted(args.root.glob('broad-*/*/trials.jsonl')):
        status=load(p.parent/'summary.json') if (p.parent/'summary.json').exists() else {}
        if not (p.parent/'prepared.json').exists() or status.get('status')!='completed':
            incomplete.append(dict(folder=str(p.parent),status=status.get('status','no completed summary'),
                stage=status.get('stage'),error=status.get('error'),completed_trials=status.get('completed_trials'),
                wall_seconds=status.get('wall_seconds')));continue
        r,rows=review(p.parent);reports.append(r);rows_by_cohort[r['cohort']]=rows
        seeds={row['trial']['seed'] for row in rows}
        for s in seeds:
            if s in seen:overlaps.append(dict(seed=s,cohorts=[seen[s],r['cohort']],
                interpretation='Shared fixture seed implies dependence. Intentional duration pairing is allowed; do not pool as independent validation or assume observations/source versions are identical.'))
            seen[s]=r['cohort']
    source_observer={}
    for observer in sorted(args.root.glob('source-energy-*.jsonl')):
        for x in map(json.loads,observer.read_text().splitlines()):
            source_observer[x['cohort']]=(x,observer)
    for r in reports:
        record=source_observer.get(r['cohort'])
        reused=False
        if record is None:
            expected={v['template_sha256'] for v in r['identity']['prepared'].values()}
            record=next((v for v in source_observer.values() if v[0]['template_sha256'] in expected and v[0]['key_seed'] in r['sampled_key_seeds'] and v[0]['epoch'] in r['sampled_public_epochs'] and v[0]['format']==r['representative_format']),None)
            reused=record is not None
        if record is None:continue
        x,observer=record
        matched=x['template_sha256'] in {v['template_sha256'] for v in r['identity']['prepared'].values()}
        checkkeys=(x['key_seed'] in r['sampled_key_seeds'] and x['epoch'] in r['sampled_public_epochs'])
        noise=r['representative_power']['complex_noise_variance']
        ratio=x['distance_squared_samples']/(2*noise)
        r['source_distance_observer']=dict(receipt=x,observer_file=str(observer.relative_to(ROOT)),observer_file_sha256=digest(observer),
            reused_source_only_from_cohort=x['cohort'] if reused else None,
            identity_matches=matched and checkkeys,
            flat_known_waveform_raw_bit_error=.5*math.erfc(math.sqrt(ratio/2)),
            benchmark_scope='Equal-prior binary known waveforms, known alignment/phase, unity-gain flat channel, injected complex-white-noise variance. NOT a bound for selected fading/AM, search or admission.')
        if not matched or not checkkeys:r['integrity']['problems'].append('source observer identity mismatch')
    for r in reports:
        error=r.get('source_distance_observer',{}).get('flat_known_waveform_raw_bit_error')
        for f in r['failures']:
            f['flat_known_waveform_error_diagnostic']=error
            if error is not None and error>=.45:
                f['priority']-=1000
                f['selection_note']='Deprioritized: even flat known-waveform diagnostic is nearly chance; retain failure in full outcome inventory.'
    failures=sorted([f for r in reports for f in r['failures']],key=lambda x:-x['priority'])[:6]
    cross_pairs=cross_cohort_pairs(reports,rows_by_cohort)
    result=dict(schema='triad-helper-broad-readonly-audit-v2',analysis_sha256=digest(pathlib.Path(__file__)),cohorts=reports,
        completed_cohort_count=len(reports),completed_capture_count=sum(r['helper']['selected_cfo_count']['n'] for r in reports),
        assisted_cost_pilot_audit=cost_pilot_audit(args.root),
        source_energy_recovery_audit=source_energy_recovery_audit(args.root),
        cache_repair_audit=cache_repair_audit(args.root),
        campaign_inventory=campaign_inventory(args.root),cross_cohort_paired_transitions=cross_pairs,
        cross_cohort_seed_overlaps=overlaps,incomplete_or_failed_cohorts=incomplete,oracle_candidates=failures,
        limitations=['No DSP rerun or hardware timing inference.',
            'Paired lag and baseline/assisted arms share captures; never pool as independent samples. Assisted-only evidence contains no baseline reception or measured speedup.',
            'Initial physical and override cohorts use disjoint seeds. Duration extensions may intentionally reuse short-cohort seeds; overlap is dependence, not corruption or independent validation.',
            '19 null calibration captures give minimum rank p=.05. Marginal per-capture exchangeability only; neither fixed-gate conditional 5% nor daily qualification.',
            'Signal intervals use fixed bit strata and conservative balanced-population bounds; null intervals conditional on frozen gate. Bounds are per named metric, not simultaneous.',
            'Paired transition counts are descriptive and oracle selection is post hoc diagnosis, never independent validation.',
            'Static CFO interval coverage does not prove coverage of stochastic paths or calibrated Helper lock.',
            'Native exporter hash is recorded but remote binary/source build linkage is not independently reconstructed here.'])
    result['energy_reference_caveats']=[dict(cohort=r['cohort'],nominal_cn0_db_hz=r['representative_power']['data_cn0_db_hz'],
        reference_window_seconds=r['representative_power']['reference_window_seconds'],
        bit_seconds=r['representative_format']['bit_seconds'],
        per_bit_calendar_reference_db={b:x['source_calendar_mean_power_relative_to_reference_db'] for b,x in r['energy'].items()},
        scope='Excluded from claims of sensitivity at the nominal calendar-average C/N0; report actual energy. A fixed early reference window can lie in a low-rate pulse tail.')
        for r in reports if any(x['source_calendar_mean_power_relative_to_reference_db'] and x['source_calendar_mean_power_relative_to_reference_db']['median']>3 for x in r['energy'].values())]
    args.output.mkdir(parents=True,exist_ok=True);(args.output/'cohort-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# Saved-cohort audit','', '| Cohort | Lag | Arm | Signal N | Correct | Wrong | Miss | Raw bit errors | Null admitted/N |', '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for r in reports:
        for key,a in r['arms'].items():
            s,arm=key.split('/');c=a['counts'];lines.append(f"| {r['cohort']} | {s} | {arm} | {a['signal_uncertainty']['signal_trials']} | {c['correct_admitted']} | {c['wrong_admitted']} | {c['missed']} | {c['raw_bit_errors']} | {c['false_admitted']}/{a['null_uncertainty']['trials']} |")
    lines+=['','Signal/null denominators and uncertainty, paired changes, exact identities, work counts, energy and timings are in `cohort-audit.json`.','']+['- '+x for x in result['limitations']]
    lines+=['','Oracle candidates (frozen evidence; post-hoc diagnostic selection):','']+[f"- {f['cohort']}/{f['trial']}, seed {f['seed']}: {f['states']}" for f in failures]
    lines+=['','## Campaign snapshot','']+[f"- {x['campaign']}: {x['cohort_status_counts']}; receipt: {x['receipt_status']}." for x in result['campaign_inventory']]
    lines+=['','## Power-reference limitations','',
        'The following successes are excluded from nominal calendar-average C/N0 sensitivity claims. Their actual source energy exceeds the stated fixed-window reference; this is a transmit-energy convention effect, not demonstrated receiver gain.','']
    for r in result['energy_reference_caveats']:
        ratios=[x['median'] for x in r['per_bit_calendar_reference_db'].values() if x]
        lines.append(f"- {r['cohort']}: nominal {r['nominal_cn0_db_hz']:g} dB-Hz, actual source calendar/reference mean power {min(ratios):+.3f} to {max(ratios):+.3f} dB; {r['bit_seconds']:g} s bit.")
    lines+=['','## Dependent paired-seed transitions','', '| Before | After | Arm | Identical I/Q / shared seeds | Signal transitions | Null transitions |', '|---|---|---|---:|---|---|']
    for p in cross_pairs:
        for arm,c in p['comparisons'].items():
            lines.append(f"| {p['before']} | {p['after']} | {arm} | {p['identical_observation_hashes']}/{p['shared_seed_count']} | {c['transitions']['signal']} | {c['transitions']['null']} |")
    pilot=result['assisted_cost_pilot_audit']
    if pilot['status']=='audited':
        lines+=['','## Saved cost-pilot comparison','',pilot['scope'],'',f"Numerical/bank identity problems: {len(pilot['problems'])}.",'',
            '| State | Paired command seconds | Assisted-only command seconds | Ratio |', '|---|---:|---:|---:|']
        for state,r in pilot['ratios'].items():lines.append(f"| {state} | {r['paired_command_wall_seconds']:.3f} | {r['assisted_only_command_wall_seconds']:.3f} | {r['measured_paired_command_over_assisted_only']:.2f} |")
    (args.output/'cohort-audit.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines[:2+2+sum(len(r['arms']) for r in reports)])); print('Integrity problems:',sum(len(r['integrity']['problems']) for r in reports),'cross-cohort seed overlaps:',len(overlaps));print('Oracle seeds:',[f['seed'] for f in failures])
    return int(any(r['integrity']['problems'] for r in reports) or any(result[k].get('problems') for k in ('assisted_cost_pilot_audit','source_energy_recovery_audit','cache_repair_audit')))
if __name__=='__main__':raise SystemExit(main())

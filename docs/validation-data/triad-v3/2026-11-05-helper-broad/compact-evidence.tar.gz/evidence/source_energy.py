#!/usr/bin/env python3
"""Read fixed public source alternatives once; no receiver/channel execution."""
import argparse,hashlib,json,pathlib,time
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--campaign',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--watch-seconds',type=float,default=0);a=p.parse_args();start=time.monotonic();seen=set()
with a.output.open('x') as out:
 while True:
  for prepared in a.campaign.glob('*/prepared.json'):
   case=prepared.parent
   if case.name in seen:continue
   mp=case/'calibration-0000'/'manifest.json'
   if not mp.exists():continue
   m=json.loads(mp.read_text());meta=m['templates'];tp=mp.parent/meta['file']
   if not meta['enabled'] or not tp.exists():continue
   x=np.memmap(tp,mode='r',dtype='<c16',shape=tuple(meta['shape']));i=meta['epoch_offsets_seconds'].index(0);s0,s1=x[i,0],x[i,1]
   e0=e1=dist=ampdist=0.;cross=0j
   for first in range(0,len(s0),262144):
    x0,x1=s0[first:first+262144],s1[first:first+262144];delta=x1-x0;ad=np.abs(x1)-np.abs(x0)
    e0+=float(np.vdot(x0,x0).real);e1+=float(np.vdot(x1,x1).real);dist+=float(np.vdot(delta,delta).real);ampdist+=float(ad@ad);cross+=complex(np.vdot(x0,x1))
   info=json.loads(prepared.read_text());row=dict(cohort=case.name,format=m['format'],key_seed=m['key_seed'],epoch=m['public_epoch_seconds'],template_sha256=next(iter(info.values()))['template_sha256'],source_rows=len(s0),e0_samples=e0,e1_samples=e1,mean_energy_seconds=(e0+e1)/(2*m['sample_rate_hz']),distance_squared_samples=dist,symmetric_difference_fraction=dist/(2*(e0+e1)),unknown_global_phase_minimum_distance_squared=e0+e1-2*abs(cross),normalized_complex_correlation=abs(cross)/np.sqrt(e0*e1),amplitude_distance_squared=ampdist,script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),scope='Exact public keyed source alternatives at epoch0 before channel; not a received SNR, channel likelihood or admission benchmark.')
   out.write(json.dumps(row,allow_nan=False)+'\n');out.flush();seen.add(case.name);del x,s0,s1
  if time.monotonic()-start>=a.watch_seconds or (a.campaign/'summary.json').exists():break
  time.sleep(20)

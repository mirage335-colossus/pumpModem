#include "datapump/triad_shaping.hpp"
#include <chrono>
#include <iomanip>
#include <iostream>
using namespace datapump::triad::v3;
int main(){Format f;f.inner_rate_hz=1000;f.added_symbols=1;f.fhss=true;f.fhss_center_aligned=true;f.quiet_seconds=.055;f.ramp_seconds=2./3600;f.margin_seconds=.005;f.sample_rate=18000;f.bit_seconds=40;
 for(unsigned p:{64U,128U,256U}){ShapingOptions o;o.maximum_phase_samples=p;const auto start=std::chrono::steady_clock::now();
 try{const auto x=plan_shaping(f,o);std::cout<<std::setprecision(17)<<"phase="<<p<<" fallback="<<x.fallback<<" reason="<<x.reason<<" width="<<x.spectrum.placement_bandwidth_hz<<" ramp="<<x.format.ramp_seconds<<" center="<<x.format.fhss_center_aligned<<" pulse="<<pulse_shape_name(x.format.pulse_shape)<<" tile="<<x.geometry.tile_seconds<<" payload="<<x.geometry.payload_fine_cells_per_tile<<" coarse="<<x.spectrum.coarse_width_hz<<" phase_width="<<x.spectrum.phase_refinement_width_hz<<" refined="<<x.spectrum.refined_width_hz<<" tail="<<x.spectrum.measured_tail_fraction<<" kernels="<<x.spectrum.kernel_ffts;}
 catch(const std::exception& e){std::cout<<"phase="<<p<<" error="<<e.what();}
 std::cout<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<'\n';}
 f.fhss_center_aligned=false;
 for(auto pulse:{PulseShape::LegacyRrc,PulseShape::TaperedRrc})for(unsigned p:{64U,128U,256U}){f.pulse_shape=pulse;ShapingOptions o;o.maximum_phase_samples=p;const auto start=std::chrono::steady_clock::now();
 try{const auto x=shaping_spectrum(f,o);std::cout<<std::setprecision(17)<<"direct phase="<<p<<" pulse="<<pulse_shape_name(pulse)<<" converged="<<x.converged<<" width="<<x.placement_bandwidth_hz<<" coarse="<<x.coarse_width_hz<<" phase_width="<<x.phase_refinement_width_hz<<" refined="<<x.refined_width_hz<<" tail="<<x.measured_tail_fraction<<" kernels="<<x.kernel_ffts;}
 catch(const std::exception& e){std::cout<<"direct phase="<<p<<" pulse="<<pulse_shape_name(pulse)<<" error="<<e.what();}
 std::cout<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<'\n';}
}

import json, pathlib, hashlib, math
import numpy as np
from scipy import fft
root=pathlib.Path('/tmp/triad-shaping'); out=root/'template-comparison.json'
def read(name):
 p=root/('templates-'+name); m=json.loads((p/'manifest.json').read_text()); f=p/m['templates']['file']
 h=hashlib.sha256()
 with f.open('rb') as s:
  for block in iter(lambda:s.read(1<<20),b''):h.update(block)
 return m,np.memmap(f,dtype='<c16',mode='r',shape=tuple(m['templates']['shape'])),h.hexdigest()
a,x,hx=read('legacy1725'); b,y,hy=read('auto1725'); assert x.shape==y.shape
rows=[]
for i,epoch in enumerate(a['templates']['epoch_offsets_seconds']):
 energies={}; spectra={}
 for label,values in [('legacy',x[i]),('auto',y[i])]:
  e=[float(np.vdot(z,z).real) for z in values]; overlap=abs(np.vdot(values[0],values[1]))
  energies[label]=dict(bit_energy=e,difference=float(np.vdot(values[1]-values[0],values[1]-values[0]).real),phase_distance=max(0,sum(e)-2*overlap))
  n=fft.next_fast_len(values.shape[-1]); f=fft.fftfreq(n,1/a['sample_rate_hz']); p=np.sum(np.abs(fft.fft(values,n=n,axis=-1,workers=2))**2,axis=0);total=float(p.sum())
  spectra[label]={str(edge):float(p[np.abs(f)>edge].sum()/total) for edge in [112.5,132.1875,300,450,600]}
 e0=energies['legacy']; e1=energies['auto']; db=lambda v:10*math.log10(v)
 rows.append(dict(epoch=epoch,energy_change_db=[db(v/u) for u,v in zip(e0['bit_energy'],e1['bit_energy'])],difference_change_db=db(e1['difference']/e0['difference']),phase_distance_change_db=db(e1['phase_distance']/e0['phase_distance']),old_template_mismatch_loss_db=[-db(abs(np.vdot(x[i,j],y[i,j]))**2/(e0['bit_energy'][j]*e1['bit_energy'][j])) for j in range(2)],tail_fraction_by_halfwidth_hz=spectra))
out.write_text(json.dumps(dict(schema='triad-shaping-source-template-comparison-v1',template_hashes=dict(legacy=hx,auto=hy),rows=rows,scope='26 full-rate source templates,13clock epochs,2bits,samekey. No channel/receiver/synchronization sensitivity bound.',sample_rate_hz=a['sample_rate_hz']),indent=2)+'\n')
print(str(out))

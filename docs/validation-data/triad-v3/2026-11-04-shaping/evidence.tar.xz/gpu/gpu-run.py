import json, pathlib, subprocess, sys, time, hashlib
root=pathlib.Path('/tmp/triad-shaping'); protocol=json.loads((root/'gpu-protocol.json').read_text()); out=root/'results';out.mkdir(exist_ok=False)
py=sys.executable; exporter=root/'build/dev-cli/triad_helper_export'; receipts=[]
def run(name,cmd):
 start=time.monotonic()
 with (out/(name+'.log')).open('x') as f: p=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 r=dict(id=name,command=cmd,returncode=p.returncode,wall_seconds=time.monotonic()-start);receipts.append(r)
 (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n'); print(json.dumps(r),flush=True)
 if p.returncode: raise RuntimeError(name+' failed')
for v in protocol['variants']:
 tm=root/('templates-'+v['id'])
 if not tm.exists():run('templates-'+v['id'],[str(exporter),'--case','eme','--seconds','16','--seed','97001','--templates','--output',str(tm),*v['options']])
 for c in protocol['conditions']:
  name=v['id']+'-'+c['cn0']
  run(name,[py,'tools/triad_helper_campaign.py','--case','eme','--cn0',c['cn0'],'--templates',str(tm),'--output',str(out/name),'--exporter',str(exporter),'--seed-base',str(c['seed_base']),'--calibration-count','19','--signal-count','32','--null-count','16','--seconds','16','--device','cuda','--precision','fp32','--fft-backend','batched','--frequency-batch-size','16','--max-cached-hypotheses','13','--memory-limit-bytes',str(8*1024**3),'--discard-iq',*v['options']])
v=protocol['variants'][1]
run('auto1725-independent',[py,'tools/triad_helper_campaign.py','--case','eme','--cn0','1.5','--templates',str(root/'templates-auto1725'),'--output',str(out/'auto1725-independent'),'--exporter',str(exporter),'--seed-base','99000','--calibration-count','19','--signal-count','32','--null-count','16','--seconds','16','--device','cuda','--precision','fp32','--fft-backend','batched','--frequency-batch-size','16','--max-cached-hypotheses','13','--memory-limit-bytes',str(8*1024**3),'--discard-iq',*v['options']])
print('COMPLETE',flush=True)

import hashlib,json,math,pathlib
base=pathlib.Path(__file__).resolve().parent
initial=base.parent/'metrology-initial/v2'
def db(a,b):return 10*math.log10(a/b) if a>0 and b>0 else None
def read(folder):
 p=folder/'interference.json';x=json.loads(p.read_text());d=x['data_to_helper'];h=x['helper_to_data'];m=json.loads((folder/'composite/manifest.json').read_text())
 return dict(path=str(folder),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),case=m['case'],source_bit=json.loads((folder/'composite/evaluator-truth.json').read_text())['source_bit'],seed=json.loads((folder/'composite/evaluator-truth.json').read_text())['random_seed_roots']['fixture'],format=x['format'],helper_plan=x['helper_plan'],data_if_hz=m['channel']['nominal_conversion_if_hz'],source_data_energy=x['actual_component_energies']['emitted_source']['data_energy_samples'],source_helper_energy=x['actual_component_energies']['emitted_source']['helper_energy_samples'],received_data_energy=x['actual_component_energies']['received_data_full_tail'],received_helper_energy=x['actual_component_energies']['received_helper_full_tail'],filtered_data_energy=h['isolated_data_output_energy'],filter_retention=h['data_energy_retained_by_filter_fraction'],helper_to_noise_db=h['helper_to_measured_noise_energy_db'],noise_equivalent_db=h['power_based_noise_equivalent_penalty_db'],coherent_norm_envelope_db=h['coherent_noise_norm_envelope_db'],linearity_relative_residual=x['linearity']['maximum_relative_residual'],helper_model_checks=d['frequency_metrics_passed_estimator_model_checks'],estimator_states={k:[v['status'],v['reason']] for k,v in d['frequency_estimators'].items()},data_induced_diagnostic_cfo_delta_hz=d['composite_minus_helper_only_cfo_hz'],helper_only_diagnostic_frequency_error_hz=d['helper_only_noise_reference_error_hz'],composite_diagnostic_frequency_error_hz=d['composite_noise_reference_error_hz'],within_design_frequency_error_ratio=d['absolute_frequency_error_ratio'],within_design_transported_phase_rms_ratios=d['phase_rms_error_ratios'],within_design_fresh_phase_rms_ratios=d['centered_aperture_phase_rms_error_ratios'],fresh_phase_rms_degrees={a:{pilot:z['centered_aperture_fresh_phase']['rms_error_degrees'] for pilot,z in q.items()} for a,q in d['phase'].items()},clean_reference_projection_powers={pilot:sum(v['reference_power'] for v in d['phase']['composite'][pilot]['rows']) for pilot in ['low','high']},phase_resolved_counts={a:{pilot:[z['resolved_apertures'],z['apertures']] for pilot,z in q.items()} for a,q in d['phase'].items()},helper_window=[d['start_seconds'],d['end_seconds']],data_window_energy_fraction=d['fraction_of_full_received_data_energy_in_window'],data_frontend=x['data_frontend'])
out=dict(schema='triad-shaping-metrology-extension-summary-v1',scope='Two independent paired validation seeds95011/95012, bit1/0; representative HF, realized burst and highrate custom-frontend diagnostics. Initial seed95001 is selection/development evidence and retained separately; no pooling for reliability or confidence claims.',stages={})
for f in sorted(base.glob('*/interference.json')):out['stages'][f.parent.name]=read(f.parent)
comparisons={}
for seed in [95001,95011,95012]:
 if seed==95001:old=read(initial/'legacy6-1725');new={n:read(initial/n) for n in ['auto-1725','auto005-1775']}
 else:old=out['stages'][f'seed{seed}-legacy6-1725'];new={n:out['stages'][f'seed{seed}-{n}'] for n in ['auto-1725','auto005-1775']}
 comparisons[str(seed)]={}
 for name,row in new.items():
  old_freq=abs(old['composite_diagnostic_frequency_error_hz']);new_freq=abs(row['composite_diagnostic_frequency_error_hz'])
  comparisons[str(seed)][name]=dict(energy_change_db={k:db(row[k],old[k]) for k in ['source_data_energy','source_helper_energy','received_data_energy','received_helper_energy','filtered_data_energy']},absolute_diagnostic_frequency_error_hz=[old_freq,new_freq],net_diagnostic_frequency_error_ratio=(new_freq/old_freq if old_freq>1e-9 else None),frequency_ratio_denominator_floor_hz=1e-9,net_fresh_phase_rms_degrees={pilot:[old['fresh_phase_rms_degrees']['composite'][pilot],row['fresh_phase_rms_degrees']['composite'][pilot]] for pilot in ['low','high']},net_fresh_phase_rms_ratios={pilot:row['fresh_phase_rms_degrees']['composite'][pilot]/old['fresh_phase_rms_degrees']['composite'][pilot] for pilot in ['low','high']},clean_reference_projected_power_change_db={pilot:db(row['clean_reference_projection_powers'][pilot],old['clean_reference_projection_powers'][pilot]) for pilot in ['low','high']},interpretation='Net comparison retains frequency-placement channel/noise changes. Within-design Data contamination is measured separately; no Helper received-power renormalization. Single finite-noise frequency-error ratios are not estimator variance ratios.')
out['paired_net_change_from_legacy6_1725']=comparisons
out['completion']=json.loads((base/'completion.json').read_text())
out['limits']=['No DATA receiver/admission or population sensitivity qualification is performed by metrology.','Highrate custom FIR is not an implemented DATA receiver.','Fixed DATA-centered channel coordinates are retained: changing DATA IF shifts every Helper relative frequency and can change low/high fading, even with identical seeds.','Helper frequency errors are relative to a clean propagated-Helper fit on the same finite window, not physical truth; subgrid quadratic peaks are diagnostics rather than receiver narrowing.']
(base/'summary.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
for n,r in out['stages'].items():print(n,'high',r['helper_plan']['high_hz'],'I/NdB',round(r['helper_to_noise_db'],3),'coherentdb',round(r['coherent_norm_envelope_db'],6),'cfo_delta',r['data_induced_diagnostic_cfo_delta_hz'],'freshRatios',r['within_design_fresh_phase_rms_ratios'],'fit',r['helper_model_checks'])
print('NET',json.dumps(comparisons,indent=2))
print('COMPLETION',out['completion'])
# Descriptive net summaries retain selection and independent-validation groups.
groups={}
for group,seeds in [('all_three_paired_seeds',[95001,95011,95012]),('independent_validation_only',[95011,95012])]:
 aggregates={}
 for design in ['auto-1725','auto005-1775']:
  rows=[out['paired_net_change_from_legacy6_1725'][str(s)][design] for s in seeds]
  oldf=[r['absolute_diagnostic_frequency_error_hz'][0] for r in rows];newf=[r['absolute_diagnostic_frequency_error_hz'][1] for r in rows]
  rms=lambda values:math.sqrt(sum(v*v for v in values)/len(values))
  summary={'legacy_absolute_frequency_error_range_hz':[min(oldf),max(oldf)],'new_absolute_frequency_error_range_hz':[min(newf),max(newf)],'legacy_descriptive_frequency_error_rms_hz':rms(oldf),'new_descriptive_frequency_error_rms_hz':rms(newf),'descriptive_frequency_error_rms_ratio':rms(newf)/rms(oldf),'fresh_phase':{}}
  for pilot in ['low','high']:
   oldp=[r['net_fresh_phase_rms_degrees'][pilot][0] for r in rows];newp=[r['net_fresh_phase_rms_degrees'][pilot][1] for r in rows]
   ratios=[r['net_fresh_phase_rms_ratios'][pilot] for r in rows]
   summary['fresh_phase'][pilot]={'legacy_rms_degrees_range':[min(oldp),max(oldp)],'new_rms_degrees_range':[min(newp),max(newp)],'per_seed_net_ratio_range':[min(ratios),max(ratios)],'pooled_aperture_descriptive_rms_ratio':rms(newp)/rms(oldp)}
  aggregates[design]=summary
 groups[group]={'seeds':seeds,'designs':aggregates,'scope':'Descriptive paired finite-sample summaries only; not estimator-variance ratios, confidence intervals, or independent per-aperture population trials.'}
out['descriptive_net_summaries']=groups
(base/'summary.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')

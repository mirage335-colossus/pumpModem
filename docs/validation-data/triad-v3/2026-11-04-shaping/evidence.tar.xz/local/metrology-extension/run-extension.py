import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path.cwd();base=root/'local-evidence/triad-shaping/metrology-extension';exe=root/'local-evidence/triad-shaping/metrology-initial/bin/triad_helper_export';python='/tmp/triad-weak-env/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');expected=sha(exe);started=time.perf_counter()
controls=[['composite','on','on'],['data-only','on','off'],['helper-only','off','on'],['both-off','off','off']]
designs=[('auto-1725',['--shaping','auto','--data-if','1725']),('legacy6-1725',['--shaping','legacy','--data-if','1725','--ramp-seconds','.006']),('auto005-1775',['--shaping','auto','--data-if','1775','--shaping-tail-fraction','.005'])]
stages=[]
for seed in [95011,95012]:
 for name,extra in designs:stages.append(dict(name=f'seed{seed}-{name}',case='eme',seed=seed,bit=seed%2,extra=extra,start=40,frontend=['--frontend-profile','legacy'],role='independent paired validation'))
stages.extend([dict(name='hf36x10-off',case='hf',seed=95021,bit=1,extra=['--shaping','auto','--data-if','1725'],start=40,frontend=['--frontend-profile','legacy'],role='representative HF'),dict(name='eme-burst3',case='eme',seed=95022,bit=0,extra=['--shaping','auto','--data-if','1725','--burst-wait-tiles','3'],start=28,frontend=['--frontend-profile','legacy'],role='realized inter-tile Symbol Burst')])
protocol=dict(binary_sha256=expected,metrology_source_sha256=sha(root/'tools/triad_helper_interference.py'),threads=2,seconds=40,stages=stages,controls=controls,highrate_rule='Run one highrate custom-frontend quartet only if earlier fixed stages finish within260s; resource-only stopping, no outcome-based pruning.')
(base/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');receipts=[]
def invoke(command,log,timeout=180):
 if sha(exe)!=expected:raise RuntimeError('snapshot changed')
 begin=time.perf_counter()
 with log.open('x') as f:completed=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if sha(exe)!=expected:raise RuntimeError('snapshot changed')
 return dict(command=command,wall_seconds=time.perf_counter()-begin,returncode=completed.returncode)
def stage(s):
 folder=base/s['name'];folder.mkdir();begin=time.perf_counter();entries=[]
 for label,data,helper in controls:
  command=[str(exe),'--case',s['case'],'--seconds','40','--seed',str(s['seed']),'--bit',str(s['bit']),'--output',str(folder/label),'--data',data,'--helper',helper]+s['extra']
  entry=invoke(command,folder/(label+'.log'));entries.append(entry);(folder/'export-receipts.json').write_text(json.dumps(entries,indent=2)+'\n');print(json.dumps(dict(stage=s['name'],control=label,returncode=entry['returncode'],seconds=entry['wall_seconds'])),flush=True)
  if entry['returncode']:return dict(stage=s,status='native_export_failed',receipts=entries,total_wall_seconds=time.perf_counter()-begin)
 command=[python,str(root/'tools/triad_helper_interference.py'),'--selected',str(folder/'composite'),'--data-only',str(folder/'data-only'),'--helper-only',str(folder/'helper-only'),'--both-off',str(folder/'both-off'),'--helper-start-seconds',str(s['start'])]+s['frontend']+['--output',str(folder/'interference.json')]
 entry=invoke(command,folder/'metrology.log');return dict(stage=s,status='measured' if entry['returncode']==0 else 'metrology_failed',metrology=entry,total_wall_seconds=time.perf_counter()-begin)
for s in stages:
 result=stage(s);receipts.append(result);(base/'run-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(dict(stage=s['name'],status=result['status'],total_seconds=result['total_wall_seconds'])),flush=True)
for name,extra in [('fhss-added100-rate3p6',['--rate','3.6','--added-symbols','100','--fhss','on','--data-if','1725']),('fine600-rate3600-off',['--rate','3600','--added-symbols','1','--fhss','off','--data-if','2600'])]:
 command=[str(exe),'--case','eme','--seconds','40','--shaping','auto','--plan-only']+extra
 result=invoke(command,base/(name+'-plan.json'));(base/(name+'-plan-receipt.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(plan=name,returncode=result['returncode'],seconds=result['wall_seconds'])),flush=True)
if time.perf_counter()-started<260:
 s=dict(name='fine600-rate3600-off',case='eme',seed=95023,bit=1,extra=['--shaping','auto','--data-if','2600','--rate','3600','--added-symbols','1','--fhss','off'],start=40,frontend=['--frontend-profile','custom','--pass-hz','1375','--stop-hz','1500'],role='wideband custom frontend metrology; no DATA receiver qualification')
 result=stage(s);receipts.append(result);(base/'run-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(dict(stage=s['name'],status=result['status'],total_seconds=result['total_wall_seconds'])),flush=True)
else:(base/'highrate-resource-limit.json').write_text(json.dumps(dict(status='not_run_resource_budget',elapsed=time.perf_counter()-started))+'\n')
(base/'completion.json').write_text(json.dumps(dict(total_wall_seconds=time.perf_counter()-started,binary_sha256_after=sha(exe)),indent=2)+'\n')

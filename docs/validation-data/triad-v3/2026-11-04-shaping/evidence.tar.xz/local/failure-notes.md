# Retained diagnostic failures and corrections

- Initial exporter compilation referred to nonexistent `helper::auxiliary_pilot_frequency_hz`; corrected to the existing `helper::auxiliary_frequency_hz` before sampled work.
- Initial metrology triplet validation omitted source-bit and endpoint/arrival identity checks. Independent review found it; focused negative controls reproduced and corrected it before accepted metrology. Final tool tests cover those failures.
- An initial metrology capture sequence noticed a native binary changing during export, stopped, and retained its partial captures/receipt separately. It is excluded from accepted comparisons; restarted work used a private frozen binary.
- The maximal Added1000 FHSS layout error initially hid the existing one-million-cell workspace cap behind an aperture error. The planner now preserves the actual cause, and its regression checks the exact boundary.
- An unconditional 6ms auto ramp seed removed valid protected cells at higher rates before the preservation check. `pre-fix-allocation.json` and the ramp-input byte bridge retain the failure and correction. Strong fine60 source bytes remain identical.
- The first Rate1000 FHSS calculation conservatively fell back at64/128 phases. Independent diagnostic refinement to256 resolved phase-quadrature aliasing. Actual rendered spectra validate the corrected width. The convergence allowances and tail acceptance checks were not loosened.
- Independent review removed phase escalation for sampling-only failure; such cases retain conservative fallback. Mandatory FFT-cap preflight also avoids spending coarse work when the required fine grid is forbidden.
- The5% net Helper precision target is not uniformly met across moved frequencies; absolute errors and conditional practical-loss calculations are reported separately.
- Actual GPU receivers still admit wrong bits, including one of32 at the physical setting. These failures also occur with the legacy shape; no threshold was adjusted to hide them.

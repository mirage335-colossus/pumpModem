from pathlib import Path
import json,hashlib,tarfile,io,subprocess,platform
root=Path.cwd(); ev=root/'local-evidence/triad-shaping'; out=root/'docs/validation-data/triad-v3/2026-11-04-shaping'; out.mkdir(parents=True,exist_ok=True)
items={}
patch_path=ev/'final-tracked.patch'
patch_path.write_bytes(subprocess.check_output(['git','diff','--binary','--','src','include','tools','tests','CMakeLists.txt']))
def add(p,name):
 p=Path(p)
 if p.is_file():items[name]=p
add(patch_path,'final-source/tracked.patch')
for name in ['baseline-identity.json','native-adaptive-extended.log','triad-group-qualified.log','python-checks.log','exporter-tests-qualified.log','template-comparison.json','template-comparison.py','gpu-protocol.json','gpu-run.py','helper-off-protocol.json','execution-scope.json','summarize-pairs.py','paired-outcomes.json','planner-census-qualified.json','raised-if-plans-qualified.json','pre-fix-allocation.json','build-adaptive-reviewed.log','package-evidence.py','failure-notes.md']:
 add(ev/name,'local/'+name)
for folder in ['metrology-initial','metrology-extension','legacy-identity','ramp-input-bridge','known-channel']:
 for p in sorted((ev/folder).rglob('*')):
  if p.suffix in ('.json','.jsonl','.py','.log'):add(p,'local/'+str(p.relative_to(ev)))
gpu=ev/'gpu'
for p in sorted(gpu.rglob('*')):
 if not p.is_file() or p.suffix not in ('.json','.jsonl','.py','.cpp','.hpp','.log'):continue
 if p.name=='result.json' or '__pycache__' in p.parts:continue # exact duplicate of retained trials.jsonl
 add(p,'gpu/'+str(p.relative_to(gpu)))
probe=root/'local-evidence/triad-shaping-rate1000-phase'
for p in sorted(probe.rglob('*')):
 if p.is_file() and p.suffix in ('.json','.cpp','.hpp','.txt','.log'):add(p,'phase-diagnostic/'+str(p.relative_to(probe)))
changed=subprocess.check_output(['git','diff','--name-only','--','src','include','tools','tests','CMakeLists.txt'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','include','tools','tests'],text=True).splitlines()
for name in sorted(set(changed+untracked)):
 if (root/name).suffix in ('.py','.cpp','.hpp','.h','.txt') or name=='CMakeLists.txt':add(root/name,'final-source/'+name)
cache={}
for line in (root/'build/dev-cli/CMakeCache.txt').read_text().splitlines():
 if line.startswith(('CMAKE_BUILD_TYPE:','CMAKE_CXX_COMPILER:','CMAKE_CXX_FLAGS:','CMAKE_CXX_FLAGS_RELEASE:','CMAKE_CXX_FLAGS_RELWITHDEBINFO:')):
  name,value=line.split('=',1);cache[name]=value
identity=dict(build_cache=cache,schema='triad-shaping-source-bindings-v1',base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),final_exporter_sha256=hashlib.sha256((root/'build/dev-cli/triad_helper_export').read_bytes()).hexdigest(),gpu_exporter_sha256=json.loads((gpu/'hardware.json').read_text())['exporter_sha256'],compiler=subprocess.check_output(['c++','--version'],text=True).splitlines()[0],python=platform.python_version(),scope='Uncommitted isolated-study source. Native binary retained locally; archive retains source/build identities and final byte bridge, not release certification.',files={name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in items.items()})
(out/'source-bindings.json').write_text(json.dumps(identity,indent=2)+'\n')
archive=out/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for name,p in items.items():t.add(p,arcname=name,recursive=False)
 t.add(out/'source-bindings.json',arcname='source-bindings.json')
for source,target in [('planner-census-qualified.json','planner-census.json'),('raised-if-plans-qualified.json','raised-if-plans.json'),('paired-outcomes.json','paired-outcomes.json')]:
 (out/target).write_bytes((ev/source).read_bytes())
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'SHA256SUMS').write_text(f'{sha}  evidence.tar.xz\n')
print(json.dumps(dict(files=len(items),archive_bytes=archive.stat().st_size,sha256=sha)))

import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path.cwd(); base=root/'local-evidence/triad-shaping/metrology-initial'
exe=root/'build/dev-cli/triad_helper_export'; python='/tmp/triad-weak-env/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=sha(exe); env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
protocol=dict(binary_sha256=expected,metrology_source_sha256=sha(root/'tools/triad_helper_interference.py'),seed=95001,seconds=40,helper_window=[40,76],threads=2,controls=[['composite','on','on'],['data-only','on','off'],['helper-only','off','on'],['both-off','off','off']])
(base/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
results=[]
for name,extra in [('auto-1725',['--shaping','auto','--data-if','1725']),('legacy6-1725',['--shaping','legacy','--data-if','1725','--ramp-seconds','.006']),('auto005-1775',['--shaping','auto','--data-if','1775','--shaping-tail-fraction','.005'])]:
 folder=base/name;folder.mkdir();stage=time.perf_counter();rows=[]
 for label,data,helper in protocol['controls']:
  if sha(exe)!=expected:raise RuntimeError('native binary changed before export')
  output=folder/label
  command=[str(exe),'--case','eme','--seconds','40','--seed','95001','--output',str(output),'--data',data,'--helper',helper]+extra
  start=time.perf_counter()
  with (folder/(label+'.log')).open('x') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
  after=sha(exe)
  rows.append(dict(label=label,command=command,wall_seconds=time.perf_counter()-start,binary_sha256_after=after))
  (folder/'export-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(json.dumps(dict(stage=name,control=label,wall_seconds=rows[-1]['wall_seconds'])),flush=True)
  if after!=expected:raise RuntimeError('native binary changed during export')
 command=[python,str(root/'tools/triad_helper_interference.py'),'--selected',str(folder/'composite'),'--data-only',str(folder/'data-only'),'--helper-only',str(folder/'helper-only'),'--both-off',str(folder/'both-off'),'--helper-start-seconds','40','--frontend-profile','legacy','--output',str(folder/'interference.json')]
 start=time.perf_counter()
 with (folder/'metrology.log').open('x') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 result=dict(name=name,total_wall_seconds=time.perf_counter()-stage,metrology_wall_seconds=time.perf_counter()-start,metrology_command=command,binary_sha256=expected)
 results.append(result);(base/'run-receipts.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)

import json,pathlib,sys,statistics
from scipy.stats import beta
root=pathlib.Path(sys.argv[1]); output=pathlib.Path(sys.argv[2]); summaries={};rows={}
for p in sorted((root/'results').glob('*/summary.json')):
 summaries[p.parent.name]=json.loads(p.read_text());rows[p.parent.name]=[json.loads(s) for s in (p.parent/'trials.jsonl').read_text().splitlines()]
def outcome(r,arm):
 d=r['decisions'][arm]
 if r['trial']['phase']=='null':return 'false_admitted' if d['accepted'] else 'rejected_null'
 return 'missed' if not d['accepted'] else ('correct_admitted' if d['bit']==r['evaluator']['source_bit'] else 'wrong_admitted')
pairs=[]
for cond in ['1.5','physical']:
 for shape in ['auto1725','auto1775']:
  pairs.append(('legacy1725-'+cond,shape+'-'+cond,['baseline','assisted']))
pairs.append(('auto1725-1.5','auto1725-helperoff-diagnostic',['baseline']))
comparisons=[]
for a,b,arms in pairs:
 assert [r['trial'] for r in rows[a]]==[r['trial'] for r in rows[b]]
 for arm in arms:
  held=[(u,v) for u,v in zip(rows[a],rows[b]) if u['trial']['phase']!='calibration'];signals=[(u,v) for u,v in held if u['trial']['phase']=='signal']; nulls=[(u,v) for u,v in held if u['trial']['phase']=='null']
  counts={bit:sum(outcome(u,arm)!=outcome(v,arm) for u,v in signals if u['trial']['bit']==bit) for bit in [0,1]}; ns={bit:sum(u['trial']['bit']==bit for u,v in signals) for bit in [0,1]}
  upper=sum(1 if counts[bit]==ns[bit] else float(beta.ppf(.975,counts[bit]+1,ns[bit]-counts[bit])) for bit in [0,1])/2
  comparisons.append(dict(reference=a,candidate=b,arm=arm,signal_outcome_disagreements=sum(counts.values()),signal_trials=len(signals),per_bit_disagreements=counts,per_bit_trials=ns,balanced_disagreement_95pct_upper=upper,uncertainty='Average of two97.5%one-sided within-bit CPbounds, Bonferroni95%for equallyweighted bits conditional onbothfrozengates and independentrepresentative paired draws; notsimultaneousacrossconditions/arms.',null_admission_disagreements=sum(outcome(u,arm)!=outcome(v,arm) for u,v in nulls),raw_signal_bit_disagreements=sum(u[arm]['bit']!=v[arm]['bit'] for u,v in signals),maximum_absolute_score_change=max(abs(u[arm]['working_presence']-v[arm]['working_presence']) for u,v in zip(rows[a],rows[b]))))
output.write_text(json.dumps(dict(schema='triad-shaping-paired-outcomes-v1',counts={k:{a:v['counts'] for a,v in s['outcomes'].items()} for k,s in summaries.items()},paired=comparisons,total_captures=sum(s['completed_trials'] for s in summaries.values()),timing={k:s['timing'] for k,s in summaries.items()},scope='Same seed comparison; no thresholdtuning. Signal uncertainty and nullintervals retainedinoriginalcampaignsummaries. Contended finalstages arenotisolatedlatencybenchmarks.'),indent=2)+'\n')
for r in comparisons: print(r['reference'],r['candidate'],r['arm'],r['signal_outcome_disagreements'],r['null_admission_disagreements'],r['raw_signal_bit_disagreements'],r['maximum_absolute_score_change'])

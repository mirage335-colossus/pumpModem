"""Keep the requested known-complex-trajectory results; omit unused phase bounds.

Run after run-known-channel.py. This only removes incidental diagnostic fields;
source/input identities, clean energies, distances and BER values are unchanged.
"""
import json
from pathlib import Path
base=Path(__file__).resolve().parent
summary=json.loads((base/'summary.json').read_text())
for row in summary['rows']:
 for key in ('real_clean_mean_inner_product','unknown_global_phase_distance_bounds_samples','phase_invariant_exact_distance_available'):
  row.pop(key,None)
summary['protocol']['phase_free']='No phase-invariant distance is claimed; known-complex-trajectory results only. Clean mean energies are retained as energy checks.'
summary['limits']=[v for v in summary['limits'] if not v.startswith('Exact unknown-global-phase')]
summary['report_scope_note']='Unused incidental global-phase-bound fields omitted; known-complex-trajectory distances, clean energies, input identities and BER calculations unchanged.'
(base/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
for row in summary['rows']:
 (base/f"seed{row['seed']}-{row['design']}"/'distance.json').write_text(json.dumps(row,indent=2,allow_nan=False)+'\n')
(base/'distances.json').write_text(json.dumps(summary['rows'],indent=2,allow_nan=False)+'\n')
protocol=json.loads((base/'protocol.json').read_text());protocol['phase_free']=summary['protocol']['phase_free']
(base/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')

import hashlib,json,math,os,pathlib,subprocess,time
import numpy as np
from scipy.special import ndtr,log_ndtr
root=pathlib.Path.cwd();base=root/'local-evidence/triad-shaping/known-channel';exe=base/'bin/triad_helper_export';expected='90f5859f49b65daad302b5f080bc4f0160b4ff6261c5e24b429e238123039d4b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
legacy_campaign=root/'local-evidence/triad-shaping/gpu/results/legacy1725-physical';lines=[json.loads(s) for s in (legacy_campaign/'trials.jsonl').read_text().splitlines()]
wrong=[r for r in lines if r['trial']['phase']=='signal' and any(d['accepted'] and d['bit']!=r['evaluator']['source_bit'] for d in r['decisions'].values())]
if len(wrong)!=1:raise RuntimeError('expected one named wrong-admitted physical signal')
selected=wrong[0];seed=selected['trial']['seed'];env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');started=time.perf_counter();rows=[]
for name,campaign,extra in [('legacy6-1725',legacy_campaign,['--shaping','legacy','--ramp-seconds','.006']),('auto-1725',root/'local-evidence/triad-shaping/gpu/results/auto1725-physical',['--shaping','auto'])]:
 original=json.loads((campaign/selected['trial']['id']/'manifest.json').read_text());originaltruth=json.loads((campaign/selected['trial']['id']/'evaluator-truth.json').read_text());folder=base/f'wrong-seed{seed}-{name}';folder.mkdir();captured=[];receipts=[]
 trialrow=next(json.loads(s) for s in (campaign/'trials.jsonl').read_text().splitlines() if json.loads(s)['trial']['seed']==seed and json.loads(s)['trial']['phase']=='signal')
 for bit in [0,1]:
  output=folder/f'bit{bit}';command=[str(exe),'--case','eme','--seconds','16','--seed',str(seed),'--bit',str(bit),'--key-seed',str(original['key_seed']),'--epoch',str(original['public_epoch_seconds']),'--data','on','--helper','off','--data-if','1725','--output',str(output)]+extra
  if sha(exe)!=expected:raise RuntimeError('snapshot changed')
  start=time.perf_counter()
  with (folder/f'bit{bit}.log').open('x') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
  m=json.loads((output/'manifest.json').read_text());t=json.loads((output/'evaluator-truth.json').read_text())
  for field in ['format','calendar','channel','power','helper_plan','key_seed','public_epoch_seconds']:
   if m[field]!=original[field]:raise RuntimeError('original campaign geometry differs '+field)
  for field in ['source_epoch_offset_seconds','arrival_seconds','tx','rx','random_seed_roots']:
   if t[field]!=originaltruth[field]:raise RuntimeError('original campaign physical realization differs '+field)
  v=np.memmap(output/m['validity']['file'],mode='r',dtype='u1',shape=tuple(m['validity']['shape']))
  if np.any(v!=1):raise RuntimeError('incomplete samples')
  path=output/m['observation']['file'];arr=np.memmap(path,mode='r',dtype='<c16',shape=tuple(m['observation']['shape']));captured.append((m,t,arr));receipts.append(dict(bit=bit,command=command,seconds=time.perf_counter()-start,observation_sha256=sha(path),manifest_sha256=sha(output/'manifest.json'),truth_sha256=sha(output/'evaluator-truth.json')));(folder/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(dict(seed=seed,design=name,bit=bit,seconds=receipts[-1]['seconds'])),flush=True)
 (m0,t0,y0),(m1,t1,y1)=captured
 if m0!=m1:
  for field in ['format','calendar','channel','power','helper_plan','key_seed','public_epoch_seconds','observation','validity']:
   if m0[field]!=m1[field]:raise RuntimeError('paired manifest differs '+field)
 delta=np.asarray(y1)-np.asarray(y0);d2=float(np.vdot(delta,delta).real);variance=m0['power']['complex_noise_variance'];z=math.sqrt(d2/(2*variance));weakvar=m0['sample_rate_hz']/10**.15;zw=math.sqrt(d2/(2*weakvar))
 rows.append(dict(design=name,seed=seed,actual_failed_source_bit=selected['evaluator']['source_bit'],campaign_decisions=trialrow['decisions'],campaign_trials_sha256=sha(campaign/'trials.jsonl'),original_manifest_sha256=sha(campaign/selected['trial']['id']/'manifest.json'),original_truth_sha256=sha(campaign/selected['trial']['id']/'evaluator-truth.json'),original_campaign_geometry_and_realization_verified=True,samples=len(y0),sample_rate_hz=m0['sample_rate_hz'],actual_data_seconds=m0['format']['bit_seconds'],complex_noise_variance=variance,difference_energy_samples=d2,distance_over_noise=d2/variance,equal_prior_known_complex_trajectory_ber=float(ndtr(-z)),log10_ber=float(log_ndtr(-z)/math.log(10)),clean_received_bit_energy=[t0['channel_report']['signal_energy_samples'],t1['channel_report']['signal_energy_samples']],analytic_1p5_db_hz=dict(complex_noise_variance=weakvar,distance_over_noise=d2/weakvar,equal_prior_known_complex_trajectory_ber=float(ndtr(-zw)),scope='Analytic variance rescaling, not a new received trial.'),receipts=receipts))
result=dict(schema='triad-shaping-wrong-admission-oracle-diagnostic-v1',selection='Single wrong-admitted physical legacy+auto1725 signal, selected after receiver outcomes; diagnostic only, not validation or a statistical test.',seed=seed,binary_sha256=expected,binary_sha256_after=sha(exe),rows=rows,fixed_power_distance_change_db=10*math.log10(rows[1]['difference_energy_samples']/rows[0]['difference_energy_samples']),total_wall_seconds=time.perf_counter()-started,scope='Known complete complex mean trajectory, including synchronization/oscillator/channel history, with raw post-channel white complex Gaussian noise. It excludes unknown-nuisance fitting/search/admission loss; no claim of achieved receiver performance or cause proof.',limits=['A small oracle BER at an observed wrong admission indicates a substantial receiver/model/acquisition gap under the stated noise/channel assumptions, but does not by itself prove which algorithmic mechanism caused the error.','Helper is disabled in new captures; a known common Helper mean would cancel from the two bit means in a linear channel. Existing bidirectional metrology separately measures Helper interference.'])
(base/'wrong-admission-diagnostic.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result),flush=True)

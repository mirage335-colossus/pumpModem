import hashlib,json,math,os,pathlib,subprocess,time
import numpy as np
root=pathlib.Path.cwd();base=root/'local-evidence/triad-shaping/known-channel';exe=base/'bin/triad_helper_export';expected='90f5859f49b65daad302b5f080bc4f0160b4ff6261c5e24b429e238123039d4b';seed=98041
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');started=time.perf_counter();rows=[]
for name,extra in [('legacy6-1725',['--shaping','legacy','--ramp-seconds','.006']),('auto-1725',['--shaping','auto'])]:
 folder=base/f'wrong-seed{seed}-{name}';ref=json.loads((folder/'bit0/manifest.json').read_text());reftruth=json.loads((folder/'bit0/evaluator-truth.json').read_text());output=folder/'both-off';command=[str(exe),'--case','eme','--seconds','16','--seed',str(seed),'--bit','0','--key-seed',str(ref['key_seed']),'--epoch',str(ref['public_epoch_seconds']),'--data','off','--helper','off','--data-if','1725','--output',str(output)]+extra
 if sha(exe)!=expected:raise RuntimeError('snapshot changed')
 begin=time.perf_counter()
 with (folder/'both-off.log').open('x') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 m=json.loads((output/'manifest.json').read_text());t=json.loads((output/'evaluator-truth.json').read_text())
 for field in ['format','calendar','channel','power','helper_plan','key_seed','public_epoch_seconds','observation','validity']:
  if m[field]!=ref[field]:raise RuntimeError('noise control geometry mismatch '+field)
 for field in ['source_epoch_offset_seconds','arrival_seconds','arrival_override','unmodified_arrival_draw_seconds','tx','rx','random_seed_roots']:
  if t[field]!=reftruth[field]:raise RuntimeError('noise control physical realization mismatch '+field)
 if m['data_enabled'] or m['helper_enabled'] or t['channel_report']['signal_energy_samples']!=0:raise RuntimeError('not a pure noise control')
 arrays=[]
 for label in ['bit0','bit1','both-off']:
  path=folder/label;meta=json.loads((path/'manifest.json').read_text());valid=np.memmap(path/meta['validity']['file'],mode='r',dtype='u1',shape=tuple(meta['validity']['shape']))
  if np.any(valid!=1):raise RuntimeError('missing samples')
  arrays.append(np.memmap(path/meta['observation']['file'],mode='r',dtype='<c16',shape=tuple(meta['observation']['shape'])))
 y0,y1,noise=arrays;mean0=np.asarray(y0)-np.asarray(noise);mean1=np.asarray(y1)-np.asarray(noise);delta=mean1-mean0;variance=m['power']['complex_noise_variance'];d2=float(np.vdot(delta,delta).real);noise_projection=float(np.vdot(delta,noise).real);llr10=(2*noise_projection-d2)/variance
 residual0=float(np.vdot(np.asarray(y0)-mean0,np.asarray(y0)-mean0).real);residual1=float(np.vdot(np.asarray(y0)-mean1,np.asarray(y0)-mean1).real);direct=(residual0-residual1)/variance
 rows.append(dict(design=name,seed=seed,true_bit=0,oracle_selected_bit=int(llr10>0),oracle_correct=llr10<=0,log_likelihood_bit1_minus_bit0=llr10,log_likelihood_true_bit0_minus_bit1=-llr10,distance_over_noise=d2/variance,twice_real_noise_projection_over_variance=2*noise_projection/variance,clean_received_mean_energy=[float(np.vdot(mean0,mean0).real),float(np.vdot(mean1,mean1).real)],original_report_clean_energy=[reftruth['channel_report']['signal_energy_samples'],json.loads((folder/'bit1/evaluator-truth.json').read_text())['channel_report']['signal_energy_samples']],residual_energy_for_bit0=residual0,residual_energy_for_bit1=residual1,direct_residual_difference_llr=direct,direct_vs_stable_llr_discrepancy=direct-llr10,samples=len(noise),complex_noise_variance=variance,control_receipt=dict(command=command,wall_seconds=time.perf_counter()-begin,manifest_sha256=sha(output/'manifest.json'),truth_sha256=sha(output/'evaluator-truth.json'),observation_sha256=sha(output/m['observation']['file']),validity_sha256=sha(output/m['validity']['file'])),identities_verified=True))
 print(json.dumps(rows[-1]),flush=True)
result=dict(schema='triad-shaping-exact-failure-oracle-decision-v1',seed=seed,selection='Post-outcome focused diagnostic of the single physical wrong admission, not held-out validation.',binary_sha256=expected,binary_sha256_after=sha(exe),rows=rows,total_wall_seconds=time.perf_counter()-started,formula='log p(y|bit1)-log p(y|bit0) = (2 Re[(mean1-mean0)^H (y-mean0)] - ||mean1-mean0||^2)/sigma^2 for CN(0,sigma^2 I).',scope='Genie-known complex means and complete synchronization/channel/oscillator trajectory, equal bit priors, exact same raw bit0 thermal-noise realization. DATA-only captures are used: in the linear composite model a known bit-independent Helper mean cancels from both hypotheses and the centered observation.',limitations=['This is not an implementation of the practical unknown-channel/synchronization receiver.','Correct oracle decisions on the actual failed noise realization support an inference/model/acquisition gap, but do not identify its exact cause.','No extra scenarios or probability-confidence claim; all finite physical/filter tails and raw sample rows retained.'])
(base/'oracle-decision.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(total_seconds=result['total_wall_seconds'],binary_unchanged=result['binary_sha256']==result['binary_sha256_after'])),flush=True)

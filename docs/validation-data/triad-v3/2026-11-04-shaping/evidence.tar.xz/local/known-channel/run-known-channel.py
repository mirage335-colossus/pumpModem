import hashlib,json,math,os,pathlib,shutil,subprocess,time
import numpy as np
from scipy.special import ndtr,log_ndtr
root=pathlib.Path.cwd();base=root/'local-evidence/triad-shaping/known-channel';exe=base/'bin/triad_helper_export';expected='90f5859f49b65daad302b5f080bc4f0160b4ff6261c5e24b429e238123039d4b'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(1<<20),b''):h.update(data)
 return h.hexdigest()
if sha(exe)!=expected:raise RuntimeError('unexpected frozen binary')
sources=['tools/triad-helper-export.cpp','src/triad_modem_v3.cpp','src/triad_simulation_stream.cpp','src/triad_shaping.cpp','include/datapump/triad_modem_v3.hpp','include/datapump/triad_simulation.hpp','include/datapump/triad_shaping.hpp']
source_hashes={}
for name in sources:
 p=base/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p);source_hashes[name]=sha(p)
designs=[('legacy6-1725',['--shaping','legacy','--data-if','1725','--ramp-seconds','.006']),('auto-1725',['--shaping','auto','--data-if','1725']),('auto005-1775',['--shaping','auto','--data-if','1775','--shaping-tail-fraction','.005'])]
protocol=dict(binary_sha256=expected,source_hashes=source_hashes,seeds=[97019,97020,97021],designs=designs,seconds=16,cn0='physical',components='DATA on, Helper off; sourcebits0and1 with identical physical/noise roots',threads=2,selection='These seeds were already frozen held-out receiver signal trials; this oracle diagnostic was selected after their outcomes. All listed seeds/designs run without outcome-based stopping.',oracle='Known full complex sampled mean trajectory including synchronization, oscillator and channel; equal-prior two-hypothesis AWGN discrimination. Not an achievable unknown-nuisance receiver or operational admission gate.',noise='CN(0,sigma^2 I) post-channel raw complex noise, no AGC or sampled frontend enabled by exporter; pair subtraction cancels shared noise.',phase_free='Only exact clean-mean energies and real cross-inner-product are available from channel reports and difference; unknown imaginary inner-product prevents an exact global-phase-invariant distance. Cauchy bounds are reported without guessing noise cross terms.')
(base/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');rows=[];started=time.perf_counter()
def metrics(d2,variance):
 z=math.sqrt(d2/(2*variance));return dict(complex_sample_noise_variance=variance,distance_over_noise=d2/variance,equal_prior_known_channel_ber=float(ndtr(-z)),log10_ber=float(log_ndtr(-z)/math.log(10)),normal_decision_separation=z)
for seed in protocol['seeds']:
 for name,extra in designs:
  folder=base/f'seed{seed}-{name}';folder.mkdir();captures=[];receipts=[]
  for bit in [0,1]:
   output=folder/f'bit{bit}';command=[str(exe),'--case','eme','--seconds','16','--seed',str(seed),'--bit',str(bit),'--data','on','--helper','off','--output',str(output)]+extra
   if sha(exe)!=expected:raise RuntimeError('snapshot changed before export')
   start=time.perf_counter()
   with (folder/f'bit{bit}.log').open('x') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
   if sha(exe)!=expected:raise RuntimeError('snapshot changed during export')
   m=json.loads((output/'manifest.json').read_text());t=json.loads((output/'evaluator-truth.json').read_text());valid=np.memmap(output/m['validity']['file'],mode='r',dtype='u1',shape=tuple(m['validity']['shape']))
   if np.any(valid!=1):raise RuntimeError('noncomplete capture')
   path=output/m['observation']['file'];shape=tuple(m['observation']['shape'])
   if m['observation']['dtype']!='<c16' or len(shape)!=1 or path.stat().st_size!=shape[0]*16:raise RuntimeError('invalid raw array')
   captures.append((m,t,np.memmap(path,mode='r',dtype='<c16',shape=shape)))
   receipts.append(dict(bit=bit,command=command,wall_seconds=time.perf_counter()-start,manifest_sha256=sha(output/'manifest.json'),truth_sha256=sha(output/'evaluator-truth.json'),observation_sha256=sha(path),validity_sha256=sha(output/m['validity']['file'])))
   (folder/'export-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(dict(seed=seed,design=name,bit=bit,seconds=receipts[-1]['wall_seconds'])),flush=True)
  (m0,t0,y0),(m1,t1,y1)=captures
  for field in ['schema','case','control','sample_rate_hz','public_epoch_seconds','key_seed','format','calendar','channel','power','helper_plan','data_enabled','helper_enabled','observation','validity']:
   if m0[field]!=m1[field]:raise RuntimeError('bit-pair public mismatch '+field)
  for field in ['source_epoch_offset_seconds','arrival_seconds','arrival_override','unmodified_arrival_draw_seconds','tx','rx','random_seed_roots']:
   if t0[field]!=t1[field]:raise RuntimeError('bit-pair physical mismatch '+field)
  if t0['source_bit']!=0 or t1['source_bit']!=1 or len(y0)!=len(y1):raise RuntimeError('bit-pair labels/calendar mismatch')
  delta=np.asarray(y1)-np.asarray(y0);d2=float(np.vdot(delta,delta).real);e0=t0['channel_report']['signal_energy_samples'];e1=t1['channel_report']['signal_energy_samples'];real_inner=(e0+e1-d2)/2
  phase_lower=(math.sqrt(e0)-math.sqrt(e1))**2;phase_upper=max(phase_lower,e0+e1-2*abs(real_inner))
  fs=m0['sample_rate_hz'];physical=m0['power']['data_cn0_db_hz'];variance=m0['power']['complex_noise_variance'];weakvariance=fs/10**(1.5/10)
  row=dict(seed=seed,design=name,pair_identities_verified=True,samples=len(y0),sample_rate_hz=fs,full_observation_seconds=len(y0)/fs,calendar=m0['calendar'],format=m0['format'],power_reference=m0['power'],helper_plan=m0['helper_plan'],source_bit0_energy=t0['source_energy']['data_energy_samples'],source_bit1_energy=t1['source_energy']['data_energy_samples'],clean_received_bit_energy=[e0,e1],difference_energy_samples=d2,real_clean_mean_inner_product=real_inner,unknown_global_phase_distance_bounds_samples=[phase_lower,phase_upper],phase_invariant_exact_distance_available=False,physical_cn0_db_hz=physical,physical=metrics(d2,variance),analytic_1p5_db_hz=dict(**metrics(d2,weakvariance),scope='Analytic noise-variance rescaling of the same fixed clean means; not new noisy reception trials.'),receipts=receipts)
  rows.append(row);(folder/'distance.json').write_text(json.dumps(row,indent=2,allow_nan=False)+'\n');(base/'distances.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
comparisons=[]
for seed in protocol['seeds']:
 reference=next(r for r in rows if r['seed']==seed and r['design']=='legacy6-1725')
 for row in [r for r in rows if r['seed']==seed and r['design']!='legacy6-1725']:
  if row['power_reference']['data_w']!=reference['power_reference']['data_w'] or row['power_reference']['reference_normalized_data_mean_norm']!=reference['power_reference']['reference_normalized_data_mean_norm']:raise RuntimeError('power references differ')
  energy=(row['source_bit0_energy']+row['source_bit1_energy'])/2;refenergy=(reference['source_bit0_energy']+reference['source_bit1_energy'])/2
  comparisons.append(dict(seed=seed,design=row['design'],fixed_power_distance_change_db=10*math.log10(row['difference_energy_samples']/reference['difference_energy_samples']),source_mean_energy_change_db=10*math.log10(energy/refenergy),distance_per_emitted_energy_change_db=10*math.log10((row['difference_energy_samples']/energy)/(reference['difference_energy_samples']/refenergy)),normalization='Identical40W DATA allocation and fixed public bit0 power reference; no per-bit or per-realization waveform renormalization. Distance-per-emitted-energy is a diagnostic efficiency ratio only.'))
summary=dict(schema='triad-shaping-known-channel-distance-v1',protocol=protocol,rows=rows,comparisons=comparisons,total_wall_seconds=time.perf_counter()-started,binary_sha256_after=sha(exe),source_hashes_after={name:sha(root/name) for name in sources},limits=['Known complex trajectory oracle; channel and synchronization fitting/search/admission loss excluded.','Thermal noise cancels between bit-pair captures because roots and state calendars are identical; subtraction retains complete source/channel/filter tails.','Analytic1.5dB-Hz values are not demonstrated reception rates.','Onlythreefixed post-outcome diagnosticseeds; no probability-confidence claim or universal waveform optimality.','Exact unknown-global-phase mean distance is unavailable; the reported interval uses Cauchy and known clean-mean energies, subject to FP64 accumulation.'])
(base/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(total_seconds=summary['total_wall_seconds'],comparisons=comparisons)),flush=True)

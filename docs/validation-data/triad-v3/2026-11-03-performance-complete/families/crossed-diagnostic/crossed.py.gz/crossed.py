#!/usr/bin/env python3
"""Six-block actual-waveform cache/schedule discriminator. No qualification."""
import argparse
import json
import math
import os
from pathlib import Path
import runpy
import statistics
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/"tools"))
import triad_perf_families as sample
from triad_perf_staged import generation_calendar


def worker_stats(worker, cpus):
    fields = Path(f"/proc/{worker.process.pid}/stat").read_text().rsplit(")", 1)[1].split()
    hz = os.sysconf("SC_CLK_TCK")
    frequencies = {}
    for cpu in cpus:
        path = Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq")
        try:
            frequencies[str(cpu)] = int(path.read_text().strip())
        except (OSError, ValueError):
            frequencies[str(cpu)] = None
    return {"user_seconds": int(fields[11])/hz, "system_seconds": int(fields[12])/hz,
            "last_processor": int(fields[36]), "assigned_core_khz_snapshot": frequencies}


def take_receiver(worker, path, case, expected, cpus):
    before = worker_stats(worker, cpus)
    result = sample.receive(worker, path, case, "cpu", "fp32")
    after = worker_stats(worker, cpus)
    signature = sample.complete_work_signature({"receiver_runs": [result]})
    if signature != expected:
        raise ValueError("crossed diagnostic changed the full receiver workload")
    cpu = sum(after[k]-before[k] for k in ("user_seconds", "system_seconds"))
    return {"receipt": result, "worker_cpu_seconds": cpu, "before": before, "after": after,
            "worker_cpu_over_request_wall": cpu/result["request_wall_seconds"]}


def array_hashes(files):
    return {name: hash_ for name, hash_ in files.items() if name != "manifest.json"}


def summarize(rows):
    output = {}
    for metric, get in (
        ("request_wall_seconds", lambda row: row["receipt"]["request_wall_seconds"]),
        ("worker_cpu_seconds", lambda row: row["worker_cpu_seconds"]),
        ("nested_update_wall_seconds", lambda row: row["receipt"]["receiver"]["seconds"]["update_iterator_and_transfer_nested"]),
    ):
        conditions = {}
        for key in ("cached", "fresh"):
            for position in (0, 1):
                conditions[f"{key}_{position}"] = [get(row["measurements"][key]) for row in rows if row["order"][position] == key]
        means = {k: statistics.fmean(v) for k, v in conditions.items()}
        differences = {k: [get(row["measurements"]["fresh"])-get(row["measurements"]["cached"])
                           for row in rows if row["order"][0] == k] for k in ("cached", "fresh")}
        f_second, f_first = map(statistics.fmean, (differences["cached"], differences["fresh"]))
        output[metric] = {"condition_means": means, "fresh_minus_cached_when_fresh_second": differences["cached"],
                          "fresh_minus_cached_when_fresh_first": differences["fresh"],
                          "balanced_fresh_minus_cached_effect": (f_second+f_first)/2,
                          "balanced_following_receiver_minus_immediately_after_generation_effect": (f_second-f_first)/2}
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--source-report", type=Path, required=True,
                        help="original staged Gaussian case report with exact cached input hashes")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--budget-seconds", type=float, default=58.)
    parser.add_argument("--fresh-seed", type=int, default=773410001)
    a = parser.parse_args()
    if not 0 < a.budget_seconds <= 65:
        parser.error("crossed diagnostic must stay within 65 seconds")
    root = a.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    binary = a.binary.resolve(strict=True)
    old = json.loads(a.source_report.read_text())
    case = old["identity"]["case"]
    profile = old["identity"]["generation_profile"]
    expected_sha = old["identity"]["binaries"]["candidate"]
    if case["id"] != "gaussian-hour" or old["identity"]["precision"] != "fp32":
        raise ValueError("expected original FP32 Gaussian-hour report")
    if sample.file_sha(binary) != expected_sha:
        raise ValueError("exporter binary does not match the original cached observation")
    fixture = old["cached_fixtures"]["candidate"]
    a_seed = fixture["generation"]["seed"]
    blocks = [{"seed": a.fresh_seed+17*i, "order": ["cached", "fresh"] if i % 2 == 0 else ["fresh", "cached"]}
              for i in range(6)]
    if a_seed in {b["seed"] for b in blocks}:
        raise ValueError("fresh capture seeds overlap the cached input")
    cpus = sorted(os.sched_getaffinity(0))
    plan = {"schema": "triad-perf-crossed-cache-diagnostic-v1", "case": case, "profile": profile,
            "source_report_sha256": sample.file_sha(a.source_report), "exporter_binary_sha256": expected_sha,
            "script_sha256": sample.file_sha(__file__),
            "harness": {name: sample.file_sha(sample.WORKER.with_name(name)) for name in sample.MEASUREMENT_DEPENDENCIES},
            "cached_seed": a_seed, "cached_fixture_sha256": fixture["fixture"][0]["sha256"],
            "blocks": blocks, "affinity_cpus": cpus, "receiver_threads": 2, "native_threads": 1,
            "scope": "one source and six descriptive balanced blocks; every fresh full export precedes both full receiver calls",
            "kernel_clock_note": "core frequency snapshots are endpoint observations, not measured clocks during individual kernels",
            "limitations": "data/fixture age contrast is combined; first versus second receiver also changes elapsed time and prior work; no statistical qualification"}
    sample.write_json(root/"plan.json", {**plan, "plan_sha256": sample.digest(plan)})

    common = runpy.run_path(str(ROOT/"tools/triad-performance.py"))
    start = time.perf_counter()
    deadline = time.monotonic()+a.budget_seconds
    worker = common["ReceiverWorker"](ROOT, threads=2, deadline=deadline,
                log_directory=root, name="candidate", adapter=sample.WORKER)
    rows = []
    try:
        setup = sample.case_worker_setup(worker, case, "cpu")
        if setup["source_sha256"] != old["identity"]["source_sha256"]["candidate"]:
            raise ValueError("candidate receiver source differs from the original timing")
        with tempfile.TemporaryDirectory(prefix="captures-", dir=root) as work:
            work = Path(work)
            cached, regeneration = sample.export_fixtures(binary, profile, a_seed, 1, work/"fixed-A", 1, deadline)
            actual = sample.fixture_evidence(cached)
            if array_hashes(actual[0]["sha256"]) != array_hashes(fixture["fixture"][0]["sha256"]):
                raise ValueError("regeneration did not reproduce the original cached array bytes")
            full_calendar = generation_calendar(cached[0])
            if full_calendar != fixture["work"]["calendars"][0]:
                raise ValueError("regenerated A changed the original public calendar")
            warmup = sample.receive(worker, cached, case, "cpu", "fp32")
            expected = sample.complete_work_signature({"receiver_runs": [warmup]})
            sample.write_json(root/"setup.json", {"setup": setup, "worker_startup_seconds": worker.external_startup_seconds,
                "regeneration": regeneration, "fixture": actual, "full_calendar": full_calendar, "warmup": warmup,
                "binding": "all original cached array bytes verified; regenerated manifest has a new output argument"})

            for i, block in enumerate(blocks):
                fresh, generation = sample.export_fixtures(binary, profile, block["seed"], 1, work/f"fresh-{i}", 1, deadline)
                measurements = {}
                for key in block["order"]:
                    measurements[key] = take_receiver(worker, cached if key == "cached" else fresh, case, expected, cpus)
                if generation_calendar(fresh[0]) != full_calendar:
                    raise ValueError("fresh native generation changed the full public calendar")
                scores = measurements["cached"]["receipt"]["receiver"]["result"]["scores"]
                baseline = warmup["receiver"]["result"]["scores"]
                if any(not math.isclose(x, y, rel_tol=1e-5, abs_tol=1e-5) for x, y in zip(scores, baseline, strict=True)):
                    raise ValueError("unchanged cached waveform changed scores")
                row = {**block, "generation": generation, "fixture": sample.fixture_evidence(fresh), "measurements": measurements}
                rows.append(row)
                sample.write_json(root/f"block-{i:02d}.json", row)

            if sample.fixture_evidence(cached)[0]["sha256"] != actual[0]["sha256"]:
                raise ValueError("retained A changed during the diagnostic")
        checked = worker.request({"action": "family-verify", "case": case, "verify_environment": True})
        if not checked["environment_matches_setup"] or sample.file_sha(binary) != expected_sha:
            raise ValueError("hardware or exporter identity changed")
        sample.write_json(root/"result.json", {"schema": plan["schema"], "status": "observed",
            "completed_blocks": len(rows), "effects": summarize(rows), "elapsed_seconds": time.perf_counter()-start,
            "plan_sha256": sample.digest(plan), "qualification": False})
    finally:
        worker.close()


if __name__ == "__main__":
    main()

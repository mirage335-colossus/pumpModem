#!/usr/bin/env python3
"""Collect a source-bound GCC gcov line/branch summary for native triad v3.

This reports compiler-instrumented counters. gcov branch records are not
semantic condition, decision, or receiver-behavior coverage.
"""

from __future__ import annotations

import argparse
import hashlib
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


SCHEMA_VERSION = 2
DEFAULT_SOURCES = (
    "src/triad_statistics.cpp",
    "src/triad_modem_v3.cpp",
    "src/triad_simulation_stream.cpp",
    "src/triad_receiver_v3.cpp",
)
HEADER_COVERAGE_TRANSLATION_UNITS = (
    "tests/test_triad_v3_source.cpp",
    "tests/test_triad_v3_channel.cpp",
    "tests/test_triad_v3_receiver.cpp",
    "tests/test_triad_statistics.cpp",
)
BRANCH_LIMITATION = (
    "GCC gcov branch records are compiler CFG edges, may include compiler- or "
    "exception-related edges, and do not establish semantic condition/decision "
    "or behavioral coverage. Negative counters are retained as invalid and make "
    "the affected branch scope unqualified. No branch exclusions are applied."
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_gcov_json(path: Path, expected_source: Path) -> dict:
    try:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            document = json.load(stream)
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot read gcov JSON {path}: {error}") from error
    expected_path = expected_source.resolve(strict=True)
    gcov_cwd = Path(document.get("current_working_directory") or path.parent)
    if not gcov_cwd.is_absolute():
        gcov_cwd = path.parent / gcov_cwd
    matches = []
    for item in document.get("files", []):
        candidate = Path(item.get("file", ""))
        if not candidate.is_absolute():
            candidate = gcov_cwd / candidate
        if candidate.resolve() == expected_path:
            matches.append(item)
    if len(matches) != 1:
        raise ValueError(f"{path}: expected exactly one gcov file resolving to {expected_path}, got {len(matches)}")

    line_hits = {}
    invalid_line_counts = {}
    branch_total = branch_hit = branch_miss = branch_invalid = 0
    for line in matches[0].get("lines", []):
        count = line.get("count")
        number = line.get("line_number")
        if not isinstance(number, int) or not isinstance(count, int):
            continue
        if count < 0:
            invalid_line_counts.setdefault(number, []).append(count)
        else:
            line_hits[number] = max(count, line_hits.get(number, 0))
        for branch in line.get("branches", []):
            branch_count = branch.get("count")
            if isinstance(branch_count, int):
                branch_total += 1
                branch_hit += branch_count > 0
                branch_miss += branch_count == 0
                branch_invalid += branch_count < 0
    executable = {line: count for line, count in line_hits.items() if count >= 0}
    executed = {line: count for line, count in executable.items() if count > 0}
    return {
        "lines": {
            "instrumented": len(executable),
            "executed": len(executed),
            "uncovered_source_lines": sorted(line for line, count in executable.items() if count == 0),
            "invalid_negative_counts": {str(line): counts for line, counts in invalid_line_counts.items()},
            "coverage_status": "unqualified_negative_line_counters" if invalid_line_counts else "counted",
        },
        "gcov_branches": {
            "instrumented_outcomes": branch_total,
            "taken_outcomes": branch_hit,
            "untaken_outcomes": branch_miss,
            "invalid_negative_outcomes": branch_invalid,
            "coverage_status": "unqualified_negative_branch_counters" if branch_invalid else "counted",
        },
    }


def header_inventory(source_root: Path) -> dict[str, str]:
    """Hash project C/C++ headers in the two maintained code roots."""
    result = {}
    for folder in (source_root / "include", source_root / "src"):
        for path in sorted(folder.rglob("*")):
            if path.is_file() and path.suffix in {".h", ".hh", ".hpp", ".hxx"}:
                result[path.relative_to(source_root).as_posix()] = sha256(path)
    return result


def aggregate_header_documents(source_root: Path, records: list[tuple[str, dict]]) -> dict:
    """Merge header counters across selected translation units, retaining TU scope."""
    merged: dict[str, dict] = {}
    for record_name, document in records:
        for item in document.get("files", []):
            try:
                path = Path(item.get("file", ""))
                if not path.is_absolute():
                    cwd = Path(document.get("current_working_directory") or source_root)
                    if not cwd.is_absolute():
                        cwd = source_root / cwd
                    path = cwd / path
                path = path.resolve(strict=True)
                relative = path.relative_to(source_root).as_posix()
            except (OSError, ValueError):
                continue
            if not relative.startswith(("include/", "src/")) or path.suffix not in {".h", ".hh", ".hpp", ".hxx"}:
                continue
            target = merged.setdefault(relative, {"lines": {}, "branches": {}, "gcov_records": set()})
            target["gcov_records"].add(record_name)
            for line in item.get("lines", []):
                number, count = line.get("line_number"), line.get("count")
                function = line.get("function_name")
                if not isinstance(number, int) or not isinstance(count, int):
                    continue
                line_key = (number, function or "")
                if count < 0:
                    target.setdefault("invalid_line_counts", {}).setdefault(line_key, []).append(count)
                else:
                    target["lines"][line_key] = max(count, target["lines"].get(line_key, 0))
                for ordinal, branch in enumerate(line.get("branches", [])):
                    branch_count = branch.get("count")
                    if not isinstance(branch_count, int):
                        continue
                    # gcov source/destination block IDs are local to a compiled TU.
                    # Keep the record identity in the key; no CFG equivalence is
                    # inferred across translation units.
                    key = (record_name, line_key, branch.get("source_block_id"),
                           branch.get("destination_block_id"), branch.get("fallthrough"),
                           branch.get("throw"), ordinal)
                    target["branches"][key] = max(branch_count, target["branches"].get(key, branch_count))

    inventory = header_inventory(source_root)
    output = {}
    for relative, values in sorted(merged.items()):
        line_counts = values["lines"]
        branch_counts = values["branches"].values()
        unique_lines = {}
        for (number, _function), count in line_counts.items():
            unique_lines[number] = max(count, unique_lines.get(number, 0))
        invalid_branch_count = sum(count < 0 for count in values["branches"].values())
        output[relative] = {
            "sha256_at_capture": inventory[relative],
            "lines": {
                "instrumented": len(unique_lines),
                "executed": sum(count > 0 for count in unique_lines.values()),
                "uncovered_source_lines": sorted(number for number, count in unique_lines.items() if count == 0),
                "invalid_negative_counts": {
                    str(number): counts for (number, _function), counts in values.get("invalid_line_counts", {}).items()
                },
                "coverage_status": "unqualified_negative_line_counters"
                if values.get("invalid_line_counts") else "counted",
            },
            "gcov_branches": {
                "instrumented_outcomes": len(values["branches"]),
                "taken_outcomes": sum(count > 0 for count in branch_counts),
                "untaken_outcomes": sum(count == 0 for count in values["branches"].values()),
                "invalid_negative_outcomes": invalid_branch_count,
                "coverage_status": "unqualified_negative_branch_counters" if invalid_branch_count else "counted",
                "unit": "translation-unit-qualified gcov CFG edge outcomes; no cross-TU edge equivalence asserted",
            },
            "gcov_records": sorted(values["gcov_records"]),
        }
    return output


def compiler_identity(build: Path) -> dict:
    cache_path = build / "CMakeCache.txt"
    if not cache_path.is_file():
        raise ValueError(f"missing CMake cache: {cache_path}")
    cache = {}
    for row in cache_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if ":" in row and not row.startswith("//") and not row.startswith("#"):
            key, value = row.split("=", 1)
            cache[key.split(":", 1)[0]] = value
    compiler = cache.get("CMAKE_CXX_COMPILER")
    if not compiler:
        raise ValueError("CMAKE_CXX_COMPILER missing from CMakeCache.txt")
    version = subprocess.run([compiler, "--version"], check=True, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout.splitlines()[0]
    cmake_compilers = sorted((build / "CMakeFiles").glob("*/CMakeCXXCompiler.cmake"))
    compiler_config = cmake_compilers[-1].read_text(encoding="utf-8", errors="replace") if cmake_compilers else ""

    def cmake_value(name):
        found = re.search(rf'^set\({name} "([^"]*)"\)', compiler_config, re.MULTILINE)
        return found.group(1) if found else None

    return {
        "path": compiler,
        "version": version,
        "cmake_id": cmake_value("CMAKE_CXX_COMPILER_ID"),
        "cmake_version": cmake_value("CMAKE_CXX_COMPILER_VERSION"),
        "build_type": cache.get("CMAKE_BUILD_TYPE"),
        "coverage_flags": {
            "cxx": cache.get("CMAKE_CXX_FLAGS", ""),
            "exe_link": cache.get("CMAKE_EXE_LINKER_FLAGS", ""),
        },
        "cmake_cache_sha256": sha256(cache_path),
        "compile_commands_sha256": sha256(build / "compile_commands.json"),
    }


def run_gcov(source_root: Path, build: Path, raw_dir: Path, gcov: str) -> dict[str, Path]:
    raw_dir.mkdir(parents=True, exist_ok=True)
    outputs = {}
    for relative in (*DEFAULT_SOURCES, *HEADER_COVERAGE_TRANSLATION_UNITS):
        source = source_root / relative
        if not source.is_file():
            raise ValueError(f"missing source: {source}")
        objects = list(build.rglob(source.name + ".gcno"))
        if len(objects) != 1:
            raise ValueError(f"expected one .gcno for {relative} in {build}, found {len(objects)}")
        gcov_prefix = objects[0].with_suffix(".o")
        raw_output = raw_dir / f"{source.stem}.gcov.json.gz"
        raw_output.unlink(missing_ok=True)
        command = [gcov, "--json-format", "-b", "-c", "-o", str(gcov_prefix), str(source)]
        result = subprocess.run(command, cwd=raw_dir, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        if result.returncode:
            raise ValueError(f"gcov failed for {relative}: {result.stdout.strip()}")
        if not raw_output.is_file():
            raise ValueError(f"gcov did not produce one retained JSON file for {relative}: {result.stdout.strip()}")
        outputs[relative] = raw_output
    return outputs


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--build-dir", type=Path)
    parser.add_argument("--raw-dir", type=Path,
                        help="directory retaining the original compressed gcov JSON")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--gcov", default="gcov", help="GCC gcov executable")
    parser.add_argument("--executed-check", action="append", default=[],
                        help="record a focused check already run (repeatable; does not execute it)")
    parser.add_argument("--header-guard-check", type=Path,
                        help="require current src/include header hashes to match a pre-build guard manifest")
    parser.add_argument("--write-header-guard", type=Path,
                        help="write a pre-build SHA-256 manifest for project src/include headers and exit")
    args = parser.parse_args(argv)
    try:
        source_root = args.source_root.resolve(strict=True)
        if args.write_header_guard:
            guard_path = args.write_header_guard.resolve()
            guard_path.parent.mkdir(parents=True, exist_ok=True)
            guard = {
                "schema": "datapump.triad.native-gcov-header-guard",
                "schema_version": 1,
                "source_root": str(source_root),
                "created_at_unix_ns": time.time_ns(),
                "headers": header_inventory(source_root),
            }
            guard_path.write_text(json.dumps(guard, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            print(guard_path)
            return 0
        if args.build_dir is None or args.raw_dir is None or args.output is None:
            raise ValueError("collection requires --build-dir, --raw-dir, and --output")
        build = args.build_dir.resolve(strict=True)
        raw_dir = args.raw_dir.resolve()
        guard_hash = None
        guard_matches = None
        guard_created_at_ns = None
        if args.header_guard_check:
            guard_path = args.header_guard_check.resolve(strict=True)
            guard = json.loads(guard_path.read_text(encoding="utf-8"))
            expected_headers = guard.get("headers")
            current_headers = header_inventory(source_root)
            if not isinstance(expected_headers, dict):
                raise ValueError("header guard has no headers object")
            changed = sorted(path for path in set(expected_headers) | set(current_headers)
                             if expected_headers.get(path) != current_headers.get(path))
            if changed:
                raise ValueError("headers changed between pre-build guard and capture: " + ", ".join(changed[:12]))
            guard_hash = sha256(guard_path)
            guard_matches = True
            guard_created_at_ns = guard.get("created_at_unix_ns")
        compiler = compiler_identity(build)
        gcov_outputs = run_gcov(source_root, build, raw_dir, args.gcov)
        sources = {}
        gcov_records = []
        translation_units = {}
        for relative, raw in gcov_outputs.items():
            with gzip.open(raw, "rt", encoding="utf-8") as stream:
                document = json.load(stream)
            # Validate exact source identity for every counter-contributing TU,
            # including the supplemental test translation units.
            parse_gcov_json(raw, source_root / relative)
            gcov_records.append((relative, document))
            note_files = list(build.rglob(Path(relative).name + ".gcno"))
            if len(note_files) != 1:
                raise ValueError(f"expected one .gcno identity for {relative}, found {len(note_files)}")
            object_path = note_files[0].with_suffix(".o")
            data_path = note_files[0].with_suffix(".gcda")
            object_mtime_ns = object_path.stat().st_mtime_ns
            translation_units[relative] = {
                "sha256": sha256(source_root / relative),
                "gcov_data": str(raw),
                "object_path": str(object_path),
                "gcno_path": str(note_files[0]),
                "gcda_path": str(data_path),
                "object_mtime_ns": object_mtime_ns,
                "gcda_mtime_ns": data_path.stat().st_mtime_ns if data_path.exists() else None,
                "object_mtime_after_prebuild_header_guard":
                    object_mtime_ns >= guard_created_at_ns if isinstance(guard_created_at_ns, int) else None,
            }
        for relative in DEFAULT_SOURCES:
            raw = gcov_outputs[relative]
            source = source_root / relative
            result = parse_gcov_json(raw, source)
            result["sha256"] = sha256(source)
            result["raw_gcov_json_gz"] = os.path.relpath(raw, args.output.parent.resolve())
            sources[relative] = result
        payload = {
            "schema": "datapump.triad.native-gcov-coverage",
            "schema_version": SCHEMA_VERSION,
            "scope": "native planner/statistics and v3 source/channel/receiver, plus focused test-TU header counters",
            "source_root": str(source_root),
            "source_revision": subprocess.run(["git", "-C", str(source_root), "rev-parse", "HEAD"],
                                               check=True, text=True, stdout=subprocess.PIPE).stdout.strip(),
            "working_tree_dirty": bool(subprocess.run(
                ["git", "-C", str(source_root), "status", "--porcelain"], check=True,
                text=True, stdout=subprocess.PIPE).stdout.strip()),
            "build_dir": str(build),
            "executed_checks": args.executed_check,
            "counter_translation_units": translation_units,
            "compiler": compiler,
            "gcov": subprocess.run([args.gcov, "--version"], check=True, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout.splitlines()[0],
            "coverage_interpretation": {
                "line_metric": "source lines with gcov execution counters",
                "branch_metric": BRANCH_LIMITATION,
                "declared_exclusions": [],
            },
            "sources": sources,
            "headers": aggregate_header_documents(source_root, gcov_records),
            "header_counter_applicability": {
                "line_merge": "executed source lines are unioned by header-relative path and line; counter values are not summed across TUs",
                "branch_merge": "GCOV edges remain TU-qualified because block IDs are local; no CFG equivalence is inferred across TUs",
                "source_hash_binding": "each header has a capture-time SHA-256; prebuild_postcapture_header_inventory_match means only the before/after inventories matched",
                "build_binding": "per-TU object/note/data paths and mtimes are retained; object_mtime_after_prebuild_header_guard records temporal order, not embedded source/header hashes",
                "dependency_limit": "gcov records validate exact compiled TU source paths and compile_commands is hashed; compiler instrumentation does not embed source/header hashes or full dependency snapshots",
                "prebuild_guard_sha256": guard_hash,
                "prebuild_postcapture_header_inventory_match": guard_matches,
                "counter_translation_units_built_after_guard": all(
                    item["object_mtime_after_prebuild_header_guard"] is True
                    for item in translation_units.values()) if guard_matches else None,
                "historical_reports_without_header_guard": "header counters are unqualified to the captured header bytes",
            },
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        print(f"triad_perf_coverage.py: {error}", file=sys.stderr)
        return 2
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

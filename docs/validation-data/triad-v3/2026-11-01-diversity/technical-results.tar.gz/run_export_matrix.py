#!/usr/bin/env python3
"""Reproduce the named development matrix; each case has its own owned runner."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--matrix',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--cases',nargs='+',required=True);p.add_argument('--start-index',type=int,default=0);p.add_argument('--split',choices=['development','holdout'],default='development');p.add_argument('--case-timeout',type=float,default=0);p.add_argument('--jobs',type=int,default=16);p.add_argument('--overall-seconds',type=float,default=1800);a=p.parse_args()
a.source=a.source.resolve();a.output.mkdir(parents=True,exist_ok=False); start=time.monotonic(); cases=json.loads(a.matrix.read_text())['cases']; outcomes=[]
for case in cases:
 if case['name'] not in a.cases:continue
 remaining=a.overall_seconds-(time.monotonic()-start)-15
 if remaining<1:outcomes.append({'case':case['name'],'status':'not_started_deadline'});continue
 timeout=min(remaining,a.case_timeout if a.case_timeout else 1200 if 'twoday' in case['name'] else 600 if 'hour_' in case['name'] else 180)
 name=case['name'];cmd=[sys.executable,str(a.source/'tools/triad_bounded_run.py'),'--cwd',str(a.source),'--log',str(a.output/(name+'.log')),'--status',str(a.output/(name+'-status.json')),'--timeout',str(timeout),'--max-seconds',str(timeout),'--',sys.executable,str(a.source/'tools/triad-diversity-export.py'),'--binary',str(a.source/'build/dev-cli/triad_long'),'--output',str(a.output/name),'--paths',str(case['paths']),'--jobs',str(a.jobs),'--start-index',str(a.start_index),'--split',a.split,'--case',name,'--']+case['args']
 code=subprocess.run(cmd,check=False).returncode
 record={'case':name,'returncode':code,'elapsed_since_start':time.monotonic()-start,'command':cmd};outcomes.append(record);print(json.dumps(record),flush=True)
 (a.output/'outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
print(json.dumps({'total_seconds':time.monotonic()-start,'completed_cases':len(outcomes)}),flush=True)
sys.exit(any(x.get('returncode',1)!=0 for x in outcomes))

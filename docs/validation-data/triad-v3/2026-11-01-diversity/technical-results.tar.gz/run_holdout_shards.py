#!/usr/bin/env python3
"""Bounded streaming scoring of independent, atomically completed workspaces."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--paths',type=int,default=300);p.add_argument('--shard',type=int,default=4);p.add_argument('--family',choices=['phase','gaussian'],required=True);p.add_argument('--cn0',type=float,required=True);p.add_argument('--phase-diffusion',type=float,default=.00018);p.add_argument('--max-seconds',type=float,default=3000);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);start=time.monotonic();done=set();records=[]
while len(done)<a.paths and time.monotonic()-start<a.max_seconds-20:
 paths=sorted(p.parent for p in a.inputs.glob('path-*/manifest.json') if str(p.parent) not in done)
 if len(paths)<min(a.shard,a.paths-len(done)):
  time.sleep(2);continue
 paths=paths[:min(a.shard,a.paths-len(done))];index=len(records);dest=a.output/f'shard-{index:04d}.json'
 cmd=[sys.executable,str(a.source/'tools'/('triad-noise-batch-study.py' if a.family=='phase' else 'triad-noise-study.py')),*map(str,paths),'--output',str(dest),'--cn0',str(a.cn0),'--mode','actual','--split','holdout','--methods','phase-frequency-ucb' if a.family=='phase' else 'residual-ucb','--selection-methods','7','--calibration-alternatives','2','--duration-alternatives','3','--calibration-scope','stationary','--threads','2','--memory-gib','60']
 if a.family=='phase':cmd+=['--device','cuda','--precision','fp32','--phase-implementation','optimized','--batch-paths',str(a.shard),'--phase-states','512','--phase-diffusion',str(a.phase_diffusion),'--frequency-bound','.000055','--frequency-std','.00003','--frequency-step','.000001','--frequency-coherence','1000000000','--frequency-model','static','--frequency-random-walk','0']
 else:cmd+=['--device','cpu','--precision','fp64','--coherences','256','1024','4096','16384','65536','262144']
 timeout=min(300,a.max_seconds-(time.monotonic()-start)-15)
 wrapper=[sys.executable,str(a.source/'tools/triad_bounded_run.py'),'--cwd',str(a.source),'--log',str(dest.with_suffix('.log')),'--status',str(dest.with_name(dest.stem+'-status.json')),'--timeout',str(timeout),'--max-seconds',str(timeout),'--',*cmd]
 code=subprocess.run(wrapper,check=False,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'}).returncode
 record={'paths':list(map(str,paths)),'returncode':code,'command':cmd,'wall_since_start':time.monotonic()-start}
 if dest.exists():
  r=json.loads(dest.read_text());record['summary']=r.get('summary_by_control');record['failed']=sum(x['status']!='completed' for x in r.get('captures',[]));record['wall_seconds_joint']=r.get('wall_seconds_joint')
 records.append(record);done.update(map(str,paths));(a.output/'outcomes.json').write_text(json.dumps({'records':records,'attempted_paths':len(done),'required_paths':a.paths,'wall_seconds':time.monotonic()-start},indent=2)+'\n');print(json.dumps({'shard':index,'attempted_paths':len(done),'returncode':code,'failed':record.get('failed'),'wall':time.monotonic()-start}),flush=True)
 if code or record.get('failed',1):break
sys.exit(int(len(done)!=a.paths or any(r['returncode'] or r.get('failed',1) for r in records)))

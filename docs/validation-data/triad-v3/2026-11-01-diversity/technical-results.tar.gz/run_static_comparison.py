#!/usr/bin/env python3
import argparse,json,subprocess,sys,time,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--max-seconds',type=float,default=480);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);start=time.monotonic();records=[]
cases=[('short-microwave-fp64','extras/microwave_shortblock',-4,.65,'cpu','fp64',12),('short-microwave-gpu','extras/microwave_shortblock',-4,.65,'cuda','fp32',12),('hf30-hour','frequency-hour/hf30_hour',-16,.0031,'cpu','fp64',8),('microwave-hour','frequency-hour/microwave_hour',-16,.65,'cpu','fp64',8),('coarse-ocxo-twoday','extras/ocxo_twoday',-34,.000055,'cpu','fp64',8),('dense-ocxo-twoday','dense-holdout-twoday/ocxo_twoday',-34,.000055,'cpu','fp64',32),('dense-ocxo-gpu','dense-holdout-twoday/ocxo_twoday',-34,.000055,'cuda','fp32',2)]
for name,sub,cn0,bound,device,precision,n in cases:
 remaining=a.max_seconds-(time.monotonic()-start)-15
 if remaining<10:break
 paths=sorted(p.parent for p in (Path('/workspace')/sub).glob('path-*/manifest.json'))
 if len(paths)<n:
  records.append({'case':name,'status':'incomplete_input_cohort','available':len(paths),'required':n});continue
 paths=paths[:n];cmd=[sys.executable,str(a.source/'tools/triad-static-frequency-study.py'),*map(str,paths),'--output',str(a.output/(name+'.json')),'--cn0',str(cn0),'--frequency-bound',str(bound),'--device',device,'--precision',precision,'--memory-gib','60']
 timeout=min(remaining,180);wrapped=[sys.executable,str(a.source/'tools/triad_bounded_run.py'),'--cwd',str(a.source),'--log',str(a.output/(name+'.log')),'--status',str(a.output/(name+'-status.json')),'--timeout',str(timeout),'--max-seconds',str(timeout),'--',*cmd];t=time.monotonic();code=subprocess.run(wrapped,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'}).returncode;r={'case':name,'returncode':code,'command':cmd,'complete_seconds':time.monotonic()-t};records.append(r);(a.output/'outcomes.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='command'}),flush=True)
(a.output/'outcomes.json').write_text(json.dumps(records,indent=2)+'\n')

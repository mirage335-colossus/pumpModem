#!/usr/bin/env python3
"""Collect only named technical results; no cloud/account operational files."""
import argparse,json,tarfile,hashlib,io
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path('/workspace');selected=set()
prefixes=('gaussian-','phase-','noise-','batch-','gpu-serial-','retained-energy-','static-')
for item in root.iterdir():
 if item.name.startswith(prefixes):
  if item.is_file() and item.suffix in ('.json','.npz','.log'):selected.add(item)
  elif item.is_dir():selected.update(q for q in item.iterdir() if q.is_file() and q.suffix in ('.json','.npz','.log'))
for name in ('screens','longpaths','long64','extras','holdout-hour','holdout-hour64','holdout-twoday','dense-holdout-twoday','null-hour','frequency-hour'):
 d=root/name
 for q in d.glob('*.json'):selected.add(q)
 for q in d.glob('*.log'):selected.add(q)
 for q in d.glob('*/campaign.json'):selected.add(q)
 for q in d.glob('*/campaign.json.partial'):selected.add(q)
 for q in d.glob('*/path-*/manifest.json'):selected.add(q)
for q in root.glob('*.py'):selected.add(q)
for q in root.glob('matrix*.json'):selected.add(q)
for q in (root/'triad/tools').glob('triad*'):
 if q.is_file():selected.add(q)
for q in (root/'triad/tests').glob('test_triad*'):
 if q.is_file():selected.add(q)
for name in ('CMakeLists.txt','CMakePresets.json','cmake/TestGroups.cmake','src/tuning.cpp','src/tuning_presets.cpp'):
 selected.add(root/'triad'/name)
records=[]
with tarfile.open(a.output,'w:gz') as tar:
 for q in sorted(selected):
  if q.is_symlink():continue
  data=q.read_bytes();records.append({'file':str(q.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});info=tarfile.TarInfo(str(q.relative_to(root)));info.size=len(data);tar.addfile(info,io.BytesIO(data))
a.output.with_suffix('.index.json').write_text(json.dumps({'files':records,'total_uncompressed_bytes':sum(r['bytes'] for r in records)},indent=2)+'\n')
print(json.dumps({'files':len(records),'bytes':a.output.stat().st_size}))

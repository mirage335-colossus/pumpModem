#!/usr/bin/env python3
"""Reproduce bounded receiver comparisons on the named exported matrix."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--cases',nargs='+',required=True);p.add_argument('--family',choices=['gaussian','phase'],required=True);p.add_argument('--mode',choices=['projected','actual'],default='actual');p.add_argument('--cn0',type=float,default=-4);p.add_argument('--trials',type=int,default=1);p.add_argument('--device',default='cpu');p.add_argument('--precision',default='fp64');p.add_argument('--noise-scale',type=float,default=1);p.add_argument('--step-factor',type=float);p.add_argument('--phase-states',type=int,default=512);p.add_argument('--limit-paths',type=int,default=0);p.add_argument('--overall-seconds',type=float,default=1800);p.add_argument('--implementation',default='reference');p.add_argument('--calibration-scope',choices=['per-block','stationary'],default='per-block');a=p.parse_args()
a.source=a.source.resolve();a.output.mkdir(parents=True,exist_ok=False);start=time.monotonic();outcomes=[]
for name in a.cases:
 remaining=a.overall_seconds-(time.monotonic()-start)-15
 if remaining<1:outcomes.append({'case':name,'status':'not_started_deadline'});continue
 inputs=sorted(x for x in (a.inputs/name).glob('path-*') if x.is_dir() and (x/'manifest.json').exists())
 if a.limit_paths:inputs=inputs[:a.limit_paths]
 if not inputs:outcomes.append({'case':name,'status':'no_complete_inputs'});continue
 methods=['gaussian-ou','angular-gaussian','residual-ucb'] if a.family=='gaussian' else ['phase-frequency','phase-frequency-ucb']
 command=[sys.executable,str(a.source/'tools/triad-noise-study.py'),*map(str,inputs),'--output',str(a.output/(name+'.json')),'--cn0',str(a.cn0),'--trials',str(a.trials),'--mode',a.mode,'--methods',*methods,'--selection-methods','7','--calibration-alternatives','2','--calibration-scope',a.calibration_scope,'--duration-alternatives','3','--device',a.device,'--precision',a.precision,'--threads','2','--memory-gib','60','--noise-scale',str(a.noise_scale),'--phase-states',str(a.phase_states),'--phase-implementation',a.implementation,'--phase-diffusion',('.00018' if 'ocxo' in name else '.0018' if 'tcxo' in name else '.018')]
 if a.family=='phase':
  bound,std,step,coherence=('.65','.3','.005','86400') if name.startswith('microwave') else ('.2','.07','.002','86400') if name=='basecrystal500k' else ('.02','.003','.001','1000') if name.startswith('colored') else ('.00016','.00009','.000003','1000000000') if name=='margin3' else ('.000055','.00003','.000001','1000000000')
  command+=['--frequency-bound',bound,'--frequency-std',std,'--frequency-step',step,'--frequency-coherence',coherence]
 if 'hour' in name or 'twoday' in name:command+=['--coherences','256','1024','4096','16384','65536','262144']
 if a.step_factor is not None:command+=['--noise-step-factor',str(a.step_factor),'--noise-step-fraction','.5']
 timeout=min(remaining,1200 if 'twoday' in name else 600 if 'hour_' in name else 300)
 wrapped=[sys.executable,str(a.source/'tools/triad_bounded_run.py'),'--cwd',str(a.source),'--log',str(a.output/(name+'.log')),'--status',str(a.output/(name+'-status.json')),'--timeout',str(timeout),'--max-seconds',str(timeout),'--',*command]
 code=subprocess.run(wrapped,check=False,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'}).returncode
 record={'case':name,'returncode':code,'elapsed_since_start':time.monotonic()-start,'command':command}
 if (a.output/(name+'.json')).exists():
  r=json.loads((a.output/(name+'.json')).read_text()); record['summary']=r.get('summary_by_control');record['wall_seconds']=r.get('wall_seconds_joint')
 outcomes.append(record);(a.output/'outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n');print(json.dumps({'case':name,'returncode':code,'elapsed_since_start':record['elapsed_since_start']}),flush=True)
print(json.dumps({'total_seconds':time.monotonic()-start,'completed_cases':len(outcomes)}),flush=True)
sys.exit(any(x.get('returncode',1)!=0 for x in outcomes))

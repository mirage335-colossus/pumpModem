#!/usr/bin/env python3
import argparse,concurrent.futures,json,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--factor',type=int,required=True);p.add_argument('--jobs',type=int,default=8);a=p.parse_args();a.output.mkdir(exist_ok=False,parents=True);start=time.monotonic()
inputs=sorted(x.parent for x in a.inputs.glob('*/path-*/manifest.json'))
def run(src):
 dest=a.output/src.parent.name/src.name
 cmd=[sys.executable,str(a.source/'tools/triad-reblock.py'),'--input',str(src),'--output',str(dest),'--factor',str(a.factor)]
 r=subprocess.run(cmd,capture_output=True,text=True)
 return {'input':str(src),'output':str(dest),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'command':cmd}
with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:r=list(pool.map(run,inputs))
(a.output/'reblock-results.json').write_text(json.dumps({'results':r,'wall_seconds':time.monotonic()-start},indent=2)+'\n');print(json.dumps({'paths':len(r),'errors':sum(x['returncode']!=0 for x in r),'seconds':time.monotonic()-start}));sys.exit(any(x['returncode'] for x in r))

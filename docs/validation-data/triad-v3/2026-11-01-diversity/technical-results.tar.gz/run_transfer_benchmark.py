#!/usr/bin/env python3
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--cn0',type=float,default=-34);p.add_argument('--phase-diffusion',type=float,default=.00018);p.add_argument('--cpu-timeout',type=float,default=500);p.add_argument('--source',type=Path,required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);records=[]
for name,device,mode,impl,timeout in [('gpu-block-a','cuda','block','optimized',100),('gpu-resident-a','cuda','resident','optimized',100),('gpu-resident-b','cuda','resident','optimized',100),('gpu-block-b','cuda','block','optimized',100),('cpu-reference','cpu','resident','reference',a.cpu_timeout)]:
 cmd=[sys.executable,str(a.source/'tools/triad-noise-batch-study.py'),str(a.inputs/'path-00000'),str(a.inputs/'path-00001'),'--output',str(a.output/(name+'.json')),'--cn0',str(a.cn0),'--device',device,'--precision','fp32','--phase-implementation',impl,'--transfer-mode',mode,'--batch-paths','2','--phase-states','512','--phase-diffusion',str(a.phase_diffusion),'--frequency-bound','.000055','--frequency-step','.000001','--frequency-std','.00003','--frequency-model','static','--frequency-random-walk','0','--memory-gib','60']
 def active_gpu_count():
  try:return len(subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip().splitlines())
  except Exception:return None
 count=active_gpu_count();start=time.monotonic();wrapper=[sys.executable,str(a.source/'tools/triad_bounded_run.py'),'--cwd',str(a.source),'--log',str(a.output/(name+'.log')),'--status',str(a.output/(name+'-status.json')),'--timeout',str(timeout),'--max-seconds',str(timeout),'--',*cmd]
 code=subprocess.run(wrapper,check=False,env={**os.environ,'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'}).returncode
 r={'name':name,'command':cmd,'returncode':code,'complete_subprocess_seconds':time.monotonic()-start,'other_gpu_process_count_before':count,'other_gpu_process_count_after':active_gpu_count()};records.append(r);(a.output/'outcomes.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='command'}),flush=True)

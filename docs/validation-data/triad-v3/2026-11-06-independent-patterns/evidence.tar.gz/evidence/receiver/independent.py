import hashlib,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify import BASE,FLAT,HERE,EXE,run
ROOT=Path.cwd(); env={**os.environ,'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2'}
protocol=dict(native_binary_sha256=hashlib.sha256(EXE.read_bytes()).hexdigest(),helper_binary_sha256=hashlib.sha256((ROOT/'build/dev-cli/triad_helper_export').read_bytes()).hexdigest(),selection='Pilot84001..84002 selected flat C/N0 2,4 dB-Hz at16sec; independent flat seeds90001..90008(bit0),91001..91008(bit1). Two fullyrandom HF seeds85001,85002 at120sec8dB-Hz; these are functional observations, not probability qualification.',flat_cn0=[2,4],flat_trials_per_revision_per_cn0=16,flat_null_trials_per_revision=8,hf_signal_seeds=[85001,85002],hf_null_seed=85003,revision_depth=.25,thresholds='native unchanged defaults; Helper incremental unchanged operational_threshold; working-model pass only for Helper')
(HERE/'frozen-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
for cn in (2,4):
 for bit,seed in ((0,90001),(1,91001)):
  for rev in ('legacy-v1','independent-apsk-v2'):
   run(f'independent-flat-cn{cn}-bit{bit}-{rev}',[*FLAT,'--pattern-revision',rev,'--cn0',str(cn),'--seed',str(seed),'--trials','8','--signal-bit',str(bit)])
for rev in ('legacy-v1','independent-apsk-v2'):
 run(f'independent-flat-null-{rev}',[*FLAT,'--pattern-revision',rev,'--cn0','2','--seed','92001','--trials','8','--control','null'])
bank=dict(coordinates=[[0,0,0,0]],taps=[[0,0],[.021,90]],stationary_power=[.5,.5],projection=dict(required_bands_hz=[[-250,250]],excluded_bands_hz=[[-1500,-1100]]))
(HERE/'bank-hf.json').write_text(json.dumps(bank,indent=2)+'\n')
base=['--case','hf','--sample-rate','6000','--rate','36','--added-symbols','10','--seconds','120','--epoch','1793850000','--base-oscillator','gpsdo-ocxo','--shift-oscillator','gpsdo-ocxo','--oscillator-effects','off','--arrival-seconds','0','--helper','on','--spread-preset','hf-worst','--margin','3','--selective-perturbation','each-65','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--cn0','8','--added-amplitude-depth','.25']
receipts=[]
for seed,bit,control in ((85001,0,'signal'),(85002,1,'signal'),(85003,0,'null')):
 for rev in ('legacy-v1','independent-apsk-v2'):
  name=f'independent-random-hf-{control}-{seed}-{rev}'
  args=['/tmp/triad-weak-env/bin/python','tools/triad_continuous.py','--block-seconds','.25','--bank',str(HERE/'bank-hf.json'),'--report',str(HERE/(name+'.json')),'--',*base,'--pattern-revision',rev,'--seed',str(seed),'--key-seed',str(seed+100000),'--bit',str(bit)]
  if control=='null':args+=['--data','off']
  t=time.perf_counter();r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=90)
  receipts.append(dict(name=name,command=args,wall_seconds=time.perf_counter()-t,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
  print(name,r.returncode,r.stdout.strip(),r.stderr[-200:],flush=True)
(HERE/'hf-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')

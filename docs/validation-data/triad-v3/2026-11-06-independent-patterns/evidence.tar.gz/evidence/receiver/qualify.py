import hashlib,json,os,resource,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path.cwd();EXE=ROOT/'build/dev-cli/triad_long'
BASE=['--mode','run','--rate','36','--added','10','--sample-rate','960','--seconds','16','--phase-diffusion','0','--start','0','0','1','--frequency','0','0','.1','--clock-ppm','0','--epoch-offsets','0','--block-seconds','1.6','--threads','2','--chunk','4096','--epoch','1793850000','--performance-trace','yes','--added-amplitude-depth','.25']
HF=['--spread-preset','hf-worst','--selective-perturbation','each-65','--margin','3','--basis','two-ray','--tap-delay-ms','21','--tap-doppler-hz','90','--ray-gaussian-width-hz','.5']
FLAT=['--spread-preset','none','--selective-perturbation','off','--basis','flat']
def run(name,extra):
 cmd=[str(EXE),*BASE,*extra];before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter()
 ident=hashlib.sha256(EXE.read_bytes()).hexdigest()
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=150,env={**os.environ,'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2'})
 usage=resource.getrusage(resource.RUSAGE_CHILDREN)
 receipt=dict(name=name,command=cmd,binary_sha256=ident,returncode=r.returncode,wall_seconds=time.perf_counter()-start,cpu_seconds=usage.ru_utime+usage.ru_stime-before.ru_utime-before.ru_stime,stderr=r.stderr)
 rows=[json.loads(line) for line in r.stdout.splitlines() if line.strip().startswith('{')]
 (HERE/(name+'.json')).write_text(json.dumps(dict(receipt=receipt,rows=rows),indent=2)+'\n')
 print(name,r.returncode,'wall',round(receipt['wall_seconds'],3),'correct',sum(x.get('correct',False) for x in rows),'miss',sum(x.get('missed',False) for x in rows),'wrong',sum(x.get('wrong_accepted',False) for x in rows),r.stderr[-200:],flush=True)
 return rows
if __name__=='__main__':
 for cn in (-4,0,4,8):
  for rev in ('legacy-v1','independent-apsk-v2'):
   run(f'pilot-flat-{cn}-{rev}',[*FLAT,'--pattern-revision',rev,'--cn0',str(cn),'--seed','84001','--trials','2'])
 for rev in ('legacy-v1','independent-apsk-v2'):
  run(f'pilot-hf-8-{rev}',[*HF,'--pattern-revision',rev,'--cn0','8','--seed','84001','--trials','1'])

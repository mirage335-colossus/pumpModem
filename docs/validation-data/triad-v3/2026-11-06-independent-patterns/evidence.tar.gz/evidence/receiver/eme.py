from pathlib import Path
import json,subprocess,os,time,hashlib
P=Path(__file__).resolve().parent
bank=dict(coordinates=[[0,0,0,0]],taps=[[0,0],[.0005,6]],stationary_power=[.5,.5],projection=dict(required_bands_hz=[[-250,250]],excluded_bands_hz=[[-1500,-1100]]))
(P/'bank-eme.json').write_text(json.dumps(bank,indent=2)+'\n')
plan=json.loads((P/'eme-plan.json').read_text());p=plan['physics'];f=plan['format']
assert p['rf_hz']==5.8e9 and p['data_w']==40 and p['effective_helper_w']==15000
assert f['fhss'] and f['added_symbols']==1 and f['inner_rate_hz']==360
assert p['spread_delay_ms']==.5 and p['spread_doppler_hz']==6 and p['selective_coefficient_law']=='sinusoidal'
assert plan['helper_placement']['planned_high_hz']==2400 and p['data_if_hz']==1725
base=['--case','eme','--sample-rate','6000','--data-if','1725','--rate','360','--added-symbols','1','--seconds','60','--seed','85004','--key-seed','185004','--bit','1','--epoch','1793850000','--fhss','on','--oscillator-effects','off','--arrival-seconds','0','--spread-preset','eme-focused','--margin','1','--selective-perturbation','each-65','--channel-evolution','legacy','--cn0','1.5']
receipts=[]
for revision in ('legacy-v1','independent-apsk-v2'):
 name='eme-strong-helper-'+revision
 command=['/tmp/triad-weak-env/bin/python','tools/triad_continuous.py','--block-seconds','.25','--bank',str(P/'bank-eme.json'),'--report',str(P/(name+'.json')),'--',*base,'--pattern-revision',revision]
 started=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=90,env={**os.environ,'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2'})
 receipt=dict(command=command,returncode=r.returncode,wall_seconds=time.perf_counter()-started,stdout=r.stdout,stderr=r.stderr)
 receipts.append(receipt);print(json.dumps(receipt),flush=True)
(P/'eme-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')

import json,math,statistics,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent

def ci(k,n):
 z=1.959963984540054;p=k/n;den=1+z*z/n;c=(p+z*z/(2*n))/den;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return [max(0.,c-h),min(1.,c+h)]
def native():
 result=[]
 for cn in (2,4):
  versions={}
  for revision in ('legacy-v1','independent-apsk-v2'):
   rows=[]
   for bit in (0,1): rows+=json.loads((P/f'independent-flat-cn{cn}-bit{bit}-{revision}.json').read_text())['rows']
   k=sum(r['correct'] and r['accepted'] for r in rows)
   versions[revision]=dict(n=len(rows),correct_admissions=k,wrong_admissions=sum(r['wrong_accepted'] for r in rows),misses=sum(r['missed'] for r in rows),correct_probability_wilson95=ci(k,len(rows)),cpu_seconds=sum(r['end_to_end_cpu_seconds'] for r in rows),energy_mean_samples=statistics.mean(r['signal_energy_pre_erasure_samples'] for r in rows),rows=rows)
  old,new=versions.values(); energy=[10*math.log10(b['signal_energy_pre_erasure_samples']/a['signal_energy_pre_erasure_samples']) for a,b in zip(old['rows'],new['rows'])]
  paired=dict(new_only_correct=sum(not a['correct'] and b['correct'] for a,b in zip(old['rows'],new['rows'])),old_only_correct=sum(a['correct'] and not b['correct'] for a,b in zip(old['rows'],new['rows'])),new_old_energy_db_mean=statistics.mean(energy),new_old_energy_db_range=[min(energy),max(energy)])
  for value in versions.values():value.pop('rows')
  result.append(dict(cn0_db_hz=cn,actual_active_seconds=23.2,requested_seconds=16,versions=versions,paired=paired))
 controls={}
 for revision in ('legacy-v1','independent-apsk-v2'):
  rows=json.loads((P/f'independent-flat-null-{revision}.json').read_text())['rows'];k=sum(r['false_admission'] for r in rows)
  controls[revision]=dict(n=len(rows),false_admissions=k,one_sided95_upper_if_zero=1-.05**(1/len(rows)) if k==0 else None)
 return result,controls

def hf():
 result=[]
 for p in sorted(P.glob('independent-random-hf-*.json')):
  d=json.loads(p.read_text());result.append(dict(file=p.name,status=d['status'],complete=d['complete'],candidate_bit=d.get('candidate_bit'),conditional_model_pass=d.get('conditional_model_pass'),admitted=d['admitted'],log_e=d.get('log_e'),bit_scores=d.get('receiver',{}).get('bit_scores'),observed_seconds=d.get('processed_seconds'),cpu_per_input_second=d.get('all_process_cpu_seconds_per_input_second'),wall_seconds=d['wall_seconds'],source_data_energy=d.get('source_completion',{}).get('source_data_energy'),identities=d.get('identities')))
 return result
if __name__=='__main__':
 a,b=native();out=dict(schema='triad-pattern-receiver-comparison-v1',scope='Known public alignment; native complete sampled captures and conditional fixed-bank Helper streaming. No blind-acquisition or rare-tail guarantee.',native_independent=a,native_nulls=b,random_hf=hf(),provenance='Per-run command, source metadata, binary identity and raw rows retained. Native HF pilot alone uses Gaussian-FIR ray variation with sinusoidal selective coefficients; random_hf uses fixed-time Gaussian rays and Gaussian-erf selective coefficients through shared sampled channel.')
 out['metadata_smoke_checks']=json.loads((P/'metadata-checks.json').read_text())
 out['provenance_note']='First HF legacy seed85001 launched before a metadata-only Helper power-identity rebuild; other HF reports bind rebuilt binary. Exact per-run identities are retained. Native binary and default DSP did not change in that rebuild.'
 out['random_hf_pair_energy_db']={}
 for item in out['random_hf']:
  d=json.loads((P/item['file']).read_text());cmd=d['command'];item['expected_bit']=int(cmd[cmd.index('--bit')+1]) if '-signal-' in item['file'] else None
  item['correct_selection']=item['candidate_bit']==item['expected_bit'] if item['expected_bit'] is not None else None
  item['conditional_log_threshold']=d['admission_policy']['log_e_threshold']
 for seed in (85001,85002):
  old=json.loads((P/f'independent-random-hf-signal-{seed}-legacy-v1.json').read_text());new=json.loads((P/f'independent-random-hf-signal-{seed}-independent-apsk-v2.json').read_text())
  out['random_hf_pair_energy_db'][str(seed)]=10*math.log10(new['source_completion']['source_data_energy']/old['source_completion']['source_data_energy'])
 (P/'summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

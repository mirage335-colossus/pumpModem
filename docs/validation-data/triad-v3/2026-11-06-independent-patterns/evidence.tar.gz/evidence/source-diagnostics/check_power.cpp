#include "datapump/triad_modem_v3.hpp"
#include <iostream>
#include <iomanip>
int main(){using namespace datapump;using namespace datapump::triad::v3;std::array<std::uint8_t,32> keybytes{};for(unsigned i=0;i<32;++i)keybytes[i]=17*i+3;Crypto key(keybytes);Format f;f.encrypt=false;f.added_symbols=1;f.inner_rate_hz=240;f.sample_rate=2048;f.bit_seconds=24;PatternSource a(f,key,0),b(f,key,1);std::cout<<std::setprecision(17);for(std::uint64_t k=0;k<a.geometry().fine_cells;++k){auto x=a.pattern_coefficient_at(k),y=b.pattern_coefficient_at(k);double px=0,py=0;for(unsigned c=0;c<3;++c){px+=std::norm(x[c]);py+=std::norm(y[c]);}if(std::abs(px-3)>=3e-15||std::abs(py-3)>=3e-15)std::cout<<k<<' '<<px<<' '<<py<<" total="<<a.geometry().fine_cells<<" seconds="<<a.geometry().bit_seconds<<'\n';}}

#include "datapump/triad_modem_v3.hpp"
#include <iostream>
#include <iomanip>
int main(){using namespace datapump;using namespace datapump::triad::v3;std::array<std::uint8_t,32> b{};for(unsigned i=0;i<32;++i)b[i]=17*i+3;Crypto key(b);std::cout<<std::setprecision(17);
for(unsigned mode=0;mode<3;++mode){Format f;if(mode==1){f.inner_rate_hz=360;f.added_symbols=1;f.sample_rate=960;f.bit_seconds=8;f.fhss=true;f.fhss_center_aligned=true;f.quiet_seconds=.055;f.ramp_seconds=.006;}if(mode==2){f.bit_seconds=40;f.burst_wait_tiles=1;}
for(unsigned bit=0;bit<2;++bit){PatternSource s(f,key,bit);for(long double t:{.037L,.317L,.731L}){auto p=s.geometry().calendar_origin_sample+t*s.geometry().tile_seconds*f.sample_rate;auto z=s.sample_at(p);std::cout<<mode<<" "<<bit<<" "<<double(t)<<" "<<z.real()<<" "<<z.imag()<<"\n";}}}}

import json
from pathlib import Path
import numpy as np
from scipy.signal import lfilter
p=Path('local-evidence/triad-pattern-revision');out=[]
for case in ('hf36-spread10','hf36-plain','no-interleave','low-max-spread'):
 for revision in ('legacy-v1','independent-apsk-v2'):
  folder=p/f'{case}-73002-{revision}';m=json.loads((folder/'manifest.json').read_text());fs=m['sample_rate_hz']
  x=np.memmap(folder/'composite.c128','<c16','r',shape=tuple(m['composite_shape']))
  for tau in (.1,.8):
   for bit in (0,1):
    power=abs(x[bit])**2;a=np.exp(-1/(tau*fs));estimate,_=lfilter([1-a],[1,-a],power,zi=[a])
    gain=np.clip(1/np.sqrt(np.maximum(estimate,1e-12)),.1,10)
    start=min(round(5*tau*fs),len(power)//4);xx=x[bit,start:];g=gain[start:];y=xx*g
    eta=abs(np.vdot(xx,y))**2/(np.vdot(xx,xx).real*np.vdot(y,y).real)
    out.append(dict(case=case,revision=revision,bit=bit,time_constant_seconds=tau,coherent_shape_loss_db=float(-10*np.log10(eta)),gain_1_99=np.quantile(g,[.01,.99]).tolist()))
report=dict(scope='Illustrative DATA-only high-SNR power detector: one-pole squared-envelope smoother, gainclamp0.1..10, no channel/noise/Helper. Applygain to actualcomposite; report normalizedmatched-template shape loss, not decode sensitivity or calibrated IC7100 model.',rows=out)
(p/'agc-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
for case in ('hf36-spread10','hf36-plain','no-interleave','low-max-spread'):
 print(case,max(r['coherent_shape_loss_db'] for r in out if r['case']==case and r['revision']=='independent-apsk-v2'))

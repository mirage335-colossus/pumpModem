import json,subprocess,time,hashlib
from pathlib import Path
from triad_pattern_metrics import measure
root=Path('local-evidence/triad-pattern-revision'); cases=[
('hf36-spread10',[]),
('hf36-plain',['--rate','36','--added','1','--sample-rate','960','--seconds','120','--window-seconds','32']),
('max-spread',['--rate','3.6','--added','1000','--sample-rate','9600','--seconds','240']),
('no-interleave',['--interleave','off']),
('microwave-fhss',['--rate','360','--added','1','--sample-rate','6000','--fhss','on','--quiet-seconds','.055','--ramp-seconds',str(2/3600)]),
('burst',['--burst-wait','3','--start-seconds','10','--window-seconds','60']),
('high24000',['--rate','24000','--added','1','--sample-rate','96000','--seconds','8','--window-seconds','2']),
('low-point1',['--rate','.1','--added','1','--sample-rate','100','--seconds','10000','--window-seconds','3000']),
('low-max-spread',['--rate','.001','--added','1000','--sample-rate','128','--seconds','1000000','--window-seconds','2000']),
('sub9-low',['--rate','.0036','--added','1','--sample-rate','1','--sample-rate-denominator','8','--seconds','1000000','--window-seconds','100000'])]
rows=[]
for seed in (73002,73003):
 for name,args in cases:
  if seed==73003 and name not in ('hf36-spread10','max-spread','microwave-fhss','high24000'):continue
  for revision in ('legacy-v1','independent-apsk-v2'):
   tag=f'{name}-{seed}-{revision}'; out=root/tag
   command=['build/dev-cli/triad_pattern_probe','--output',str(out),'--seed',str(seed),'--pattern-revision',revision,*args]
   start=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=90)
   row=dict(tag=tag,command=command,returncode=r.returncode,seconds=time.perf_counter()-start,stderr=r.stderr)
   if r.returncode==0:
    metrics=measure(out);(root/(tag+'-metrics.json')).write_text(json.dumps(metrics,indent=2)+'\n')
    row.update(energy=[x['mean_power'] for x in metrics['bits']],coef=metrics['coefficient'],max_windows=[[round(x.get('maximum_absolute_deviation_db',-1),3) for x in b['composite_windows']] for b in metrics['bits']])
    row['files_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
   rows.append(row);print(json.dumps({k:row[k] for k in ('tag','returncode','seconds','stderr')}),flush=True)
   (root/'coverage-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')

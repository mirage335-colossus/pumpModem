import json,subprocess,hashlib
from pathlib import Path
import numpy as np
root=Path('local-evidence/triad-pattern-revision'); results=[]
for revision in ('legacy-v1','independent-apsk-v2'):
 windows=[]
 for index,start in enumerate(np.linspace(100000,900000,24)):
  folder=root/f'dense-low-{revision}-{index}'
  command=['build/dev-cli/triad_pattern_probe','--output',str(folder),'--rate','.0036','--added','1','--sample-rate','100','--seconds','1000000','--window-seconds','.8','--start-seconds',str(start),'--pattern-revision',revision,'--seed','73004']
  r=subprocess.run(command,capture_output=True,text=True,check=True)
  m=json.loads((folder/'manifest.json').read_text());x=np.fromfile(folder/'composite.c128','<c16').reshape(2,-1)
  means={str(w):[float(np.mean(abs(y[:round(w*100)])**2)) for y in x] for w in (.1,.8)}
  windows.append(dict(command=command,first_sample=m['first_sample'],window_power=means,sha256=hashlib.sha256((folder/'composite.c128').read_bytes()).hexdigest()))
 row=dict(revision=revision,spacing_hz=.00075,sample_rate_hz=100,window_locations=24,windows=windows,scope='24 predeclared sparse dense windows; true100/800ms samples across9.26days ofcalendar, not continuous high-rate longrun; observed extrema only')
 row['statistics']={}
 for w in (.1,.8):
  power=np.array([z['window_power'][str(w)] for z in windows]);db=10*np.log10(power/np.median(power,axis=0))
  row['statistics'][str(w)]=dict(min_db=db.min(axis=0).tolist(),max_db=db.max(axis=0).tolist(),median_power=np.median(power,axis=0).tolist())
 results.append(row);print(revision,row['statistics'],flush=True)
(root/'dense-low-summary.json').write_text(json.dumps(results,indent=2)+'\n')

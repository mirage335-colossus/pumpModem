#!/usr/bin/env python3
"""Reject-only performance guard, separate from prediction qualification.

Only fresh direct full-target pairs may establish a regression. Screening and
engineering warnings are advisory. The statistical family is frozen before any
measurements and spends one workflow-wide false-rejection budget across jobs,
hypotheses and predeclared confirmation looks.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
import hashlib
import json
import math
import statistics
from typing import Iterable, Mapping

from scipy.stats import t as student_t


SCHEMA = "triad-performance-reject-only-guard-v1"
_PROFILES = {
    "ci": {"suite_alpha": .01, "threshold": 1.70, "screen_threshold": 1.50, "looks": (5,)},
    "gpu-dev": {"suite_alpha": .05, "threshold": 1.30, "screen_threshold": 1.15, "looks": (5, 9)},
}
ASSUMPTIONS = (
    "confirmation pairs are independent and stationary within the recorded execution regime",
    "paired direct-runtime contrasts are approximately normally distributed",
    "screen observations are excluded from every confirmation observation",
    "the hypothesis family, workflow job count and confirmation looks are frozen before measurement",
    "each confirmation measures its complete declared target without extrapolation",
)


@dataclass(frozen=True)
class GuardPolicy:
    profile: str = "ci"
    suite_alpha: float | None = None
    workflow_job_count: int = 1

    def __post_init__(self):
        if self.profile not in _PROFILES:
            raise ValueError("guard profile must be ci or gpu-dev")
        value = _PROFILES[self.profile]["suite_alpha"] if self.suite_alpha is None else self.suite_alpha
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= .05:
            raise ValueError("suite_alpha must be finite and in (0, .05]")
        if (type(self.workflow_job_count) is not int or self.workflow_job_count < 1):
            raise ValueError("workflow_job_count must be a positive integer")
        object.__setattr__(self, "suite_alpha", float(value))

    @property
    def threshold(self) -> float:
        return _PROFILES[self.profile]["threshold"]

    @property
    def screen_threshold(self) -> float:
        return _PROFILES[self.profile]["screen_threshold"]

    @property
    def looks(self) -> tuple[int, ...]:
        return _PROFILES[self.profile]["looks"]


@dataclass(frozen=True)
class PairObservation:
    run_id: str
    reference_seconds: float
    candidate_seconds: float

    def __post_init__(self):
        if not isinstance(self.run_id, str) or not self.run_id.strip():
            raise ValueError("run_id must be a nonempty string")
        for name in ("reference_seconds", "candidate_seconds"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")


def _digest(value: Mapping) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _seal(value: dict) -> dict:
    return {**value, "record_sha256": _digest(value)}


def _verify(value: Mapping, *, schema: str) -> dict:
    if not isinstance(value, Mapping) or value.get("schema") != schema:
        raise ValueError("unsupported guard record schema")
    result = dict(value)
    claimed = result.pop("record_sha256", None)
    if claimed != _digest(result):
        raise ValueError("guard record identity mismatch")
    return result


def build_guard_plan(hypothesis_ids: Iterable[str], policy: GuardPolicy | None = None,
                     *, metadata: Mapping | None = None) -> dict:
    policy = GuardPolicy() if policy is None else policy
    if not isinstance(policy, GuardPolicy):
        raise ValueError("policy must be GuardPolicy")
    if isinstance(hypothesis_ids, (str, bytes)):
        raise ValueError("hypothesis_ids must be a complete ordered family")
    ids = list(hypothesis_ids)
    if (not ids or any(not isinstance(name, str) or not name.strip() for name in ids)
            or len(ids) != len(set(ids))):
        raise ValueError("hypothesis IDs must be unique nonempty strings")
    # JSON copying rejects nonfinite metadata and prevents later caller mutation.
    metadata = json.loads(json.dumps(dict(metadata or {}), allow_nan=False))
    per_hypothesis = policy.suite_alpha / (policy.workflow_job_count * len(ids))
    if not 0 < per_hypothesis / len(policy.looks) < 1:
        raise ValueError("confirmation error allocation is outside representable positive range")
    return _seal({
        "schema": SCHEMA+".plan", "hypothesis_ids": ids,
        "policy": asdict(policy), "threshold": policy.threshold,
        "screen_threshold": policy.screen_threshold, "looks": list(policy.looks),
        "family_size": len(ids), "per_hypothesis_alpha": per_hypothesis,
        "per_confirmation_look_alpha": per_hypothesis / len(policy.looks),
        "workflow_false_rejection_budget": policy.suite_alpha,
        "job_false_rejection_budget": policy.suite_alpha / policy.workflow_job_count,
        "statistical_scope": "one declared CI workflow across its predeclared performance jobs; not lifetime control across commits",
        "cross_hypothesis_independence_required": False,
        "distribution_free_claim": False, "assumptions": list(ASSUMPTIONS),
        "metadata": metadata,
    })


def _plan(value: Mapping) -> dict:
    raw = _verify(value, schema=SCHEMA+".plan")
    expected = build_guard_plan(raw["hypothesis_ids"], GuardPolicy(**raw["policy"]), metadata=raw["metadata"])
    if value != expected:
        raise ValueError("guard plan arithmetic or immutable policy differs")
    return raw


def _pair(value: PairObservation | Mapping) -> PairObservation:
    if isinstance(value, PairObservation):
        return value
    if not isinstance(value, Mapping) or set(value) != {"run_id", "reference_seconds", "candidate_seconds"}:
        raise ValueError("a pair requires run_id and reference/candidate seconds")
    return PairObservation(**value)


def _hypothesis(plan: dict, hypothesis_id: str):
    if hypothesis_id not in plan["hypothesis_ids"]:
        raise ValueError("hypothesis was not in the frozen complete family")


def screen_case(plan: Mapping, hypothesis_id: str, observation: PairObservation | Mapping,
                *, warnings: Iterable[str] = (), force_confirmation: bool = False) -> dict:
    raw = _plan(plan)
    _hypothesis(raw, hypothesis_id)
    observation = _pair(observation)
    if isinstance(warnings, (str, bytes)):
        raise ValueError("warnings must be a list of advisory reasons")
    reasons = list(warnings)
    if any(not isinstance(reason, str) or not reason.strip() for reason in reasons):
        raise ValueError("advisory reasons must be nonempty strings")
    if type(force_confirmation) is not bool:
        raise ValueError("force_confirmation must be boolean")
    ratio = observation.candidate_seconds / observation.reference_seconds
    return _seal({"schema": SCHEMA+".screen", "plan_sha256": plan["record_sha256"],
        "hypothesis_id": hypothesis_id, "observation": asdict(observation),
        "point_ratio": ratio, "nominate_confirmation": ratio > raw["screen_threshold"] or force_confirmation,
        "force_confirmation": force_confirmation,
        "advisory_reasons": reasons, "blocking": False,
        "scope": "one advisory paired screen; no statistical non-regression or regression decision"})


@lru_cache(maxsize=128)
def _critical_value(n: int, alpha: float) -> float:
    return float(student_t.isf(alpha, n-1))


def confirm_case(plan: Mapping, hypothesis_id: str, observations: Iterable[PairObservation | Mapping],
                 *, screen_run_ids: Iterable[str]) -> dict:
    raw = _plan(plan)
    _hypothesis(raw, hypothesis_id)
    rows = [_pair(row) for row in observations]
    n = len(rows)
    if n not in raw["looks"]:
        raise ValueError("confirmation count must equal a predeclared look")
    ids = [row.run_id for row in rows]
    if len(set(ids)) != n:
        raise ValueError("confirmation pairs require distinct outer run IDs")
    if isinstance(screen_run_ids, (str, bytes)):
        raise ValueError("screen_run_ids must list excluded screen observations")
    excluded = list(screen_run_ids)
    if (not excluded or any(not isinstance(value, str) or not value.strip() for value in excluded)
            or len(excluded) != len(set(excluded))):
        raise ValueError("at least one unique excluded screen ID is required")
    if set(excluded) & set(ids):
        raise ValueError("screen observations cannot be reused for confirmation")
    contrasts = [row.candidate_seconds-raw["threshold"]*row.reference_seconds for row in rows]
    if any(not math.isfinite(value) for value in contrasts):
        raise ValueError("paired runtime contrast is not finite")
    center = statistics.fmean(contrasts)
    spread = statistics.stdev(contrasts)
    se = spread / math.sqrt(n)
    critical = _critical_value(n, raw["per_confirmation_look_alpha"])
    lower = center-critical*se
    mean_reference = statistics.fmean(row.reference_seconds for row in rows)
    mean_candidate = statistics.fmean(row.candidate_seconds for row in rows)
    return _seal({"schema": SCHEMA+".confirmation", "plan_sha256": plan["record_sha256"],
        "hypothesis_id": hypothesis_id, "observations": [asdict(row) for row in rows],
        "excluded_screen_run_ids": excluded, "sample_count": n,
        "mean_reference_seconds": mean_reference, "mean_candidate_seconds": mean_candidate,
        "arithmetic_mean_ratio": mean_candidate/mean_reference,
        "contrast_definition": "candidate_seconds - threshold * reference_seconds",
        "contrast_mean_seconds": center, "contrast_standard_error_seconds": se,
        "contrast_one_sided_lower_bound_seconds": lower, "critical_value": critical,
        "one_sided_alpha": raw["per_confirmation_look_alpha"],
        "confirmed_regression": lower > 0.,
        "status": "confirmed_regression" if lower > 0. else "no_confirmed_regression",
        "scope": "direct full-target arithmetic-mean contrast test, conditional on the frozen assumptions",
        "affirmative_non_regression_certification": False})


def build_guard_report(plan: Mapping, screens: Iterable[Mapping], confirmations: Iterable[Mapping],
                       *, functional_failures: Iterable[str] = (), advisory: Iterable[str] = ()) -> dict:
    """The sole guard exit decision; engineering diagnostics cannot turn it red."""
    raw = _plan(plan)
    screens = list(screens)
    confirmations = list(confirmations)
    if isinstance(functional_failures, (str, bytes)) or isinstance(advisory, (str, bytes)):
        raise ValueError("failure and advisory messages must be lists")
    failures, messages = list(functional_failures), list(advisory)
    if any(not isinstance(message, str) or not message.strip() for message in (*failures, *messages)):
        raise ValueError("failure and advisory messages must be nonempty strings")
    by_id = {}
    for receipt in screens:
        screen = _verify(receipt, schema=SCHEMA+".screen")
        if screen["hypothesis_id"] in by_id:
            raise ValueError("duplicate hypothesis screen")
        expected = screen_case(plan, screen["hypothesis_id"], screen["observation"],
                               warnings=screen["advisory_reasons"], force_confirmation=screen["force_confirmation"])
        if receipt != expected:
            raise ValueError("screen receipt does not replay")
        by_id[screen["hypothesis_id"]] = screen
        messages.extend(f"{screen['hypothesis_id']}: {reason}" for reason in screen["advisory_reasons"])
    seen = {}
    confirmed = set()
    for receipt in confirmations:
        result = _verify(receipt, schema=SCHEMA+".confirmation")
        name = result["hypothesis_id"]
        if name not in by_id or not by_id[name]["nominate_confirmation"]:
            raise ValueError("confirmation requires its nominated screen")
        excluded = [by_id[name]["observation"]["run_id"]]
        expected = confirm_case(plan, name, result["observations"], screen_run_ids=excluded)
        if receipt != expected:
            raise ValueError("confirmation receipt does not replay")
        history = seen.setdefault(name, [])
        if history:
            prior = history[-1]
            if (result["sample_count"] <= prior["sample_count"] or
                    result["observations"][:prior["sample_count"]] != prior["observations"]):
                raise ValueError("confirmation looks must extend the same frozen sequence")
            if prior["confirmed_regression"]:
                raise ValueError("cannot retry a previously confirmed regression")
        history.append(result)
        if result["confirmed_regression"]:
            confirmed.add(name)
    missing = [name for name in raw["hypothesis_ids"] if name not in by_id]
    unconfirmed = [name for name, result in by_id.items() if result["nominate_confirmation"] and name not in seen]
    early = [name for name, history in seen.items()
             if history[-1]["sample_count"] < raw["looks"][-1] and name not in confirmed]
    if missing:
        messages.append("screening unavailable or incomplete for: "+", ".join(missing))
    if unconfirmed:
        messages.append("confirmation unavailable or budget-limited for: "+", ".join(unconfirmed))
    if early:
        messages.append("confirmation stopped before the final predeclared look for: "+", ".join(early))
    blocking = bool(failures or confirmed)
    return _seal({"schema": SCHEMA+".report", "plan_sha256": plan["record_sha256"],
        "status": "blocked" if blocking else "no_confirmed_regression",
        "exit_code": 2 if blocking else 0,
        "functional_status": "failed" if failures else "no_functional_failure_reported",
        "functional_failures": failures, "confirmed_regressions": sorted(confirmed),
        "performance_status": "confirmed_regression" if confirmed else "no_confirmed_regression",
        "screened_hypotheses": list(by_id), "missing_screens": missing,
        "unconfirmed_nominations": unconfirmed, "confirmation_effort_limited": early, "advisory": messages,
        "screens": screens, "confirmations": confirmations,
        "qualification_status": "not_evaluated_by_fast_guard",
        "affirmative_non_regression_certification": False,
        "probability_scope": "conditional workflow-level statistical false rejection only; deterministic correctness and infrastructure failures are separate",
        "workflow_false_rejection_budget": raw["workflow_false_rejection_budget"],
        "distribution_free_claim": False})

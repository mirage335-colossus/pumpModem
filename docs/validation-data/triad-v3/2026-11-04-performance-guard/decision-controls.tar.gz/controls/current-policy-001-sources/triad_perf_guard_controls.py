#!/usr/bin/env python3
"""Cheap model checks of the workflow-level performance guard.

These simulations test the actual guard aggregator on a retained subset and a
cross-checked vectorized equivalent on the complete Monte Carlo sample. They
measure behavior under named distributions, including deliberate violations of
the guard's normality and independence assumptions. They are not radio or CPU
performance measurements and establish no distribution-free machine guarantee.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.stats import beta

from triad_perf_guard_policy import (GuardPolicy, PairObservation, _critical_value,
                                    build_guard_plan, build_guard_report,
                                    confirm_case, screen_case)


SCHEMA = "triad-performance-guard-distribution-controls-v1"


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def binomial_interval(successes, trials, alpha=.05):
    if type(successes) is not int or type(trials) is not int or not 0 <= successes <= trials or trials < 1:
        raise ValueError("valid integer binomial counts required")
    return [0. if successes == 0 else float(beta.ppf(alpha/2, successes, trials-successes+1)),
            1. if successes == trials else float(beta.ppf(1-alpha/2, successes+1, trials-successes))]


def scenarios(ci_hypotheses=36, dev_hypotheses=39):
    result = []
    def add(profile, ratio, *, distribution="gaussian-contrast", rho=.8, jobs=1, alpha=None):
        policy = GuardPolicy(profile, suite_alpha=alpha, workflow_job_count=jobs)
        result.append({"profile": profile, "suite_alpha": policy.suite_alpha,
            "hypotheses_per_job": ci_hypotheses if profile == "ci" else dev_hypotheses,
            "workflow_jobs": jobs, "ratio": ratio, "distribution": distribution,
            "latent_cross_case_correlation": rho})
    for rho in (0., .8):
        for ratio in (1., 1.69, 1.70, 1.71, 2., 3.):
            add("ci", ratio, rho=rho)
    for jobs in (1, 2):
        for alpha in (.01, .05):
            for ratio in (1.7, 2.):
                add("ci", ratio, jobs=jobs, alpha=alpha)
    for ratio in (1., 1.29, 1.30, 1.31, 1.6):
        add("gpu-dev", ratio)
    for distribution in ("lognormal-scheduling", "heavy-lognormal-scheduling",
                         "rademacher-jitter", "rare-fast-bimodal", "serial-regime"):
        for rho in (0., .8):
            add("ci", 1.7, distribution=distribution, rho=rho)
    for distribution in ("rademacher-jitter", "rare-fast-bimodal", "serial-regime"):
        add("gpu-dev", 1.3, distribution=distribution)
    return result


def _draw(rng, trials, count, n, *, ratio, threshold, distribution, rho):
    # The leading row is an independent screen except in the explicitly serial
    # adversarial model. Its stored IDs remain disjoint in every model.
    shared = rng.standard_normal((trials, 1, n))
    z = math.sqrt(rho)*shared+math.sqrt(1-rho)*rng.standard_normal((trials,count,n))
    reference = np.full((trials,count,n), 10., dtype=np.float64)
    if distribution == "gaussian-contrast":
        contrast = (ratio-threshold)*10.+.5*z
        candidate = threshold*reference+contrast
        assumptions = "independent stationary Gaussian contrasts; arbitrary declared cross-case correlation"
    elif distribution in ("lognormal-scheduling", "heavy-lognormal-scheduling"):
        sigma = .5 if distribution == "lognormal-scheduling" else 1.0
        za = math.sqrt(rho)*shared+math.sqrt(1-rho)*rng.standard_normal((trials,count,n))
        zb = math.sqrt(rho)*shared+math.sqrt(1-rho)*rng.standard_normal((trials,count,n))
        reference = 10.*np.exp(sigma*za-sigma*sigma/2)
        candidate = ratio*10.*np.exp(sigma*zb-sigma*sigma/2)
        assumptions = "independent positive lognormal scheduling; paired contrast is nonnormal"
    elif distribution == "rademacher-jitter":
        contrast = (ratio-threshold)*10.+np.where(z >= 0.,1.,-1.)+1e-6*rng.standard_normal(z.shape)
        candidate = threshold*reference+contrast
        assumptions = "independent symmetric near-Rademacher contrasts; violates Gaussian contrast assumption"
    elif distribution == "rare-fast-bimodal":
        # P(positive)=.9, contrast +1 or -9 gives exactly zero population
        # contrast mean at the threshold. Candidate runtime remains positive.
        from scipy.special import ndtr
        contrast = (ratio-threshold)*10.+np.where(ndtr(z) < .9,1.,-9.)+1e-6*rng.standard_normal(z.shape)
        candidate = threshold*reference+contrast
        assumptions = "independent asymmetric two-regime contrasts; violates Gaussian contrast assumption"
    elif distribution == "serial-regime":
        # A regime lasts across screen and every confirmation observation.
        regime = z[:,:,:1]
        contrast = (ratio-threshold)*10.+np.where(regime >= 0.,1.,-1.)+1e-6*rng.standard_normal(z.shape)
        candidate = threshold*reference+contrast
        assumptions = "regime persists through screen and confirmations; violates independent-pair and Gaussian assumptions"
    else:
        raise ValueError("unknown distribution")
    if not np.isfinite(reference).all() or not np.isfinite(candidate).all() or np.any(candidate <= 0):
        raise ValueError("simulation produced an invalid physical runtime")
    return reference, candidate, assumptions


def _replay_one(plan, reference, candidate, expected_reject, *, trial, h, jobs):
    any_reject = False
    for job in range(jobs):
        screens, confirmations = [], []
        for local,name in enumerate(plan["hypothesis_ids"]):
            index = job*h+local
            screen_id = f"screen-{trial}-{job}-{local}"
            screen = screen_case(plan,name,PairObservation(screen_id,
                float(reference[index,0]),float(candidate[index,0])))
            screens.append(screen)
            if screen["nominate_confirmation"]:
                for look in plan["looks"]:
                    rows = [PairObservation(f"confirmation-{trial}-{job}-{local}-{i}",
                        float(reference[index,i+1]),float(candidate[index,i+1])) for i in range(look)]
                    receipt = confirm_case(plan,name,rows,screen_run_ids=[screen_id])
                    confirmations.append(receipt)
                    if receipt["confirmed_regression"]:
                        break
        report = build_guard_report(plan,screens,confirmations)
        any_reject |= report["exit_code"] != 0
    if any_reject != bool(expected_reject):
        raise AssertionError("vectorized decision disagrees with actual aggregator")
    return any_reject


def simulate_case(spec, *, trials, seed, parity_workflows=4):
    if type(trials) is not int or trials < 1 or type(parity_workflows) is not int or parity_workflows < 0:
        raise ValueError("positive trials and nonnegative parity count required")
    h, jobs = spec["hypotheses_per_job"], spec["workflow_jobs"]
    policy = GuardPolicy(spec["profile"], suite_alpha=spec["suite_alpha"], workflow_job_count=jobs)
    plan = build_guard_plan([f"case-{i}" for i in range(h)],policy,
                            metadata={"experiment": "synthetic distribution control"})
    rng = np.random.default_rng(seed)
    reference,candidate,assumptions = _draw(rng,trials,h*jobs,policy.looks[-1]+1,
        ratio=spec["ratio"],threshold=policy.threshold,distribution=spec["distribution"],
        rho=spec["latent_cross_case_correlation"])
    nominate = candidate[:,:,0]/reference[:,:,0] > policy.screen_threshold
    rejected = np.zeros_like(nominate)
    fresh_pairs = np.zeros_like(nominate,dtype=np.int64)
    prior = 0
    per_look_counts = []
    for look in policy.looks:
        active = nominate & ~rejected
        fresh_pairs += active*(look-prior)
        contrasts = candidate[:,:,1:look+1]-policy.threshold*reference[:,:,1:look+1]
        means = np.mean(contrasts,axis=2)
        se = np.std(contrasts,axis=2,ddof=1)/math.sqrt(look)
        lower = means-_critical_value(look,plan["per_confirmation_look_alpha"])*se
        new = active & (lower > 0.)
        rejected |= new
        per_look_counts.append({"look":look,"new_rejected_hypotheses":int(np.sum(new))})
        prior = look
    workflow = np.any(rejected,axis=1)
    for trial in range(min(parity_workflows,trials)):
        _replay_one(plan,reference[trial],candidate[trial],workflow[trial],trial=trial,h=h,jobs=jobs)
    blocked = int(np.sum(workflow))
    null = spec["ratio"] <= policy.threshold
    total_pairs = h*jobs+np.sum(fresh_pairs,axis=1)
    return {**spec,"trials":trials,"seed":seed,"assumption_status":assumptions,
        "plan":plan,"blocked_workflows":blocked,"blocked_rate":blocked/trials,
        "blocked_rate_95_percent_interval":binomial_interval(blocked,trials),
        "false_block_workflows":blocked if null else None,
        "missed_regression_workflows":trials-blocked if not null else None,
        "false_block_rate":blocked/trials if null else None,
        "miss_rate":(trials-blocked)/trials if not null else None,
        "mean_nominated_hypotheses":float(np.mean(np.sum(nominate,axis=1))),
        "mean_confirmation_pairs":float(np.mean(np.sum(fresh_pairs,axis=1))),
        "mean_total_pairs_including_screen":float(np.mean(total_pairs)),
        "pair_count_is_not_processor_wall_time":True,
        "per_look_rejections":per_look_counts,
        "actual_aggregator_parity_workflows":min(parity_workflows,trials),
        "actual_aggregator_parity":"all matched",
        "sample_distribution_scope":"declared synthetic law only; no universal machine-timing false-block guarantee"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trials",type=int,default=5000)
    parser.add_argument("--parity-workflows",type=int,default=4)
    parser.add_argument("--ci-hypotheses",type=int,default=36)
    parser.add_argument("--dev-hypotheses",type=int,default=39)
    parser.add_argument("--seed",type=int,default=184231)
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args(argv)
    if args.trials < 1 or args.ci_hypotheses < 1 or args.dev_hypotheses < 1 or args.parity_workflows < 0:
        parser.error("positive counts and nonnegative parity count required")
    started = time.perf_counter()
    specs = scenarios(args.ci_hypotheses,args.dev_hypotheses)
    rows = [simulate_case(spec,trials=args.trials,seed=args.seed+i*1009,
                          parity_workflows=args.parity_workflows) for i,spec in enumerate(specs)]
    for row in rows:
        row["blocked_rate_simultaneous_95_percent_interval"] = binomial_interval(
            row["blocked_workflows"],row["trials"],alpha=.05/len(rows))
    result = {"schema":SCHEMA,"cases":rows,"scenario_count":len(rows),
        "source_sha256":{Path(__file__).name:_hash(__file__),
            "triad_perf_guard_policy.py":_hash(Path(__file__).with_name("triad_perf_guard_policy.py"))},
        "elapsed_seconds":time.perf_counter()-started,
        "interval_scope":"per-scenario exact binomial intervals; separate Bonferroni intervals cover all declared scenarios",
        "qualification_scope":"policy model checks, not measured hardware/receiver performance",
        "existing_policy_changed":False}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write("\n")
    print(json.dumps({"scenario_count":len(rows),"elapsed_seconds":result["elapsed_seconds"],
        "output":str(args.output),"actual_aggregator_workflows":sum(row["actual_aggregator_parity_workflows"] for row in rows)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

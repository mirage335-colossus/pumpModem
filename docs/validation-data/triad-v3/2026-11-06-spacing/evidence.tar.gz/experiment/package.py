from pathlib import Path
import hashlib,json,platform,tarfile,io
root=Path('.');ev=Path('local-evidence/triad-spacing');out=Path('docs/validation-data/triad-v3/2026-11-06-spacing')
old=Path('local-evidence/triad-pattern-revision')
names=['hf36-spread10-73002','hf36-spread10-73003','initial-apsk25','no-interleave-73002','microwave-fhss-73002','microwave-fhss-73003','hf36-plain-73002','max-spread-73002','high24000-73002','burst-73002']
probes=[old/(n if n.startswith('initial') else n+'-independent-apsk-v2') for n in names]+[ev/f'holdout-{i}' for i in range(74101,74109)]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
ident=[]
for p in probes:
 m=json.loads((p/'manifest.json').read_text());ident.append(dict(path=str(p),manifest=m,files={q.name:dict(bytes=q.stat().st_size,sha256=sha(q)) for q in p.iterdir() if q.is_file()}))
(ev/'probe-identities.json').write_text(json.dumps(ident,indent=2)+'\n')
model=next((x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'unknown')
(ev/'environment.json').write_text(json.dumps(dict(platform=platform.platform(),cpu=model,python=platform.python_version(),scope='Local source diagnostics; no GPU/device measurements'),indent=2)+'\n')
source=['tools/triad_spacing_diagnostic.py','tests/test_triad_spacing_diagnostic.py','tools/triad_pattern_metrics.py','tools/triad-pattern-probe.cpp','include/datapump/triad_modem_v3.hpp','include/datapump/triad_shaping.hpp','include/datapump/pattern_pulse.hpp','src/triad_modem_v3.cpp','src/triad_shaping.cpp','src/helper_carrier.cpp']
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for p in sorted(ev.iterdir()):
  if p.is_file() and p.suffix in ['.py','.cpp','.json','.log','.csv','.txt']:
   if p.name in ['diagnostic-saved-cases.json','final-holdout-diagnostic.json','final-receipts.json'] or p.name.endswith('-final.log'):continue # intermediate tool revisions, not final evidence
   t.add(p,arcname='experiment/'+p.name)
 for f in source:t.add(f,arcname='source/'+f)
 t.add(out/'README.md',arcname='README.md');t.add(out/'summary.json',arcname='summary.json')
checks=''.join(f'{sha(out/name)}  {name}\n' for name in ['README.md','summary.json','evidence.tar.gz'])
(out/'SHA256SUMS').write_text(checks)
print('artifact bytes:',(out/'evidence.tar.gz').stat().st_size)

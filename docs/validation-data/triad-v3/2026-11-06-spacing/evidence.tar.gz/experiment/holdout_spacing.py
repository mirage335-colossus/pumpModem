import sys,json,math
from pathlib import Path
import numpy as np
from scipy.signal import lfilter
sys.path.insert(0,'tools')
from triad_pattern_metrics import envelope_metrics
root=Path('local-evidence/triad-spacing')
out=[]
for name in [f'holdout-{seed}' for seed in range(74101,74109)]:
 p=root/name
 m=json.loads((p/'manifest.json').read_text());fs=m['sample_rate_hz'];f=m['fine_rate_hz']
 c=np.memmap(p/m['carrier_file'],dtype='<c16',mode='r',shape=m['carrier_shape'])
 e=np.memmap(p/m['envelope_file'],dtype='<f8',mode='r',shape=m['envelope_shape'])
 t=(np.arange(m['rows'])+m['first_sample']-m['calendar_origin_sample'])/fs
 summed=np.sum(abs(c)**2,axis=1)
 def stats(power):
  r={}
  for w in [.08,.09,.1,.11,.12,.15,.2,.4,.8]:
   a=[envelope_metrics(x,e,fs,w,10*math.log10(1.6)) for x in power]
   r[str(w)]=max(v['maximum_absolute_deviation_db'] for v in a if v['measured'])
  # one-pole square law power (only flat-envelope windows); evaluate gain on actual samples
  r['onepole']={}
  for tau in [.05,.1,.2,.8]:
   beta=math.exp(-1/(fs*tau));valid=(e>1-1e-12)&(t>t[0]+5*tau)
   a=[]
   if not valid.any():
    r['onepole'][str(tau)]=None;continue
   for x in power:
    y=lfilter([1-beta],[1,-beta],x,zi=[beta*x[0]])[0]
    db=10*np.log10(np.maximum(y[valid],1e-30)/np.median(y[valid]));a.append(float(np.max(abs(db))))
   r['onepole'][str(tau)]=max(a)
  return r
 rows={'name':name,'fine':f,'summed':stats(summed),'candidates':[]}
 for ratio in [1.25,1.375,1.5,1.6]:
  x=np.sum(c*np.exp(2j*np.pi*np.array([-1,0,1])[None,:,None]*f*ratio*t[None,None,:]),axis=1)
  rows['candidates'].append({'ratio':ratio,'nominal_width':(2*ratio+1.25)*f,'energy':float(np.mean(abs(x)**2)),**stats(abs(x)**2)})
 out.append(rows);print(name,json.dumps([{'r':r['ratio'],'100':r['0.1'],'near':max(r[str(w)] for w in [.08,.09,.1,.11,.12]),'800':r['0.8'],'pole':r['onepole']['0.1']} for r in rows['candidates']]),flush=True)
Path('local-evidence/triad-spacing/holdout-spacing.json').write_text(json.dumps(out,indent=2)+'\n')

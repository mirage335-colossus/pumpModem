#include "datapump/triad_shaping.hpp"
#include "datapump/helper_carrier.hpp"
#include <iostream>
#include <iomanip>
#include <algorithm>
int main(){using namespace datapump;using namespace triad::v3;
 std::cout<<std::setprecision(17)<<"case,if_hz,spacing_ratio,spacing_hz,nominal_width_hz,conservative_width_hz,high_hz,baseline_high_hz,eligible\n";
 for(bool eme:{false,true}){Format f;f.sample_rate=6000;f.bit_seconds=60;
  if(eme){f.inner_rate_hz=360;f.added_symbols=1;f.fhss=f.fhss_center_aligned=true;f.quiet_seconds=.055;f.ramp_seconds=2./3600;}
  auto s=plan_shaping(f);helper::Options o;o.data_power_w=eme?40:4;o.power_w=o.data_power_w+(eme?15000:40);o.timecode=true;o.callsign="TRIAD";
  for(double center:{1725.,1775.}){double baseline=helper::plan(o,helper::PlacementBand{center,s.geometry.occupied_bandwidth_hz,std::max(0.,s.spectrum.placement_bandwidth_hz-s.geometry.occupied_bandwidth_hz),f.fhss},f.sample_rate).frequency_hz;
   for(double r:{1.25,1.3,1.375,1.5,1.6}){double spacing=r*s.geometry.fine_chip_rate_hz;double width=2*spacing+1.25*s.geometry.fine_chip_rate_hz;double skirt=std::max(0.,s.spectrum.placement_bandwidth_hz-s.geometry.occupied_bandwidth_hz);double high=-1;
    try{high=helper::plan(o,helper::PlacementBand{center,width,skirt,f.fhss},f.sample_rate).frequency_hz;}catch(const std::exception&){}
    std::cout<<(eme?"eme":"hf")<<','<<center<<','<<r<<','<<spacing<<','<<width<<','<<width+skirt<<','<<high<<','<<baseline<<','<<(high==baseline)<<'\n';
   }
  }
 }
}

import json,math
from pathlib import Path
import numpy as np
out=[]
for beta in [.25,.35,.5]:
 a=np.arange(2049)/256
 with np.errstate(invalid='ignore',divide='ignore'):v=(np.sin(np.pi*a*(1-beta))+4*beta*a*np.cos(np.pi*a*(1+beta)))/(np.pi*a*(1-16*beta*beta*a*a))
 v[0]=1+beta*(4/np.pi-1);mask=np.isclose(a,1/(4*beta),atol=1e-12,rtol=0);v[mask]=beta/math.sqrt(2)*((1+2/np.pi)*np.sin(np.pi/(4*beta))+(1-2/np.pi)*np.cos(np.pi/(4*beta)))
 s=np.clip((8-a)/2,0,1);v*=s**3*(10+s*(-15+6*s));v/=math.sqrt((v[0]**2+v[-1]**2+2*np.sum(v[1:-1]**2))/256)
 phase=np.arange(4096)/4096;power=sum(np.interp(abs(phase-k),a,v,right=0)**2 for k in range(-8,9));power/=power.mean()
 harmonic=2*abs(np.mean(power*np.exp(-2j*np.pi*phase)))
 out.append(dict(rolloff=beta,periodic_mean_power_harmonic_amplitude=float(harmonic),ideal_infinite_rrc_amplitude=2*beta/np.pi,peak_to_peak_mean_power_db=float(10*np.log10(power.max()/power.min()))))
Path('local-evidence/triad-spacing/cyclic.json').write_text(json.dumps(dict(assumptions='ensemble mean for independent zero-mean cell vectors; unit-energy finite tapered RRC, no dwell gate; analytical pulse diagnostic, not an interceptor performance measurement',rows=out),indent=2)+'\n')
print(json.dumps(out,indent=2))

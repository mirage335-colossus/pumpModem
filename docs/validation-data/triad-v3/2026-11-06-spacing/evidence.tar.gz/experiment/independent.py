import subprocess,json,time,hashlib
from pathlib import Path
root=Path('local-evidence/triad-spacing');exe=Path('build/dev-cli/triad_pattern_probe').resolve()
rows=[]
for seed in range(74101,74109):
 p=root/f'holdout-{seed}'
 cmd=[str(exe),'--output',str(p),'--rate','36','--added','10','--sample-rate','6000','--seconds','60','--window-seconds','16','--seed',str(seed)]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 rows.append(dict(seed=seed,command=cmd,returncode=r.returncode,wall_seconds=time.monotonic()-start,stderr=r.stderr))
 if r.returncode:raise RuntimeError(r.stderr)
(root/'holdout-receipts.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')

import subprocess,time,json,hashlib,os,resource
from pathlib import Path
root=Path('local-evidence/triad-spacing');py='/tmp/triad-weak-env/bin/python';env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
commands=[('unit',[py,'tests/test_triad_spacing_diagnostic.py']),('related-metrics',[py,'tests/test_triad_pattern_metrics.py']),('independent-diagnostic',[py,'tools/triad_spacing_diagnostic.py',*[str(root/f'holdout-{i}') for i in range(74101,74109)],'--spacing-ratios','1.25,1.5','--output',str(root/'final-holdout-diagnostic.json')])]
rows=[]
for name,argv in commands:
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);r=subprocess.run(argv,env=env,capture_output=True,text=True);after=resource.getrusage(resource.RUSAGE_CHILDREN)
 row=dict(name=name,argv=argv,returncode=r.returncode,wall_seconds=time.monotonic()-start,process_cpu_seconds=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime)
 rows.append(row);(root/(name+'-final.log')).write_text(r.stdout+r.stderr);print(row,flush=True)
 if r.returncode:break
(root/'final-receipts.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(Path('tools/triad_spacing_diagnostic.py').read_bytes()).hexdigest(),thread_limits={k:env[k] for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']},rows=rows),indent=2)+'\n')
raise SystemExit(any(x['returncode'] for x in rows))

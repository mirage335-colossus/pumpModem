import csv,hashlib,json,subprocess
from pathlib import Path
p=Path('local-evidence/triad-spacing');out=Path('docs/validation-data/triad-v3/2026-11-06-spacing')
spacing=json.loads((p/'holdout-spacing.json').read_text());rolloff=json.loads((p/'holdout-rolloff.json').read_text())
def digest(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=dict(schema='triad-spacing-study-v1',decision='Keep current native spacing and pulse; no justified practical improvement from tested widening.',runtime_changed=False,
 base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 scope='Source-only finite keyed fixtures and production Helper planning calls, not channel/sensitivity/physical AGC/operational false-admission qualification.',
 independent_seeds=list(range(74101,74109)),bits_per_seed=2,window_seconds_per_bit=16,fine_rate_hz=60,sample_rate_hz=6000,
 threshold_db=.25*10*__import__('math').log10(1.6),spacing=[],rolloff=[],
 helper_placement=list(csv.DictReader((p/'placement.csv').open())),
 periodic_pulse_power=json.loads((p/'cyclic.json').read_text()),checks={})
for ratio in [1.25,1.375,1.5,1.6]:
 a=[next(y for y in x['candidates'] if y['ratio']==ratio) for x in spacing]
 summary['spacing'].append(dict(ratio=ratio,spacing_hz=ratio*60,nominal_width_hz=(2*ratio+1.25)*60,max_db={w:max(x[w] for x in a) for w in ['0.08','0.09','0.1','0.11','0.12','0.15','0.2','0.4','0.8']}))
for beta in [.25,.5]:
 a=[x for x in rolloff if x['beta']==beta]
 summary['rolloff'].append(dict(beta=beta,spacing_hz=(1+beta)*60,nominal_width_hz=3*(1+beta)*60,max_db={w:max(x['windows'][w] for x in a) for w in ['0.08','0.09','0.1','0.11','0.12','0.15','0.2','0.8']},max_100ms_illustrative_shape_loss_db=max(x['pole']['0.1'] for x in a),maximum_native_baseline_reconstruction_error=max(x['baseline_reconstruction_error'] for x in a)))
if (p/'accepted-receipts.json').exists():summary['checks']=json.loads((p/'accepted-receipts.json').read_text())
files=['tools/triad_spacing_diagnostic.py','tests/test_triad_spacing_diagnostic.py','tools/triad_pattern_metrics.py','include/datapump/triad_modem_v3.hpp','include/datapump/pattern_pulse.hpp','include/datapump/triad_shaping.hpp','src/triad_modem_v3.cpp','src/triad_shaping.cpp','src/helper_carrier.cpp','tools/triad-pattern-probe.cpp','build/dev-cli/triad_pattern_probe','build/dev-cli/triad_helper_export','local-evidence/triad-spacing/placement']
summary['identities']={f:digest(f) for f in files}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('wrote summary')

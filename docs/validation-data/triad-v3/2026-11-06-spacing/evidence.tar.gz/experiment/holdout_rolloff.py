import json,sys,math
from pathlib import Path
import numpy as np
from scipy.signal import fftconvolve,lfilter
sys.path.insert(0,'tools')
from triad_pattern_metrics import envelope_metrics,spectrum_metrics
root=Path('local-evidence/triad-spacing');out=[]
for name in [f'holdout-{seed}' for seed in range(74101,74109)]:
 p=root/name;m=json.loads((p/'manifest.json').read_text());fs=m['sample_rate_hz'];f=m['fine_rate_hz'];n=m['rows'];sps=round(fs/f);assert fs/f==sps
 coef=np.memmap(p/m['coefficients_file'],dtype='<c16',mode='r',shape=m['coefficients_shape']);env=np.memmap(p/m['envelope_file'],dtype='<f8',mode='r',shape=m['envelope_shape'])
 native=np.memmap(p/m['carrier_file'],dtype='<c16',mode='r',shape=m['carrier_shape'])
 t=(np.arange(n)+m['first_sample']-m['calendar_origin_sample'])/fs
 impulses=np.zeros((2,3,n),complex);positions=np.rint(((np.arange(coef.shape[1])+m['coefficient_first']+.5)/f-t[0])*fs).astype(int)
 valid=(positions>=0)&(positions<n);impulses[:,:,positions[valid]]=coef[:,valid,:].transpose(0,2,1)/math.sqrt(3)
 cut=slice(8*sps+1,-8*sps-1);e=env[cut];tt=t[cut]
 for beta in [.25,.5]:
  a=np.arange(2049)/256
  with np.errstate(invalid='ignore',divide='ignore'):v=(np.sin(np.pi*a*(1-beta))+4*beta*a*np.cos(np.pi*a*(1+beta)))/(np.pi*a*(1-16*beta*beta*a*a))
  v[0]=1+beta*(4/np.pi-1)
  pos=np.isclose(a,1/(4*beta),atol=1e-12,rtol=0);v[pos]=beta/math.sqrt(2)*((1+2/np.pi)*np.sin(np.pi/(4*beta))+(1-2/np.pi)*np.cos(np.pi/(4*beta)))
  s=np.clip((8-a)/2,0,1);v*=s*s*s*(10+s*(-15+6*s));v/=math.sqrt((v[0]**2+v[-1]**2+2*np.sum(v[1:-1]**2))/256)
  pulse=np.interp(np.abs(np.arange(-8*sps,8*sps+1)/sps),a,v)
  carriers=np.array([[fftconvolve(x,pulse,mode='same') for x in b] for b in impulses])*env
  if beta==.25:
   error=float(np.max(abs(carriers[:,:,cut]-native[:,:,cut])));assert error<1e-9,error
  spacing=(1+beta)*f;x=np.sum(carriers[:,:,cut]*np.exp(2j*np.pi*np.array([-1,0,1])[None,:,None]*spacing*tt),axis=1)
  r=dict(name=name,beta=beta,spacing=spacing,width=3*spacing,baseline_reconstruction_error=error,windows={},pole={},spectra=[])
  for w in [.08,.09,.1,.11,.12,.15,.2,.8]:r['windows'][str(w)]=max(envelope_metrics(abs(y)**2,e,fs,w,10*math.log10(1.6))['maximum_absolute_deviation_db'] for y in x)
  for tau in [.08,.1,.12,.8]:
   losses=[]
   for y in x:
    a=math.exp(-1/(fs*tau));est=lfilter([1-a],[1,-a],abs(y)**2,zi=[a*abs(y[0])**2])[0];gain=np.clip(1/np.sqrt(np.maximum(est,1e-12)),.1,10);start=min(round(5*tau*fs),len(y)//4);xx=y[start:];yy=xx*gain[start:]
    eta=abs(np.vdot(xx,yy))**2/(np.vdot(xx,xx).real*np.vdot(yy,yy).real);losses.append(float(-10*np.log10(eta)))
   r['pole'][str(tau)]=max(losses)
  r['spectra']=[spectrum_metrics(y,fs,3*spacing) for y in x];out.append(r)
  print(name,beta,r['windows'],r['pole'],flush=True)
Path('local-evidence/triad-spacing/holdout-rolloff.json').write_text(json.dumps(out,indent=2)+'\n')

import hashlib,json,resource,time,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'tools')
from triad_continuous import NativeStream
p=Path('local-evidence/triad-native-render-bank')
original=Path('local-evidence/triad-hf-high-snr-cost')
command=json.loads((original/'public-generation.json').read_text())['command']
args=command[1:command.index('--output')]+['--power-reference','whole-active']
m=json.loads((original/'public/manifest.json').read_text());count=m['templates']['shape'][-1]
rows=[(bit,epoch,0,0,0,0,0) for epoch in range(-6,7) for bit in (0,1)]
reference=np.memmap(original/'public/templates.c128',mode='r',dtype='<c16',shape=(26,count))
results=[]
for name,binary in [('before',p/'triad_helper_export.before'),('after',Path('build/dev-cli/triad_helper_export'))]:
 u=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter();source=NativeStream(binary,args,kind='emitted');startup=time.perf_counter()-w
 arrays=[];elapsed=time.perf_counter()
 try:
  for first in range(0,count,4096):arrays.append(source.basis(first,min(4096,count-first),rows))
  render_wall=time.perf_counter()-elapsed
 finally: receipt=source.close()
 v=resource.getrusage(resource.RUSAGE_CHILDREN)
 result=np.concatenate(arrays,axis=1);difference=np.max(abs(result-reference));exact=np.array_equal(result.view(np.uint64),np.asarray(reference).view(np.uint64))
 row=dict(name=name,binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),command=[str(binary),*args],count=count,patterns=len(rows),startup_wall_seconds=startup,bank_wall_seconds=render_wall,total_wall_seconds=time.perf_counter()-w,child_cpu_seconds=v.ru_utime+v.ru_stime-u.ru_utime-u.ru_stime,maximum_complex_difference=float(difference),bitwise_matches_archived_templates=exact,native_receipt=receipt)
 results.append(row);print(row,flush=True)
(p/'benchmark.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['bitwise_matches_archived_templates'] for r in results)

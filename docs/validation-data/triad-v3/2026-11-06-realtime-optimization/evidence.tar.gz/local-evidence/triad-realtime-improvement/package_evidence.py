from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path.cwd(); evidence=root/'local-evidence/triad-realtime-improvement'
out=root/'docs/validation-data/triad-v3/2026-11-06-realtime-optimization'
def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pairs=[]
for label,before,after in [
 ('physical20',root/'local-evidence/triad-hf-high-snr-cost/physical0',evidence/'optimized-high0'),
 ('target8',root/'local-evidence/triad-hf-current-cost/target8',evidence/'optimized-weak0')]:
 a=read(before/'report.json');b=read(after/'report.json')
 x=read(before/'receiver/slot-0-receiver.json');y=read(after/'receiver/slot-0-receiver.json')
 fields=['bit','score','margin','bit_scores','operational']
 identical={k:x.get(k)==y.get(k) for k in fields}
 assert all(identical.values())
 pairs.append(dict(name=label,before_report_sha256=sha(before/'report.json'),after_report_sha256=sha(after/'report.json'),
  before_reception=a['reception'],after_reception=b['reception'],after_workspace=b['receiver_preparation'],
  decisions_exact=identical,score=y.get('score'),physical_null_qualified=False))
c=read(evidence/'sustained-v1/result/receiver-campaign.json')
summary=dict(schema='triad-realtime-optimization-summary-v1',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 cpu='AMD Ryzen 5 PRO 5650U, six physical cores',pairs=pairs,
 cadence={k:v for k,v in c.items()if k not in ['records','source_hashes']},
 evaluation=read(evidence/'sustained-v1/result/evaluation.json'),
 final_checks=dict(native_group=dict(passed=28,failed=0,wall_seconds=46.59),
  focused_python=dict(collected=95,passed=93,skipped=2,skip_reasons=['CUDA unavailable','Optional additional native capture not requested']),
  native_protocol=dict(passed=11,failed=0),
  final_native_identity=dict(all_eight_frozen_cases_accepted=True,baseline_bank_bitwise_equal=True)),
 final_native_sha256=sha(root/'build/dev-cli/triad_helper_export'),
 interpretation='Direct CPU measurements, not a calibrated future runtime bound. Fresh-window computational cadence, not contiguous-message/live qualification.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=set()
for folder in [evidence,root/'local-evidence/triad-native-render-bank']:
 files.update(p for p in folder.rglob('*')if p.is_file()and p.suffix in {'.json','.py','.log','.txt','.pstats'})
for parent in ['triad-hf-high-snr-cost','triad-hf-current-cost']:
 folder=root/'local-evidence'/parent
 for name in ['generation-protocol.json','measure.py']:
  if (folder/name).exists():files.add(folder/name)
 for case in (['physical0','public','signal0']if parent.endswith('high-snr-cost')else ['target8','public','signal0']):
  if (folder/case).exists():
   files.update(p for p in (folder/case).rglob('*.json') if p.is_file())
for name in c['source_hashes']:
 files.add(root/'tools'/name)
for rel in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines():
 if rel.startswith(('tools/','src/','include/','tests/')):files.add(root/rel)
for rel in ['tests/test_triad_template_bank.py','tests/test_triad_weak_throughput.py']:files.add(root/rel)
identities={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)}
(out/'archive-index.json').write_text(json.dumps(identities,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9)as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(root)))
 patch=subprocess.check_output(['git','diff','--','tools','src','include','tests'])
 info=tarfile.TarInfo('runtime-working-tree.patch');info.size=len(patch);t.addfile(info,io.BytesIO(patch))
for p in [out/'summary.json',out/'archive-index.json',out/'evidence.tar.gz']:
 print(p.name,p.stat().st_size,sha(p))
(out/'SHA256SUMS').write_text(''.join(f'{sha(out/name)}  {name}\n'for name in ['README.md','summary.json','archive-index.json','evidence.tar.gz']))

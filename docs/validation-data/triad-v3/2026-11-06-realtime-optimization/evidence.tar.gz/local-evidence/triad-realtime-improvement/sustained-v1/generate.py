import json,pathlib,resource,subprocess,time,hashlib
p=pathlib.Path(__file__).resolve().parent
prior=json.loads(pathlib.Path('local-evidence/triad-hf-high-snr-cost/generation-protocol.json').read_text())
base=prior['base']+['--power-reference','whole-active']
rows=[dict(name=f'bit-{i:02}',ordinal=i+1,seed=202611067001+i,bit=i%2,arrival=[-6.9,2.7,0.,6.9,-2.7,0.,2.7,-6.9][i]) for i in range(8)]
protocol=dict(base=base,rows=rows,source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),native_sha256=hashlib.sha256(pathlib.Path(base[0]).read_bytes()).hexdigest(),scope='Independent full sampled channel cases with changing public ordinal. Computational jobs will arrive at bit cadence; these captures are not one contiguous transmitted waveform. Frozen seeds before generation/scoring.')
(p/'generation-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
for row in rows:
 out=p/row['name'];cmd=base+['--epoch','1793850000','--symbol-ordinal',str(row['ordinal']),'--seed',str(row['seed']),'--bit',str(row['bit']),'--arrival-seconds',str(row['arrival']),'--output',str(out)]
 c=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter()
 with (p/(row['name']+'-generation.log')).open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 e=resource.getrusage(resource.RUSAGE_CHILDREN)
 (p/(row['name']+'-generation.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,cpu_seconds=e.ru_utime+e.ru_stime-c.ru_utime-c.ru_stime,wall_seconds=time.perf_counter()-w),indent=2)+'\n')
 print(row['name'],r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)

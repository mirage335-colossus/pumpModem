import pathlib,json,sys,hashlib
import numpy as np
sys.path.insert(0,'tools')
from triad_stream_slots import load_slots
from triad_stream_run import StreamSession,prepare_pcm,replay_pcm
p=pathlib.Path(__file__).resolve().parent
protocol=json.loads((p/'generation-protocol.json').read_text());cases=[];truth={}
for row in protocol['rows']:
 folder=p/row['name'];original=json.loads((folder/'manifest.json').read_text())
 bank=np.zeros(tuple(original['templates']['shape']),np.complex128)
 _,slots=load_slots(folder,templates=bank)
 destination=folder/'frontend';destination.mkdir()
 class Capture:
  def score(self,raw,valid):
   np.savez(folder/'scoring-input.npz',raw=raw,valid=valid)
   return dict(status='frontend-fixture-only',bit=None,score=0.,margin=0.,timing={},operational=dict(passes_conditional_bound=False))
 session=StreamSession(original,slots,destination,fixed_gain=.002,playback_offset_frames=48000,receiver_factory=lambda *unused:Capture())
 clean=folder/'clean.stereo.s16le';bridge=prepare_pcm(folder,original,clean,fixed_gain=.002)
 transport=replay_pcm(session,clean,preroll_frames=48000,postroll_frames=96000,chunk_frames=2400)
 result=session.finish(20)
 assert result['schedule']['drained'] and result['schedule']['records'][0]['status']=='scored'
 (destination/'receipt.json').write_text(json.dumps(dict(bridge=bridge,transport=transport,frontend=result['frontend'],scope='Frontend fixture preparation only, no receiver decision'),indent=2)+'\n')
 (folder/'adjusted-public-manifest.json').write_text(json.dumps(session.slots[0][0],indent=2)+'\n')
 argv=protocol['base']+['--epoch','1793850000','--symbol-ordinal',str(row['ordinal']),'--seed','202611067000','--bit','0','--arrival-seconds','0']
 cases.append(dict(name=row['name'],public_dir=str(folder),scoring_input=str(folder/'scoring-input.npz'),template_argv=argv))
 truth[row['name']]=row['bit'];print(row['name'],'prepared',flush=True)
 del session,bank,slots
(p/'evaluation.json').write_text(json.dumps(truth,indent=2)+'\n')
frozen=dict(schema='triad-weak-throughput-protocol-v1',cadence_seconds=11.6,workers=2,numerical_threads=2,queue_capacity=2,cases=cases,evaluation_file=str(p/'evaluation.json'),fixed_gain=.002,playback_offset_frames=48000,scope='Eight independent complete random-channel audio windows with fresh ordinal keys offered at nominalDATA bit cadence. Fullbank+perbitprep included; not one contiguouswaveform.')
(p/'protocol.json').write_text(json.dumps(frozen,indent=2)+'\n')

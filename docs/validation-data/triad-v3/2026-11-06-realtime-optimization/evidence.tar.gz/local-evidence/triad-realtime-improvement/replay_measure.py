#!/usr/bin/env python3
"""Current full-public-bank one-bit RX timing through the maintained audio DDC.

Prepared real PCM is replayed without real-time waiting. Source/channel and PCM
synthesis are outside RX. The authoritative reception timer spans frontend,
Helper, acquisition, candidate-dependent preparation/scoring and final drain.
No evaluator truth is opened. Parent evaluation follows the immutable report.
"""
from __future__ import annotations

import time
START_CPU, START_WALL = time.process_time(), time.perf_counter()
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'tools'))

# Configure numerical workers before importing their libraries. The parent may
# set these as well; explicit CLI selection is kept small and reproducible.
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--public', type=Path, required=True)
p.add_argument('--capture', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--replay-pcm', type=Path)
p.add_argument('--noise-inflation', type=float, default=1.)
p.add_argument('--threads', type=int, default=2, choices=(1,2,3,4,6))
p.add_argument('--fixed-gain', type=float, default=.002)
p.add_argument('--drain-timeout', type=float, default=180.)
a = p.parse_args()
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = str(a.threads)

import numpy as np
import torch
from triad_stream_run import StreamSession, digest, prepare_pcm, replay_pcm, write_json
from triad_stream_slots import load_slots
from triad_weak_receiver import WeakReceiver

IMPORT_TIMING = dict(cpu_seconds=time.process_time()-START_CPU,
                     wall_seconds=time.perf_counter()-START_WALL)


def timed(f):
    cpu, wall = time.process_time(), time.perf_counter()
    value = f()
    return value, dict(cpu_seconds=time.process_time()-cpu,
                       wall_seconds=time.perf_counter()-wall)


def child_cpu():
    r = resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime+r.ru_stime


def main():
    if not math.isfinite(a.fixed_gain) or a.fixed_gain <= 0:
        raise ValueError('finite positive fixed audio gain required')
    if not math.isfinite(a.drain_timeout) or not 0 < a.drain_timeout <= 180:
        raise ValueError('drain timeout must be within (0,180] seconds')
    a.output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(a.threads)
    torch.set_num_interop_threads(1)
    torch.set_float32_matmul_precision('highest')
    sources = [Path(__file__).resolve(), *(ROOT/'tools'/name for name in (
        'triad_stream_run.py', 'triad_stream_slots.py', 'triad_stream_frontend.py',
        'triad_stream_scheduler.py', 'triad_weak_receiver.py', 'triad_weak_helper.py',
        'triad_realtime_receiver.py', 'triad_realtime_fft.py', 'triad_segmented_fft.py',
        'triad_dynamic_joint.py', 'triad_dynamic_variants.py', 'triad_dynamic_scan.py',
        'triad_dynamic_frequency.py', 'triad_gaussian_prepared.py', 'triad_gaussian_state.py',
        'triad_helper_receiver.py', 'triad_operational_admission.py'))]
    source_hashes = {str(path.relative_to(ROOT)): digest(path) for path in sources}
    revision = subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip()
    invocation = dict(argv=sys.argv, source_revision=revision, source_hashes=source_hashes,
        native_exporter_sha256=digest(ROOT/'build/dev-cli/triad_helper_export'),
        numerical_threads=a.threads, libraries=dict(numpy=np.__version__, torch=torch.__version__),
        platform=platform.platform(), cpu_model=next((line.split(':',1)[1].strip()
            for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')), 'unknown'),
        load_average_before=os.getloadavg(), evaluator_truth_opened=False)
    write_json(a.output/'invocation.json', invocation)
    (original, slots), loading = timed(lambda: load_slots(a.public))
    if len(slots) != 1:
        raise ValueError('cost probe requires one complete public slot')
    # Read declared metadata only to reject accidental geometry/noise changes.
    # Never copy actual epoch, arrival, bit or channel trajectory into RX.
    capture = json.loads((a.capture/'manifest.json').read_text())
    if capture['sample_rate_hz'] != original['sample_rate_hz'] or capture['format'] != original['format']:
        raise ValueError('actual capture changes public waveform geometry')
    if capture['observation']['shape'] != original['observation']['shape']:
        raise ValueError('capture length differs; public window adaptation must be explicit')
    if capture['power']['complex_noise_variance'] != original['power']['complex_noise_variance']:
        raise ValueError('actual noise law differs from the prepared public receiver')
    for name in ('arrival_prior_seconds', 'capture_lead_seconds', 'capture_trail_seconds'):
        if capture['calendar'][name] != original['calendar'][name]:
            raise ValueError('capture changed public calendar '+name)
    actual_valid = np.memmap(a.capture/capture['validity']['file'], dtype='u1', mode='r',
                            shape=tuple(capture['validity']['shape']))
    if not np.all(actual_valid == 1):
        raise ValueError('actual capture has erasures; this audio replay route requires complete observed source input')
    c, w = time.process_time(), time.perf_counter()
    identities = dict(public_manifest=digest(a.public/'manifest.json'),
        public_templates=digest(a.public/original['templates']['file']),
        actual_capture_manifest=digest(a.capture/'manifest.json'),
        actual_observation=digest(a.capture/capture['observation']['file']),
        actual_validity=digest(a.capture/capture['validity']['file']))
    verification = dict(cpu_seconds=time.process_time()-c, wall_seconds=time.perf_counter()-w)
    clean = a.replay_pcm or a.output/'clean.stereo.s16le'
    if a.replay_pcm:
        bridge,bridge_timing=dict(mode='paired saved PCM',file=str(clean),sha256=digest(clean)),dict(cpu_seconds=0.,wall_seconds=0.)
    else:
        bridge, bridge_timing = timed(lambda: prepare_pcm(a.public, original, clean,
            fixed_gain=a.fixed_gain, observation_file=a.capture/capture['observation']['file']))
    write_json(a.output/'bridge.json', bridge)
    session = None
    failure = None
    stream = {}
    try:
        c, w = time.process_time(), time.perf_counter()
        session = StreamSession(original, slots, a.output/'receiver',
            fixed_gain=a.fixed_gain, analog_gain=1., playback_offset_frames=48000,
            noise_inflation=a.noise_inflation)
        receiver = WeakReceiver(*session.slots[0], noise_inflation=a.noise_inflation,
            admission_policy=session.slots[0][0].get('weak_admission_policy'))
        session.receiver_factory = lambda *unused: receiver
        preparation = dict(cpu_seconds=time.process_time()-c, wall_seconds=time.perf_counter()-w)
        c, w, children = time.process_time(), time.perf_counter(), child_cpu()
        try:
            transport = replay_pcm(session, clean, preroll_frames=48000,
                postroll_frames=96000, chunk_frames=2400)
        except Exception as error:
            failure = type(error).__name__+': '+str(error)
            transport = {}
        finally:
            stream = session.finish(a.drain_timeout)
        receive = dict(cpu_seconds=time.process_time()-c,
            child_cpu_seconds=child_cpu()-children, wall_seconds=time.perf_counter()-w)
    except BaseException:
        if session is not None:
            session.scheduler.close(0)
        raise
    original_slot = original['whole_bit_calendar']['slots'][0]
    fs = original['sample_rate_hz']
    denominators = dict(observed_audio=stream['capture']['seconds'],
        analysis_window=slots[0][0]['calendar']['capture_samples']/fs,
        transmitted_helper_and_data=(original_slot['helper_end_sample']-original_slot['helper_begin_sample'])/fs,
        active_data=original['power']['data_reference_active_seconds'])
    receive['duration_denominators_seconds'] = denominators
    receive['cpu_per_second_by_duration'] = {name: dict(
        prepared=(receive['cpu_seconds']+receive['child_cpu_seconds'])/duration,
        including_workspace=(receive['cpu_seconds']+receive['child_cpu_seconds']+preparation['cpu_seconds'])/duration,
        including_import_loading_workspace=(receive['cpu_seconds']+receive['child_cpu_seconds']+preparation['cpu_seconds']+
            loading['cpu_seconds']+IMPORT_TIMING['cpu_seconds'])/duration)
        for name,duration in denominators.items() if duration > 0}
    errors = [dict(index=row['index'], status=row['status'], error=row.get('error'))
        for row in stream['schedule']['records'] if row['status'] != 'scored']
    source_hashes_end = {str(path.relative_to(ROOT)): digest(path) for path in sources}
    records = stream['schedule']['records']
    fully_scored = (len(records) == len(slots) == 1 and failure is None and
                    all(row.get('result', {}).get('status') == 'scored' for row in records))
    result = dict(schema='triad-hf-current-full-audio-cost-v1', **invocation,
        public_power=original['power'], public_channel=original['channel'],
        public_calendar=original['calendar'], public_format=original['format'],
        imports=IMPORT_TIMING, public_loading=loading, input_identity_verification=verification,
        input_hashes=identities, receiver_preparation=preparation,
        pcm_generation=bridge_timing, reception=receive, stream=stream, transport=transport,
        peak_process_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        peak_rss_scope='Process high-water RSS including imports, fixture PCM generation and receiver; not a pure DSP workspace bound.',
        failure=failure, scheduler_errors=errors, source_hashes_end=source_hashes_end,
        source_identity_unchanged=source_hashes_end == source_hashes,
        measurement_execution_pass=not(failure or errors or not stream['schedule']['drained']),
        receiver_fully_scored=fully_scored,
        timing_scope='Reception includes audio DDC/ingestion, Helper acquisition, full-public timing/epoch/clock search, candidate-dependent refinement preparation/scoring and drain. Excludes simulated TX/channel generation, real-PCM synthesis and public workspace preparation. Nested process deltas overlap and must not be summed.',
        preparation_scope='Imports/loading/public FFT workspace separate; native raw keyed-template synthesis not included and must be charged from exporter measurements. Public cache belongs to declared key/epoch/calendar/noise/precision. Candidate-dependent preparation remains RX cost.',
        streaming_scope='One prepared public scheduled bit; no completed text/message adapter or physical end detection; unpaced replay wall time is compute latency, not observed hardware backlog.',
        message_completed=False, physical_null_qualified=False)
    write_json(a.output/'report.json', result)
    print(json.dumps(dict(status=('scored' if fully_scored else 'unresolved') if result['measurement_execution_pass'] else 'failed',
        preparation=preparation, reception=receive, bits=stream['pending_candidate_bits'],
        failures=errors or failure), allow_nan=False))
    return int(not result['measurement_execution_pass'] or not result['source_identity_unchanged'])


if __name__ == '__main__':
    raise SystemExit(main())

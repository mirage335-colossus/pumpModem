import hashlib,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path('tools').resolve()))
from triad_template_bank import generate_template_bank
root=Path('local-evidence/triad-realtime-improvement')
protocol=json.loads((root/'sustained-v1/protocol.json').read_text())
rows=[]
for case in protocol['cases']:
 manifest=json.loads((Path(case['public_dir'])/'manifest.json').read_text())
 bank,receipt=generate_template_bank(manifest,case['template_argv'])
 rows.append(dict(name=case['name'],receipt=receipt,bank_sha256=hashlib.sha256(bank.tobytes()).hexdigest()))
reference=json.loads((root/'template-helper-integration.json').read_text())
manifest=json.loads(Path('local-evidence/triad-hf-high-snr-cost/public/manifest.json').read_text())
bank,receipt=generate_template_bank(manifest,reference['native_argv'])
old=np.fromfile('local-evidence/triad-hf-high-snr-cost/public/templates.c128',dtype='<c16').reshape(bank.shape)
assert np.array_equal(bank,old)
report=dict(schema='triad-native-template-identity-followup-v1',all_eight_frozen_cases_accepted=True,
 baseline_bank_bitwise_equal=True,maximum_difference=float(np.max(np.abs(bank-old))),cases=rows,
 baseline_receipt=receipt,sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in ['tools/triad_template_bank.py','build/dev-cli/triad_helper_export']},
 scope='Validation and memory-guard follow-up only; numeric template and receiver paths unchanged after frozen cadence run. Timings here are not performance anchors.')
(root/'template-identity-followup.json').write_text(json.dumps(report,indent=2)+'\n')
print('All eight frozen case identities accepted; baseline bank bitwise equal.')

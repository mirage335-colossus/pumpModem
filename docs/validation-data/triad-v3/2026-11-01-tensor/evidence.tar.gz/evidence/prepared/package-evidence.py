"""Package sanitized scientific evidence; excludes cloud operational records."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('local-evidence/triad-tensor-20261101')
out=Path('docs/validation-data/triad-v3/2026-11-01-tensor')
items={}
def add(name,data,mode=0o644):items[name]=(data,mode)
def tree(folder,prefix):
 for p in sorted(folder.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   add(prefix+'/'+str(p.relative_to(folder)),p.read_bytes(),0o755 if p.suffix=='.py' else 0o644)
for name in ('screen','fusion','final','prepared','source-snapshots'):
 tree(root/name,name)
for name in ('micro.json','gpu-bundle.tar.gz','fusion-overlay.tar.gz','driver-failure.json','noise-transport-status.json','environment-technical.log','exporter-environment.json'):
 add(name,(root/name).read_bytes())
for p in sorted(root.glob('*check.log')):add('checks/'+p.name,p.read_bytes())
for p in sorted((root/'physical-holdout').rglob('*')):
 if p.is_file() and (p.name in ('manifest.json','campaign.json') or p.suffix in ('.stdout','.stderr')):
  add('physical-holdout/'+str(p.relative_to(root/'physical-holdout')),p.read_bytes())
for p in sorted((root/'replay-check/replay').rglob('*')):
 if p.is_file():add('replay-check/'+str(p.relative_to(root/'replay-check/replay')),p.read_bytes())
with tarfile.open(root/'final-runtime-evidence.tar.gz') as t:
 for m in t:
  if m.isfile() and m.name.startswith(('tools/','tests/')) and '__pycache__' not in Path(m.name).parts:
   add('source-final/'+m.name,t.extractfile(m).read(),m.mode)
add('exporter/triad_long',Path('build/dev/triad_long').read_bytes(),0o755)
for name in ('render.py','analyse-validation.py','replay-exports.py'):
 add('analysis/'+name,(out/name).read_bytes(),0o755)
manifest={'base_commit':'ebfe649c1f9c0a5bace48594c982111f64c28f41','scope':'Scientific source, scores, traces, manifests and exact exporter. Physical/holdout numeric arrays omitted; replay-exports verifies regenerated component bytes. Historical hour/flat numeric inputs included; their original exporter binding remains unavailable. No account operations metadata.', 'files':{k:{'bytes':len(v[0]),'sha256':hashlib.sha256(v[0]).hexdigest()} for k,v in sorted(items.items())}}
add('evidence-index.json',(json.dumps(manifest,indent=2)+'\n').encode())
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
 for name,(data,mode) in sorted(items.items()):
  info=tarfile.TarInfo('evidence/'+name);info.size=len(data);info.mode=mode;info.mtime=0;archive.addfile(info,io.BytesIO(data))
p=out/'evidence.tar.gz';print(json.dumps({'archive':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(items)},indent=2))

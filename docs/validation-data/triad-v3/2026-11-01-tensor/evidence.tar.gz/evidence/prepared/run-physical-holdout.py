"""Bounded paired scoring of frozen, independent sampled hour captures."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--max-seconds', type=int, default=900)
settings = parser.parse_args()
if not 1 <= settings.max_seconds <= 900:
    parser.error('maximum stage duration is900seconds')
deadline = time.monotonic()+settings.max_seconds
root = Path(__file__).resolve().parent
out = root/'results/physical-holdout'
out.mkdir(exist_ok=False)
paths = sorted((root/'inputs/physical-holdout').glob('path-*'))
assert len(paths) == 128
sources = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
           for p in (root/'tools').glob('triad*') if p.is_file()}
runs = []
policies = [('baseline',['--phase-implementation','graph-fp64']),
    ('bf16-split2',['--phase-implementation','tensor','--tensor-mode','bf16-split2','--tensor-block-columns','64','--tensor-fuse-advection']),
    ('tf32x3',['--phase-implementation','tensor','--tensor-mode','tf32x3','--tensor-block-columns','64','--tensor-fuse-advection'])]
for offset in range(0,128,16):
    for name,policy in policies:
        remaining = deadline-time.monotonic()
        if remaining <= 2:
            (out/'timeout.json').write_text(json.dumps({'status':'incomplete_deadline','next_offset':offset,'policy':name})+'\n')
            raise SystemExit(124)
        dest = out/f'{offset:03d}-{name}.json'
        command = [sys.executable,'tools/triad-path-study.py',*[str(p) for p in paths[offset:offset+16]],
            '--output',str(dest),'--cn0','-18','--seed','180361','--split','holdout',
            '--device','cuda:0','--precision','fp32','--methods','phase-frequency',
            '--actual-observation','--memory-limit-mib','16384']+policy
        start = time.perf_counter()
        timed_out = False
        with dest.with_suffix('.stdout').open('w') as stdout, dest.with_suffix('.stderr').open('w') as stderr:
            process = subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True)
            try:
                process.wait(timeout=min(120,remaining-1))
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid,signal.SIGTERM)
                try:process.wait(timeout=.5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid,signal.SIGKILL)
                    process.wait()
        runs.append(dict(offset=offset,policy=name,command=command,returncode=process.returncode,
            timed_out=timed_out,parent_wall_seconds=time.perf_counter()-start))
        (out/'driver.json').write_text(json.dumps(dict(source_sha256=sources,max_seconds=settings.max_seconds,runs=runs),indent=2)+'\n')
        print(json.dumps(runs[-1]),flush=True)
        if timed_out or process.returncode:
            raise SystemExit(124 if timed_out else process.returncode)

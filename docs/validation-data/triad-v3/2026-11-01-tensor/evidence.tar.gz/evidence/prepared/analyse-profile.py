import argparse,collections,gzip,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();rows={}
for policy in ('baseline','bf16-split2','tf32x3'):
 f=a.evidence/'final/results/validation-profile-v2'/('profile-'+policy)/'trace.json.gz'
 d=json.load(gzip.open(f,'rt'));events=[v for v in d['traceEvents'] if v.get('cat')=='kernel' and v.get('dur')]
 byname=collections.defaultdict(float)
 for v in events:byname[v['name']]+=v['dur']
 rows[policy]={'trace_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'kernel_count':len(events),'summed_kernel_ms':sum(byname.values())/1000,'first_to_last_kernel_span_ms':(max(v['ts']+v['dur'] for v in events)-min(v['ts'] for v in events))/1000,'kernel_ms':dict(sorted(((k,v/1000) for k,v in byname.items()),key=lambda x:-x[1]))}
result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Torch instrumented64update trace; summed durations are not hardware utilization counters or complete-job timings','policies':rows}
a.output.write_text(json.dumps(result,indent=2)+'\n')

from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parent
out=root/'results';out.mkdir(exist_ok=True)
rows=[]
def run(name, argv):
    start=time.perf_counter()
    with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:
        p=subprocess.run([sys.executable]+argv,cwd=root,stdout=so,stderr=se)
    rows.append(dict(name=name,command=[sys.executable]+argv,returncode=p.returncode,parent_wall_seconds=time.perf_counter()-start))
    (out/'screen-driver.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows[-1]),flush=True)
    return p.returncode
if run('native-tests',['tests/test_triad_phase_tensor.py','--device','cuda:0']): raise SystemExit(1)
run('micro',['tools/triad-tensor-diagnostics.py','--output',str(out/'micro.json'),'--repeats','30'])
for batch in [1,4,12]:
    base=['tools/triad-resident-campaign.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch',str(batch),'--batches','4','--seed','180301','--split','development','--cpu-threads','2']
    ref=out/f'b{batch}-graph-fp64.json'
    if run(f'b{batch}-graph-fp64',base+['--backend','graph-fp64','--output',str(ref)]): raise SystemExit(1)
    for mode in ['strict-padded','tf32','tf32x3','bf16','fp16-scaled','bf16-split2']:
        for columns in ([64,128,256] if batch==4 else [128]):
            name=f'b{batch}-{mode}-bc{columns}'
            run(name,base+['--backend','tensor','--tensor-mode',mode,'--tensor-block-columns',str(columns),'--output',str(out/(name+'.json')),'--compare-report',str(ref)])

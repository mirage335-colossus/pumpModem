from pathlib import Path
import hashlib,json,subprocess,sys
import torch
sys.path.insert(0,'tools')
from triad_phase_tensor import frequency_contract_advected
from triad_phase_optimized import OptimizedPhaseFrequencyLikelihood
from triad_phase_frequency import PhaseFrequencyModel
root=Path('results/isa-fused');root.mkdir(exist_ok=False)
torch.set_num_threads(2);torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False
receiver=OptimizedPhaseFrequencyLikelihood(12,2,2,PhaseFrequencyModel(phase_states=512,relative_phase_states=8,nominal_dt_seconds=4.),device='cuda',dtype=torch.float32,validate_inputs=False)
transition=receiver._transition(4.)
rows=[]
for mode in ['bf16-split2','tf32x3']:
 _,k=frequency_contract_advected(receiver.weights,transition,mode,block_columns=64,return_kernel=True)
 cube=root/(mode+'.cubin');cube.write_bytes(k.asm['cubin']);(root/(mode+'.ptx')).write_text(k.asm['ptx'])
 p=subprocess.run(['/usr/local/cuda/bin/nvdisasm',str(cube)],capture_output=True,text=True,timeout=30)
 (root/(mode+'.sass')).write_text(p.stdout);(root/(mode+'.stderr')).write_text(p.stderr)
 rows.append(dict(mode=mode,returncode=p.returncode,registers=k.n_regs,spills=k.n_spills,shared_bytes=k.metadata.shared,
   shape=list(receiver.weights.shape),tensor_instructions=sorted(set(line.strip() for line in p.stdout.splitlines() if 'HMMA' in line))[:8],
   hashes={suffix:hashlib.sha256((root/(mode+'.'+suffix)).read_bytes()).hexdigest() for suffix in ['cubin','ptx','sass']}))
(root/'summary.json').write_text(json.dumps(dict(rows=rows,source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path('tools/triad_phase_tensor.py')]}),indent=2)+'\n')

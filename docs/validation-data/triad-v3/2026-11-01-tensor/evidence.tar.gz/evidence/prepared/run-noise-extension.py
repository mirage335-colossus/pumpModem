from pathlib import Path
import json,subprocess,sys,time,hashlib,argparse,os,signal
parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['noise'],required=True);parser.add_argument('--max-seconds',type=int,default=900);args=parser.parse_args()
if not 1 <= args.max_seconds <= 900:parser.error('each stage must be bounded to at most900seconds')
deadline=time.monotonic()+args.max_seconds
root=Path(__file__).resolve().parent;out=root/('results/validation-noise-high-v2');out.mkdir(exist_ok=False);rows=[]
policies=[('baseline',['--backend','graph-fp64']),('bf16-split2',['--backend','tensor','--tensor-mode','bf16-split2','--tensor-block-columns','64','--tensor-fuse-advection']),('tf32x3',['--backend','tensor','--tensor-mode','tf32x3','--tensor-block-columns','64','--tensor-fuse-advection'])]
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()}
def run(name,arguments):
 start=time.perf_counter();cmd=[sys.executable]+arguments
 remaining=deadline-time.monotonic()
 if remaining<=2:
  (out/'timeout.json').write_text(json.dumps({'status':'incomplete_deadline','next_case':name,'budget_seconds':args.max_seconds})+'\n');raise SystemExit(124)
 with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:
  p=subprocess.Popen(cmd,cwd=root,stdout=so,stderr=se,start_new_session=True)
  try:p.wait(timeout=min(180,remaining-1))
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=.5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rows.append(dict(name=name,command=cmd,returncode=p.returncode,status='incomplete_timeout',parent_wall_seconds=time.perf_counter()-start));(out/'driver.json').write_text(json.dumps({'source_sha256':sources,'stage':args.stage,'max_seconds':args.max_seconds,'runs':rows},indent=2)+'\n');raise SystemExit(124)
 rows.append(dict(name=name,command=cmd,returncode=p.returncode,parent_wall_seconds=time.perf_counter()-start));(out/'driver.json').write_text(json.dumps({'source_sha256':sources,'stage':args.stage,'max_seconds':args.max_seconds,'runs':rows},indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for cn0 in ([-17,-16] if args.stage=="noise" else []):
 base=['tools/triad-resident-campaign.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch','12','--batches','32','--seed','180371','--split','holdout','--cn0',str(cn0),'--cpu-threads','2']
 reference=out/f'noise-cn{cn0}-baseline.json'
 for name,policy in policies:
  dest=out/f'noise-cn{cn0}-{name}.json';run(dest.stem,base+policy+['--output',str(dest)]+([] if name=='baseline' else ['--compare-report',str(reference)]))
for folder in (sorted((root/'inputs/physical').iterdir()) if args.stage=='physical' else []):
 if not (folder/'manifest.json').exists():continue
 base=['tools/triad-optimization-study.py',str(folder),'--device','cuda:0','--precision','fp32','--batch','1','--cn0','-18','--seed','180341','--split','development','--actual-observation','--output-scores','--memory-gib','12','--cpu-threads','2']
 reference=out/f'actual-{folder.name}-baseline.json'
 for name,policy in policies:
  dest=out/f'actual-{folder.name}-{name}.json';run(dest.stem,base+policy+['--output',str(dest)]+([] if name=='baseline' else ['--compare-report',str(reference)]))
for name,policy in (policies if args.stage=="profile" else []):
 run('profile-'+name,['tools/triad-profile.py','inputs/hour','--output',str(out/('profile-'+name)),'--batch','12','--blocks','64']+policy)
# Single-capture latency with new source, paired models and alternating fixed policies.
for rep in (range(3) if args.stage=="latency" else []):
 base=['tools/triad-resident-campaign.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch','1','--batches','1','--seed',str(180351+rep),'--split','holdout','--cpu-threads','2']
 reference=out/f'latency-r{rep}-baseline.json'
 for name,policy in policies:
  dest=out/f'latency-r{rep}-{name}.json';run(dest.stem,base+policy+['--output',str(dest)]+([] if name=='baseline' else ['--compare-report',str(reference)]))

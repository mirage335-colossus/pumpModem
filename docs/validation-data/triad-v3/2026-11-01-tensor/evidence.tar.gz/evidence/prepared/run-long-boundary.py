"""Bounded development precision x accumulation-length x weak-signal check."""
import argparse,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--max-seconds',type=int,default=450);settings=parser.parse_args()
if not 1<=settings.max_seconds<=450:parser.error('bounded to450seconds')
deadline=time.monotonic()+settings.max_seconds
root=Path(__file__).resolve().parent;out=root/'results/long-boundary';out.mkdir(exist_ok=False);runs=[]
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()}
policies=[('baseline',['--backend','graph-fp64']),('bf16-split2',['--backend','tensor','--tensor-mode','bf16-split2','--tensor-block-columns','64','--tensor-fuse-advection']),('tf32x3',['--backend','tensor','--tensor-mode','tf32x3','--tensor-block-columns','64','--tensor-fuse-advection'])]
for cn0 in [-28,-26]:
 reference=out/f'cn{cn0}-baseline.json'
 for name,policy in policies:
  remaining=deadline-time.monotonic()
  if remaining<=2:(out/'timeout.json').write_text(json.dumps({'status':'incomplete_deadline','cn0':cn0,'policy':name}));raise SystemExit(124)
  dest=out/f'cn{cn0}-{name}.json'
  command=[sys.executable,'tools/triad-optimization-study.py','inputs/physical/two-day-baseline','--output',str(dest),'--device','cuda:0','--precision','fp32','--batch','1','--cn0',str(cn0),'--seed','180381','--split','development','--output-scores','--memory-gib','12','--cpu-threads','2']+policy+([] if name=='baseline' else ['--compare-report',str(reference)])
  start=time.perf_counter();timed_out=False
  with dest.with_suffix('.stdout').open('w') as so,dest.with_suffix('.stderr').open('w') as se:
   p=subprocess.Popen(command,cwd=root,stdout=so,stderr=se,start_new_session=True)
   try:p.wait(timeout=min(180,remaining-1))
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=.5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  runs.append(dict(cn0=cn0,policy=name,command=command,returncode=p.returncode,timed_out=timed_out,parent_wall_seconds=time.perf_counter()-start));(out/'driver.json').write_text(json.dumps(dict(source_sha256=sources,max_seconds=settings.max_seconds,runs=runs),indent=2)+'\n');print(json.dumps(runs[-1]),flush=True)
  if timed_out or p.returncode:raise SystemExit(124 if timed_out else p.returncode)

from pathlib import Path
import json,subprocess,sys,time,hashlib
root=Path(__file__).resolve().parent;out=root/'results';runs=[]
commands=[('isa',[sys.executable,'inspect-isa.py']),('profile-baseline',[sys.executable,'tools/triad-profile.py','inputs/hour','--output','results/profile-baseline','--backend','graph-fp64','--batch','12','--blocks','64']),('ncu-counter-probe',['/opt/nvidia/nsight-compute/2025.1.1/ncu','--metrics','sm__throughput.avg.pct_of_peak_sustained_elapsed','--launch-count','1',sys.executable,'tools/triad-profile.py','inputs/hour','--output','results/ncu-probe','--backend','graph-fp64','--batch','1','--blocks','2','--no-torch-profile'])]
for name,cmd in commands:
 start=time.perf_counter()
 with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:
  p=subprocess.run(cmd,cwd=root,stdout=so,stderr=se)
 runs.append(dict(name=name,command=cmd,returncode=p.returncode,parent_wall_seconds=time.perf_counter()-start))
 (out/'attribution-driver.json').write_text(json.dumps(runs,indent=2)+'\n')
 print(json.dumps(runs[-1]),flush=True)

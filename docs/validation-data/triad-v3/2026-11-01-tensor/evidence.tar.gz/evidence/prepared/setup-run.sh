set -eu
cd /workspace/triad-tensor
tar -xzf gpu-bundle.tar.gz
python -m venv --system-site-packages /workspace/triad-env
/workspace/triad-env/bin/pip install scipy==1.16.3 > setup.log 2>&1
/workspace/triad-env/bin/python run-screen.py

from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parent;out=root/'results/fusion';out.mkdir(exist_ok=False);rows=[]
def run(name,args):
 start=time.perf_counter();cmd=[sys.executable]+args
 with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:p=subprocess.run(cmd,cwd=root,stdout=so,stderr=se)
 rows.append(dict(name=name,command=cmd,returncode=p.returncode,parent_wall_seconds=time.perf_counter()-start));(out/'driver.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 return p.returncode
if run('native-tests',['tests/test_triad_phase_tensor.py','--device','cuda:0']):raise SystemExit(1)
for rep in range(3):
 base=['tools/triad-resident-campaign.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch','12','--batches','8','--seed',str(180311+rep),'--split','development','--cpu-threads','2']
 ref=out/f'r{rep}-baseline.json'
 if run(f'r{rep}-baseline',base+['--backend','graph-fp64','--output',str(ref)]):raise SystemExit(1)
 policies=[('bf16-split2',64,False),('bf16-split2',64,True),('bf16-split2',128,True),('tf32x3',64,True)]
 if rep%2:policies.reverse()
 for mode,cols,fused in policies:
  name=f'r{rep}-{mode}-bc{cols}-f{int(fused)}';extra=['--tensor-fuse-advection'] if fused else[]
  if run(name,base+['--backend','tensor','--tensor-mode',mode,'--tensor-block-columns',str(cols),'--output',str(out/(name+'.json')),'--compare-report',str(ref)]+extra):raise SystemExit(1)
 if run(f'r{rep}-baseline-end',base+['--backend','graph-fp64','--output',str(out/f'r{rep}-baseline-end.json'),'--compare-report',str(ref)]):raise SystemExit(1)

from pathlib import Path
import json,hashlib,subprocess,sys
import torch
sys.path.insert(0,'tools')
from triad_phase_tensor import frequency_contract,TENSOR_MODES
root=Path('results/isa');root.mkdir(exist_ok=False)
torch.set_num_threads(2);torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False
x=torch.ones((1,2,24,43,512),device='cuda')/(24*43*512)
t=torch.eye(43,device='cuda')
rows=[]
for mode in TENSOR_MODES:
 _,k=frequency_contract(x,t,mode,block_columns=128,return_kernel=True)
 p=root/(mode+'.cubin');p.write_bytes(k.asm['cubin'])
 proc=subprocess.run(['/usr/local/cuda/bin/nvdisasm',str(p)],capture_output=True,text=True)
 (root/(mode+'.sass')).write_text(proc.stdout)
 (root/(mode+'.stderr')).write_text(proc.stderr)
 rows.append({'mode':mode,'returncode':proc.returncode,'cubin_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sass_sha256':hashlib.sha256(proc.stdout.encode()).hexdigest(),'n_regs':k.n_regs,'n_spills':k.n_spills,'shared':k.metadata.shared,'ptx_sha256':hashlib.sha256(k.asm['ptx'].encode()).hexdigest(),'sass_tensor_lines':sorted(set(line.strip() for line in proc.stdout.splitlines() if any(s in line for s in ['HMMA','MMA.','IMMA','BMMA'])))[:8]})
(root/'summary.json').write_text(json.dumps({'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path('tools/triad_phase_tensor.py')]},'rows':rows},indent=2)+'\n')

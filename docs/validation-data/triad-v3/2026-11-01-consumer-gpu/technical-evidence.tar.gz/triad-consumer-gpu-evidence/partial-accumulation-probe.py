#!/usr/bin/env python3
"""Bounded actual-CUDA FP8 partial-accumulation diagnostic.

All methods use identical actual packed operands. Kernels return unscaled
products; physical row scales are restored only in CPU FP64 diagnostics, so the
known libdevice.ldexp epilogue boundary cannot contaminate this comparison.
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib,platform,statistics,sys,time,traceback
import torch


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root',type=pathlib.Path,required=True)
    p.add_argument('--output',type=pathlib.Path,required=True)
    p.add_argument('--artifacts',type=pathlib.Path,required=True)
    p.add_argument('--repeats',type=int,default=7)
    p.add_argument('--max-seconds',type=float,default=240.)
    p.add_argument('--skip-large',action='store_true')
    p.add_argument('--seed',type=int,default=673901)
    args=p.parse_args()
    if args.repeats<1 or args.max_seconds<=0:p.error('positive repeats/budget required')
    if args.output.exists() or args.artifacts.exists():p.error('outputs must be new')
    sys.path.insert(0,str(args.source_root.resolve()/'tools'))
    from triad_tensor_native import TensorBackend,_native_ptx_evidence
    import triton
    import triton.language as tl
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction=False
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=False
    if hasattr(torch.backends.cuda.matmul,'allow_fp16_accumulation'):
        torch.backends.cuda.matmul.allow_fp16_accumulation=False
    torch.manual_seed(args.seed)
    args.artifacts.mkdir(parents=True)
    args.output.parent.mkdir(parents=True,exist_ok=True)

    @triton.jit
    def gemm(A,B,C,M:tl.constexpr,N:tl.constexpr,K:tl.constexpr,
             BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr,
             CHUNK:tl.constexpr,OUTER64:tl.constexpr,FLOAT8:tl.constexpr):
        mi=tl.program_id(0)*BM+tl.arange(0,BM)
        ni=tl.program_id(1)*BN+tl.arange(0,BN)
        kk=tl.arange(0,BK)
        if CHUNK==0:
            acc=tl.full((BM,BN),0.,tl.float32)
            for kblock in range(tl.cdiv(K,BK)):
                ki=kblock*BK+kk
                a=tl.load(A+mi[:,None]*K+ki[None,:],(mi[:,None]<M)&(ki[None,:]<K),other=0.)
                b=tl.load(B+ni[None,:]*K+ki[:,None],(ni[None,:]<N)&(ki[:,None]<K),other=0.)
                if FLOAT8:
                    acc=tl.dot(a,b,acc,max_num_imprecise_acc=0)
                else:
                    acc=tl.dot(a,b,acc)
            result=acc
        else:
            if OUTER64:
                total=tl.full((BM,BN),0.,tl.float64)
            else:
                total=tl.full((BM,BN),0.,tl.float32)
            for start in range(tl.cdiv(K,CHUNK)):
                partial=tl.full((BM,BN),0.,tl.float32)
                for inner in range(tl.cdiv(CHUNK,BK)):
                    ki=start*CHUNK+inner*BK+kk
                    a=tl.load(A+mi[:,None]*K+ki[None,:],(mi[:,None]<M)&(ki[None,:]<K),other=0.)
                    b=tl.load(B+ni[None,:]*K+ki[:,None],(ni[None,:]<N)&(ki[:,None]<K),other=0.)
                    if FLOAT8:
                        partial=tl.dot(a,b,partial,max_num_imprecise_acc=0)
                    else:
                        partial=tl.dot(a,b,partial)
                # Inline PTX creates an explicit ordinary add boundary that
                # cannot be folded back into the following tensor accumulator.
                if OUTER64:
                    total=tl.inline_asm_elementwise('add.rn.f64 $0, $1, $2;',
                        constraints='=d,d,d',args=[total,partial.to(tl.float64)],
                        dtype=tl.float64,is_pure=True,pack=1)
                else:
                    total=tl.inline_asm_elementwise('add.rn.f32 $0, $1, $2;',
                        constraints='=f,f,f',args=[total,partial],
                        dtype=tl.float32,is_pure=True,pack=1)
            result=total
        tl.store(C+mi[:,None]*N+ni[None,:],result,(mi[:,None]<M)&(ni[None,:]<N))

    started=time.perf_counter()
    result={'schema':'triad-consumer-partial-accumulation-probe-v1',
            'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
            'backend_source_sha256':hashlib.sha256((args.source_root/'tools/triad_tensor_native.py').read_bytes()).hexdigest(),
            'seed':args.seed,'repeats':args.repeats,'max_seconds':args.max_seconds,
            'environment':{'python':platform.python_version(),'torch':torch.__version__,'triton':triton.__version__,
                           'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(),
                           'compute_capability':list(torch.cuda.get_device_capability())},
            'scope':'Raw normalized products on identical actual packed CUDA operands. CPU FP64 decoded-product oracle and CPU FP64 power-of-two scale restoration. Synthetic diagnostic, no waveform/admission qualification. FP64 outer method writes FP64 output; other methods write FP32. Packing/conversion is outside cached-product timing and is reported separately.',
            'cases':[],'status':'running'}
    def save():
        result['elapsed_seconds']=time.perf_counter()-started
        args.output.write_text(json.dumps(result,indent=2)+'\n')
    methods=[('long-chain',0,False)]+[(f'partial-{k}-outer-{d}',k,d=='fp64') for k in (32,128,256) for d in ('fp32','fp64')]
    def timing(fn):
        values=[]
        for _ in range(args.repeats):
            begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            torch.cuda.synchronize();wall=time.perf_counter();begin.record();value=fn();end.record();end.synchronize()
            values.append({'cuda_ms':begin.elapsed_time(end),'wall_seconds':time.perf_counter()-wall})
        return {'samples':values,'median_cuda_ms':statistics.median(x['cuda_ms'] for x in values),
                'median_wall_seconds':statistics.median(x['wall_seconds'] for x in values)}
    def metric(actual,reference):
        error=actual-reference
        norm=float(torch.linalg.vector_norm(reference))
        return {'max_abs_error':float(error.abs().max()),'rms_abs_error':float(error.square().mean().sqrt()),
                'relative_l2_error':float(torch.linalg.vector_norm(error))/norm if norm else None,
                'finite':bool(torch.isfinite(actual).all()),'exact':bool(torch.equal(actual,reference))}
    budget=False
    formats=['fp16','bf16','fp8-e4m3','fp8-e5m2']
    for fmt in formats:
        cases=[('constructed-large-plus-small',1,1,4096)]
        if fmt.startswith('fp8'):
            cases.append(('random-small',8,8,4096))
            if not args.skip_large:cases.append(('random-timing',2048,1024,4096))
        for name,m,n,k in cases:
            if time.perf_counter()-started>args.max_seconds:budget=True;break
            if name.startswith('constructed'):
                a=torch.full((m,k),.125,device='cuda');b=torch.full((n,k),.125,device='cuda')
                a[:,1:32]=0.;b[:,1:32]=0.;a[:,0]=256.;b[:,0]=256.
            else:
                a=torch.randn((m,k),device='cuda');b=torch.randn((n,k),device='cuda')
            backend=TensorBackend(fmt,implementation='triton',pack_implementation='torch')
            prep=time.perf_counter();pa,pb=backend.pack_rows(a),backend.pack_rows(b);torch.cuda.synchronize()
            prep=time.perf_counter()-prep
            am,bn=min(m,8),min(n,8)
            ar=pa.data[:am].cpu().double();br=pb.data[:bn].cpu().double()
            ea,eb=pa.exponents[:am].cpu(),pb.exponents[:bn].cpu()
            reference=ar@br.T;scale=ea[:,None]+eb[None,:]
            physical_reference=torch.ldexp(reference,scale)
            case={'format':fmt,'case':name,'shape_mnk':[m,n,k],'oracle_rows':[am,bn],
                  'backend_contract':backend.contract_metadata(),'pack_seconds':prep,
                  'packed_bytes':[pa.nbytes,pb.nbytes],
                  'oracle_raw_fp64':reference.tolist() if m<=8 and n<=8 else None,
                  'oracle_physical_fp64':physical_reference.tolist() if m<=8 and n<=8 else None,
                  'constructed_expected_physical':65599.5 if name.startswith('constructed') else None,
                  'methods':[]}
            result['cases'].append(case);save()
            for method,chunk,outer64 in methods:
                if time.perf_counter()-started>args.max_seconds:budget=True;break
                entry={'method':method,'chunk_k':chunk,'outer_precision':'fp64' if outer64 else 'tensor-fp32' if chunk==0 else 'fp32',
                       'output_precision':'fp64' if outer64 else 'fp32','status':'running'}
                case['methods'].append(entry);save()
                try:
                    output=torch.empty((m,n),device='cuda',dtype=torch.float64 if outer64 else torch.float32)
                    bm=64 if m>=64 else 32;bn_=64 if n>=64 else 32
                    def call():
                        return gemm[(triton.cdiv(m,bm),triton.cdiv(n,bn_))](pa.data,pb.data,output,m,n,pa.padded_shape[1],bm,bn_,32,chunk,outer64,fmt.startswith('fp8'),num_warps=4,num_stages=2,enable_fp_fusion=False)
                    cold=time.perf_counter();kernel=call();torch.cuda.synchronize();cold=time.perf_counter()-cold
                    native=_native_ptx_evidence(kernel.asm['ptx'],fmt)
                    prefix=f'{fmt}-{name}-{method}'
                    artifacts={}
                    for ext in ['ptx','cubin']:
                        payload=kernel.asm[ext];payload=payload.encode() if isinstance(payload,str) else payload
                        path=args.artifacts/f'{prefix}.{ext}';path.write_bytes(payload)
                        artifacts[ext]={'name':path.name,'sha256':hashlib.sha256(payload).hexdigest()}
                    ptx=kernel.asm['ptx']
                    if chunk and not (('add.rn.f64' if outer64 else 'add.rn.f32') in ptx):
                        raise RuntimeError('compiled partial path lost explicit ordinary outer-add instruction')
                    for _ in range(2):call()
                    torch.cuda.synchronize()
                    timed=timing(call)
                    actual=output[:am,:bn].cpu().double()
                    physical=torch.ldexp(actual,scale)
                    entry.update(status='completed',cold_seconds=cold,timing=timed,
                        raw_product_vs_cpu_fp64=metric(actual,reference),
                        physical_product_vs_cpu_fp64=metric(physical,physical_reference),
                        actual_raw_values=actual.tolist() if m<=8 and n<=8 else None,
                        actual_physical_values=physical.tolist() if m<=8 and n<=8 else None,
                        instruction_evidence=native,explicit_outer_add_present=bool(chunk),artifacts=artifacts)
                except Exception as error:
                    entry.update(status='failed',error=repr(error),traceback=traceback.format_exc())
                save()
            if budget:break
            # Ordinary strict FP32 products on the same represented values,
            # not a higher-accuracy input representation, provide a control.
            aa,bb=pa.data.float(),pb.data.float()
            for _ in range(2):torch.mm(aa,bb.T)
            torch.cuda.synchronize()
            control=timing(lambda:torch.mm(aa,bb.T))
            actual=torch.mm(aa,bb.T)[:am,:bn].cpu().double()
            case['strict_fp32_represented_input_control']={'timing':control,'raw_product_vs_cpu_fp64':metric(actual,reference),
                'physical_product_vs_cpu_fp64':metric(torch.ldexp(actual,scale),physical_reference),
                'actual_physical_values':torch.ldexp(actual,scale).tolist() if m<=8 and n<=8 else None,
                'scope':'CUDA Torch strict FP32 multiplication; input conversion is cached outside timing; no tensor instruction claim'}
            save()
        if budget:break
    failures=sum(x['status']=='failed' for c in result['cases'] for x in c['methods'])
    result.update(status='budget_exhausted' if budget else 'complete_with_failures' if failures else 'complete',failed_methods=failures)
    save();print(json.dumps({'output':str(args.output),'status':result['status'],'cases':len(result['cases']),'failed_methods':failures,'elapsed_seconds':result['elapsed_seconds']},indent=2))
    return 2 if budget else 1 if failures else 0


if __name__=='__main__':raise SystemExit(main())

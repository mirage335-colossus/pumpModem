from __future__ import annotations
import hashlib,importlib.util,json,pathlib,sys,time
import numpy as np
import torch
repo=pathlib.Path('/home/user/___quick/p/_cur/dataPump/pumpModem')
sys.path.insert(0,str(repo/'tools'))
from triad_tensor_native import FORMATS,pack_rows_cpu,decode_rows
from triad_fp4_representation import RepresentationDiagnostic
from triad_exhaustive_correlation import ExhaustiveCorrelationBank
spec=importlib.util.spec_from_file_location('triad_review_campaign',repo/'tools/triad-fp4-campaign.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
torch.set_num_threads(2)
p=repo/'local-evidence/triad-fp4-20261101/inputs/boundary-cn-10-r0'
capture=runner.load_capture(p,trim_zero_suffix=True)
class CpuPacker:
    group_size=1
    def __init__(self,fmt):self.format=fmt;self.counts=np.zeros(3,dtype=np.int64);self.total_values=0
    def pack_rows(self,rows):
        packed=pack_rows_cpu(rows,self.format)
        self.counts+=packed.diagnostics[:,:3].sum(0).to(torch.int64).numpy()
        self.total_values+=rows.numel()
        return packed
    @staticmethod
    def decode_rows(packed,*,dtype=torch.float64):return decode_rows(packed,dtype=dtype)
    def describe(self):return {'format':self.format,'implementation':'explicit CPU representation oracle','native_arithmetic_executed':False}
def calculate(precision,backend=None):
    bank=ExhaustiveCorrelationBank(capture['basis'],64,[-.01,0,.01],[0,1,2],256,precision=precision,backend=backend)
    return torch.stack([x.r for x in bank.iter_blocks(capture['observation'],640.)]).numpy()
def metric(x,ref):
    e=x-ref
    return dict(relative_l2=float(np.linalg.norm(e.ravel())/np.linalg.norm(ref.ravel())),max_abs_error=float(np.max(np.abs(e))),rms_abs_error=float(np.sqrt(np.mean(np.abs(e)**2))))
started=time.perf_counter();original=calculate('fp64')
strict_staging=calculate('diagnostic-fp64',RepresentationDiagnostic(CpuPacker('fp16'),mode='strict',output_dtype='fp64'))
rows=[]
for fmt in FORMATS:
    for mode in ['template-only','observation-only','both']:
        packer=CpuPacker(fmt)
        projected=calculate('diagnostic-fp64',RepresentationDiagnostic(packer,mode=mode,output_dtype='fp64'))
        rows.append(dict(format=fmt,mode=mode,vs_fp32_staged_fp64_product=metric(projected,strict_staging),vs_original_complex128=metric(projected,original),packer_input_values=packer.total_values,packer_diagnostics_nonfinite_saturated_zeroed=packer.counts.tolist(),diagnostic_counts_scope='Both operands are packed in every diagnostic mode; only declared operands are used quantized.'))
result={'schema':'triad-consumer-cpu-representation-review-v1','scope':'One old development sampled capture. Complete declared 36-hypothesis bank/85 blocks; CPU FP64 represented-product correlations only. No tensor execution, downstream likelihood, decisions, reception, admission, throughput, or policy-selection claim. Not a new holdout.','input':str(p),'input_hashes':{q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in capture['paths']},'source_hashes':{q:hashlib.sha256((repo/'tools'/q).read_bytes()).hexdigest() for q in ['triad_tensor_native.py','triad_fp4_representation.py','triad_exhaustive_correlation.py']},'shape':list(original.shape),'fp32_staging_loss_vs_original_complex128':metric(strict_staging,original),'cases':rows,'wall_seconds':time.perf_counter()-started,'environment':{'torch':torch.__version__,'numpy':np.__version__,'torch_cpu_threads':torch.get_num_threads()}}
out=pathlib.Path('/tmp/triad-consumer-cpu-review/representation-screen.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(out),'shape':result['shape'],'staging':result['fp32_staging_loss_vs_original_complex128'],'both':[{k:x[k] for k in ['format','vs_fp32_staged_fp64_product','packer_diagnostics_nonfinite_saturated_zeroed']} for x in rows if x['mode']=='both'],'wall_seconds':result['wall_seconds']},indent=2))

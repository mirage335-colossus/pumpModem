import json,pathlib,sys,subprocess,hashlib
sys.path.insert(0,'tools')
from triad_duration_model import plan_from_native
from triad_continuous import NativeStream
p=pathlib.Path('local-evidence/triad-hf-high-snr-plan')
old=json.load(open('local-evidence/triad-hf-current-cost/one-bit-plan.json'))
args=old['native']['probe']['command'][1:-3]
commands=[]; plans={}
for bits,name in [(1,'one'),(22,'fox')]:
 cmd=[sys.executable,'tools/triad_weak_plan.py','--target-cn0','20.020599913279625','--message-bits',str(bits),'--report',str(p/(name+'-plan.json')),'--',*args]
 commands.append(cmd)
 r=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=30)
 (p/(name+'-stdout.json')).write_text(r.stdout)
 plans[name]=json.load(open(p/(name+'-plan.json')))
results=[]
native=plans['one']['native']['selected_duration_plan']
active=plans['one']['duration_plan']['active_seconds']
for bits in [1,22]:
 for retained in [1.,.5]:
  lo,hi=-20.,40.
  for _ in range(40):
   mid=(lo+hi)/2
   q=plan_from_native(native,mid,correct_probability=.9,message_bits=bits,retained_fraction=retained,manual_seconds=active)
   if q['selected']['meets_detection_allocation']:hi=mid
   else:lo=mid
  q=plan_from_native(native,hi,correct_probability=.9,message_bits=bits,retained_fraction=retained,manual_seconds=active)
  results.append(dict(message_bits=bits,retained_energy_fraction=retained,cn0_threshold_db_hz=hi,detection_allocation=q['per_bit_detection_miss_budget'],modeled_detection_lower_bound=q['selected']['modeled_detection_lower_bound'],model_qualified=q['model_qualified'],selected=q['selected'],unmodeled=q['unmodeled_selected_effects']))
streamargs=plans['one']['native']['selected_duration_probe']['command'][1:-1]+['--key-seed','2417','--epoch','1793850000']
s=NativeStream('build/dev-cli/triad_helper_export',streamargs,kind='emitted')
try:descriptor=s.descriptor;streamcmd=s.command
finally:s.close()
report=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),commands=commands,native_stream_command=streamcmd,descriptor=descriptor,active_seconds=active,one_air_seconds=descriptor['emitted_samples']/descriptor['sample_rate_hz'],fox_air_seconds_estimate=38+22*active+.4,thresholds=results,scope='Frozen shortest high-SNR bit duration; surrogate90%per-message allocation, not end-to-end qualified90%correct reception. Half missbudgetreservedforacquisitionandwrongbit.')
(p/'calculation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k in ['active_seconds','one_air_seconds','fox_air_seconds_estimate','thresholds']},indent=2))

import hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).resolve().parent
out=pathlib.Path('docs/validation-data/triad-v3/2026-11-06-hf-high-snr-cost');plan=p.parent/'triad-hf-high-snr-plan'
read=lambda f:json.loads(f.read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
g=read(p/'public-generation.json');n=read(p/'public-no-templates-generation.json');key_cpu=g['cpu_seconds']-n['cpu_seconds'];key_wall=g['wall_seconds']-n['wall_seconds']
rows=[]
for name in ['physical0','physical1','target16']:
 d=read(p/name/'report.json');r=read(p/name/'receiver/slot-0-receiver.json');assert d['measurement_execution_pass'] and d['source_identity_unchanged'];assert len(d['stream']['schedule']['records'])==1 and d['stream']['schedule']['records'][0]['status']=='scored'
 rx=d['reception']['cpu_seconds'];work=d['receiver_preparation'];imp=d['imports'];prep=key_cpu+work['cpu_seconds'];assert r['bit']==(1 if name=='physical1' else 0)
 row=dict(name=name,source_revision=d['source_revision'],rx_cpu_seconds=rx,rx_wall_seconds=d['reception']['wall_seconds'],workspace=work,imports=imp,
 fresh_preparation_cpu_estimate=prep+imp['cpu_seconds'],fresh_preparation_wall_estimate=key_wall+work['wall_seconds']+imp['wall_seconds'],
 continuous_data_cpu_per_second_estimate=(rx+prep)/11.6,one_bit_cold_cpu_per_air_second=(rx+prep+imp['cpu_seconds'])/50,
 fox_cpu_estimate=22*(rx+prep)+imp['cpu_seconds'],fox_cpu_per_air_second_estimate=(22*(rx+prep)+imp['cpu_seconds'])/293.6,
 scorer_elapsed_seconds=r['timing']['total']['wall_seconds'],peak_process_rss_kib=d.get('peak_process_rss_kib'),
 coarse_numeric_peak_bytes_estimate=r['coarse']['work']['estimated_peak_bytes'],scheduler_numeric_bound_bytes=d['stream']['schedule']['numeric_array_bound_bytes'],ring_capacity_samples=d['stream']['schedule']['ring_capacity_samples'],
 bit=r['bit'],conditional_pass=r['operational']['passes_conditional_bound'],log_e=r['operational']['log_e_lower_bound'],physical_null_qualified=False,
 helper_proposals=r['helper']['selected_count'],executed_coarse_cfo_points=r['coarse']['work']['frequency_points'],report_sha256=sha((p/name/'report.json').read_bytes()))
 if name=='target16':row['nominal_cn0_metrology']=d['metrology']['bands'][0]
 rows.append(row)
summary=dict(schema='triad-hf-high-snr-cost-v1',raw_keyed_template_cpu_estimate=key_cpu,raw_keyed_template_wall_estimate=key_wall,trials=rows,planning=read(plan/'calculation.json'),scope='Short high-SNR localCPU measurement; softwareaudio replay, no ADC/ASRC; no confidence qualified runtime or end-to-end success probability.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={f.name:f for f in p.iterdir() if f.suffix in ('.py','.json','.log') and f.is_file() and f.name not in ('archive-identities.json','package.log')}
for name in ['public','public-no-templates','signal0','signal1','physical0','physical1','target16']:
 files.update({str(f.relative_to(p)):f for f in (p/name).rglob('*.json')})
files.update({'planner/'+f.name:f for f in plan.iterdir() if f.is_file() and f.suffix in ('.py','.json')})
idx={name:dict(bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for name,f in files.items()}
(p/'archive-identities.json').write_text(json.dumps(idx,indent=2)+'\n')
files['archive-identities.json']=p/'archive-identities.json'
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for name,f in sorted(files.items()):t.add(f,arcname=name,recursive=False)
(out/'SHA256SUMS').write_text(''.join(f'{sha((out/name).read_bytes())}  {name}\n' for name in ['summary.json','evidence.tar.gz']))
with tarfile.open(out/'evidence.tar.gz') as t:
 assert len(t.getnames())==len(set(t.getnames()))
 for name,v in idx.items():
  data=t.extractfile(name).read();assert sha(data)==v['sha256'] and len(data)==v['bytes']
print('Verified',len(files),'members;', (out/'evidence.tar.gz').stat().st_size,'bytes')

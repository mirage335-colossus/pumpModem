import hashlib,json,pathlib,resource,sys,time
sys.path.insert(0,'tools')
from triad_cpu import resolve_cpu_budget,configure_numerical_threads
from triad_weak_throughput import _public_case,run_cadence
root=pathlib.Path('local-evidence/triad-cpu-default')
label=sys.argv[1];jobs=int(sys.argv[2]);thread=None if sys.argv[3]=='auto'else int(sys.argv[3])
allocation=resolve_cpu_budget(jobs=jobs,threads=thread)
allocation['runtime']=configure_numerical_threads(allocation)
import torch
torch.set_float32_matmul_precision('highest')
protocol=json.loads(pathlib.Path('local-evidence/triad-realtime-improvement/sustained-v1/protocol.json').read_text())
protocol['numerical_threads']=allocation['threads'];cases=protocol['cases'][:jobs]
output=root/label;output.mkdir()
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in pathlib.Path('tools').glob('triad_*.py')}
report=run_cadence(cases,lambda i,c:_public_case(c,protocol,output,i),cadence_seconds=11.6,
 workers=allocation['workers'],queue_capacity=2)
report.update(cpu_allocation=allocation,source_hashes=sources,source_identity_unchanged=all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h for p,h in sources.items()),
 peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 scope='Single saved high-SNR HF input for paired numerical/thread comparison; two-case default verifies bounded cadence. No new sensitivity or physical qualification.')
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(label,report['total_cpu_seconds'],report['wall_seconds'],report['completed'],report['errors'],flush=True)

from pathlib import Path
import hashlib,io,json,subprocess,tarfile
base=Path.cwd();local=base/'local-evidence/triad-cpu-default';out=base/'docs/validation-data/triad-v3/2026-11-06-cpu-default'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for name in ['explicit2','auto-single','auto-pipeline','final-auto-single','final-auto-pipeline']:
 r=json.loads((local/name/'report.json').read_text())
 fields=['cpu_allocation','source_identity_unchanged','total_cpu_seconds','wall_seconds','maximum_queue_wait_seconds','maximum_completion_delay_seconds','completed','overloads','errors','peak_rss_kib']
 row=dict(name=name,**{k:r[k]for k in fields})
 equal=[]
 for p in sorted((local/name).glob('bit-*-receiver.json')):
  x=json.loads(p.read_text());old=json.loads((base/'local-evidence/triad-realtime-improvement/sustained-v1/result'/p.name).read_text())
  equal.append(all(x[k]==old[k]for k in ['bit','score','margin','bit_scores','operational']))
 row['all_decisions_and_scores_exact']=all(equal);rows.append(row)
summary=dict(schema='triad-auto-cpu-followup-v1',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 trials=rows,final_checks=dict(passed=72,failed=0,test_wall_seconds=.508,real_worker_probe_passed=True),
 timing_scope='Fresh keyed bank, preparation and full saved-HF scoring; no ADC/DDC/TX simulation/imports. Individual measurements, not a confidence-qualified speedup.',
 transfer='Final broad default explicitly selects the same LA2 limit as final timing runs. Later worker initializer enforces the same observed limits; identities also include actual LA thread count. Other receiver families use full budget without this heuristic.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p for p in local.rglob('*')if p.is_file()and p.suffix in {'.json','.log','.py'}}
for line in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines():
 if line.startswith(('tools/','tests/','.github/')):files.add(base/line)
for name in ['tools/triad_cpu.py','tests/test_triad_cpu.py','tests/test_triad_receiver_cpu_limits.py','tools/build_capacity.py']:
 files.add(base/name)
(out/'archive-index.json').write_text(json.dumps({str(p.relative_to(base)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)},indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz')as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(base)))
 patch=subprocess.check_output(['git','diff']);info=tarfile.TarInfo('working-tree.patch');info.size=len(patch);t.addfile(info,io.BytesIO(patch))
(out/'SHA256SUMS').write_text(''.join(f'{sha(out/n)}  {n}\n'for n in ['README.md','summary.json','archive-index.json','evidence.tar.gz']))
print('archive bytes', (out/'evidence.tar.gz').stat().st_size)

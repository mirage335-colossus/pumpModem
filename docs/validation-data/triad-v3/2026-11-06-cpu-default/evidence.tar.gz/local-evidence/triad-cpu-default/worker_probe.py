import hashlib,json,pathlib,sys,threading
sys.path.insert(0,'tools')
import numpy as np,scipy.linalg,torch
from triad_cpu import resolve_cpu_budget,configure_numerical_threads,initialize_numerical_worker
from triad_stream_scheduler import StreamingWindowScheduler,WindowRequest
from threadpoolctl import threadpool_info
allocation=resolve_cpu_budget(jobs=2,linear_algebra_limit=2)
allocation['runtime']=configure_numerical_threads(allocation)
barrier=threading.Barrier(2)
def score(i,x,v):
 barrier.wait(timeout=5)
 info=threadpool_info()
 assert torch.get_num_threads()==allocation['linear_algebra_threads']
 assert all(p['num_threads']==allocation['linear_algebra_threads']for p in info)
 return dict(index=i,torch_threads=torch.get_num_threads(),pools=info)
s=StreamingWindowScheduler([WindowRequest('a',0,1),WindowRequest('b',1,1)],score,
 workers=2,worker_initializer=lambda:initialize_numerical_worker(allocation))
s.append(np.ones(2,np.complex64));r=s.close(10)
assert r['drained']and all(x['status']=='scored'for x in r['records'])
paths=['tools/triad_cpu.py','tools/triad_stream_scheduler.py','tools/triad_stream_run.py']
report=dict(allocation=allocation,scheduler=r,sources={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()for p in paths})
pathlib.Path('local-evidence/triad-cpu-default/worker-probe.json').write_text(json.dumps(report,indent=2)+'\n')
print('Both actual workers report configured LA limits; full FFT budget',allocation['total_thread_budget'])

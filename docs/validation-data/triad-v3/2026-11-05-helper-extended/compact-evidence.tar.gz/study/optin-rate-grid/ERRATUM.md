# Native planning sweep interpretation

Independent review recomputed the 68 cases and all classifications from the native JSON and command arrays. It confirmed 66 native commands plus two candidate sample rates beyond uint32, with unchanged source/binary identities. Total native command time is 4.4456 seconds; wrapper time is 4.4723 seconds.

The frozen protocol's description and `nominal_half_bandwidth_hz` field misname W=0.625*Rate*Added: W is the FULL three-carrier nominal bandwidth. The actual formula correctly uses W/2 to place the DATA center. This is a metadata-label defect; the commands, geometry and counts remain valid. The original frozen record is retained unchanged.

All clocks and centers here are generously raised candidates outside the user's fixed-IF catalog. A resource lower bound exceeding 2GiB excludes that candidate fixture, not every possible lower sampling rate. The raw17 and template26*16 bounds omit positive overhead; passing them does not prove actual allocation feasibility. Thirty-four candidates pass only the listed necessary screens, not source-power calibration, waveform export, receiver construction or reception.

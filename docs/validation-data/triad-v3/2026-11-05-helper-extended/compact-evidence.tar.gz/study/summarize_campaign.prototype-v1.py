#!/usr/bin/env python3
"""Independently recount a downloaded triad Helper campaign without scoring.

Each cohort remains its own inference unit. This intentionally does not create
an overall reception rate from cohorts that may share seed addresses.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from collections import Counter, defaultdict

from scipy.stats import beta


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def cp(successes: int, trials: int, confidence: float = .95) -> dict:
    if trials <= 0:
        return {"successes": successes, "trials": trials, "estimate": None,
                "one_sided_lower": 0., "one_sided_upper": 1.,
                "confidence": confidence, "qualified": False}
    lower = 0. if successes == 0 else float(beta.ppf(1-confidence, successes, trials-successes+1))
    upper = 1. if successes == trials else float(beta.ppf(confidence, successes+1, trials-successes))
    return {"successes": successes, "trials": trials, "estimate": successes/trials,
            "one_sided_lower": lower, "one_sided_upper": upper,
            "confidence": confidence, "qualified": True}


def arm_decision(variant: dict, arm: str) -> dict | None:
    d = variant.get("decisions", {}).get(arm)
    if isinstance(d, dict):
        return d
    # Compatibility with early compact records that retained final arms.
    if isinstance(variant.get(arm), dict) and "accepted" in variant[arm]:
        return variant[arm]
    return None


def manifest_for(cohort_dir: Path, trial_id: str) -> Path:
    direct = cohort_dir / trial_id / "manifest.json"
    if direct.is_file():
        return direct
    # Downloaded compact package layouts may place captures under a workspace root.
    matches = list(cohort_dir.glob(f"**/{trial_id}/manifest.json"))
    return matches[0] if len(matches) == 1 else direct


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as exc:
                raise ValueError(f"{path}:{line_no}: invalid JSON: {exc}") from exc
    return rows


def recapture_identity(cohort_dir: Path, row: dict) -> dict:
    trial = row.get("trial", {})
    path = manifest_for(cohort_dir, str(trial.get("id", "")))
    result = {"available": path.is_file(), "path": str(path),
              "recorded_manifest_sha256": row.get("manifest_sha256"),
              "observed_manifest_sha256": None, "manifest_hash_matches": None,
              "recorded_observation_sha256": row.get("input_sha256"),
              "recorded_validity_sha256": row.get("validity_sha256"),
              "recorded_truth_sha256": row.get("truth_sha256"),
              "observed_truth_sha256": None,
              "truth_hash_matches": None,
              "manifest_consistency": None}
    if not path.is_file():
        return result
    result["observed_manifest_sha256"] = sha256(path)
    result["manifest_hash_matches"] = (result["observed_manifest_sha256"] == row.get("manifest_sha256"))
    try:
        manifest = json.loads(path.read_text())
        erasure = json.loads((path.parent / "erasure.json").read_text())
        native = erasure.get("native", {})
        truth_path = path.parent / manifest.get("evaluator_truth_file", "evaluator-truth.json")
        result["observed_truth_sha256"] = sha256(truth_path) if truth_path.is_file() else None
        result["truth_hash_matches"] = (result["observed_truth_sha256"] == row.get("truth_sha256")
                                         if result["observed_truth_sha256"] else None)
        observation = manifest.get("observation", {})
        manifest_native_hash = observation.get("sha256") if isinstance(observation, dict) else None
        manifest_samples = (observation.get("sample_count") if isinstance(observation, dict) else None)
        if manifest_samples is None:
            manifest_samples = manifest.get("sample_count")
        result["manifest_consistency"] = {
            "recorded_input_matches_erasure": row.get("input_sha256") == erasure.get("observation_sha256"),
            "recorded_validity_matches_erasure": row.get("validity_sha256") == erasure.get("validity_sha256"),
            "native_original_observation_matches_manifest": (native.get("observation_sha256") == manifest_native_hash
                                                              if manifest_native_hash else None),
            "manifest_sample_count": manifest_samples,
        }
    except (OSError, ValueError, TypeError):
        result["manifest_consistency"] = "manifest present; paired erasure receipt unavailable or incompatible"
    return result


def work_and_assistance(rows: list[dict], lag: str, arm: str) -> dict:
    statuses, reasons = Counter(), Counter()
    wall_export, receiver, shared_prep, helper, receiver_prep = [], [], [], [], []
    samples, effective_groups = [], []
    for row in rows:
        variant = row.get("variants", {}).get(str(lag), {})
        a = variant.get("assistance", {})
        if a:
            statuses[a.get("status", "unknown")] += 1
            reasons[a.get("reason") or "none"] += 1
        wall_export.append(row.get("export_wall_seconds"))
        shared_prep.append(row.get("shared_preparation_seconds"))
        t = variant.get("timing", {})
        receiver_prep.append(t.get("public_preparation_seconds"))
        helper.append(t.get("helper_seconds"))
        out = arm_decision(variant, arm)
        # Trial-level receiver internals are recorded on the outcome object.
        rx = variant.get(arm, {})
        rt = rx.get("timing", {}) if isinstance(rx, dict) else {}
        receiver.append(rt.get("total_score_prepared_seconds", t.get("assisted_score_seconds")))
        w = rx.get("work", {}) if isinstance(rx, dict) else {}
        samples.append(w.get("samples"))
        effective_groups.append(w.get("effective_group_count"))

    def sums(xs):
        vals = [float(v) for v in xs if isinstance(v, (int, float)) and math.isfinite(v)]
        return {"count": len(vals), "sum_seconds": sum(vals) if vals else None,
                "median_seconds": sorted(vals)[len(vals)//2] if vals else None}

    return {"assistance_status_counts_including_calibration": dict(statuses),
            "assistance_reason_counts_including_calibration": dict(reasons),
            "native_export_wall": sums(wall_export),
            "shared_capture_preparation": sums(shared_prep),
            "public_receiver_preparation": sums(receiver_prep),
            "helper_assistance_processing": sums(helper),
            "receiver_score": sums(receiver),
            "receiver_sample_count_sum": sum(int(x) for x in samples if isinstance(x, (int,float))),
            "effective_group_count_sum": sum(int(x) for x in effective_groups if isinstance(x, (int,float))),
            "timing_semantics": "Export wall is native simulation plus serialization; receiver score is per-trial reported scorer time. Shared preprocessing is counted separately. These sums are per captured trial and do not include unrelated setup unless recorded by the campaign."}


def analyze_cohort(cohort_dir: Path, global_protocol: dict, arm: str) -> dict:
    cohort_id = cohort_dir.name
    protocol_path, summary_path, trials_path = (cohort_dir / x for x in
                                                ("protocol.json", "summary.json", "trials.jsonl"))
    status_summary = json.loads(summary_path.read_text()) if summary_path.is_file() else {}
    local_protocol = json.loads(protocol_path.read_text()) if protocol_path.is_file() else {}
    # A direct high-rate run is checked against the pre-frozen root protocol.
    global_case = next((c for c in global_protocol.get("cohorts", []) if c.get("id") == cohort_id), None)
    local_case = local_protocol.get("case") or local_protocol.get("cohort")
    case_match = None if global_case is None or local_case is None else global_case == local_case
    recorded_protocol_hash = status_summary.get("protocol_sha256")
    observed_protocol_hash = sha256(protocol_path) if protocol_path.is_file() else None
    rows = read_jsonl(trials_path) if trials_path.is_file() else []
    # Some outputs write wrapper variants, some write step -> variant.
    lags = sorted({str(k) for row in rows for k in row.get("variants", {})}, key=lambda x: int(x) if x.isdigit() else x)
    lag = lags[0] if lags else str((global_case or {}).get("lag_steps", [1])[0])
    by_phase = defaultdict(list)
    for row in rows:
        by_phase[row.get("trial", {}).get("phase", "unknown")].append(row)
    counts = Counter(correct_admitted=0, wrong_admitted=0, missed=0,
                      null_admitted=0, null_rejected=0)
    per_bit = {0: Counter(correct=0, wrong=0, missed=0, n=0),
               1: Counter(correct=0, wrong=0, missed=0, n=0)}
    identity = []
    helper_status = Counter()
    missing_decisions = 0
    for phase in ("signal", "null"):
        for row in by_phase[phase]:
            variant = row.get("variants", {}).get(lag, {})
            decision = arm_decision(variant, arm)
            if decision is None:
                missing_decisions += 1
                continue
            accepted = bool(decision.get("accepted"))
            if phase == "signal":
                trial = row.get("trial", {})
                bit = int(row.get("evaluator", {}).get("source_bit", trial.get("bit", -1)))
                if bit not in (0, 1):
                    missing_decisions += 1
                    continue
                selected = decision.get("bit")
                if accepted and selected not in (0, 1):
                    missing_decisions += 1
                    continue
                wrong = accepted and selected != bit
                correct = accepted and selected == bit
                counts["wrong_admitted" if wrong else "correct_admitted"] += int(wrong or correct)
                counts["missed"] += int(not accepted)
                per_bit[bit]["n"] += 1
                per_bit[bit]["wrong" if wrong else "correct" if correct else "missed"] += 1
            else:
                counts["null_admitted" if accepted else "null_rejected"] += 1
    for row in rows:
        aid = row.get("variants", {}).get(lag, {}).get("assistance", {})
        if aid:
            helper_status[(aid.get("status", "unknown"), aid.get("reason") or "none")] += 1
        identity.append(recapture_identity(cohort_dir, row))

    # Equal-bit mean lower bound. For all-success balanced n/n, independence
    # within both strata gives the exact AM-GM confidence bound p_low^n<=.05.
    n0, n1 = per_bit[0]["n"], per_bit[1]["n"]
    all_success = (n0 == n1 and n0 > 0 and per_bit[0]["correct"] == n0 and per_bit[1]["correct"] == n1)
    if all_success:
        equal_bit_lower = .05 ** (1 / (n0 + n1))
        uncertainty = {"method": "all-success balanced-strata AM-GM bound",
                       "confidence": .95, "equal_bit_mean_one_sided_lower": equal_bit_lower,
                       "per_bit_one_sided_lower": .05 ** (1 / n0),
                       "validity": "Conditional on independent representative trials within each bit stratum and frozen gate; pointwise per cohort."}
    else:
        # Bonferroni CP lower limits for the two independent strata; averaging
        # the lower limits is valid for the fixed equal-weight target.
        bounds = {}
        for bit in (0, 1):
            b = per_bit[bit]
            bounds[str(bit)] = cp(b["correct"], b["n"], .975)
        qualified = n0 > 0 and n1 > 0
        uncertainty = {"method": "average of two 97.5% one-sided Clopper-Pearson lower bounds (Bonferroni)",
                       "confidence": .95,
                       "equal_bit_mean_one_sided_lower": (bounds["0"]["one_sided_lower"] + bounds["1"]["one_sided_lower"]) / 2 if qualified else 0.,
                       "per_bit": bounds,
                       "validity": "Conditional on independent representative trials within each stratum and frozen gate; pointwise per cohort." if qualified else "At least one bit stratum has no scored signal; lower bound set to zero."}

    manifest_values = []
    for item in identity:
        if item["available"] and item["manifest_hash_matches"]:
            try:
                manifest_values.append(json.loads(Path(item["path"]).read_text()))
            except (OSError, ValueError):
                pass
    m = manifest_values[0] if manifest_values else {}
    fmt, physics = m.get("format", {}), m.get("physics", {})
    if not fmt and local_case:
        args = local_case.get("export_args", [])
        argmap = {args[i]: args[i+1] for i in range(len(args)-1) if args[i].startswith("--")}
        fmt = {"inner_rate_hz": float(argmap["--rate"]) if "--rate" in argmap else None,
               "added_symbols": int(argmap["--added-symbols"]) if "--added-symbols" in argmap else None,
               "requested_bit_seconds": local_case.get("seconds")}
        physics = {"data_cn0_db_hz": float(argmap["--cn0"]) if "--cn0" in argmap else None,
                   "data_if_hz": float(argmap["--data-if"]) if "--data-if" in argmap else None}
        planned_sample_rate = float(argmap["--sample-rate"]) if "--sample-rate" in argmap else None
    else:
        planned_sample_rate = None
    cost = [r.get("native_cost", {}) for r in rows]
    native_seconds = sum(float(c.get("wall_seconds", 0)) for c in cost if c)
    stored_counts = status_summary.get("outcomes", {}).get(lag, {}).get(arm, {}).get("counts", {})
    count_reconciliation = {
        "summary_counts": stored_counts,
        "recount_matches_summary": {
            "correct_admitted": stored_counts.get("correct_admitted") == counts["correct_admitted"] if stored_counts else None,
            "wrong_admitted": stored_counts.get("wrong_admitted") == counts["wrong_admitted"] if stored_counts else None,
            "missed": stored_counts.get("missed") == counts["missed"] if stored_counts else None,
            "false_admitted": stored_counts.get("false_admitted") == counts["null_admitted"] if stored_counts else None,
        }}
    manifest_sample_counts = [int(x["manifest_consistency"]["manifest_sample_count"])
                              for x in identity if isinstance(x.get("manifest_consistency"), dict)
                              and isinstance(x["manifest_consistency"].get("manifest_sample_count"), (int,float))]
    return {
        "cohort": cohort_id,
        "status": status_summary.get("status", "missing-summary"),
        "protocol_sha256_recorded": recorded_protocol_hash,
        "protocol_sha256_observed": observed_protocol_hash,
        "protocol_hash_matches_summary": None if not recorded_protocol_hash or not observed_protocol_hash else recorded_protocol_hash == observed_protocol_hash,
        "global_frozen_case_match": case_match,
        "planned_trials": {"calibration": (global_case or {}).get("calibration_count"),
                           "signal": (global_case or {}).get("signal_count"), "null": (global_case or {}).get("null_count")},
        "recounted_trials": {p: len(by_phase[p]) for p in ("calibration", "signal", "null")},
        "completed_scored_signal_trials": sum(per_bit[b]["n"] for b in (0,1)),
        "missing_signal_decisions": missing_decisions,
        "counts": dict(counts),
        "summary_count_reconciliation": count_reconciliation,
        "per_bit": {str(b): dict(per_bit[b]) for b in (0,1)},
        "uncertainty": uncertainty,
        "null_false_admission": cp(counts["null_admitted"], counts["null_admitted"] + counts["null_rejected"], .95),
        "null_decisions_missing": len(by_phase["null"]) - counts["null_admitted"] - counts["null_rejected"],
        "null_limit": "Finite pointwise per-capture null diagnostic conditional on frozen gate; no daily or repeated-attempt false-admission guarantee.",
        "helper_status_reason_counts": {f"{s}|{r}": n for (s,r),n in helper_status.items()},
        "configuration_from_verified_manifest": {"rate_hz": fmt.get("inner_rate_hz"),
            "added_symbols": fmt.get("added_symbols"), "sample_rate_hz": m.get("sample_rate_hz", planned_sample_rate),
            "actual_bit_seconds": fmt.get("bit_seconds"), "data_cn0_db_hz": physics.get("data_cn0_db_hz"),
            "requested_bit_seconds": fmt.get("requested_bit_seconds"),
            "data_if_hz": physics.get("data_if_hz"), "spread_preset": physics.get("spread_preset"),
            "selective_perturbation": physics.get("requested_selective_perturbation")},
        "manifest_validation": {"trial_manifests": len(identity),
            "available": sum(bool(x["available"]) for x in identity),
            "hash_matches": sum(x["manifest_hash_matches"] is True for x in identity),
            "hash_mismatches": sum(x["manifest_hash_matches"] is False for x in identity),
            "missing": sum(not x["available"] for x in identity),
            "receipt_consistency_checked": sum(isinstance(x.get("manifest_consistency"), dict) for x in identity),
            "truth_hash_matches": sum(x.get("truth_hash_matches") is True for x in identity),
            "truth_hash_mismatches": sum(x.get("truth_hash_matches") is False for x in identity)},
        "work": work_and_assistance(rows, lag, arm) | {
            "native_simulation_reported_wall_seconds_sum": native_seconds,
            "native_export_bytes_sum": sum(int(c.get("binary_export_bytes", 0)) for c in cost if c),
            "verified_manifest_sample_count_sum": sum(manifest_sample_counts) if manifest_sample_counts else None,
            "warning": "Receiver-work samples, native export wall time and manifest sample counts are distinct work measures."},
        "scope": "This named cohort only; no cross-cohort pooling. Paired seed reuse is reported at campaign scope."}


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True, type=Path, help="Downloaded campaign tree with cohort subdirectories")
    p.add_argument("--protocol", type=Path, help="Frozen root protocol; default local protocol-v1.json")
    p.add_argument("--output-dir", type=Path, help="Defaults to --root")
    p.add_argument("--arm", default="assisted")
    p.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument("--native-executable", type=Path, help="Optional exact local exporter for hash check")
    args = p.parse_args()
    protocol_path = args.protocol or Path(__file__).resolve().parent / "protocol-v1.json"
    protocol = json.loads(protocol_path.read_text())
    root_protocol_path = args.root / "protocol.json"
    root_protocol = json.loads(root_protocol_path.read_text()) if root_protocol_path.is_file() else {}
    if not (args.root / "protocol.json").is_file() and not protocol.get("cohorts"):
        p.error("need either downloaded root protocol.json or frozen --protocol with cohorts")
    case_ids = {c["id"] for c in protocol.get("cohorts", [])}
    dirs = sorted(d for d in args.root.iterdir() if d.is_dir() and (d / "trials.jsonl").is_file())
    if not dirs:
        p.error("no cohort trials.jsonl files found directly below --root")
    cases = {c["id"]: c for c in protocol.get("cohorts", [])}
    # If campaign root protocol holds runtime-mutated definitions, preserve and
    # check it against frozen protocol digest metadata when available.
    if root_protocol.get("cohorts"):
        for c in root_protocol["cohorts"]:
            if c.get("id") not in cases:
                cases[c["id"]] = c
    rows = [analyze_cohort(d, {"cohorts": list(cases.values())}, args.arm) for d in dirs]
    # Exact seed overlaps are diagnostic only; never pool such arms/cohorts.
    seed_groups: dict[int, list[str]] = defaultdict(list)
    for c in cases.values():
        seed_groups[int(c.get("seed_base", -1))].append(c["id"])
    overlaps = [names for names in seed_groups.values() if len(names) > 1]
    native_recorded = root_protocol.get("exporter_sha256")
    native_observed = sha256(args.native_executable) if args.native_executable and args.native_executable.is_file() else None
    source_validation = {}
    recorded_sources = root_protocol.get("source_hashes", {})
    for rel, expected in recorded_sources.items():
        path = args.repo / rel
        source_validation[rel] = {"expected": expected,
                                  "observed": sha256(path) if path.is_file() else None,
                                  "status": "match" if path.is_file() and sha256(path) == expected else "unavailable-or-mismatch"}
    output = {
        "schema": "triad-helper-independent-campaign-recount-v1",
        "input_root": str(args.root),
        "frozen_protocol": str(protocol_path),
        "frozen_protocol_sha256": sha256(protocol_path),
        "downloaded_protocol_sha256": sha256(root_protocol_path) if root_protocol_path.is_file() else None,
        "native_binary_validation": {"expected_sha256": native_recorded, "observed_sha256": native_observed,
                                     "status": "not-checked" if not args.native_executable else "match" if native_recorded == native_observed else "mismatch-or-unavailable"},
        "source_validation": source_validation,
        "seed_base_duplicate_groups": overlaps,
        "pooling_policy": "No campaign-wide reception pool or rate. Recount each cohort independently. Cohorts sharing seed_base are explicitly paired/dependent; even distinct seed bases do not establish exchangeability across configurations.",
        "cohorts": rows,
        "unresolved_or_unaccounted": {},
    }
    seen = {d.name for d in dirs}
    root_statuses = root_protocol.get("cohort_status", {})
    campaign_summary = args.root / "summary.json"
    if campaign_summary.is_file():
        try:
            root_statuses = json.loads(campaign_summary.read_text()).get("cohorts", root_statuses)
        except ValueError:
            pass
    for d in dirs:
        s_path = d / "summary.json"
        s = json.loads(s_path.read_text()) if s_path.is_file() else {}
        if s.get("status") != "completed":
            output["unresolved_or_unaccounted"][d.name] = s.get("status", "missing-summary")
    for cohort_id in cases:
        if cohort_id not in seen:
            prior = root_statuses.get(cohort_id) if isinstance(root_statuses, dict) else None
            output["unresolved_or_unaccounted"][cohort_id] = (prior.get("status", "not-run")
                if isinstance(prior, dict) else "planned-but-no-cohort-directory")
    outdir = args.output_dir or args.root
    outdir.mkdir(parents=True, exist_ok=True)
    json_path = outdir / "independent-recount.json"
    md_path = outdir / "independent-recount.md"
    json_path.write_text(json.dumps(output, indent=2, sort_keys=True, allow_nan=False) + "\n")
    lines = ["# Independent Helper campaign recount", "",
             f"Input: `{args.root}`", "",
             "Each row is one cohort; counts are independently reconstructed from `trials.jsonl`. No campaign-wide percentage is pooled.", "",
             "| Cohort | Status | rate Hz | Added | C/N₀ dB-Hz | actual / requested bit s | Correct / wrong / miss | null false / N | equal-bit 95% lower | Helper statuses / reasons | samples | sim wall s | score s | manifests verified / total |",
             "|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|"]
    for c in rows:
        cfg, counts, w = c["configuration_from_verified_manifest"], c["counts"], c["work"]
        sc = w["receiver_sample_count_sum"]
        score = w["receiver_score"]["sum_seconds"]
        manifests = c["manifest_validation"]
        bit_duration = f"{cfg.get('actual_bit_seconds')} / {cfg.get('requested_bit_seconds')}"
        lines.append(f"| {c['cohort']} | {c['status']} | {cfg.get('rate_hz')} | {cfg.get('added_symbols')} | {cfg.get('data_cn0_db_hz')} | {bit_duration} | {counts['correct_admitted']} / {counts['wrong_admitted']} / {counts['missed']} | {counts['null_admitted']} / {c['recounted_trials']['null']} | {c['uncertainty']['equal_bit_mean_one_sided_lower']:.4f} | `{c['helper_status_reason_counts']}` | {sc} | {w['native_simulation_reported_wall_seconds_sum']:.3f} | {score} | {manifests['hash_matches']} / {manifests['available']} of {manifests['trial_manifests']} |")
    lines += ["", "## Limits", "",
              "Null upper limits are finite per-cohort pointwise intervals under the frozen gate; they do not bound future or daily false admissions. Missing trials, score failures, timeout and interrupted cohorts remain unresolved, not misses or passes. All admissions, misses, and interval claims remain per named configuration. Shared seed bases are listed in the JSON as dependent comparisons.", "",
              f"Recorded native exporter hash: `{native_recorded}`; observed hash: `{native_observed}`. Source and manifest mismatches/unavailability are retained per path in the JSON.", ""]
    md_path.write_text("\n".join(lines))
    print(f"wrote {json_path}\nwrote {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

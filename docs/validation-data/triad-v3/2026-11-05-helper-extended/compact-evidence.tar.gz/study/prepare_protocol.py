#!/usr/bin/env python3
"""Freeze independent Helper high-rate/spreading qualification inputs.

This is an occasional sampled campaign, never a routine CI test. A finite
empirical rank gate does not qualify an operational daily false-admission rate.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
EXE = ROOT / 'build/dev-cli/triad_helper_export'

def case(name, *, rate, added=1, fs=48000, data_if=3600, rf=30e6,
         cn0=8, scenario='hf', spread='hf-worst', margin=3, fhss=False,
         seconds=8, seed=8200000, signals=32, nulls=16, erasure='none',
         burst_wait=0, base='gpsdo-ocxo', shift='gpsdo-ocxo', clock=0,
         scales=1):
    args = ['--case', scenario, '--rate', str(rate), '--added-symbols', str(added),
            '--sample-rate', str(fs), '--data-if', str(data_if), '--rf-hz', str(rf),
            '--cn0', str(cn0), '--base-oscillator', base, '--shift-oscillator', shift,
            '--spread-preset', spread, '--margin', str(margin),
            '--selective-perturbation', 'off' if spread == 'none' else 'each-65',
            '--timing-policy', 'bounded', '--fhss', 'on' if fhss else 'off',
            '--key-seed', '82001', '--burst-wait-tiles', str(burst_wait)]
    return dict(id=name, export_args=args, seconds=seconds, seed_base=seed,
                calibration_count=19, signal_count=signals, null_count=nulls,
                lag_steps=[1], arms=['assisted'], frontend_profile='rate-aware',
                frequency_batch_size=8, max_cached_hypotheses=13,
                memory_limit_bytes=64*1024**3, erasure=erasure,
                clock_step_ppm=clock, doppler_scale_count=scales)

cases = [
    case('rate3600-hf8-each65', rate=3600, seed=8200000),
    case('rate12000-hf8-each65', rate=12000, data_if=7800, seed=8201000),
    case('rate18000-hf8-each65', rate=18000, fs=96000, data_if=10800, seed=8202000),
    case('rate24000-hf8-each65', rate=24000, fs=96000, data_if=13800, seed=8203000),
    case('rate24000-flat8-paired', rate=24000, fs=96000, data_if=13800,
         spread='none', seed=8203000),
    case('rate3600-eme10-fhss', rate=3600, rf=5.8e9, scenario='eme',
         cn0=10.020599913279625, spread='eme-focused', margin=1, fhss=True,
         seed=8205000),
    case('added1000-rate1-minus10', rate=1, added=1000, fs=6000, data_if=1725,
         rf=500000, cn0=-10, spread='sub9-moderate', margin=1,
         seed=8206000),
    case('added100-rate10-minus10', rate=10, added=100, fs=6000, data_if=1725,
         rf=500000, cn0=-10, spread='sub9-moderate', margin=1, seconds=384,
         seed=8207000),
    case('added1000-rate1-minus16-paired', rate=1, added=1000, fs=6000, data_if=1725,
         rf=500000, cn0=-16, spread='sub9-moderate', margin=1,
         seed=8206000),
    case('rate3600-free-ic7100-hf8', rate=3600, margin=1, base='crystal',
         shift='ic-7100', clock=25, scales=3, seed=8209000, signals=8, nulls=8),
    case('rate3600-eme10-fhss-waits3', rate=3600, rf=5.8e9, scenario='eme',
         cn0=10.020599913279625, spread='eme-focused', margin=1, fhss=True,
         seconds=24, burst_wait=3, seed=8210000, signals=8, nulls=8),
    case('rate3600-eme10-fhss-adcgaps', rate=3600, rf=5.8e9, scenario='eme',
         cn0=10.020599913279625, spread='eme-focused', margin=1, fhss=True,
         seed=8205000, erasure='every-dwell-10ms', signals=32, nulls=16),
]

def main():
    protocol = dict(schema='triad-helper-extended-protocol-v1', alpha=.05,
        purpose='New high-rate and maximal-spreading sampled scope, with paired mismatch/marginal controls.',
        frozen_before_receiver_outcomes=True,
        preparation_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        comparison_scope='Paired same-seed arms are dependent; independent seed roots separate other cohorts. Do not pool.',
        qualification_limits=['19 calibration samples only support a minimum empirical p-value .05.',
            '32 balanced signals can establish a pointwise equal-bit mean lower bound above90% only if all succeed; not99%.',
            'Null controls are finite diagnostics, not daily false-admission qualification.',
            'Whole-bit burst, physicalRFretune, arbitrary renewing fading and multidayHelper are outside these cohorts.'],
        cohorts=cases)
    (OUT/'protocol-v1.json').write_text(json.dumps(protocol,indent=2)+'\n')
    with (OUT/'native-preflight-v1.jsonl').open('w') as stream:
        for c in cases:
            cmd=[str(EXE),*c['export_args'],'--seconds',str(c['seconds']),'--plan-only']
            start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True,timeout=20)
            row=dict(id=c['id'],command=cmd,returncode=r.returncode,wall_seconds=time.monotonic()-start,
                     stderr=r.stderr,stdout=r.stdout)
            stream.write(json.dumps(row)+'\n');stream.flush()
            p=json.loads(r.stdout) if r.returncode==0 else {}
            print(c['id'],r.returncode,p.get('geometry_feasible'),p.get('helper_placement',{}).get('feasible_at_requested_if'),flush=True)

if __name__=='__main__':main()

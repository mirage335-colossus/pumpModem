"""Independent continuous analytic fixture, not encrypted-link qualification."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
from triad_helper_receiver import HelperDataReceiver

torch.set_num_threads(1)
fs, out, n = 48000, 16000, 4800
T = (n - 1) / fs

def pattern(u, bit):
    good = (u >= 0) & (u <= T)
    y = np.zeros(len(u), complex)
    q = u[good]
    y[good] = (np.sin(np.pi*q/T)**2 * (1 + .2*np.cos(2*np.pi*137*q)) *
               np.exp(2j*np.pi*(-4500 if bit == 0 else 5100)*q))
    return y

p = np.asarray([[pattern(np.arange(n)/fs, b) for b in (0, 1)]])
opts = dict(source_offset_seconds=.2, capture_lead_seconds=.1, capture_rows=24000,
    arrival_bounds_seconds=(0., .002), delay_seconds=.0005, doppler_hz=30.,
    source_half_bandwidth_hz=5500., reference_variance=.0001,
    frequency_offsets=(-8., 0., 8.), sample_rate=fs, output_sample_rate=out,
    frontend_profile='rate-aware', fft_backend='batched', precision='fp64',
    memory_limit_bytes=256*1024**2, clock_ppm_values=(-300., 0., 300.),
    doppler_scale_values=(.99985, 1., 1.00015))
rx = HelperDataReceiver(p, (0,), **opts)
t = np.arange(rx.capture_rows)/fs
res = []
for bit in (0, 1):
    a, r, delay = 1.0003, 1.00015, .0005
    arrival = .0009375*r
    u = a*(t-(.1+arrival)/r)-.2
    y = ((1.2+.3j)*pattern(u, bit) + (.6-.4j)*pattern(u-a*delay/r, bit) *
         np.exp(2j*np.pi*30*r*(t-.1/r)))
    y *= np.exp(2j*np.pi*8*(t-.1/r))
    rng = np.random.default_rng(934+bit)
    y += .01*(rng.normal(size=len(t))+1j*rng.normal(size=len(t)))
    z = rx.score(y)
    assert z['bit'] == bit
    best = z['best_group_public_parameters']
    assert best['clock_ppm'] == 300 and best['doppler_scale'] == 1.00015
    assert best['frequency_hz'] == 8 and best['arrival_seconds'] == .0009375
    res.append(dict(bit=bit, best=best, bit_log_likelihoods=z['bit_log_likelihoods']))
record = dict(scope=__doc__, options=opts, source_sha256=hashlib.sha256(
    (ROOT/'tools/triad_helper_receiver.py').read_bytes()).hexdigest(), cases=res)
Path(__file__).with_suffix('.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))

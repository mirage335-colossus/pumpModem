# Independent Helper campaign recount

Input: `local-evidence/triad-helper-extended/remote/extended-main-v2`

Each row is one cohort; counts are independently reconstructed from `trials.jsonl`. No campaign-wide percentage is pooled.

| Cohort | Status | rate Hz | Added | C/N₀ dB-Hz | actual / requested bit s | Correct / wrong / miss | null false / N | equal-bit 95% lower | Helper statuses / reasons | samples | sim wall s | score s | manifests verified / total |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|
| rate3600-hf8-each65 | completed | 3600.0 | 1 | 8.0 | None / 8 | 32 / 0 / 0 | 1 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 2613335 | 349.481 | 5.96933752996847 | 0 / 0 of 67 |

## Limits

Null upper limits are finite per-cohort pointwise intervals under the frozen gate; they do not bound future or daily false admissions. Missing trials, score failures, timeout and interrupted cohorts remain unresolved, not misses or passes. All admissions, misses, and interval claims remain per named configuration. Shared seed bases are listed in the JSON as dependent comparisons.

Recorded native exporter hash: `None`; observed hash: `None`. Source and manifest mismatches/unavailability are retained per path in the JSON.

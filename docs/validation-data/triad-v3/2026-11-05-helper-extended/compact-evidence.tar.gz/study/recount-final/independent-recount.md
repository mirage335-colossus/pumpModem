# Independent Helper campaign recount

Input: `local-evidence/triad-helper-extended/remote/extended-main-v2`

Each row is one cohort; counts are independently reconstructed from `trials.jsonl`. No campaign-wide percentage is pooled.

| Cohort | Status | rate Hz | Added | C/N₀ dB-Hz | actual / requested bit s | Correct / wrong / miss | null false / N | equal-bit 95% lower | Helper statuses / reasons | samples | sim wall s | score s | manifests verified / total |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|
| added100-rate10-minus10 | completed | 10 | 100 | -10 | 388.00000000000006 / 384 | 28 / 0 / 4 | 0 / 16 | 0.6165 | `{'fallback|insufficient_presence_diagnostic': 20, 'fallback|flat_profile': 47}` | 26061258 | 522.713 | 36.95469383546151 | 67 / 67 of 67 |
| added1000-rate1-minus10 | completed | 1 | 1000 | -10 | 384.40000000000003 / 8 | 27 / 0 / 5 | 1 / 16 | 0.5800 | `{'fallback|flat_profile': 42, 'fallback|insufficient_presence_diagnostic': 25}` | 25820058 | 514.193 | 37.062811512034386 | 67 / 67 of 67 |
| added1000-rate1-minus16-paired | completed | 1 | 1000 | -16 | 384.40000000000003 / 8 | 5 / 0 / 27 | 1 / 16 | 0.0280 | `{'fallback|flat_profile': 22, 'fallback|insufficient_presence_diagnostic': 45}` | 25820058 | 513.781 | 36.60543871927075 | 67 / 67 of 67 |
| rate12000-hf8-each65 | completed | 12000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 3 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 7831898 | 352.524 | 14.85925722005777 | 67 / 67 of 67 |
| rate18000-hf8-each65 | completed | 18000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 1 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 10440610 | 698.275 | 21.532658459385857 | 67 / 67 of 67 |
| rate24000-flat8-paired | completed | 24000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 2 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 12474462 | 697.501 | 25.44832251803018 | 67 / 67 of 67 |
| rate24000-hf8-each65 | completed | 24000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 0 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 15659709 | 748.450 | 33.92562229861505 | 67 / 67 of 67 |
| rate3600-eme10-fhss | completed | 3600 | 1 | 10.020599913279625 | 8.8 / 8 | 32 / 0 / 0 | 0 / 16 | 0.9106 | `{'narrowed|conditional_model_checks_passed': 67}` | 1953385 | 359.481 | 4.323986343108118 | 67 / 67 of 67 |
| rate3600-eme10-fhss-adcgaps | completed | 3600 | 1 | 10.020599913279625 | 8.8 / 8 | 32 / 0 / 0 | 0 / 16 | 0.9106 | `{'narrowed|conditional_model_checks_passed': 67}` | 1953385 | 358.116 | 4.236961689544842 | 67 / 67 of 67 |
| rate3600-eme10-fhss-waits3 | completed | 3600 | 1 | 10.020599913279625 | 79.2 / 24 | 8 / 0 / 0 | 0 / 8 | 0.6877 | `{'narrowed|conditional_model_checks_passed': 35}` | 8412425 | 489.590 | 20.2229587349575 | 35 / 35 of 35 |
| rate3600-free-ic7100-hf8 | completed | 3600 | 1 | 8 | 8.8 / 8 | 8 / 0 / 0 | 0 / 8 | 0.6877 | `{'narrowed|conditional_joint_clock_model_checks_passed': 35}` | 1090040 | 182.618 | 442.4875649770256 | 35 / 35 of 35 |
| rate3600-hf8-each65 | completed | 3600 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 1 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 2613335 | 349.481 | 5.96933752996847 | 67 / 67 of 67 |

## Limits

Null upper limits are finite per-cohort pointwise intervals under the frozen gate; they do not bound future or daily false admissions. Missing trials, score failures, timeout and interrupted cohorts remain unresolved, not misses or passes. All admissions, misses, and interval claims remain per named configuration. Shared seed bases are listed in the JSON as dependent comparisons.

Recorded native exporter hash: `39a70e311f71b4a9e63fcf0c9beaae3123e834d560ccffd263094f2236875210`; observed hash: `39a70e311f71b4a9e63fcf0c9beaae3123e834d560ccffd263094f2236875210`. Source and manifest mismatches/unavailability are retained per path in the JSON.

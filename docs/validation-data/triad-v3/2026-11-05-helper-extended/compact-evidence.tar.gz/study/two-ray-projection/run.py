#!/usr/bin/env python3
"""Frozen, waveform-known raw two-ray projection; no practical receiver run."""
import argparse, hashlib, json, math, os
from pathlib import Path
import signal, subprocess, sys, time, traceback
REPO = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).with_name('frozen-plan.json')

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_text())
def write(path, value): Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
def check(ok, reason):
    if not ok: raise ValueError(reason)

def frozen(a, p):
    check(digest(__file__)==p['script_sha256'], 'projection script identity changed')
    check(digest(a.exporter)==p['exporter_sha256'], 'native binary differs from oracle')
    for name, expected in p['source_hashes'].items():
        check(digest(REPO/name)==expected, 'source changed: '+name)

def worker(a, p):
    stage='imports'; started=time.perf_counter()
    try:
        for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[k]='2'
        import numpy as np
        sys.path.insert(0,str(REPO/'tools'))
        from triad_helper_receiver import clock_warp, fractional_delay
        from triad_fft_acquire import phase
        frozen(a,p); stage='existing-template'
        folder=a.campaign_root/p['template']['relative_folder']
        check(digest(folder/'manifest.json')==p['template']['manifest_sha256'], 'template manifest differs')
        path=folder/p['template']['file']
        check(path.is_file(), 'retained template is gone; refusing to regenerate it')
        check(digest(path)==p['template']['sha256'], 'retained template bytes differ')
        bank=np.memmap(path,dtype='<c16',mode='r',shape=tuple(p['template']['shape']))
        source=np.array(bank[p['template']['epoch_index'],p['source_bit']],np.complex128,copy=True)
        del bank  # Owned slice survives the campaign's eventual template cleanup.
        records={}; vectors={}; exports=[]
        for name, spec in p['exports'].items():
            stage=name; frozen(a,p); destination=a.output/name
            command=[str(a.exporter),*spec['arguments']]
            command[command.index('--output')+1]=str(destination)
            mark=time.perf_counter()
            with (a.output/(name+'.log')).open('x') as log:
                subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
            m=read(destination/'manifest.json'); t=read(destination/'evaluator-truth.json')
            mm=dict(m); mm.pop('cost')
            check(mm==spec['manifest_without_cost'], name+': fixed metadata changed')
            check(digest(destination/'evaluator-truth.json')==spec['truth_sha256'], name+': truth changed')
            for field, identity in spec['hashes'].items():
                raw=destination/identity['file']
                check(raw.stat().st_size==identity['bytes'] and digest(raw)==identity['sha256'], name+': '+field+' hash mismatch')
            n=m['observation']['shape'][0]
            valid=np.memmap(destination/m['validity']['file'],dtype='u1',mode='r',shape=(n,))
            check(bool(np.all(valid==1)), 'projection requires completely valid raw samples'); del valid
            vectors[name]=np.memmap(destination/m['observation']['file'],dtype='<c16',mode='r',shape=(n,))
            records[name]=(m,t)
            exports.append(dict(name=name,command=command,wall_seconds=time.perf_counter()-mark,native_cost=m['cost'],matched_oracle_hashes=spec['hashes']))
        stage='raw-two-ray-fit'; m,t=records['bit1-high']; fs=m['sample_rate_hz']; n=m['calendar']['capture_samples']
        y=np.asarray(vectors['bit1-high'])-np.asarray(vectors['helper-high']); vectors.clear()
        tx=1+t['tx']['audio_ppm']*1e-6; rx=1+t['rx']['audio_ppm']*1e-6
        rate=tx/rx; scale=1/rx; q=(rate-1)*1e6
        c=m['calendar']; ch=m['channel']; lead=c['capture_lead_seconds']; arrival=t['arrival_seconds']
        offset=c['data_sample_offset']/fs; delay=ch['spread_delay_ms']*.001; D=ch['spread_doppler_hz']
        cfo=((t['tx']['rf_ppm']-t['rx']['rf_ppm'])*ch['rf_hz']+(t['tx']['audio_ppm']-t['rx']['audio_ppm'])*ch['nominal_conversion_if_hz'])*1e-6/rx
        check(t['tx']['rf_drift_ppm_per_second']==t['rx']['rf_drift_ppm_per_second']==0, 'nonzero drift is outside this static family')
        warped=clock_warp(source,q); A=np.zeros((n,2),np.complex128)
        anchor=((lead+arrival)/scale+offset/rate)*fs
        for j in (0,1):
            column=fractional_delay(warped,anchor+j*delay/scale*fs)
            check(len(column)<=n, 'complete two-ray source support exceeds capture')
            times=np.arange(len(column),dtype=np.longdouble)/fs
            column*=phase(cfo,times)
            if j: column*=phase(D*scale,times-lead/scale)
            A[:len(column),j]=column
        coefficients,_,rank,singular=np.linalg.lstsq(A,y,rcond=p['svd_relative_cutoff'])
        fitted=A@coefficients; residual=y-fitted
        energy=float(np.vdot(y,y).real); kept=float(np.vdot(fitted,fitted).real); lost=float(np.vdot(residual,residual).real)
        check(math.isclose(energy,p['oracle_propagated_data_energy_samples'],rel_tol=1e-11), 'regenerated oracle DATA mean energy differs')
        check(rank==2 and 0<kept<=energy*(1+1e-10), 'degenerate or inconsistent projection')
        orthogonality=float(np.linalg.norm(A.conj().T@residual)/(np.linalg.norm(A)*np.linalg.norm(y)))
        check(abs(energy-kept-lost)/energy<1e-10 and orthogonality<1e-10, 'SVD projection consistency failed')
        frozen(a,p)
        result=dict(status='completed',schema='triad-helper-raw-two-ray-projection-v1',plan_sha256=digest(PLAN),
            worker_wall_seconds=time.perf_counter()-started,python=sys.version,numpy=np.__version__,exports=exports,
            rows=n,sample_rate_hz=fs,capture_seconds=n/fs,source_bit=p['source_bit'],seed=p['seed'],
            truth_parameters=dict(source_clock_ppm=q,rx_doppler_scale=scale,arrival_seconds=arrival,static_cfo_hz=cfo,anchor_samples=anchor,delay_samples=delay/scale*fs,doppler_hz=D*scale),
            svd_rank=int(rank),singular_values=singular.tolist(),coefficients_real_imag=[[float(z.real),float(z.imag)]for z in coefficients],
            data_energy_samples=energy,projected_energy_samples=kept,residual_energy_samples=lost,
            retained_energy_fraction=kept/energy,residual_energy_fraction=lost/energy,representation_loss_db=-10*math.log10(kept/energy),
            orthogonality_relative=orthogonality,pythagoras_relative_error=abs(energy-kept-lost)/energy,
            physical_noise_variance=p['physical_noise_variance'],projected_energy_over_physical_noise=kept/p['physical_noise_variance'],
            limits=p['limits'],template_sha256=p['template']['sha256'],source_hashes=p['source_hashes'],exporter_sha256=p['exporter_sha256'])
        write(a.output/'result.json',result)
        for name,spec in p['exports'].items():
            for identity in spec['hashes'].values(): (a.output/name/identity['file']).unlink()
        return 0
    except Exception as error:
        write(a.output/'result.json',dict(status='failed',stage=stage,error=str(error),traceback=traceback.format_exc(),worker_wall_seconds=time.perf_counter()-started)); return 2

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign-root',type=Path,required=True); parser.add_argument('--exporter',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True); parser.add_argument('--_worker',action='store_true',help=argparse.SUPPRESS)
    a=parser.parse_args(); a.campaign_root=a.campaign_root.resolve(); a.exporter=a.exporter.resolve(); a.output=a.output.resolve(); p=read(PLAN)
    if a._worker: return worker(a,p)
    started=time.perf_counter(); frozen(a,p); a.output.mkdir(parents=True,exist_ok=False)
    write(a.output/'frozen-plan.json',p)
    command=[sys.executable,str(Path(__file__).resolve()),'--_worker',*sys.argv[1:]]
    with (a.output/'worker.stdout.log').open('x') as out,(a.output/'worker.stderr.log').open('x') as err:
        child=subprocess.Popen(command,cwd=REPO,stdout=out,stderr=err,start_new_session=True); expired=False
        try: child.wait(timeout=max(.01,117-(time.perf_counter()-started)))
        except subprocess.TimeoutExpired:
            expired=True; os.killpg(child.pid,signal.SIGTERM)
            try: child.wait(timeout=1)
            except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL); child.wait(timeout=2)
    write(a.output/'supervisor.json',dict(status='deadline-exceeded'if expired else('completed'if child.returncode==0 else'failed'),returncode=child.returncode,total_wall_seconds=time.perf_counter()-started,budget_seconds=120))
    return 124 if expired else child.returncode

if __name__=='__main__': raise SystemExit(main())

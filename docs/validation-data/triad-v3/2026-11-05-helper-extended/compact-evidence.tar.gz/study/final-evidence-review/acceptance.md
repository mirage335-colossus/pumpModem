# Final extended-campaign evidence acceptance receipt

Recount command (1.6 s wall here; reads retained manifests and trial records, does not simulate or decode again):

```sh
/tmp/triad-weak-env/bin/python local-evidence/triad-helper-extended/summarize_campaign.py \
  --root local-evidence/triad-helper-extended/remote/extended-main-v2 \
  --protocol local-evidence/triad-helper-extended/protocol-v1.json \
  --repo . \
  --native-executable /tmp/triad-helper-extended-cloud/triad_helper_export.remote \
  --output-dir local-evidence/triad-helper-extended/recount-final
```

Machine-readable recount: `recount-final/independent-recount.json`; concise per-cohort Markdown table: `recount-final/independent-recount.md`.

## Provenance and receipt checks

- All 12 planned cohorts have completed summaries; no unaccounted cohort or missing signal/null decision was reported.
- Root `input_protocol_sha256` equals the frozen input protocol SHA256 `bdb4d62ad49ffe52cd42f7f177b51c4a5b461f6cc3cbc34123a1c31240668c40`. The enriched root document has its separate digest recorded in JSON.
- The exact private local executable used for comparison has SHA256 `39a70e311f71b4a9e63fcf0c9beaae3123e834d560ccffd263094f2236875210`, matching the campaign root and all cohort exporter identities. The executable itself is not copied into this evidence package.
- All 19 campaign source-file identities match the current repository, and all 12 cohort source maps match the campaign root. All 12 cohort protocol hashes match their summary records.
- Independent trial/manifest/receipt recount: 740 trial rows; 740 manifests present and matching recorded manifest SHA; 740 evaluator-truth files present and matching recorded truth SHA; 740 paired erasure receipts present; 740/740 recorded input hashes match erasure receipts and 740/740 validity hashes match. Manifest metadata does not contain the original native observation SHA, so that particular cross-check is unavailable (not a failure).
- Every cohort's independent correct/wrong/miss/false-admission recount matches its stored cohort summary counts.
- Three duplicated seed-base groups are explicitly reported as paired/dependent. Cohorts are not pooled for inference.

## Outcome recount

There are 228 calibration, 336 signal, and 176 null trial rows. Across those separate cohorts, counts sum descriptively to 300 correct admissions, 0 wrong admissions, 36 misses, and 9 null admissions. Those arithmetic totals are not a campaign-wide performance estimate.

| Cohort | Bit 0 correct / n | Bit 1 correct / n | Correct / wrong / miss | Null admitted / n (pointwise 95% upper) | Equal-bit mean one-sided 95% lower | Actual / requested bit s | Helper result |
|---|---:|---:|---:|---:|---:|---:|---|
| added100-rate10-minus10 | 14/16 | 14/16 | 28 / 0 / 4 | 0/16 (.171) | .617 | 388 / 384 | fallback: flat profile or insufficient presence |
| added1000-rate1-minus10 | 14/16 | 13/16 | 27 / 0 / 5 | 1/16 (.264) | .580 | 384.4 / 8 | fallback: flat profile or insufficient presence |
| added1000-rate1-minus16-paired | 2/16 | 3/16 | 5 / 0 / 27 | 1/16 (.264) | .028 | 384.4 / 8 | fallback: flat profile or insufficient presence |
| rate12000-hf8-each65 | 16/16 | 16/16 | 32 / 0 / 0 | 3/16 (.417) | .911 | 8.8 / 8 | fallback: no bank shrink |
| rate18000-hf8-each65 | 16/16 | 16/16 | 32 / 0 / 0 | 1/16 (.264) | .911 | 8.8 / 8 | fallback: no bank shrink |
| rate24000-flat8-paired | 16/16 | 16/16 | 32 / 0 / 0 | 2/16 (.344) | .911 | 8.8 / 8 | fallback: no bank shrink |
| rate24000-hf8-each65 | 16/16 | 16/16 | 32 / 0 / 0 | 0/16 (.171) | .911 | 8.8 / 8 | fallback: no bank shrink |
| rate3600-eme10-fhss | 16/16 | 16/16 | 32 / 0 / 0 | 0/16 (.171) | .911 | 8.8 / 8 | narrowed; conditional model checks passed |
| rate3600-eme10-fhss-adcgaps | 16/16 | 16/16 | 32 / 0 / 0 | 0/16 (.171) | .911 | 8.8 / 8 | narrowed; conditional model checks passed |
| rate3600-eme10-fhss-waits3 | 4/4 | 4/4 | 8 / 0 / 0 | 0/8 (.312) | .688 | 79.2 / 24 | narrowed; conditional model checks passed |
| rate3600-free-ic7100-hf8 | 4/4 | 4/4 | 8 / 0 / 0 | 0/8 (.312) | .688 | 8.8 / 8 | narrowed; conditional joint-clock checks passed |
| rate3600-hf8-each65 | 16/16 | 16/16 | 32 / 0 / 0 | 1/16 (.264) | .911 | 8.8 / 8 | fallback: no bank shrink |

All confidence limits are pointwise per named cohort and conditional on independent representative trials within the bit stratum(s) and the frozen gate. The null upper bounds do not establish a daily/repeated-search false admission guarantee. The no-failure bounds for 8-trial cohorts are notably weak.

The marked actual/requested duration differences are part of the result: low-rate Added1000 requested 8 seconds but each bit was 384.4 seconds; Added100 at 10 Hz was 388 seconds versus 384 requested; and the burst-wait FHSS cohort was 79.2 seconds versus 24 requested. These must be reported as actual allocations, not treated as eight-second or 24-second trials.

## Work totals and limitations

Across per-trial records, native simulation wall sums to 5,786.724 s and cohort-level native export wall sums to 5,808.355 s. Per-trial receiver scoring sums to 683.630 s. These are distinct timer scopes, not campaign end-to-end wall time. Summed scorer sample-work is 140,130,623 and effective groups sum to 48,636,523; neither is transmitted observation sample count. Per-cohort exact measures are retained in the machine-readable output.

The Helper narrowed in three EME/FHSS cohorts and the free-crystal/IC-7100 cohort (four total); it fell back in eight of twelve cohorts (including every 12/18/24 kHz row and the default 3.6 kHz HF/Each65 row). Successful 32/32 signal results therefore do not establish Helper assistance for those rows. The 5.8 GHz setting is simulator RF metadata with GPSDO model in EME rows, not a physical RF test.

No raw I/Q array or executable is included in this acceptance receipt. The full local manifests contain shape/count metadata, and the compact archive review is separate. Result confidence is not extrapolated across rates, SNR, helper status, duplicated seed groups, or duration choices.

Output hashes:
- `independent-recount.json`: `e098b651633f0ae6cd2ce163b125bae2b765f9d2627a91cdc04355a605d71c02`
- `independent-recount.md`: `7346d63514ceae55550657b983654f2a16ead5eacf18d95fd9c98a6b25274051`
- recount script: `351d230c012089bcedf5986c63c0dd6e6aaf5b24cbe784347c4d7a530d5d685b`

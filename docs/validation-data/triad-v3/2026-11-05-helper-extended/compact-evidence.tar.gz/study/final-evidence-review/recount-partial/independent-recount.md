# Independent Helper campaign recount

Input: `local-evidence/triad-helper-extended/remote/extended-main-v2`

Each row is one cohort; counts are independently reconstructed from `trials.jsonl`. No campaign-wide percentage is pooled.

| Cohort | Status | rate Hz | Added | C/N₀ dB-Hz | actual / requested bit s | Correct / wrong / miss | null false / N | equal-bit 95% lower | Helper statuses / reasons | samples | sim wall s | score s | manifests verified / total |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|
| added1000-rate1-minus10 | completed | 1 | 1000 | -10 | 384.40000000000003 / 8 | 27 / 0 / 5 | 1 / 16 | 0.5800 | `{'fallback|flat_profile': 42, 'fallback|insufficient_presence_diagnostic': 25}` | 25820058 | 514.193 | 37.062811512034386 | 67 / 67 of 67 |
| rate12000-hf8-each65 | completed | 12000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 3 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 7831898 | 352.524 | 14.85925722005777 | 67 / 67 of 67 |
| rate18000-hf8-each65 | completed | 18000 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 1 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 10440610 | 698.275 | 21.532658459385857 | 67 / 67 of 67 |
| rate3600-hf8-each65 | completed | 3600 | 1 | 8 | 8.8 / 8 | 32 / 0 / 0 | 1 / 16 | 0.9106 | `{'fallback|no_bank_shrink': 67}` | 2613335 | 349.481 | 5.96933752996847 | 67 / 67 of 67 |

## Limits

Null upper limits are finite per-cohort pointwise intervals under the frozen gate; they do not bound future or daily false admissions. Missing trials, score failures, timeout and interrupted cohorts remain unresolved, not misses or passes. All admissions, misses, and interval claims remain per named configuration. Shared seed bases are listed in the JSON as dependent comparisons.

Recorded native exporter hash: `39a70e311f71b4a9e63fcf0c9beaae3123e834d560ccffd263094f2236875210`; observed hash: `None`. Source and manifest mismatches/unavailability are retained per path in the JSON.

# Final evidence accounting review (read-only)

Review snapshot: repository HEAD `388d0749bc3fae9c529a5d298946ab2d6ee19791`, with dirty candidate edits under `tools/`, `tests/`, and the maintained Helper documentation. No modem tests or campaign runs were launched for this review.

## Findings

- `summarize_campaign.py` correctly treats cohorts independently, labels duplicate seed-base groups as dependent, and does not pool reception outcomes. It reports per-bit counts and uses a balanced-strata all-success AM-GM lower bound only when bit sample sizes match and both strata have all correct admissions; otherwise it uses per-stratum Bonferroni Clopper–Pearson bounds. This remains conditional on within-stratum independent, representative trials and a frozen gate.
- The previous public receiver preparation overcount was corrected: use summary-level `receiver_preparation_seconds` once, with a unique trial-value fallback. Sample count reads observation shape[0] then calendar capture samples.
- Material recount defect: `missing_decisions` accumulates missing/malformed outcomes from both signal and null loops, but is emitted under `missing_signal_decisions`. In a cohort with any null decision missing, the signal missing count is overstated. `null_decisions_missing` is computed separately. Keep the per-phase results distinct or rename this field before relying on final completeness accounting.
- Protocol validation is not decisive: it records frozen and downloaded protocol digests but does not compare them, and cohort `global_frozen_case_match` is only a full-dictionary comparison between a local case and a root cohort. In the current downloaded campaign root, the protocol contains no source hashes or exporter hash. The recount therefore has no source/build binding from the run receipt itself.
- Frozen candidate-v2 source identity currently validates: all 11 listed file SHA256 values match current files; the git base is the expected commit. `package-evidence.py` includes those source files and tracked patch material. Candidate-v1 identity has two expected mismatches from later v2 edits and must not be cited as the final candidate.
- Build identity gap: package/source IDs prove the archived candidate source, but no executable hash is recorded in the campaign root protocol, cohort summary, or sampled waveform manifest (`native` is null). `native_binary_validation` remains `not-checked` unless an executable is supplied, and even then the absent expected exporter hash cannot make a run-to-binary comparison. Describe source reconstruction and run/build binding separately; do not call it an exact binary-bound run without another receipt.
- Packaging review: package script filters to compact textual/JSON evidence extensions and rejects individual files >256 MiB; current included tree is about 9.9 MB across 1,271 eligible files. A pattern scan found no private-key headers, credential assignments, or RunPod SSH command patterns. Eight numeric lists >1,000 entries are `geometry.lag_samples` (4,345 values in paired CPU/GPU score records), not raw I/Q observation arrays. This is a scan, not a formal privacy guarantee; package inclusion is broad `rglob`, so review any newly downloaded logs before packaging.

## Current campaign receipt limits

The first downloaded cohort remains the only fully recounted one at this snapshot; remaining cohort package download is pending. Its verified outcome counts are 32 correct / 0 wrong / 0 missed, 1 null admission in 16; Helper status is fallback/no-bank-shrink for all 67 rows. Its balanced-strata lower bound is 0.91063, per-bit lower 0.82925; these are pointwise and conditional, and do not establish a daily false-admission guarantee. Trial manifests were missing in that earlier first-cohort download. Re-run the independent recount after the full tree lands and retain manifest/hash discrepancies, incomplete trials, and cohort status distinctly.

## Suggested narrow repairs before final accounting

1. Split missing outcome counters into signal and null, and count unknown phases/duplicate trial IDs as explicit accounting defects.
2. Compare downloaded root protocol hash to the supplied frozen protocol and expose a direct boolean/status. Preserve any intentional difference as mismatch, not silent precedence.
3. Validate actual source hashes against `candidate-v2-source-identities.json` and label that as local/archive source identity, separately from run provenance.
4. Either obtain a run-recorded exporter hash to compare, or state that exact executable provenance is unavailable. Do not infer it from current source files.

## Repair update

A parent-authorized script-only repair was made after preserving the prior version at `original-review/summarize_campaign.pre-repair.py` (SHA256 `dcba8ae973aa85bb27ea0c2e35c0ea5729c292437d1db858a1bde3dd99418541`). Current script SHA256: `351d230c012089bcedf5986c63c0dd6e6aaf5b24cbe784347c4d7a530d5d685b`.

- Signal and null missing-decision counters are now independent.
- The enriched campaign protocol's `input_protocol_sha256` is compared with the frozen input protocol file SHA256. Its own full-document hash is separately recorded.
- Every cohort's source map and exporter hash are compared with campaign-level identities.
- Native executable status distinguishes absent expected hash, expected hash with no executable supplied, unavailable path, match and mismatch.
- On the currently downloaded four-cohort partial tree, compilation and recount passed. Frozen input hash matched (`bdb4d62a…668c40`), all 19 local source hashes matched, all four cohort source/exporter maps matched the root, and each cohort summary protocol hash matched its local protocol. The recorded native exporter hash is `39a70e31…75210`; binary was not supplied yet, so exact binary comparison remains pending. Each of these four cohorts had 0 missing signal/null outcomes and all 67 trial-manifest hashes matched. This is not the final campaign recount; remaining download is pending.

# Ideal presence reference: scope and correction

This is a scalar known-waveform AWGN diagnostic, not a sampled-modem campaign.
The one million H0 draws and one million H1 draws are independent within each
vector and between H0/H1; the vectors are reused across power ratios and
thresholds. Those conditions are paired and must not be pooled as independent
experiments. The duration table is analytical, not a million-trial duration
experiment.

The first calculation mistakenly treated several requested day counts as
seconds. The coordinator rejected that output from its energy arithmetic:
38 days at -60 dB-Hz has E/N0=3.2832, not 0.000038. The corrected script uses
explicit seconds derived from days. The file under `original-unit-error/` is a
reproduction of the faulty calculation, not an untouched original result;
its hash must not be presented as the first output's identity. The original
agent-reported output hash was
`8ab91e69947a2aa5840c8da3503345dd50151e0b693bd3c6f0092d4181995dd6`.

The coordinator independently checked the corrected mean shift sqrt(2 E/N0),
normal-tail formula, day conversion, and single-tone unknown-phase CRLB
6/((2 pi)^2 (C/N0) T^3). The CRLB is an optimistic asymptotic estimator variance
reference, not a certified coverage interval for the real Helper estimator.
Every multiple-search, unknown-channel, bit-discrimination and operational
false-admission issue remains outside this diagnostic.

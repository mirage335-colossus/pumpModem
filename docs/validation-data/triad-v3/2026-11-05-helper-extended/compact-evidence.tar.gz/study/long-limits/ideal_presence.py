#!/usr/bin/env python3
"""Frozen ideal AWGN presence benchmark for the Helper-at-minus-60 study.

This models one known complex waveform and a single known-phase correlation.
It does not generate triad/Helper waveforms, exercise a receiver, model a
search, validate a channel, or qualify an operational false-admission rate.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.special import ndtr, ndtri
from scipy.stats import beta


SEED_H0 = 0xC0FFEE
SEED_H1 = 0x5EED60
TRIALS = 1_000_000
CNO_DATA_DB_HZ = -60.0
DATA_CNO_HZ = 10.0 ** (CNO_DATA_DB_HZ / 10.0)
DURATION_SECONDS = (38.0 * 86400.0, 63.0 * 86400.0, 0.5 * 86400.0,
                     75.33 * 86400.0, 211.50 * 86400.0, 432.07 * 86400.0,
                     850.0 * 86400.0)
ALPHAS = (0.01, 1.0e-4)
POWER_RATIOS_DB = {"fixed-HF-40W-helper/4W-DATA": 10.0,
                   "fixed-EME-15kW-helper/40W-DATA": 10.0 * math.log10(15000.0 / 40.0)}
STRONG_HELPER_CNO_DB_HZ = 30.0
HELPER_OBSERVATION_SECONDS = 36.0
COARSE_CFO_BOUND_HZ = 0.01
LONG_DURATION_DAYS = 850.0
RAW_SAMPLE_RATE_HZ = 18000
RAW_COMPLEX_IQ_AND_VALIDITY_BYTES = 17
RAW_CAPTURE_BUDGET_BYTES = 2 * 1024**3


def cp_interval(successes: int, trials: int, confidence: float = 0.95) -> tuple[float, float]:
    """Two-sided exact Clopper-Pearson interval (no normal approximation)."""
    tail = (1.0 - confidence) / 2.0
    lower = 0.0 if successes == 0 else float(beta.ppf(tail, successes, trials - successes + 1))
    upper = 1.0 if successes == trials else float(beta.ppf(1.0 - tail, successes + 1,
                                                               trials - successes))
    return lower, upper


def rho_for_duration(cno_hz: float, seconds: float) -> float:
    return cno_hz * seconds


def ideal_known_waveform_presence_pd(rho: float, alpha: float) -> float:
    """P_D for Z~N(sqrt(2*rho),1), H0 threshold Phi^-1(1-alpha)."""
    threshold = float(ndtri(1.0 - alpha))
    return float(ndtr(math.sqrt(2.0 * rho) - threshold))


def target_rho(pd: float, alpha: float) -> float:
    return 0.5 * (float(ndtri(1.0 - alpha)) + float(ndtri(pd))) ** 2


def mc_presence(rho: float, alpha: float, scores_h0: np.ndarray,
                standard_h1: np.ndarray) -> dict[str, object]:
    threshold = float(ndtri(1.0 - alpha))
    false_count = int(np.count_nonzero(scores_h0 > threshold))
    detected_count = int(np.count_nonzero(standard_h1 + math.sqrt(2.0 * rho) > threshold))
    false_ci = cp_interval(false_count, int(scores_h0.size))
    detection_ci = cp_interval(detected_count, int(standard_h1.size))
    return {
        "alpha_nominal": alpha,
        "known_single_test_threshold_standard_normal": threshold,
        "false_admissions": false_count,
        "false_trials": int(scores_h0.size),
        "false_rate": false_count / int(scores_h0.size),
        "false_rate_two_sided_95pct_exact_binomial_interval": list(false_ci),
        "correct_presence_detections": detected_count,
        "signal_trials": int(standard_h1.size),
        "detection_rate": detected_count / int(standard_h1.size),
        "detection_two_sided_95pct_exact_binomial_interval": list(detection_ci),
        "analytic_detection_probability": ideal_known_waveform_presence_pd(rho, alpha),
        "interpretation": "Monte Carlo for this one ideal known-waveform Gaussian sufficient statistic only; not modem trials.",
    }


def main() -> int:
    rng_h0 = np.random.Generator(np.random.PCG64(SEED_H0))
    rng_h1 = np.random.Generator(np.random.PCG64(SEED_H1))
    # Each is an independently seeded direct draw from the exact one-real-
    # degree-of-freedom sufficient-statistic distributions, not synthesized IQ.
    scores_h0 = rng_h0.standard_normal(TRIALS)
    standard_h1 = rng_h1.standard_normal(TRIALS)

    helper_results = {}
    for name, ratio_db in POWER_RATIOS_DB.items():
        helper_cno_db_hz = CNO_DATA_DB_HZ + ratio_db
        helper_cno_hz = 10.0 ** (helper_cno_db_hz / 10.0)
        rho = helper_cno_hz * HELPER_OBSERVATION_SECONDS
        helper_results[name] = {
            "helper_to_data_power_ratio_db": ratio_db,
            "data_cn0_db_hz": CNO_DATA_DB_HZ,
            "helper_cn0_db_hz": helper_cno_db_hz,
            "helper_observation_seconds": HELPER_OBSERVATION_SECONDS,
            "helper_energy_to_N0_rho": rho,
            "by_false_admission_target": {
                f"alpha={alpha:g}": mc_presence(rho, alpha, scores_h0, standard_h1)
                for alpha in ALPHAS
            },
        }

    duration_rows = []
    for seconds in DURATION_SECONDS:
        rho = rho_for_duration(DATA_CNO_HZ, seconds)
        duration_rows.append({
            "seconds": seconds,
            "days": seconds / 86400.0,
            "data_cn0_db_hz": CNO_DATA_DB_HZ,
            "known_waveform_energy_to_N0_rho": rho,
            "ideal_presence_probability": {
                f"alpha={alpha:g}": ideal_known_waveform_presence_pd(rho, alpha)
                for alpha in ALPHAS
            },
        })

    target_rows = []
    for pd in (0.90, 0.99):
        for alpha in ALPHAS:
            rho = target_rho(pd, alpha)
            target_rows.append({
                "target_detection_probability": pd,
                "single_test_false_admission_probability": alpha,
                "required_rho": rho,
                "required_seconds_at_minus60_db_hz": rho / DATA_CNO_HZ,
                "required_days_at_minus60_db_hz": rho / DATA_CNO_HZ / 86400.0,
            })

    # Asymptotic CRLB for one ideal, constant complex tone, known amplitude,
    # unknown phase, white complex Gaussian noise, and rectangular observation.
    strong_helper_cno_hz = 10.0 ** (STRONG_HELPER_CNO_DB_HZ / 10.0)
    sigma_f_hz = math.sqrt(6.0 / ((2.0 * math.pi) ** 2 * strong_helper_cno_hz *
                                 HELPER_OBSERVATION_SECONDS ** 3))
    cfo_grid_step_hz = 1.0 / (4.0 * LONG_DURATION_DAYS * 86400.0)
    cfo_95_halfwidth_hz = 1.959963984540054 * sigma_f_hz

    raw_samples = int(LONG_DURATION_DAYS * 86400.0 * RAW_SAMPLE_RATE_HZ)
    raw_capture_bytes = raw_samples * RAW_COMPLEX_IQ_AND_VALIDITY_BYTES
    required_grid_half_count = math.ceil(COARSE_CFO_BOUND_HZ / cfo_grid_step_hz)

    script = Path(__file__)
    result = {
        "schema": "triad-helper-ideal-presence-bound-v1",
        "status": "completed-independent-analytic-and-ideal-sufficient-statistic-monte-carlo",
        "created_utc_date": "2026-11-05",
        "code_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
        "environment": {"python": sys.version, "platform": platform.platform(),
                        "numpy": np.__version__, "scipy": scipy.__version__},
        "frozen_protocol": {
            "data_cn0_db_hz": CNO_DATA_DB_HZ,
            "mc_h0_seed_pcg64": SEED_H0,
            "mc_h1_seed_pcg64": SEED_H1,
            "mc_trials_per_hypothesis": TRIALS,
            "alpha_values": list(ALPHAS),
            "duration_seconds": list(DURATION_SECONDS),
            "simulator_or_receiver_invoked": False,
            "waveforms_or_keystreams_generated": False,
        },
        "assumptions": {
            "signal_model": "one fixed, known complex waveform, known phase and known channel; matched filter output in complex AWGN",
            "complex_noise_convention": "E[|n|^2]=N0; rho=signal_energy/N0=(C/N0)*T",
            "sufficient_statistic": "Z=Re(s^H y)/(sigma*||s||); H0: N(0,1/2); H1: N(sqrt(rho),1/2); reported standard-normal score is sqrt(2)*Z, with H1 mean sqrt(2*rho)",
            "threshold": "Phi^-1(1-alpha) on reported standard-normal score",
            "search_multiplicity": "one known candidate only; no timing, frequency, epoch, bit, duration, model, or repeated-attempt penalty",
            "channel_and_oscillator": "perfectly known and static over observation; no fading, outages, drift, sideband truncation, or modulation mismatch",
            "monte_carlo": "Direct Gaussian sufficient-statistic draws validate the analytic scalar probabilities; they are not waveform/receiver performance experiments.",
        },
        "source_references": [
            {"title": "Rife and Boorstyn, Single tone parameter estimation from discrete-time observations", "doi": "10.1109/TIT.1974.1055282", "use": "Asymptotic single-tone frequency-estimation CRLB context; does not establish a bound for the Helper waveform estimator."},
            {"path": "docs/triad-helper-coverage.md", "claim": "C/N0 conversion, inherited power ratios and prior single-test presence formula."},
            {"path": "docs/validation-data/triad-v3/2026-11-03-broad/long_followup/README.md", "claim": "Existing 850-day standalone stream: source/calendar and finite simulated receiver evidence, not Helper acquisition."},
        ],
        "helper_36_second_ideal_presence_monte_carlo": helper_results,
        "data_minus60_known_waveform_duration_points": duration_rows,
        "data_minus60_target_presence_bounds": target_rows,
        "strong_helper_frequency_reference": {
            "helper_cn0_db_hz": STRONG_HELPER_CNO_DB_HZ,
            "helper_observation_seconds": HELPER_OBSERVATION_SECONDS,
            "single_known_complex_tone_frequency_sigma_crlb_hz": sigma_f_hz,
            "asymptotic_normal_95pct_halfwidth_hz": cfo_95_halfwidth_hz,
            "850_day_coherent_grid_step_hz_at_0p22db_rectangular_bound": cfo_grid_step_hz,
            "estimated_number_of_grid_cells_in_crlb_95pct_interval": 2.0 * cfo_95_halfwidth_hz / cfo_grid_step_hz + 1.0,
            "interpretation": "Ideal single-tone asymptotic lower reference, known amplitude, unknown phase, no Helper line split or channel fitting. A 95% CRLB interval is not a proven estimator coverage interval.",
        },
        "850_day_default_18khz_raw_export_resource_reference": {
            "duration_seconds": LONG_DURATION_DAYS * 86400.0,
            "raw_sample_rate_hz": RAW_SAMPLE_RATE_HZ,
            "sample_count": raw_samples,
            "bytes_per_complex_sample_plus_validity": RAW_COMPLEX_IQ_AND_VALIDITY_BYTES,
            "complex_iq_plus_validity_bytes": raw_capture_bytes,
            "complex_iq_plus_validity_decimal_tb": raw_capture_bytes / 1.0e12,
            "current_export_fixture_budget_bytes": RAW_CAPTURE_BUDGET_BYTES,
            "capture_over_budget_factor": raw_capture_bytes / RAW_CAPTURE_BUDGET_BYTES,
            "cfo_engineering_allowance_hz": COARSE_CFO_BOUND_HZ,
            "coherent_frequency_step_hz": cfo_grid_step_hz,
            "full_grid_point_count_for_allowance": 2 * required_grid_half_count + 1,
            "note": "Resource arithmetic for retained full-rate samples before templates; the standalone v3 path uses streamed sufficient statistics to avoid such a raw file. This fixed18k Helper fixture itself caps bit capture at3600 seconds and2GiB.",
        },
        "interpretation_limits": [
            "The existing 850-day 32/32 point results concern the standalone v3 receiver under a narrow static simulated channel and nominal acquisition conditions. They are not Helper-assisted evidence and do not establish a 99% bound.",
            "The Helper MC shows that a single ideal known waveform at inherited power ratios is hard to identify in the 36-second Helper window at DATA C/N0=-60 dB-Hz. It omits multi-frequency acquisition and every real Helper nuisance; actual assistance is no better guaranteed by this upper reference.",
            "DATA presence probabilities are not one-bit correct-reception probabilities. The DATA waveform pair distance, unknown phase/channel, acquisition bank and false-admission budget require separate tests.",
            "No output from this file is an experiment on actual triad/Helper reception, and no daily false-admission guarantee follows.",
        ],
    }
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

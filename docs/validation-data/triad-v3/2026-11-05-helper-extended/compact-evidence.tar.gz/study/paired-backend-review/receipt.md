# Paired CPU/CUDA benchmark evidence review

The saved results are consistent with the scoped claims. This is one independent native capture scored eight times, not an admission or sensitivity campaign. No DSP was rerun during review.

| Timing scope | CPU seconds | CUDA seconds | CPU/CUDA |
|---|---:|---:|---:|
| Warm prepared scoring, median of three | 2.332722 | 0.430279 | 5.4214× |
| Warm correlation-batch substage | 1.758345 | 0.011035 | 159.338× |
| First score including lazy factors | 7.811674 | 5.906773 | 1.3225× |
| First receiver use, composed components | 9.139323 | 7.348954 | 1.2436× |

Both devices selected raw bit 1, matching the source, with the same winning epoch, arrival and CFO. All ten independently recalculated comparisons passed; maximum absolute retained log-likelihood difference was 2.11338933e-05, with zero retained rank displacement. Bulk arithmetic was complex FP32 with TF32 disabled and FP64 sensitive stages. The CPUs were configured for two threads on an AMD EPYC 9355; the GPU was an RTX PRO 6000 Blackwell Server Edition.

The full bank comprised 13 epochs × 4,345 arrivals × 3 CFOs = 169,455 groups, with 13 cached public workspaces on both devices. Helper returned `no_bank_shrink` (3→3 CFOs): none of this speedup is attributable to Helper search narrowing. The 96-kHz capture lasted 47.846969 simulated seconds; the requested eight-second DATA pattern realized 8.8 seconds. Whole-active power reference gave DATA active mean norm 0.999962716.

Shared Helper/filter preparation took 0.906276s once; native generation took 20.745231s. The entire paired experiment took 46.588562s. These shared costs must not be counted twice or omitted when discussing production workloads. There is no measured whole-campaign speedup. Warm factors cost zero; first-use factor construction cost CPU 5.567549s / CUDA 5.184228s.

CUDA peak allocated memory was 722,011,136 bytes (0.672 GiB), with 805,306,368 bytes reserved. The CPU/GPU explicit-array bounds were 7.155/9.400 GiB; these are not measured RSS.

Key limitations: 159× covers only the correlation-batch timer, excluding initial FFTs and uploads; 5.42× covers warm prepared scoring. Cold components were measured in a shared process, not isolated starts. Three repeats are descriptive ranges, not a performance confidence interval. Per-CFO/arrival ranks were streamed rather than retained. Actual BLAS pool sizes were not enumerated, and CPU affinity was not pinned. Retained identity hashes check; removed raw arrays cannot be rehashed. See `receipt.json` for all measurements, checks, identities and limits. The reviewer authored the private benchmark script; root performed its separate pre-execution review.

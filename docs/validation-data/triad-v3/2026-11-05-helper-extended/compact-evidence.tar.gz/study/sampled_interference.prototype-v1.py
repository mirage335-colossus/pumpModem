#!/usr/bin/env python3
"""Paired sampled-waveform DATA/Helper spectral-interference diagnostic.

This occasional diagnostic runs three actual native exports with matched
protocol inputs, then measures energy before/after the public rate-aware DATA
front end.  It does not qualify receiver sensitivity, rare channel tails, or
physical radios.  Large I/Q and validity files are deleted only after all
measurements and provenance receipts have been written successfully.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
from scipy import signal


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))

from triad_helper_receiver import data_fir_taps, rate_aware_frontend  # noqa: E402
from triad_helper_study import _frontend_support, public_clock_grids, public_geometry  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_sha256_optional(path: Path) -> str | None:
    return sha256(path) if path.is_file() else None


def run_checked(command: list[str], log_path: Path) -> dict:
    start = time.monotonic()
    result = subprocess.run(command, text=True, capture_output=True)
    elapsed = time.monotonic() - start
    log_path.write_text(
        "COMMAND: " + json.dumps(command) + "\n"
        + f"RETURN_CODE: {result.returncode}\n"
        + f"WALL_SECONDS: {elapsed:.9f}\n"
        + "--- STDOUT ---\n" + result.stdout
        + "\n--- STDERR ---\n" + result.stderr
    )
    receipt = dict(command=command, returncode=result.returncode,
                   wall_seconds=elapsed, log=log_path.name)
    if result.returncode:
        raise RuntimeError(
            f"native export failed ({result.returncode}); see {log_path}: "
            f"{result.stderr[-1000:]}"
        )
    return receipt


def _load_capture(folder: Path, manifest: dict):
    obs = manifest["observation"]
    shape = tuple(int(x) for x in obs["shape"])
    if len(shape) != 1 or shape[0] != int(manifest["calendar"]["capture_samples"]):
        raise ValueError(f"unexpected observation shape in {folder}")
    raw_path = folder / obs["file"]
    if raw_path.stat().st_size != shape[0] * 16:
        raise ValueError(f"observation file size mismatch in {folder}")
    validity = manifest["validity"]
    valid_path = folder / validity["file"]
    if valid_path.stat().st_size != shape[0]:
        raise ValueError(f"validity file size mismatch in {folder}")
    return np.memmap(raw_path, dtype="<c16", mode="r", shape=shape), valid_path


def _energy(values: np.ndarray, sample_rate: float) -> float:
    # Deliberately accumulate in float64 without copying the full waveform.
    total = 0.0
    block = 1_000_000
    for first in range(0, len(values), block):
        part = values[first:first + block]
        total += float(np.sum(part.real * part.real + part.imag * part.imag,
                              dtype=np.float64))
    return total / sample_rate


def _rms_and_peak(values: np.ndarray) -> tuple[float, float]:
    if not len(values):
        return 0., 0.
    energy = 0.0
    peak = 0.0
    block = 1_000_000
    for first in range(0, len(values), block):
        part = values[first:first + block]
        power = part.real * part.real + part.imag * part.imag
        energy += float(np.sum(power, dtype=np.float64))
        peak = max(peak, float(np.sqrt(np.max(power))))
    return math.sqrt(energy / len(values)), peak


def _difference_metrics(left: np.ndarray, right: np.ndarray,
                        third: np.ndarray | None = None) -> tuple[float, float]:
    """Chunked RMS/peak for left-right[-third], without a full-sized copy."""
    if len(left) != len(right) or (third is not None and len(left) != len(third)):
        raise ValueError("difference arrays must have equal lengths")
    energy = 0.0
    peak = 0.0
    block = 1_000_000
    for first in range(0, len(left), block):
        past = min(len(left), first + block)
        delta = left[first:past] - right[first:past]
        if third is not None:
            delta -= third[first:past]
        power = delta.real * delta.real + delta.imag * delta.imag
        energy += float(np.sum(power, dtype=np.float64))
        peak = max(peak, float(np.sqrt(np.max(power))))
    return (math.sqrt(energy / len(left)), peak) if len(left) else (0., 0.)


def _filter_to_memmap(raw: np.memmap, taps: np.ndarray, decimation: int,
                      capture_samples: int, output_path: Path) -> np.memmap:
    """Match receiver filtering: complete causal OLA and original [::D] phase."""
    expected = (capture_samples + len(taps) - 1 + decimation - 1) // decimation
    output = np.memmap(output_path, dtype="<c16", mode="w+", shape=(expected,))
    # scipy's overlap-add is required for the long, narrow rate-aware filters.
    # Only one convolution result is resident at a time; the decimated output
    # is copied immediately into a compact temporary file.
    filtered = signal.oaconvolve(raw, taps, mode="full")
    decimated = filtered[::decimation]
    if len(decimated) != expected:
        output_path.unlink(missing_ok=True)
        raise RuntimeError(f"unexpected FIR output length {len(decimated)} != {expected}")
    output[:] = decimated
    output.flush()
    del decimated, filtered
    return output


def _match_manifests(manifests: dict[str, dict]) -> None:
    reference = manifests["composite"]
    for arm, manifest in manifests.items():
        if public_geometry(manifest) != public_geometry(reference):
            raise ValueError(f"public source/channel geometry differs in {arm} export")
        if manifest["sample_rate_hz"] != reference["sample_rate_hz"]:
            raise ValueError(f"sample rate differs in {arm} export")
        if manifest["calendar"]["capture_samples"] != reference["calendar"]["capture_samples"]:
            raise ValueError(f"capture length differs in {arm} export")
        if manifest["power"]["complex_noise_variance"] != reference["power"]["complex_noise_variance"]:
            raise ValueError(f"noise variance differs in {arm} export")
    expected = {"composite": (True, True), "data-only": (True, False),
                "helper-only": (False, True)}
    for arm, (data_on, helper_on) in expected.items():
        m = manifests[arm]
        if (bool(m["data_enabled"]), bool(m["helper_enabled"])) != (data_on, helper_on):
            raise ValueError(f"export controls do not match {arm}")


def analyze(folders: dict[str, Path], work: Path, case: dict) -> dict:
    manifests = {name: json.loads((folder / "manifest.json").read_text())
                 for name, folder in folders.items()}
    _match_manifests(manifests)
    m = manifests["composite"]
    fs = int(m["sample_rate_hz"])
    calendar = m["calendar"]
    ch = m["channel"]
    # Reuse the exact clock and RX-rate grid convention used by the sampled
    # receiver, while filtering the actual native samples (which already
    # contain the simulated transmitter/channel clock effects).
    clock_values, doppler_values = public_clock_grids(
        m, case.get("clock_step_ppm"), int(case.get("doppler_scale_count", 1)))
    support = _frontend_support(m, "rate-aware", clock_values, doppler_values)
    frontend = rate_aware_frontend(
        fs, support["required_nominal_edge_hz"],
        rejected_bands_hz=support["rejected_helper_bands_hz"])
    if (frontend["output_sample_rate"] != support["output_sample_rate_hz"] or
            frontend["decimation"] != support["decimation"]):
        raise RuntimeError("receiver and diagnostic rate-aware frontend plans differ")
    taps = data_fir_taps("rate-aware", sample_rate=fs,
                         output_sample_rate=support["output_sample_rate_hz"],
                         pass_edge_hz=support["pass_edge_hz"],
                         stop_edge_hz=support["stop_edge_hz"])
    decimation = int(support["decimation"])
    fs_out = fs / decimation
    fir_tail_s = (len(taps) - 1) / fs
    crop = calendar["data_sample_offset"] / fs
    source_duration = calendar["data_source_samples"] / fs
    arrival_low, arrival_high = map(float, calendar["arrival_prior_seconds"])
    delay_s = float(ch["spread_delay_ms"]) * .001
    # Public uncertainty defines the crop. It is widened by one complete FIR
    # duration at each edge and retains source/channel/receiver tails.
    crop_lo = max(0., crop + arrival_low - fir_tail_s)
    crop_hi = crop + source_duration + arrival_high + delay_s + fir_tail_s
    raw_lo = max(0, math.floor(crop_lo * fs))
    raw_hi = min(int(calendar["capture_samples"]), math.ceil(crop_hi * fs))
    out_lo = max(0, raw_lo // decimation)
    out_hi = min(math.ceil((int(calendar["capture_samples"]) + len(taps) - 1) / decimation),
                 math.ceil(raw_hi / decimation))
    if raw_hi <= raw_lo or out_hi <= out_lo:
        raise ValueError("public DATA crop is empty")

    capture_start = int(round(float(calendar["capture_lead_seconds"]) * fs))
    leading_raw_end = min(int(calendar["capture_samples"]), capture_start + 36 * fs)
    leading_out_start = min(out_lo, capture_start // decimation)
    leading_out_end = min(out_hi, math.ceil(leading_raw_end / decimation))
    noise_variance = float(m["power"]["complex_noise_variance"])
    expected_filtered_noise_rms = math.sqrt(noise_variance * float(np.sum(taps * taps)))

    arrays = {}
    raw_hashes = {}
    raw_metadata = {}
    try:
        for arm, folder in folders.items():
            manifest = manifests[arm]
            raw, _ = _load_capture(folder, manifest)
            raw_hashes[arm] = sha256(folder / manifest["observation"]["file"])
            raw_metadata[arm] = dict(samples=len(raw), bytes=(folder / manifest["observation"]["file"]).stat().st_size,
                                     sha256=raw_hashes[arm])
            out = _filter_to_memmap(raw, taps, decimation, len(raw),
                                    work / f"filtered-{arm}.c128")
            arrays[arm] = out
            del raw

        c = arrays["composite"][out_lo:out_hi]
        d = arrays["data-only"][out_lo:out_hi]
        h = arrays["helper-only"][out_lo:out_hi]
        data_raw, _ = _load_capture(folders["data-only"], manifests["data-only"])
        raw_data_window = data_raw[raw_lo:raw_hi]
        raw_data_energy = _energy(raw_data_window, fs)
        del data_raw, raw_data_window

        # Full complex-FFT front end output includes FIR convolution tails;
        # use the original decimation phase and energy/sample-rate conversion.
        data_out_energy = _energy(d, fs_out)
        helper_out_energy = _energy(h, fs_out)
        composite_out_energy = _energy(c, fs_out)
        retained_ratio = data_out_energy / raw_data_energy if raw_data_energy else None
        helper_to_data = helper_out_energy / data_out_energy if data_out_energy else None
        residual_rms, residual_peak = _difference_metrics(c, d, h)
        residual_noise_ratio = (residual_rms / expected_filtered_noise_rms
                                if expected_filtered_noise_rms else None)

        lead_lo = leading_out_start
        lead_hi = leading_out_end
        lead_rms, lead_peak = _difference_metrics(
            arrays["composite"][lead_lo:lead_hi],
            arrays["helper-only"][lead_lo:lead_hi])
        lead_noise_ratio = (lead_rms / expected_filtered_noise_rms
                            if expected_filtered_noise_rms else None)
        lead_seconds = max(0., (lead_hi - lead_lo) / fs_out)

        validity_counts = {}
        for arm, folder in folders.items():
            validity = manifests[arm]["validity"]
            mask = np.memmap(folder / validity["file"], dtype="u1", mode="r")
            validity_counts[arm] = dict(valid=int(np.count_nonzero(mask)),
                                        total=int(mask.size))
            del mask

        result = dict(
            case_id=case["id"],
            status="measured_sampled_waveform_diagnostic",
            configuration={
                "case": m["case"], "sample_rate_hz": fs,
                "inner_rate_hz": m["format"]["inner_rate_hz"],
                "added_symbols": m["format"]["added_symbols"],
                "fhss_envelope_only": m["format"]["fhss_envelope_only"],
                "rf_hz": case["export_args"][case["export_args"].index("--rf-hz") + 1]
                    if "--rf-hz" in case["export_args"] else None,
                "public_epoch_seconds": m["public_epoch_seconds"],
                "key_seed": m["key_seed"], "sample_clock_grid_ppm": list(clock_values),
                "doppler_scale_grid": list(doppler_values),
                "arrival_prior_seconds": [arrival_low, arrival_high],
                "delay_seconds": delay_s,
                "selective_perturbation": ch["selective_perturbation"],
                "noise_variance_raw": noise_variance,
                "cn0_override_db_hz": m["power"]["data_cn0_db_hz"],
            },
            frontend=dict(profile="rate-aware", input_sample_rate_hz=fs,
                output_sample_rate_hz=fs_out, decimation=decimation,
                pass_edge_hz=support["pass_edge_hz"], stop_edge_hz=support["stop_edge_hz"],
                required_nominal_edge_hz=support["required_nominal_edge_hz"],
                helper_stopbands_hz=support["rejected_helper_bands_hz"],
                tap_count=len(taps), fir_duration_seconds=fir_tail_s,
                filtered_noise_rms_expected=expected_filtered_noise_rms,
                filter_engine="scipy.signal.oaconvolve(full), original [::D] phase"),
            public_data_crop=dict(start_seconds=crop_lo, stop_seconds=crop_hi,
                raw_start_sample=raw_lo, raw_stop_sample=raw_hi,
                filtered_start_sample=out_lo, filtered_stop_sample=out_hi,
                raw_crop_duration_seconds=(raw_hi - raw_lo) / fs,
                filtered_crop_duration_seconds=(out_hi - out_lo) / fs_out,
                includes_public_arrival_range=True, includes_delay_and_fir_tail=True,
                uses_receiver_truth=False),
            energy=dict(raw_data_only_crop_joules_normalized=raw_data_energy,
                filtered_data_only_crop_joules_normalized=data_out_energy,
                filtered_composite_crop_joules_normalized=composite_out_energy,
                filtered_helper_only_in_data_crop_joules_normalized=helper_out_energy,
                filtered_data_energy_retained_ratio=data_out_energy / raw_data_energy
                    if raw_data_energy else None,
                helper_to_data_energy_ratio=helper_to_data,
                raw_data_energy_per_crop_second=raw_data_energy / ((raw_hi - raw_lo) / fs),
                filtered_data_energy_per_crop_second=data_out_energy / ((out_hi - out_lo) / fs_out),
                filtered_helper_energy_per_crop_second=helper_out_energy / ((out_hi - out_lo) / fs_out)),
            linearity=dict(
                composite_minus_data_minus_helper_residual_rms=residual_rms,
                composite_minus_data_minus_helper_residual_peak=residual_peak,
                residual_rms_divided_by_nominal_filtered_thermal_noise= residual_noise_ratio,
                leading_36s_composite_minus_helper_only_rms=lead_rms,
                leading_36s_composite_minus_helper_only_peak=lead_peak,
                leading_36s_rms_divided_by_nominal_filtered_thermal_noise=lead_noise_ratio,
                leading_observed_seconds=lead_seconds,
                interpretation="Remainders include any non-identical seeded-noise draws, floating-point error, and channel/nonlinear effects; ratios are diagnostics, not an admission threshold."),
            exports={arm: dict(manifest_sha256=sha256(folder / "manifest.json"),
                               public_geometry_sha256=hashlib.sha256(json.dumps(
                                   public_geometry(manifests[arm]), sort_keys=True).encode()).hexdigest(),
                               raw_observation=raw_metadata[arm],
                               validity=validity_counts[arm])
                     for arm, folder in folders.items()},
            limits=[
                "This is a deterministic sampled-channel diagnostic, not a false-admission or sensitivity qualification.",
                "It does not establish rare frequency-selective fades, operational tail probabilities, or physical transceiver behavior.",
                "The public finite FIR and crop preserve the modeled skirts and channel response; they do not imply compact spectral support.",
                "At CN0=200 dB-Hz the thermal noise is intentionally negligible, so nonlinear residual interpretation is noise-floor limited.",
            ],
        )
        return result, raw_hashes
    finally:
        for array in arrays.values():
            try:
                array.flush()
                mmap = getattr(array, "_mmap", None)
                if mmap is not None:
                    mmap.close()
            except Exception:
                pass
        for path in work.glob("filtered-*.c128"):
            path.unlink(missing_ok=True)


def _source_receipt(exporter: Path, protocol: Path) -> dict:
    paths = [exporter, ROOT / "tools/triad-helper-export.cpp",
             TOOLS / "triad_helper_receiver.py", TOOLS / "triad_helper_study.py",
             TOOLS / "triad_helper_assistance.py", Path(__file__)]
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                         capture_output=True, text=True)
    return dict(protocol_sha256=sha256(protocol),
                code_and_binary_sha256={str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path):
                                        file_sha256_optional(path) for path in paths},
                git_head=git.stdout.strip() if git.returncode == 0 else None,
                git_head_status=git.returncode)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exporter", required=True, type=Path)
    parser.add_argument("--protocol", required=True, type=Path)
    parser.add_argument("--case", required=True)
    parser.add_argument("--output", required=True, type=Path,
                        help="new empty output directory; all capture exports are made inside")
    args = parser.parse_args()
    exporter = args.exporter.resolve()
    protocol_path = args.protocol.resolve()
    output = args.output.resolve()
    if not exporter.is_file() or not os.access(exporter, os.X_OK):
        parser.error("--exporter must name an executable native triad_helper_export binary")
    if not protocol_path.is_file():
        parser.error("--protocol file does not exist")
    if output.exists() and any(output.iterdir()):
        parser.error("--output must be a new or empty directory")
    output.mkdir(parents=True, exist_ok=True)
    protocol = json.loads(protocol_path.read_text())
    cases = {entry["id"]: entry for entry in protocol.get("cohorts", [])}
    if args.case not in cases:
        parser.error(f"unknown --case {args.case!r}; choose one of {', '.join(cases)}")
    case = cases[args.case]
    source_receipt = _source_receipt(exporter, protocol_path)
    folders = {"composite": output / "composite", "data-only": output / "data-only",
               "helper-only": output / "helper-only"}
    controls = {"composite": ("on", "on"), "data-only": ("on", "off"),
                "helper-only": ("off", "on")}
    receipt = dict(schema="triad-helper-sampled-interference-receipt-v1",
        case_id=args.case, started_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        source=source_receipt, native_exports={})
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    for arm, (data, helper) in controls.items():
        folder = folders[arm]
        folder.mkdir()
        command = [str(exporter), *case["export_args"], "--seconds", str(case["seconds"]),
                   "--seed", str(case["seed_base"]), "--cn0", "200",
                   "--data", data, "--helper", helper, "--output", str(folder)]
        log = output / f"native-{arm}.log"
        receipt["native_exports"][arm] = run_checked(command, log)
        (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")

    # A successful native export is not enough to delete evidence. Preserve all
    # raw samples if any alignment, hash, or convolution step raises.
    result, raw_hashes = analyze(folders, output, case)
    result["source"] = source_receipt
    result["native_commands"] = receipt["native_exports"]
    result["raw_capture_sha256_before_removal"] = raw_hashes
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    receipt["analysis"] = "success"
    receipt["completed_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")

    # Retain manifests, truth receipts, commands, logs, hashes and compact
    # results. Remove only large sampled arrays, and only after successful
    # analysis and receipt persistence.
    for arm, folder in folders.items():
        for manifest_key in ("observation", "validity"):
            manifest = json.loads((folder / "manifest.json").read_text())
            filename = manifest[manifest_key]["file"]
            (folder / filename).unlink(missing_ok=True)
    print(json.dumps(dict(output=str(output), result=str(output / "result.json"),
                          raw_hashes=raw_hashes), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

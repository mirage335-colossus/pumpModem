#!/usr/bin/env python3
"""Direct paired CPU/CUDA Helper benchmark; private experiment, not routine CI.

One native signal capture and one shared immutable prepared observation. Each
backend scores the complete Helper-selected bank once cold and three times warm.
The supervisor bounds the entire process tree, including imports/native export.
No acquisition pruning, prediction, calibration or sensitivity claim is made.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import sys
import time
import traceback

REPO = Path(__file__).resolve().parents[2]
DEFAULT_PROTOCOL = REPO / 'local-evidence/triad-helper-extended/protocol-v1.json'
COHORT = 'rate24000-hf8-each65'
LL_ATOL = 5e-4
LL_RTOL = 2e-5
REPEATS = 4


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, default=DEFAULT_PROTOCOL)
    parser.add_argument('--exporter', type=Path, default=REPO / 'build/dev-cli/triad_helper_export')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--seed', type=int, default=9900001)
    parser.add_argument('--bit', type=int, choices=(0, 1), default=1)
    parser.add_argument('--cuda-device', default='cuda:0')
    parser.add_argument('--budget-seconds', type=float, default=600.)
    parser.add_argument('--native-timeout-seconds', type=float, default=240.)
    parser.add_argument('--retain-arrays', action='store_true')
    parser.add_argument('--check-api', action='store_true', help='Import/signature and synthetic comparison checks only; no DSP/native/GPU run.')
    parser.add_argument('--_worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if not 0 < args.budget_seconds <= 600 or not 0 < args.native_timeout_seconds <= 240:
        parser.error('total budget must be in (0,600]s and native timeout in (0,240]s')
    if not 0 <= args.seed < 2**64:
        parser.error('seed must fit uint64')
    if not args.cuda_device.startswith('cuda:') or not args.cuda_device[5:].isdigit():
        parser.error('explicit logical CUDA device required, e.g. cuda:0')
    if args.output is None and not args.check_api:
        parser.error('--output is required')
    args.protocol = args.protocol.resolve(strict=True)
    args.exporter = args.exporter.resolve(strict=True)
    if args.output is not None:
        args.output = args.output.resolve()
    return args


def case_from_protocol(args):
    protocol = json.loads(args.protocol.read_text())
    matches = [x for x in protocol['cohorts'] if x['id'] == COHORT]
    if len(matches) != 1:
        raise ValueError('exact frozen high-rate HF cohort is missing/ambiguous')
    case = matches[0]
    for c in protocol['cohorts']:
        n = sum(c.get(k, 0) for k in ('calibration_count', 'signal_count', 'null_count'))
        if c['seed_base'] <= args.seed < c['seed_base'] + n:
            raise ValueError('benchmark seed overlaps a frozen campaign schedule')
    if (case.get('frequency_batch_size') != 8 or case.get('max_cached_hypotheses') != 13 or
            case.get('lag_steps') != [1] or case.get('erasure', 'none') != 'none' or
            case.get('frontend_profile') != 'rate-aware'):
        raise ValueError('frozen cohort no longer has the reviewed batch8/cache13/lag1/rate-aware/no-erasure policy')
    managed = {'--output', '--seed', '--bit', '--data', '--helper', '--seconds', '--templates', '--plan-only'}
    if managed.intersection(case['export_args']):
        raise ValueError('frozen export_args contains a managed flag')
    return case


def numeric_modules():
    # Set before any BLAS/OpenMP/torch import, including the supervisor child.
    for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
                 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        os.environ[name] = '2'
    sys.path.insert(0, str(REPO / 'tools'))
    import numpy as np
    import scipy
    import torch
    from triad_helper_campaign import source_hashes
    from triad_helper_receiver import PreparedDataObservation
    from triad_helper_study import HelperComparison, public_clock_grids
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision('highest')
    return np, scipy, torch, HelperComparison, public_clock_grids, source_hashes, PreparedDataObservation


def receiver_options(case, manifest, clock_grids, device):
    clocks, scales = clock_grids(manifest, case.get('clock_step_ppm', 0.), case.get('doppler_scale_count', 1))
    return dict(device=device, precision='fp32', fft_backend='batched',
        frontend_profile=case['frontend_profile'], clock_ppm_values=clocks, doppler_scale_values=scales,
        lag_step=1, aligned_fft_grid=case.get('aligned_fft_grid', True), frequency_batch_size=8,
        max_cached_hypotheses=13, memory_limit_bytes=case['memory_limit_bytes'])


def compare_scores(reference, candidate, np):
    """Compare actual full-bank mixtures/hypotheses, not just the raw bit."""
    a, b = reference['assisted'], candidate['assisted']
    arrays = [('bit', a['bit_log_likelihoods'], b['bit_log_likelihoods']),
              ('epoch', a['epoch_bit_log_likelihoods'], b['epoch_bit_log_likelihoods'])]
    ah, bh = a['hypothesis_bit_log_likelihoods'], b['hypothesis_bit_log_likelihoods']
    keys = ('epoch', 'clock_ppm', 'doppler_scale')
    hypothesis_keys_match = [[h.get(k) for k in keys] for h in ah] == [[h.get(k) for k in keys] for h in bh]
    arrays.append(('hypothesis', [h['bit_log_likelihoods'] for h in ah], [h['bit_log_likelihoods'] for h in bh]))
    differences = {}
    for name, left, right in arrays:
        x, y = np.asarray(left, float), np.asarray(right, float)
        if x.shape != y.shape or not np.isfinite(x).all() or not np.isfinite(y).all():
            differences[name] = dict(passed=False, shape_left=list(x.shape), shape_right=list(y.shape), finite=False)
            continue
        delta = np.abs(x - y)
        allowed = LL_ATOL + LL_RTOL * np.abs(x)
        order_x = np.argsort(-x.ravel(), kind='stable')
        order_y = np.argsort(-y.ravel(), kind='stable')
        rank_x, rank_y = np.empty(x.size, int), np.empty(y.size, int)
        rank_x[order_x], rank_y[order_y] = np.arange(x.size), np.arange(y.size)
        differences[name] = dict(passed=bool(np.all(delta <= allowed)), finite=True,
            max_absolute_log_likelihood_error=float(np.max(delta, initial=0.)),
            max_error_over_frozen_tolerance=float(np.max(delta / allowed, initial=0.)),
            max_rank_displacement=int(np.max(np.abs(rank_x - rank_y), initial=0)),
            rank_positions_changed=int(np.sum(rank_x != rank_y)),
            rank_scope='Descriptive stable ranking of all retained scores; tiny secondary near-ties may exchange order.')
    checks = dict(input_matches=reference['input_sha256'] == candidate['input_sha256'],
        template_matches=reference['template_sha256'] == candidate['template_sha256'],
        complete_search_banks_match=reference['search_banks'] == candidate['search_banks'],
        complete_data_geometry_matches=a.get('geometry') == b.get('geometry'),
        effective_cache_capacity_matches=a.get('resources',{}).get('maximum_cached_hypotheses') == b.get('resources',{}).get('maximum_cached_hypotheses'),
        hypothesis_keys_match=hypothesis_keys_match,
        bit_matches=a['bit'] == b['bit'], epoch_matches=a['best_epoch_offset_seconds'] == b['best_epoch_offset_seconds'],
        winning_parameters_match=a['best_group_public_parameters'] == b['best_group_public_parameters'],
        likelihoods_within_tolerance=all(x['passed'] for x in differences.values()))
    return dict(passed=all(checks.values()), checks=checks, numerical=differences,
        tolerance=dict(absolute=LL_ATOL, relative=LL_RTOL, frozen_before_execution=True),
        scope='Numerical equivalence on one paired observation; no admission/detection calibration or performance-regression confidence bound.')


def api_check(args):
    case = case_from_protocol(args)
    np, scipy, torch, Comparison, grids, hashes, Prepared = numeric_modules()
    options = dict(device='cpu', precision='fp32', fft_backend='batched', frontend_profile='rate-aware',
        clock_ppm_values=(0.,), doppler_scale_values=(1.,), lag_step=1, aligned_fft_grid=True,
        frequency_batch_size=8, max_cached_hypotheses=13, memory_limit_bytes=case['memory_limit_bytes'])
    inspect.signature(Comparison).bind(Path('capture'), Path('capture'), **options)
    inspect.signature(Comparison.prepare_capture).bind(object(), Path('capture'))
    inspect.signature(Comparison.score_capture).bind(object(), {}, include_baseline=False)
    inspect.signature(grids).bind({}, 0., 1)
    assert {'samples', 'preprocessing_id', 'filtering_seconds', 'validity_id'} <= Prepared.__dataclass_fields__.keys()
    value = dict(input_sha256='a', template_sha256='b', search_banks={'f': [0.]}, assisted=dict(
        bit=0, best_epoch_offset_seconds=0, best_group_public_parameters={'arrival_seconds': .1},
        bit_log_likelihoods=[1., 0.], epoch_bit_log_likelihoods=[[1., 0.]],
        hypothesis_bit_log_likelihoods=[dict(epoch=0, clock_ppm=0., doppler_scale=1., bit_log_likelihoods=[1., 0.])]))
    assert compare_scores(value, value, np)['passed']
    changed = json.loads(json.dumps(value)); changed['assisted']['bit_log_likelihoods'][0] += .1
    assert not compare_scores(value, changed, np)['passed']
    changed = json.loads(json.dumps(value)); changed['assisted']['bit'] = 1
    assert not compare_scores(value, changed, np)['passed']
    print(json.dumps(dict(status='api-and-comparison-checks-passed', cohort=case['id'],
        protocol_sha256=digest(args.protocol), torch=torch.__version__, cuda_available=torch.cuda.is_available(),
        scope='Syntax/signatures and synthetic comparison controls only; no receiver instantiation, native export, GPU execution or throughput qualification.')))
    return 0


def worker(args):
    start = time.perf_counter(); phase = 'imports'; output = args.output
    try:
        plan = json.loads((output / 'plan.json').read_text())
        if (digest(args.protocol) != plan['protocol_sha256'] or digest(args.exporter) != plan['exporter_sha256'] or
                digest(__file__) != plan['script_sha256']):
            raise ValueError('protocol/native binary/benchmark script changed after supervisor freeze')
        case = case_from_protocol(args)
        np, scipy, torch, Comparison, grids, source_hashes, Prepared = numeric_modules()
        imports_seconds = time.perf_counter() - start
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable: benchmark cannot silently fall back to CPU')
        sources = source_hashes(); sources['experiment_script'] = digest(__file__)
        sources['tools/triad_helper_broad_campaign.py'] = digest(REPO / 'tools/triad_helper_broad_campaign.py')
        def unchanged():
            if source_hashes() != {k:v for k,v in sources.items() if k not in ('experiment_script', 'tools/triad_helper_broad_campaign.py')}:
                raise RuntimeError('source changed during benchmark')
            if (digest(__file__) != sources['experiment_script'] or digest(args.exporter) != plan['exporter_sha256'] or
                    digest(REPO / 'tools/triad_helper_broad_campaign.py') != sources['tools/triad_helper_broad_campaign.py'] or
                    digest(args.protocol) != plan['protocol_sha256']):
                raise RuntimeError('script/native identity changed during benchmark')
        def sync(device):
            if device.startswith('cuda:'):
                torch.cuda.synchronize(device)
        phase = 'cuda-context-initialization'; mark = time.perf_counter()
        torch.cuda.set_device(args.cuda_device); torch.cuda.init(); sync(args.cuda_device)
        cuda_initialization_seconds = time.perf_counter() - mark
        prop = torch.cuda.get_device_properties(args.cuda_device)
        gpu = dict(logical_device=args.cuda_device, name=prop.name, total_memory=prop.total_memory,
            capability=list(torch.cuda.get_device_capability(args.cuda_device)), multiprocessors=prop.multi_processor_count,
            uuid=str(getattr(prop, 'uuid', 'unavailable')))
        try:
            smi = subprocess.run(['nvidia-smi', '--query-gpu=name,uuid,driver_version', '--format=csv,noheader'],
                check=False, capture_output=True, text=True, timeout=5)
            gpu['nvidia_smi'] = dict(returncode=smi.returncode, output=smi.stdout.strip(), stderr=smi.stderr.strip())
        except (OSError, subprocess.TimeoutExpired) as error:
            gpu['nvidia_smi'] = dict(unavailable=str(error))
        environment = dict(platform=platform.platform(), python=sys.version, numpy=np.__version__, scipy=scipy.__version__,
            torch=torch.__version__, torch_cuda=torch.version.cuda, gpu=gpu, cpu=platform.processor(),
            cpu_affinity=sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None,
            torch_threads=torch.get_num_threads(), torch_interop_threads=torch.get_num_interop_threads(),
            cuda_matmul_tf32=torch.backends.cuda.matmul.allow_tf32, cudnn_tf32=torch.backends.cudnn.allow_tf32,
            float32_matmul_precision=torch.get_float32_matmul_precision(),
            thread_environment={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')})
        cpuinfo = Path('/proc/cpuinfo')
        if cpuinfo.exists():
            environment['cpu_model'] = next((x.split(':',1)[1].strip() for x in cpuinfo.read_text().splitlines() if x.startswith('model name')), 'unavailable')
        try:
            from threadpoolctl import threadpool_info
            environment['numerical_library_threadpools'] = threadpool_info()
        except ImportError:
            environment['numerical_library_threadpools'] = 'threadpoolctl unavailable; explicit thread settings reported above'
        write_json(output / 'environment.json', environment)
        phase = 'native-export'; capture = output / 'capture'
        command = [str(args.exporter), *case['export_args'], '--output', str(capture), '--seconds', str(case['seconds']),
            '--seed', str(args.seed), '--bit', str(args.bit), '--data', 'on', '--helper', 'on', '--templates']
        mark = time.perf_counter()
        with (output / 'native-export.log').open('x') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=args.native_timeout_seconds)
        native_seconds = time.perf_counter() - mark; unchanged()
        manifest = json.loads((capture / 'manifest.json').read_text())
        if manifest['format']['inner_rate_hz'] != 24000 or manifest['sample_rate_hz'] != 96000:
            raise ValueError('native exporter did not produce the frozen rate24000/96000-Hz capture')
        if manifest['power'].get('data_power_reference_policy') != 'whole-active':
            raise ValueError('benchmark requires the current whole-active power reference')
        identities = {name:dict(file=manifest[name]['file'], sha256=digest(capture / manifest[name]['file']),
                               bytes=(capture / manifest[name]['file']).stat().st_size)
                      for name in ('observation','validity','templates')}
        constructors = {}; comparisons = {}
        for label, device in (('cpu','cpu'), ('cuda',args.cuda_device)):
            phase = label + '-constructor'; sync(device); mark = time.perf_counter()
            comparisons[label] = Comparison(capture, capture, **receiver_options(case, manifest, grids, device))
            sync(device); constructors[label] = time.perf_counter() - mark
        cpu, cuda = comparisons['cpu'], comparisons['cuda']
        if cpu.shared_capture_id != cuda.shared_capture_id or cpu.template_hash != cuda.template_hash:
            raise ValueError('CPU/CUDA public preparation identities differ; no cross-backend substitution allowed')
        phase = 'shared-capture-preparation'; mark = time.perf_counter()
        prepared = cpu.prepare_capture(capture); shared_seconds = time.perf_counter() - mark
        if not isinstance(prepared['prepared'], Prepared) or prepared['prepared'].samples.flags.writeable:
            raise ValueError('shared prepared samples must be the immutable actual receiver workspace')
        prepared_hash = hashlib.sha256(memoryview(prepared['prepared'].samples).cast('B')).hexdigest()
        if prepared['input_sha256'] != identities['observation']['sha256']:
            raise ValueError('prepared input identity differs from frozen native capture')
        setup = dict(case=case, sources=sources, exporter_sha256=plan['exporter_sha256'], command=command,
            identities=identities, manifest_sha256=digest(capture/'manifest.json'), imports_seconds=imports_seconds,
            native_export_seconds=native_seconds, constructor_seconds=constructors,
            cuda_initialization_seconds=cuda_initialization_seconds, shared_preparation_seconds=shared_seconds,
            helper_seconds=prepared['assistance']['wall_seconds'], filtering_seconds=prepared['prepared'].filtering_seconds,
            prepared_samples_sha256=prepared_hash, prepared_samples=len(prepared['prepared'].samples),
            shared_capture_id=prepared['shared_capture_id'],
            preprocessing_id=prepared['prepared'].preprocessing_id,
            procedure_ids={k:v.procedure_id for k,v in comparisons.items()},
            constructor_order=['cpu', 'cuda'],
            shared_preparation_scope='One actual CPU Helper estimate/FIR/load/hash pass, shared unchanged with both backends; device transfer remains inside backend scoring.')
        write_json(output/'setup.json', setup)
        results = {'cpu':[], 'cuda':[]}; timings = {'cpu':[], 'cuda':[]}; checks = []
        for repeat in range(REPEATS):
            order = ('cpu','cuda') if repeat % 2 == 0 else ('cuda','cpu')
            for label in order:
                device = 'cpu' if label == 'cpu' else args.cuda_device
                phase = f'{label}-score-{repeat}'; unchanged(); sync(device)
                if label == 'cuda':torch.cuda.reset_peak_memory_stats(args.cuda_device)
                mark = time.perf_counter()
                result = comparisons[label].score_capture(prepared, include_baseline=False)
                sync(device); elapsed = time.perf_counter() - mark
                arithmetic=result['assisted']['arithmetic']
                if (arithmetic['requested_correlation_precision']!='fp32' or
                        arithmetic.get('observation_fft_and_products') != 'torch.complex64' or
                        arithmetic.get('tf32_allowed') or arithmetic.get('implicit_fallback')):
                    raise ValueError('actual arithmetic violates strict FP32/no-fallback policy')
                if result.get('baseline') is not None or result['executed_arms'] != ['assisted']:
                    raise ValueError('benchmark unexpectedly executed or supplied baseline')
                memory = None if label == 'cpu' else dict(allocated=torch.cuda.memory_allocated(args.cuda_device),
                    reserved=torch.cuda.memory_reserved(args.cuda_device), peak_allocated=torch.cuda.max_memory_allocated(args.cuda_device),
                    peak_reserved=torch.cuda.max_memory_reserved(args.cuda_device))
                record = dict(backend=label, repeat=repeat, state='cold' if repeat==0 else 'warm',
                    synchronized_wall_seconds=elapsed, cuda_memory=memory, result=result)
                write_json(output/f'{label}-score-{repeat}.json', record)
                results[label].append(result); timings[label].append(elapsed)
                if repeat:checks.append(dict(kind='within-backend-replay',backend=label,repeat=repeat,**compare_scores(results[label][0],result,np)))
            checks.append(dict(kind='paired-backend',repeat=repeat,**compare_scores(results['cpu'][repeat],results['cuda'][repeat],np)))
        unchanged()
        if hashlib.sha256(memoryview(prepared['prepared'].samples).cast('B')).hexdigest()!=prepared_hash:
            raise ValueError('scoring mutated shared prepared samples')
        # Evaluator truth is opened only after every score and comparison exists.
        truth=json.loads((capture/'evaluator-truth.json').read_text())
        stage_summary={}
        for label in ('cpu','cuda'):
            stage_summary[label]=dict(cold_score_seconds=timings[label][0],warm_score_seconds=timings[label][1:],
                warm_score_median_seconds=statistics.median(timings[label][1:]),
                warm_correlation_batch_seconds=[r['assisted']['timing']['observation_fft_seconds'] for r in results[label][1:]],
                correlation_batch_scope='Maintained observation_fft_seconds: CFO correlation batches including modulation/FFT/IFFT/indexing/refinement; excludes initial base FFTs and observation upload, both included in total score.',
                cold_factor_preparation_seconds=results[label][0]['assisted']['timing']['hypothesis_preparation_seconds'],
                warm_factor_preparation_seconds=[r['assisted']['timing']['hypothesis_preparation_seconds'] for r in results[label][1:]],
                cold_receiver_composed_seconds=constructors[label]+shared_seconds+timings[label][0]+(cuda_initialization_seconds if label=='cuda' else 0.))
        ratios=dict(warm_prepared_score_cpu_over_cuda=stage_summary['cpu']['warm_score_median_seconds']/stage_summary['cuda']['warm_score_median_seconds'],
            warm_correlation_batch_cpu_over_cuda=statistics.median(stage_summary['cpu']['warm_correlation_batch_seconds'])/statistics.median(stage_summary['cuda']['warm_correlation_batch_seconds']),
            cold_score_cpu_over_cuda=timings['cpu'][0]/timings['cuda'][0],
            cold_receiver_composed_cpu_over_cuda=stage_summary['cpu']['cold_receiver_composed_seconds']/stage_summary['cuda']['cold_receiver_composed_seconds'])
        removed=[]
        if not args.retain_arrays:
            for identity in identities.values():
                (capture/identity['file']).unlink();removed.append(identity)
        report=dict(schema='triad-helper-paired-backend-benchmark-v1',
            status='completed' if all(c['passed'] for c in checks) else 'numerical-disagreement',
            phase='finished',worker_wall_seconds=time.perf_counter()-start,setup=setup,environment=environment,
            stages=stage_summary,ratios=ratios,numerical_checks=checks,
            truth_evaluated_after_all_scores=dict(source_bit=truth['source_bit'],source_energy=truth['source_energy'],
                truth_sha256=digest(capture/'evaluator-truth.json')),
            removed_arrays=removed,
            scope=['Direct same-capture measurements, not frozen forecasts or a regression confidence interval.',
                'One cold and three warm scores per backend; interleaved order; no sensitivity or admission qualification.',
                'Warm scoring reuses identical prepared data and cached public factors; it is not four independent captures.',
                'Rank checks cover retained epoch/clock/rate mixtures; streamed individual CFO/arrival scores are not retained. Final raw bit and diagnostic winning parameters are checked exactly.',
                'Cold stage composition includes each constructor/shared preprocessing and CUDA initialization when applicable; native generation, imports and process startup are reported separately.',
                'Shared preparation executes once. Do not add its cost four times or count nested stage timings twice.',
                'Score memory ceilings are conservative array bounds; CUDA allocator peaks are measured separately and are not host RSS.'])
        write_json(output/'benchmark.json',report)
        return 0 if report['status']=='completed' else 2
    except Exception as error:
        write_json(output/'benchmark.json',dict(status='failed',phase=phase,error_type=type(error).__name__,error=str(error),
            traceback=traceback.format_exc(),worker_wall_seconds=time.perf_counter()-start,
            scope='Incomplete benchmark; retained individual score files are observations, not a completed paired throughput result.'))
        return 2


def supervisor(args):
    started=time.perf_counter();case=case_from_protocol(args)
    args.output.mkdir(parents=True,exist_ok=False)
    write_json(args.output/'plan.json',dict(schema='triad-helper-paired-backend-plan-v1',cohort=case,
        protocol_sha256=digest(args.protocol),exporter_sha256=digest(args.exporter),script_sha256=digest(__file__),
        seed=args.seed,bit=args.bit,repeats=REPEATS,cpu_threads=2,frequency_batch_size=8,cache_capacity=13,
        likelihood_tolerance=dict(absolute=LL_ATOL,relative=LL_RTOL),
        budget_seconds=args.budget_seconds,native_timeout_seconds=args.native_timeout_seconds,
        scope='Direct measurement with frozen numerical checks; no prediction or statistical performance gate.'))
    command=[sys.executable,str(Path(__file__).resolve()),'--_worker',*sys.argv[1:]]
    with (args.output/'worker.stdout.log').open('x') as out, (args.output/'worker.stderr.log').open('x') as err:
        process=subprocess.Popen(command,cwd=REPO,stdout=out,stderr=err,start_new_session=True)
        deadline_reached=False
        try:
            process.wait(timeout=max(.01,args.budget_seconds-(time.perf_counter()-started)-3.))
        except subprocess.TimeoutExpired:
            deadline_reached=True
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=1.)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=2.)
    report=dict(status='deadline-exceeded' if deadline_reached else ('completed' if process.returncode==0 else 'failed'),
        returncode=process.returncode,total_wall_seconds=time.perf_counter()-started,
        budget_seconds=args.budget_seconds,command=command,
        scope='Entire supervised process tree: Python imports/startup, native generation, setup, eight scores, outputs and finalization. Deadline termination is not a numerical or throughput pass.')
    write_json(args.output/'supervisor.json',report)
    print(json.dumps(report));return 124 if deadline_reached else process.returncode


def main(argv=None):
    args=parse_args(argv)
    if args.check_api:return api_check(args)
    if args._worker:return worker(args)
    return supervisor(args)


if __name__=='__main__':
    raise SystemExit(main())

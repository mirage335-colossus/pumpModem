#!/usr/bin/env python3
"""Two selected waveform-known diagnostics; never a practical receiver result.

Select the sole raw-bit error and first correctly admitted signal, in frozen
trial order, from the completed Added1000/Rate1/-10 cohort. Regenerate one actual
and three common-seed high-C/N0 captures per case; preserve complete raw tails.
No receiver is rerun. All reductions are bounded, CPU-only and chunked.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import sys
import time
import traceback

REPO = Path(__file__).resolve().parents[2]
COHORT = 'added1000-rate1-minus10'
HIGH_CN0 = 200.
ALPHA = .05
CHUNK = 65536


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def args_from(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--campaign-root', type=Path)
    p.add_argument('--protocol', type=Path, default=REPO / 'local-evidence/triad-helper-extended/protocol-v1.json')
    p.add_argument('--exporter', type=Path, default=REPO / 'build/dev-cli/triad_helper_export')
    p.add_argument('--output', type=Path)
    p.add_argument('--budget-seconds', type=float, default=600.)
    p.add_argument('--native-timeout-seconds', type=float, default=240.)
    p.add_argument('--retain-arrays', action='store_true')
    p.add_argument('--check-api', action='store_true', help='Cheap scalar formulas and optional frozen selection only; no native/DSP execution.')
    p.add_argument('--_worker', action='store_true', help=argparse.SUPPRESS)
    a = p.parse_args(argv)
    if not 0 < a.budget_seconds <= 600 or not 0 < a.native_timeout_seconds <= 240:
        p.error('total budget must be (0,600]s; native timeout (0,240]s')
    if not a.check_api and (a.campaign_root is None or a.output is None):
        p.error('--campaign-root and a new --output are required')
    for key in ('campaign_root', 'protocol', 'exporter', 'output'):
        if getattr(a, key) is not None:
            setattr(a, key, getattr(a, key).resolve())
    return a


def context(a):
    folder = a.campaign_root / COHORT
    global_path = a.campaign_root / 'protocol.json'
    paths = [global_path, a.protocol, folder/'protocol.json', folder/'trials.jsonl',
             folder/'summary.json', folder/'gate-lag-1.json']
    global_protocol, cohort_protocol = read(global_path), read(folder/'protocol.json')
    external, summary, gate = read(a.protocol), read(folder/'summary.json'), read(folder/'gate-lag-1.json')
    require(summary['status'] == 'completed', 'selected cohort is incomplete')
    require(global_protocol['input_protocol_sha256'] == sha(a.protocol), 'input protocol is not the original campaign input')
    matching = [c for c in external['cohorts'] if c['id'] == COHORT]
    require(len(matching) == 1, 'missing/duplicate selected cohort')
    case = matching[0]
    require(cohort_protocol['case'] == case and case in global_protocol['cohorts'], 'global/cohort/input protocols differ')
    require(case.get('erasure', 'none') == 'none' and case['lag_steps'] == [1] and case['arms'] == ['assisted'], 'unsupported erasure or receiver-arm policy')
    require(global_protocol['exporter_sha256'] == cohort_protocol['exporter_sha256'], 'native identity differs across protocols')
    require(global_protocol['source_hashes'] == cohort_protocol['source_hashes'], 'source identity differs across protocols')
    require(sha(folder/'protocol.json') == summary['protocol_sha256'] and
            sha(folder/'gate-lag-1.json') == summary['gate_sha256']['1'], 'cohort protocol/gate summary hashes disagree')
    rows = [json.loads(line) for line in (folder/'trials.jsonl').read_text().splitlines()]
    require(len(rows) == summary['completed_trials'] == len(cohort_protocol['trial_schedule']), 'incomplete trial rows')
    require([r['trial'] for r in rows] == cohort_protocol['trial_schedule'], 'row order or trial schedule changed')
    signals = [r for r in rows if r['trial']['phase'] == 'signal']
    errors, controls = [], []
    for row in signals:
        v = row['variants']['1']; t = row['trial']; decision = v['decisions']['assisted']
        require(v['procedure_id'] == gate['procedure_id'] and
                v['execution_policy_id'] == gate['execution_policy_id'] and
                v['calibration_condition_id'] == gate['calibration_condition_id'], 'score/gate identity mismatch')
        score = v['assisted']['working_presence']
        p_value = (1 + sum(x >= score for x in gate['scores']['assisted'])) / (gate['count'] + 1)
        require(p_value == decision['p_value'] and (p_value <= gate['alpha']) == decision['accepted'], 'saved decision disagrees with frozen gate')
        if v['assisted']['bit'] != t['bit']:
            errors.append(row)
        elif decision['accepted']:
            controls.append(row)
    require(len(errors) == 1 and controls, 'selection requires exactly one raw error and a correctly admitted control')
    selected = [dict(role='sole-raw-bit-error', row=errors[0]), dict(role='first-correct-admitted-control', row=controls[0])]
    for item in selected:
        row = item['row']; trial = row['trial']; capture = folder/trial['id']
        paths.extend([capture/'manifest.json', capture/'evaluator-truth.json'])
        m, t = read(capture/'manifest.json'), read(capture/'evaluator-truth.json')
        require(row['erasure']['recipe'] == 'none' and row['erasure']['missing_rows'] == 0, 'selected input contains erasures')
        require(row['input_sha256'] == row['erasure']['native']['observation_sha256'] == row['variants']['1']['input_sha256'], 'selected native/input identity differs')
        require(t['random_seed_roots']['fixture'] == trial['seed'] and t['source_bit'] == trial['bit'], 'original source truth differs from schedule')
        require(m['power']['data_power_reference_policy'] == 'whole-active', 'historical power reference is outside this diagnostic')
        # Reconstruct the exact original signal command, excluding output path
        # and executable spelling; forbid unreviewed extra native options.
        expected = [*case['export_args'], '--output', row['export_command'][row['export_command'].index('--output')+1],
            '--seconds', str(case['seconds']), '--seed', str(trial['seed']), '--bit', str(trial['bit']), '--data', 'on', '--helper', 'on']
        require(row['export_command'][1:] == expected, 'original native command differs from frozen case/schedule')
        item['original_manifest'] = m; item['original_truth'] = t
    return dict(case=case, selected=selected, gate=gate, source_hashes=global_protocol['source_hashes'],
        exporter_sha256=global_protocol['exporter_sha256'], frozen_inputs={str(p):sha(p) for p in paths},
        selection_counts=dict(signal=len(signals), raw_errors=len(errors), correct_admitted=len(controls)),
        selection_rule='In frozen trial order: sole raw-bit error, then first correct admitted signal. Outcome-selected diagnostics, not representative performance samples.')


def verify_frozen(a, c, script_hash):
    require(sha(a.exporter) == c['exporter_sha256'], 'native binary differs from original campaign')
    for path, expected in c['source_hashes'].items():
        require(sha(REPO/path) == expected, 'source differs from original campaign: '+path)
    for path, expected in c['frozen_inputs'].items():
        require(sha(path) == expected, 'original evidence changed: '+path)
    require(sha(__file__) == script_hash, 'oracle script changed after freeze')


def normalized_manifest(m):
    m = copy.deepcopy(m)
    m.pop('cost', None); m.pop('data_enabled')
    for key in ('data_cn0_db_hz', 'effective_helper_cn0_db_hz', 'complex_noise_variance'):
        m['power'].pop(key)
    for key in ('data_cn0_db_hz', 'effective_helper_cn0_db_hz'):
        m['physics'].pop(key)
    return m


def channel_state(t):
    value = copy.deepcopy(t['channel_report'])
    for key in ('signal_energy_samples', 'observed_energy_samples'):
        value.pop(key)
    selective = value.get('selective_perturbation')
    if selective is not None:
        selective.pop('pre_selective_energy_samples', None)
        selective.pop('post_selective_energy_samples', None)
    return value


def validate_exports(records, original, np):
    actual = records['actual']; m0 = actual['manifest']; t0 = actual['truth']
    om, ot = original['original_manifest'], original['original_truth']; row = original['row']
    for old, new in ((om, m0),):
        x, y = copy.deepcopy(old), copy.deepcopy(new)
        x.pop('cost'); y.pop('cost')
        require(x == y, 'regenerated actual manifest differs beyond timing/cost')
    require(t0 == ot, 'regenerated actual evaluator truth differs')
    require(actual['hashes']['observation']['sha256'] == row['input_sha256'], 'regenerated actual I/Q does not byte-match original')
    require(actual['hashes']['validity']['sha256'] == row['validity_sha256'], 'regenerated validity does not byte-match original')
    fixed_truth_keys = ('source_epoch_offset_seconds', 'arrival_seconds', 'arrival_override',
        'unmodified_arrival_draw_seconds', 'tx', 'rx', 'random_seed_roots')
    for name, r in records.items():
        m,t = r['manifest'],r['truth']
        require(normalized_manifest(m) == normalized_manifest(m0), name+': geometry/gain/power/state metadata differs beyond CN0/control')
        require(all(t[k] == t0[k] for k in fixed_truth_keys), name+': timing/oscillator/random roots differ')
        require(channel_state(t) == channel_state(t0), name+': continuous channel state/tails differ')
        require(t['source_energy']['helper_energy_samples'] == t0['source_energy']['helper_energy_samples'], name+': Helper source energy changed')
        require(r['hashes']['validity']['sha256'] == actual['hashes']['validity']['sha256'], name+': validity differs')
        require(m['observation']['dtype'] == '<c16' and len(m['observation']['shape']) == 1 and
                m['validity']['dtype'] == 'u1' and m['validity']['shape'] == m['observation']['shape'], name+': unsupported raw layout')
        count = m['observation']['shape'][0]
        require(r['hashes']['observation']['bytes'] == count*16 and r['hashes']['validity']['bytes'] == count, name+': incomplete raw files')
        valid = np.memmap(r['folder']/m['validity']['file'], dtype='u1', mode='r', shape=(count,))
        require(all(bool(np.all(valid[i:i+CHUNK] == 1)) for i in range(0,count,CHUNK)), name+': raw erasure mask is not all valid')
        del valid
        expected_cn0 = m0['power']['data_cn0_db_hz'] if name == 'actual' else HIGH_CN0
        require(m['power']['data_cn0_db_hz'] == expected_cn0 and m['helper_enabled'], name+': wrong CN0/Helper setting')
        require(m['data_enabled'] == (name != 'helper-high'), name+': wrong DATA enable control')
        expected_bit = row['trial']['bit'] if name in ('actual','helper-high') else int(name[3])
        require(t['source_bit'] == expected_bit, name+': wrong source bit')
        require(math.isclose(m['power']['complex_noise_variance'], m['sample_rate_hz']*10**(-expected_cn0/10), rel_tol=1e-14), name+': unexpected AWGN convention')
    high_variances = [records[k]['manifest']['power']['complex_noise_variance'] for k in ('bit0-high','bit1-high','helper-high')]
    require(len(set(high_variances)) == 1, 'high-CN0 variances differ')
    require(records['helper-high']['truth']['source_energy']['data_energy_samples'] == 0, 'Helper control contains DATA')
    same = records['bit'+str(row['trial']['bit'])+'-high']
    require(same['truth']['source_energy'] == t0['source_energy'], 'CN0 change altered emitted components')
    return dict(actual_iq_byte_match=True, actual_truth_exact_match=True, all_valid=True,
        unchanged_geometry_gains_physical_powers=True, shared_noise_seed=True,
        manifest_variations_allowed=['data_enabled', 'power.data_cn0_db_hz', 'power.effective_helper_cn0_db_hz', 'power.complex_noise_variance', 'physics.data_cn0_db_hz', 'physics.effective_helper_cn0_db_hz', 'cost'])


def oracle_summary(sums, variance, target_variance, source_bit):
    energy0, energy1, distance = sums['energy0'], sums['energy1'], sums['distance']
    require(min(energy0,energy1,distance,variance,target_variance)>0, 'degenerate oracle distance/variance')
    argument = math.sqrt(distance/(2*variance))
    physical_argument = math.sqrt(distance/(2*target_variance))
    ml_bit = int(sums['ml_numerator'] > 0)
    threshold = statistics.NormalDist().inv_cdf(1-ALPHA/2)
    z = [math.sqrt(2)*sums['dot0_y']/math.sqrt(variance*energy0), math.sqrt(2)*sums['dot1_y']/math.sqrt(variance*energy1)]
    return dict(ml_bit=ml_bit, ml_correct=ml_bit==source_bit, ml_log_likelihood_ratio=sums['ml_numerator']/variance,
        distance_energy_samples=distance, distance_over_residual_noise=distance/variance,
        propagated_data_energy_samples=[energy0,energy1], propagated_energy_over_residual_noise=[energy0/variance,energy1/variance],
        equal_prior_known_channel_pe=.5*math.erfc(argument/math.sqrt(2)), known_channel_q_argument=argument,
        physical_target_noise_known_channel_pe=.5*math.erfc(physical_argument/math.sqrt(2)),
        presence_z_by_bit=z, presence_alpha_union_two=ALPHA, presence_threshold=threshold,
        presence_admitted=bool(max(z)>=threshold), ml_bit_presence_crossed=bool(z[ml_bit]>=threshold),
        theoretical_presence_mean_for_own_word=[math.sqrt(2*energy0/variance),math.sqrt(2*energy1/variance)],
        scope='Known complete channel/oscillators/arrival/epoch/Helper waveform; equal-prior bit test and two fixed-waveform one-sided presence tests. No acquisition search or parameter estimation. Not an implementable receiver or operational admission guarantee.')


def reduce_records(records, source_bit, np):
    m = records['actual']['manifest']; count = m['observation']['shape'][0]
    arrays = {k:np.memmap(r['folder']/r['manifest']['observation']['file'], dtype='<c16', mode='r', shape=(count,)) for k,r in records.items()}
    parts = {k:[] for k in ('energy0','energy1','distance','ml_numerator','dot0_y','dot1_y','noise_energy','noise_mean_real','noise_mean_imag','same_word_noise_identity_error')}
    prefix_max = 0.; prefix_rows = min(count,round(m['sample_rate_hz']))
    # The first one-second interval is before the DATA calendar begins at 38s;
    # verify its full native supports are source-free rather than clipping tails.
    require(m['calendar']['data_calendar_start_seconds'] + m['calendar']['arrival_prior_seconds'][0] > 2, 'source-free prefix assumption invalid')
    for first in range(0,count,CHUNK):
        last = min(count,first+CHUNK); h = arrays['helper-high'][first:last]
        s0 = arrays['bit0-high'][first:last] - h; s1 = arrays['bit1-high'][first:last] - h
        y = arrays['actual'][first:last] - h; delta=s1-s0
        noise = arrays['actual'][first:last] - arrays['bit'+str(source_bit)+'-high'][first:last]
        values = dict(energy0=np.vdot(s0,s0).real, energy1=np.vdot(s1,s1).real, distance=np.vdot(delta,delta).real,
            ml_numerator=2*np.vdot(delta,y-.5*(s0+s1)).real, dot0_y=np.vdot(s0,y).real, dot1_y=np.vdot(s1,y).real,
            noise_energy=np.vdot(noise,noise).real, noise_mean_real=noise.real.sum(dtype=np.float64), noise_mean_imag=noise.imag.sum(dtype=np.float64),
            same_word_noise_identity_error=np.vdot(y-(s0 if source_bit==0 else s1)-noise,y-(s0 if source_bit==0 else s1)-noise).real)
        require(all(math.isfinite(float(v)) for v in values.values()), 'nonfinite reduction')
        for key,value in values.items():parts[key].append(float(value))
        if first < prefix_rows:
            stop=min(last,prefix_rows)-first
            prefix_max=max(prefix_max,float(abs(s0[:stop]).max(initial=0.)),float(abs(s1[:stop]).max(initial=0.)))
    del arrays
    require(prefix_max==0., 'high-CN0 common Helper/noise cancellation failed before DATA begins')
    sums={k:math.fsum(v)for k,v in parts.items()}
    target=m['power']['complex_noise_variance']; high=records['helper-high']['manifest']['power']['complex_noise_variance']
    variance=(math.sqrt(target)-math.sqrt(high))**2
    require(0<variance<=target, 'invalid shared-noise subtraction variance')
    report=oracle_summary(sums,variance,target,source_bit)
    report.update(rows=count, sample_rate_hz=m['sample_rate_hz'], capture_seconds=count/m['sample_rate_hz'],
        target_complex_noise_variance=target, high_complex_noise_variance=high,
        residual_complex_noise_variance=variance, residual_over_target_variance=variance/target,
        common_noise_cancellation_prefix_max=prefix_max, reduction=sums,
        observed_noise_energy_over_expected=sums['noise_energy']/(count*variance),
        observed_noise_mean_complex=[sums['noise_mean_real']/count,sums['noise_mean_imag']/count],
        chunk_rows=CHUNK, arithmetic='complex128 chunk dot products, float64 per-chunk sums, math.fsum across chunks; CPU2 thread environment',
        finite_high_cn0_scope='s_b=(composite_b+same tiny noise)-(Helper+same tiny noise), linear superposition up to stored FP64 rounding. y=actual-(Helper+tiny noise). Common target/high standard-normal draws give (sqrt(vtarget)-sqrt(v200))^2, not vtarget+v200. Physical-target variance benchmark also reported.')
    return report


def worker(a):
    start=time.perf_counter();stage='imports';outputs=[]
    try:
        for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
            os.environ[name]='2'
        import numpy as np
        plan=read(a.output/'plan.json');c=context(a);script_hash=plan['script_sha256']
        require(c==plan['context'], 'selection/context changed after freeze')
        verify_frozen(a,c,script_hash)
        write(a.output/'environment.json',dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),thread_environment={k:os.environ[k]for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}))
        for item in c['selected']:
            trial=item['row']['trial'];folder=a.output/trial['id'];folder.mkdir()
            records={}
            for name,bit,data,high in (('actual',trial['bit'],True,False),('bit0-high',0,True,True),('bit1-high',1,True,True),('helper-high',trial['bit'],False,True)):
                stage=trial['id']+'/'+name;verify_frozen(a,c,script_hash)
                export_args=list(c['case']['export_args'])
                require(export_args.count('--cn0')==1, 'explicit original CN0 required')
                if high:export_args[export_args.index('--cn0')+1]=str(HIGH_CN0)
                destination=folder/name
                command=[str(a.exporter),*export_args,'--output',str(destination),'--seconds',str(c['case']['seconds']),
                    '--seed',str(trial['seed']),'--bit',str(bit),'--data','on' if data else 'off','--helper','on']
                mark=time.perf_counter()
                with (folder/(name+'.log')).open('x') as log:
                    subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=a.native_timeout_seconds)
                m,t=read(destination/'manifest.json'),read(destination/'evaluator-truth.json')
                hashes={k:dict(file=m[k]['file'],sha256=sha(destination/m[k]['file']),bytes=(destination/m[k]['file']).stat().st_size)for k in ('observation','validity')}
                record=dict(command=command,export_wall_seconds=time.perf_counter()-mark,
                    export_timer_scope='native subprocess, metadata loading and array hashing; native internal cost retained separately',native_reported_cost=m['cost'],
                    manifest_sha256=sha(destination/'manifest.json'),truth_sha256=sha(destination/'evaluator-truth.json'),hashes=hashes)
                write(folder/(name+'-export.json'),record)
                records[name]=dict(record,folder=destination,manifest=m,truth=t)
                verify_frozen(a,c,script_hash)
            stage=trial['id']+'/validate';checks=validate_exports(records,item,np)
            stage=trial['id']+'/reduce';mark=time.perf_counter();oracle=reduce_records(records,trial['bit'],np)
            result=dict(role=item['role'],trial=trial,original_receiver=item['row']['variants']['1'],
                original_input_sha256=item['row']['input_sha256'],validation=checks,oracle=oracle,
                source_energy_by_export={k:r['truth']['source_energy']for k,r in records.items()},
                reduction_seconds=time.perf_counter()-mark,export_seconds=sum(r['export_wall_seconds']for r in records.values()),
                exports={k:{kk:vv for kk,vv in r.items()if kk not in ('folder','manifest','truth')}for k,r in records.items()})
            verify_frozen(a,c,script_hash);write(folder/'result.json',result);outputs.append(result)
            if not a.retain_arrays:
                for r in records.values():
                    for h in r['hashes'].values():(r['folder']/h['file']).unlink()
        write(a.output/'result.json',dict(status='completed',schema='triad-helper-selected-known-channel-oracle-v1',
            worker_wall_seconds=time.perf_counter()-start,cases=outputs,gate=c['gate'],source_hashes=c['source_hashes'],
            exporter_sha256=c['exporter_sha256'],limits=[
                'Two outcome-selected diagnostic cases. Do not estimate population success, sensitivity or false-admission rates from them.',
                'All channel/oscillator/arrival/epoch/Helper waveform truth is supplied by regenerated counterfactual signals; this is not an implementable receiver.',
                'Known-channel equal-prior bit discrimination is distinct from presence admission. Union-two alpha=.05 covers only two fixed known templates under white Gaussian residual noise, not the practical acquisition search or daily operation.',
                'Raw complete capture includes filter/propagation tails. No receiver passband filtering, oracle alignment cropping, masking or spectral clipping is applied.',
                'Fixed native/source/inputs and I/Q byte identity are required. Same tiny high-C/N0 noise realization cancels in component differences up to FP64 rounding; prefix and algebra checks are reported.',
                'Array reductions are deterministic diagnostic arithmetic, not a backend performance benchmark.']))
        return 0
    except Exception as error:
        write(a.output/'result.json',dict(status='failed',stage=stage,error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc(),completed_cases=outputs,worker_wall_seconds=time.perf_counter()-start))
        return 2


def api_check(a):
    # Pure scalar closed-form controls; no simulated or measured DSP workload.
    s=dict(energy0=1.,energy1=1.,distance=4.,ml_numerator=4.,dot0_y=-1.,dot1_y=1.)
    r=oracle_summary(s,1.,1.,1)
    require(r['ml_bit']==1 and abs(r['equal_prior_known_channel_pe']-.07864960352514257)<1e-15,'scalar oracle formula check failed')
    require(not r['presence_admitted'] and abs(r['presence_threshold']-1.9599639845400536)<1e-12,'scalar presence formula check failed')
    require((math.sqrt(4)-math.sqrt(1))**2==1,'common-noise variance check failed')
    chosen=None
    if a.campaign_root is not None:
        c=context(a);chosen=[dict(role=x['role'],trial=x['row']['trial'])for x in c['selected']]
    print(json.dumps(dict(status='scalar-contract-and-selection-checks-passed',selected=chosen,
        scope='Scalar formulas and frozen JSON selection only. Native export, array reduction, source/binary runtime match and known-channel waveform outcomes remain unexecuted.')))
    return 0


def supervisor(a):
    start=time.perf_counter();c=context(a);script_hash=sha(__file__)
    verify_frozen(a,c,script_hash);a.output.mkdir(parents=True,exist_ok=False)
    write(a.output/'plan.json',dict(schema='triad-helper-selected-known-channel-plan-v1',context=c,script_sha256=script_hash,
        high_cn0_db_hz=HIGH_CN0,alpha_union_two=ALPHA,chunk_rows=CHUNK,budget_seconds=a.budget_seconds,
        native_timeout_seconds=a.native_timeout_seconds,export_count=8,
        decision='Selection frozen from original outcomes before new waveform regeneration; no rerun/rescore of the practical receiver.'))
    command=[sys.executable,str(Path(__file__).resolve()),'--_worker',*sys.argv[1:]]
    with (a.output/'worker.stdout.log').open('x') as out,(a.output/'worker.stderr.log').open('x') as err:
        child=subprocess.Popen(command,cwd=REPO,stdout=out,stderr=err,start_new_session=True)
        expired=False
        try:child.wait(timeout=max(.01,a.budget_seconds-(time.perf_counter()-start)-3.))
        except subprocess.TimeoutExpired:
            expired=True;os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=1.)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2.)
    result=dict(status='deadline-exceeded'if expired else('completed'if child.returncode==0 else'failed'),
        returncode=child.returncode,total_wall_seconds=time.perf_counter()-start,budget_seconds=a.budget_seconds,
        scope='Whole isolated process tree including native generation, imports, validation, reductions and outputs; deadline termination is incomplete evidence.')
    write(a.output/'supervisor.json',result);print(json.dumps(result))
    return 124 if expired else child.returncode


def main(argv=None):
    a=args_from(argv)
    if a.check_api:return api_check(a)
    if a._worker:return worker(a)
    return supervisor(a)


if __name__=='__main__':
    raise SystemExit(main())

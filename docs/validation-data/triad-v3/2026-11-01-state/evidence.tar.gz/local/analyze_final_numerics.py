#!/usr/bin/env python3
"""Reproduce final numerical comparisons from the extracted triad study outputs."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


HERE = Path(__file__).resolve().parent
REMOTE = HERE / "remote"
OUTPUT = HERE / "final-numerics.json"
TWO_DAY_GATE = 18.342919304608863


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_report(stem: str) -> tuple[Path, dict[str, Any], Path, dict[str, np.ndarray]]:
    report_path = REMOTE / f"{stem}.json"
    score_path = REMOTE / f"{stem}.scores.npz"
    report = json.loads(report_path.read_text())
    if not score_path.exists():
        raise FileNotFoundError(score_path)
    with np.load(score_path, allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    return report_path, report, score_path, arrays


def classify(scores: np.ndarray, truth: list[int] | int, gate: float) -> dict[str, int]:
    scores = np.asarray(scores, dtype=np.float64)
    if scores.ndim != 2 or scores.shape[1] != 2 or np.isnan(scores).any():
        raise ValueError(f"expected N x 2 non-NaN scores, got {scores.shape}")
    labels = np.full(scores.shape[0], int(truth), dtype=np.int64) if isinstance(truth, int) else np.asarray(truth, dtype=np.int64)
    if labels.shape != (scores.shape[0],) or not set(labels.tolist()) <= {0, 1}:
        raise ValueError("truth labels must be one binary label per score row")
    winners = np.argmax(scores, axis=1)
    admitted = np.max(scores, axis=1) >= gate
    correct = int(np.count_nonzero(admitted & (winners == labels)))
    wrong = int(np.count_nonzero(admitted & (winners != labels)))
    return {"n": int(scores.shape[0]), "accepted": correct + wrong,
            "correct_accepted": correct, "wrong_accepted": wrong,
            "missed": int(scores.shape[0]) - correct - wrong}


def null_count(scores: np.ndarray, gate: float) -> int:
    scores = np.asarray(scores, dtype=np.float64)
    if scores.ndim != 2 or scores.shape[1] != 2 or np.isnan(scores).any():
        raise ValueError(f"expected N x 2 non-NaN null scores, got {scores.shape}")
    return int(np.count_nonzero(np.max(scores, axis=1) >= gate))


def hoeffding(successes: int, total: int, alpha: float = .05) -> list[float]:
    q = successes / total
    eps = math.sqrt(math.log(1 / alpha) / (2 * total))
    return [max(0., q - eps), min(1., q + eps)]


def chernoff(successes: int, total: int, alpha: float = .05) -> list[float]:
    """Two one-sided Chernoff bounds, valid for independent unequal path rates."""
    if not 0 <= successes <= total or total < 1:
        raise ValueError("invalid Bernoulli count")
    q, target = successes / total, -math.log(alpha) / total
    if successes == 0:
        return [0., -math.expm1(math.log(alpha) / total)]
    if successes == total:
        return [math.exp(math.log(alpha) / total), 1.]

    def divergence(p: float) -> float:
        return q * math.log(q / p) + (1 - q) * math.log((1 - q) / (1 - p))

    lo, hi = 0., q
    for _ in range(70):
        mid = (lo + hi) / 2
        if divergence(mid) > target:
            lo = mid
        else:
            hi = mid
    lower = lo
    lo, hi = q, 1.
    for _ in range(70):
        mid = (lo + hi) / 2
        if mid == 1. or divergence(mid) > target:
            hi = mid
        else:
            lo = mid
    return [lower, hi]


def source_ref(report_path: Path, score_path: Path) -> dict[str, str]:
    return {"report": report_path.name, "report_sha256": digest(report_path),
            "scores": score_path.name, "scores_sha256": digest(score_path)}


def state_numeric_pair(left_name: str, right_name: str, label: str) -> dict[str, Any]:
    lp, left, lsp, la = load_report(left_name)
    rp, right, rsp, ra = load_report(right_name)
    if left.get("schema") != "triad-state-study-report-v1" or right.get("schema") != "triad-state-study-report-v1":
        raise ValueError(f"{label}: unexpected report schema")
    if len(left["rows"]) != 1 or len(right["rows"]) != 1:
        raise ValueError(f"{label}: expected exactly one report row")
    lrow, rrow = left["rows"][0], right["rows"][0]
    if (lrow["manifest_sha256"], lrow["seed"], lrow["cn0_db_hz"], lrow["method"]) != (
            rrow["manifest_sha256"], rrow["seed"], rrow["cn0_db_hz"], rrow["method"]):
        raise ValueError(f"{label}: paired reports differ in path/noise/CN0/method")
    if set(la) != set(ra):
        raise ValueError(f"{label}: NPZ keys differ")
    threshold = float(lrow["admission_threshold"])
    result_arrays = {}
    all_absolute_errors: list[tuple[float, str]] = []
    for key in sorted(la):
        a, b = np.asarray(la[key], np.float64), np.asarray(ra[key], np.float64)
        if a.shape != b.shape or a.ndim != 2 or a.shape[1] != 2 or np.isnan(a).any() or np.isnan(b).any():
            raise ValueError(f"{label}: invalid paired score arrays for {key}: {a.shape} vs {b.shape}")
        delta = a - b
        all_absolute_errors.extend((float(value), key) for value in np.abs(delta).ravel())
        gate_checks = {}
        for gate_label, gate_value in (("source_gate", threshold),
                                       ("reference_three_method_gate_18_274498", 18.274498233774285)):
            gate_checks[gate_label] = int(np.count_nonzero(
                (np.max(a, axis=1) >= gate_value) != (np.max(b, axis=1) >= gate_value)))
        result_arrays[key] = {
            "shape": list(a.shape),
            "max_absolute_score_difference": float(np.max(np.abs(delta))),
            "mean_absolute_score_difference": float(np.mean(np.abs(delta))),
            "rms_score_difference": float(np.sqrt(np.mean(delta * delta))),
            "candidate_argmax_changes": int(np.count_nonzero(np.argmax(a, axis=1) != np.argmax(b, axis=1))),
            "threshold_admission_changes_by_gate": gate_checks,
        }
    return {
        "comparison": label,
        "left": source_ref(lp, lsp), "right": source_ref(rp, rsp),
        "shared_path_manifest_sha256": lrow["manifest_sha256"],
        "shared_noise_seed": int(lrow["seed"]),
        "cn0_db_hz": float(lrow["cn0_db_hz"]),
        "threshold_log_likelihood_ratio": threshold,
        "left_precision": left["configuration"].get("precision"),
        "right_precision": right["configuration"].get("precision"),
        "left_phase_states": left["configuration"].get("phase_states"),
        "right_phase_states": right["configuration"].get("phase_states"),
        "left_frequency_spacing_hz": lrow.get("diagnostics", {}).get("frequency_spacing_hz"),
        "right_frequency_spacing_hz": rrow.get("diagnostics", {}).get("frequency_spacing_hz"),
        "arrays": result_arrays,
        "all_score_entries": sum(int(x.size) for x in la.values()),
        "max_absolute_score_difference_across_all_entries": max(all_absolute_errors)[0],
        "max_difference_array": max(all_absolute_errors)[1],
        "scope": "paired score-array numerical comparison on identical exported path and noise seed; not independent performance trials",
    }


def combine_hmm_shards() -> dict[str, Any]:
    shard_names = ["holdout-two-day-phase-lower", "holdout-two-day-phase-lower-shard2"]
    shards = []
    for stem in shard_names:
        rp, report, sp, arrays = load_report(stem)
        if report.get("schema") != "triad-path-study-report-v1" or len(report.get("rows", [])) != 1:
            raise ValueError(f"{stem}: unexpected path-study structure")
        row = report["rows"][0]
        summary, paths = row["summary"], row["paths"]
        if summary["method"] != "phase-frequency" or not math.isclose(summary["cn0_db_hz"], -28., abs_tol=1e-9):
            raise ValueError(f"{stem}: not the requested -28 dB-Hz HMM shard")
        signal = arrays["cn0_phase-frequency_signal"]
        null = arrays["cn0_phase-frequency_null"]
        if signal.shape != (len(paths), 2) or null.shape != (len(paths), 2):
            raise ValueError(f"{stem}: score/path count mismatch")
        truths = [int(p["transmitted_bit"]) for p in paths]
        noise_seeds = [int(p["noise_seed"]) for p in paths]
        manifest_hashes = [p["manifest_sha256"] for p in paths]
        gate = float(summary["threshold"])
        signal_counts = classify(signal, truths, gate)
        null_admitted = null_count(null, gate)
        if (signal_counts["correct_accepted"] != summary["correct_accepted"]
                or signal_counts["wrong_accepted"] != summary["wrong_accepted"]
                or signal_counts["missed"] != summary["missed"]
                or null_admitted != summary["false_admitted"]):
            raise ValueError(f"{stem}: score-derived counts mismatch the report summary")
        shards.append({"stem": stem, "report_ref": source_ref(rp, sp), "paths": paths,
                       "truths": truths, "noise_seeds": noise_seeds,
                       "manifest_hashes": manifest_hashes, "signal": signal, "null": null,
                       "gate": gate, "per_shard": {"signal": signal_counts, "null_admitted": null_admitted,
                       "reported_summary": summary}})

    configs = [json.loads((REMOTE / f"{stem}.json").read_text())["configuration"] for stem in shard_names]
    for key in ("cn0", "split", "phase_states", "relative_phase_states", "phase_diffusion", "frequency_std",
                "frequency_coherence", "frequency_bound", "taps", "precision", "selection_methods",
                "false_probability", "horizon_seconds", "attempt_spacing", "duration_alternatives"):
        if configs[0].get(key) != configs[1].get(key):
            raise ValueError(f"HMM shards differ in declared profile field {key}")
    manifests = [x for shard in shards for x in shard["manifest_hashes"]]
    seeds = [x for shard in shards for x in shard["noise_seeds"]]
    if len(set(manifests)) != len(manifests) or len(set(seeds)) != len(seeds):
        raise ValueError("HMM shard manifests or independent noise seeds overlap")
    paths = [x for shard in shards for x in shard["paths"]]
    truths = [x for shard in shards for x in shard["truths"]]
    signal = np.concatenate([x["signal"] for x in shards], axis=0)
    null = np.concatenate([x["null"] for x in shards], axis=0)
    gate = shards[0]["gate"]
    sig_counts, null_admitted = classify(signal, truths, gate), null_count(null, gate)
    bits = {}
    for bit in (0, 1):
        selected = [i for i, truth in enumerate(truths) if truth == bit]
        correct = sum(int(np.max(signal[i]) >= gate and np.argmax(signal[i]) == bit) for i in selected)
        wrong = sum(int(np.max(signal[i]) >= gate and np.argmax(signal[i]) != bit) for i in selected)
        bits[str(bit)] = {"paths": len(selected), "correct_accepted": correct,
                          "wrong_accepted": wrong, "missed": len(selected) - correct - wrong,
                          "correct_probability_iid_cp95": cp95(correct, len(selected)),
                          "assumption": "iid keys/channel realizations within this fixed bit stratum"}
    return {
        "sources": [s["report_ref"] for s in shards],
        "shared_profile": {k: configs[0].get(k) for k in ("cn0", "split", "phase_states", "relative_phase_states",
                            "phase_diffusion", "frequency_std", "frequency_coherence", "frequency_bound",
                            "taps", "precision", "selection_methods", "false_probability", "horizon_seconds",
                            "attempt_spacing", "duration_alternatives")},
        "paired_independence_audit": {"manifest_count": len(manifests), "unique_manifest_count": len(set(manifests)),
                                      "noise_seed_count": len(seeds), "unique_noise_seed_count": len(set(seeds)),
                                      "shard_local_row_indices": [p["independent_path_index"] for p in paths],
                                      "physical_input_basenames": [Path(p["path"]).name for p in paths],
                                      "truth_balance": {str(bit): truths.count(bit) for bit in (0, 1)}},
        "threshold_log_likelihood_ratio": gate,
        "signal": {**sig_counts, "independent_path_hoeffding95": hoeffding(sig_counts["correct_accepted"], len(paths)),
                   "independent_path_chernoff95": chernoff(sig_counts["correct_accepted"], len(paths)),
                   "per_bit": bits},
        "null": {"paths": len(paths), "admitted": null_admitted,
                 "independent_path_hoeffding95": hoeffding(null_admitted, len(paths)),
                 "independent_path_chernoff95": chernoff(null_admitted, len(paths))},
        "per_shard": [{"source": s["stem"], "signal": s["per_shard"]["signal"],
                       "null_admitted": s["per_shard"]["null_admitted"]} for s in shards],
        "scope": "combined two-day HF HMM fixed holdout profile; 32 independent sampled physical paths, not continuous-day false-admission qualification",
    }


def paired_gaussian_vs_hmm() -> dict[str, Any]:
    gp, gaussian, gsp, ga = load_report("holdout-two-day-gaussian-edge")
    hmm_reports = [load_report(stem) for stem in (
        "holdout-two-day-phase-lower", "holdout-two-day-phase-lower-shard2")]
    grow = next(row for row in gaussian["rows"]
                if row["summary"]["method"] == "gaussian"
                and math.isclose(float(row["summary"]["cn0_db_hz"]), -28.0, abs_tol=1e-9))
    gpaths = grow["paths"]
    gsignals = ga["cn0_gaussian_signal"]
    ggate = float(grow["summary"]["threshold"])
    gaussian_by_identity = {}
    for i, path in enumerate(gpaths):
        ident = (path["manifest_sha256"], int(path["noise_seed"]))
        outcome = classify(gsignals[i:i + 1], int(path["transmitted_bit"]), ggate)
        gaussian_by_identity[ident] = outcome
    hmm_by_identity = {}
    hmm_source_refs = []
    hmm_gate = None
    for rp, report, sp, arrays in hmm_reports:
        hmm_source_refs.append(source_ref(rp, sp))
        row = report["rows"][0]
        hmm_gate = float(row["summary"]["threshold"])
        paths = row["paths"]
        scores = arrays["cn0_phase-frequency_signal"]
        if scores.shape != (len(paths), 2):
            raise ValueError("paired HMM score/path mismatch")
        for i, path in enumerate(paths):
            ident = (path["manifest_sha256"], int(path["noise_seed"]))
            hmm_by_identity[ident] = classify(scores[i:i + 1], int(path["transmitted_bit"]), hmm_gate)
    if not math.isclose(ggate, float(hmm_gate), abs_tol=1e-12):
        raise ValueError("paired Gaussian/HMM reports use different admission gates")
    common = sorted(set(gaussian_by_identity) & set(hmm_by_identity))
    if len(common) != 32:
        raise ValueError(f"expected 32 paired Gaussian/HMM paths, found {len(common)}")
    if any(gaussian_by_identity[k]["n"] != 1 or hmm_by_identity[k]["n"] != 1 for k in common):
        raise ValueError("paired path classification did not remain one trial per path")
    gsuccess = [int(gaussian_by_identity[k]["correct_accepted"] == 1) for k in common]
    hsuccess = [int(hmm_by_identity[k]["correct_accepted"] == 1) for k in common]
    hmm_only = sum(h and not g for h, g in zip(hsuccess, gsuccess))
    gaussian_only = sum(g and not h for h, g in zip(hsuccess, gsuccess))
    return {
        "gaussian_source": source_ref(gp, gsp),
        "hmm_sources": hmm_source_refs,
        "cn0_db_hz": -28.0,
        "shared_path_count": len(common),
        "shared_identity_count": len(common),
        "unique_identity_count_across_each_complete_set": {
            "gaussian_paths": len(gaussian_by_identity), "hmm_paths": len(hmm_by_identity)},
        "threshold_log_likelihood_ratio": ggate,
        "gaussian_correct_accepted": sum(gsuccess),
        "hmm_correct_accepted": sum(hsuccess),
        "mcnemar_discordances": {
            "hmm_correct_gaussian_missed": hmm_only,
            "gaussian_correct_hmm_missed": gaussian_only,
            "paired_concordant_correct": sum(h and g for h, g in zip(hsuccess, gsuccess)),
            "paired_concordant_missed": sum(not h and not g for h, g in zip(hsuccess, gsuccess)),
        },
        "scope": "paired diagnostic on the 32 exact shared path-manifest/noise-seed identities; score classifications at one shared gate; descriptive discordances only, not a new receiver-gain inference",
    }


def cp95(successes: int, total: int) -> list[float]:
    try:
        from scipy.stats import beta
    except ImportError as exc:
        raise RuntimeError("scipy is required to compute exact per-bit CP intervals") from exc
    return [0. if successes == 0 else float(beta.ppf(.05, successes, total - successes + 1)),
            1. if successes == total else float(beta.ppf(.95, successes + 1, total - successes))]


def gaussian_minus26() -> dict[str, Any]:
    rp, report, sp, arrays = load_report("holdout-two-day-gaussian-minus26")
    if report.get("schema") != "triad-path-study-report-v1":
        raise ValueError("unexpected -26 Gaussian report schema")
    manifest_hashes = report.get("independent_path_manifest_hashes", [])
    noise_seeds = report.get("independent_noise_seeds", [])
    if (len(manifest_hashes) != 300 or len(set(manifest_hashes)) != 300
            or len(noise_seeds) != 300 or len(set(noise_seeds)) != 300):
        raise ValueError("-26 report does not contain 300 unique manifests and independent noise seeds")
    rows = []
    for row in report["rows"]:
        summary, paths = row["summary"], row["paths"]
        method = summary["method"]
        signal = arrays[f"cn0_{method}_signal"]
        null = arrays[f"cn0_{method}_null"]
        truths = [int(path["transmitted_bit"]) for path in paths]
        gate = float(summary["threshold"])
        signal_counts = classify(signal, truths, gate)
        null_admitted = null_count(null, gate)
        if (signal_counts["correct_accepted"] != summary["correct_accepted"]
                or signal_counts["wrong_accepted"] != summary["wrong_accepted"]
                or signal_counts["missed"] != summary["missed"]
                or null_admitted != summary["false_admitted"]):
            raise ValueError(f"-26 row {method}: score-derived counts mismatch summary")
        rows.append({"method": method, "cn0_db_hz": summary["cn0_db_hz"],
                     "paths": len(paths), "balanced_signal_bits": summary["balanced_signal_bits"],
                     "threshold_log_likelihood_ratio": gate, "signal": signal_counts,
                     "null_admitted": null_admitted,
                     "original_correct_independent_chernoff95": summary["correct_probability_independent_chernoff95"],
                     "original_null_independent_chernoff95": summary["false_probability_independent_chernoff95"]})
    return {"source": source_ref(rp, sp), "rows": rows,
            "path_independence_audit": {"manifest_count": len(manifest_hashes),
                                         "unique_manifest_count": len(set(manifest_hashes)),
                                         "noise_seed_count": len(noise_seeds),
                                         "unique_noise_seed_count": len(set(noise_seeds))},
            "scope": "300 independent two-day HF colored paths at -26 dB-Hz, as exported in holdout-two-day-extra; results checked against saved report summaries"}


def fixed_gaussian_minus28() -> dict[str, Any]:
    rp, report, sp, arrays = load_report("fixed-gaussian-minus28")
    bound_path = HERE / "two-day-minus28-gaussian-bound.json"
    if not bound_path.exists():
        bound_path = REMOTE / "two-day-minus28-gaussian-bound.json"
    bound = json.loads(bound_path.read_text())
    gate = float(bound["gaussian_chernoff_threshold"])
    if not math.isclose(gate, TWO_DAY_GATE, rel_tol=0., abs_tol=1e-10):
        raise ValueError(f"fixed Gaussian threshold changed: {gate}")
    row = report["rows"][0]
    workspace_manifest_path = HERE / "dev-two-day-1" / "manifest.json"
    workspace_manifest = json.loads(workspace_manifest_path.read_text())
    manifest_hash = digest(workspace_manifest_path)
    if manifest_hash != row["manifest_sha256"]:
        raise ValueError("fixed Gaussian source manifest hash mismatch")
    truth = int(workspace_manifest["signal_bit"])
    signal = arrays["p0_c0_gaussian_signal"]
    null = arrays["p0_c0_gaussian_null"]
    source_gate = float(row["admission_threshold"])
    source_signal = classify(signal, truth, source_gate)
    source_null = null_count(null, source_gate)
    if (source_signal["correct_accepted"] != row["signal"]["correct_accepted"]
            or source_signal["wrong_accepted"] != row["signal"]["wrong_accepted"]
            or source_signal["missed"] != row["signal"]["missed"]
            or source_null != row["null"]["admitted"]):
        raise ValueError("fixed Gaussian original-gate scores do not match the state-study report")
    reclassified = classify(signal, truth, gate)
    null_admitted = null_count(null, gate)
    return {
        "source": source_ref(rp, sp),
        "bound_reference": {"file": bound_path.name, "sha256": digest(bound_path),
                            "gaussian_chernoff_threshold": gate},
        "path_manifest_sha256": manifest_hash,
        "truth_bit": truth,
        "cn0_db_hz": float(row["cn0_db_hz"]),
        "conditional_noise_trials": int(signal.shape[0]),
        "source_threshold_log_likelihood_ratio": float(row["admission_threshold"]),
        "source_gate_classification": {"signal": source_signal, "null_admitted": source_null},
        "reclassification_threshold_log_likelihood_ratio": gate,
        "signal": reclassified,
        "null_admitted": null_admitted,
        "scope": "128 conditional noise realizations on one two-day path; point counts are not independent-path or operational-day qualification",
    }


def long_refinement() -> dict[str, Any]:
    rp, report, sp, arrays = load_report("long-grid-refinement")
    row = report["rows"][0]
    summary, paths = row["summary"], row["paths"]
    signal = arrays["cn0_phase-frequency_signal"]
    null = arrays["cn0_phase-frequency_null"]
    truths = [int(path["transmitted_bit"]) for path in paths]
    gate = float(summary["threshold"])
    sc = classify(signal, truths, gate)
    nc = null_count(null, gate)
    if (sc["correct_accepted"] != summary["correct_accepted"]
            or sc["wrong_accepted"] != summary["wrong_accepted"]
            or sc["missed"] != summary["missed"] or nc != summary["false_admitted"]):
        raise ValueError("long-grid score-derived counts mismatch report")
    return {"source": source_ref(rp, sp), "phase_states": report["configuration"]["phase_states"],
            "frequency_spacing_hz": row["receiver_diagnostics"]["signal"].get("frequency_spacing_hz"),
            "signal": sc, "null_admitted": nc,
            "correct_independent_path_chernoff95": summary["correct_probability_independent_chernoff95"],
            "unique_manifest_count": len(set(report["independent_path_manifest_hashes"])),
            "unique_noise_seed_count": len(set(report["independent_noise_seeds"])),
            "scope": "two independent two-day HF colored paths at -28 dB-Hz, refined phase/frequency grid; not sensitivity qualification"}


def long_refinement_against_baseline() -> dict[str, Any]:
    bp, baseline, bsp, ba = load_report("holdout-two-day-phase-lower")
    rp, refined, rsp, ra = load_report("long-grid-refinement")
    brows, rrows = baseline["rows"][0]["paths"], refined["rows"][0]["paths"]
    baseline_ids = {(x["manifest_sha256"], int(x["noise_seed"])): i for i, x in enumerate(brows)}
    refined_ids = {(x["manifest_sha256"], int(x["noise_seed"])): i for i, x in enumerate(rrows)}
    shared = sorted(set(baseline_ids) & set(refined_ids))
    if len(shared) != 2:
        raise ValueError(f"expected two paired baseline/refined paths; found {len(shared)}")
    bmatrix = ba["cn0_phase-frequency_signal"][[baseline_ids[x] for x in shared]]
    rmatrix = ra["cn0_phase-frequency_signal"][[refined_ids[x] for x in shared]]
    if bmatrix.shape != rmatrix.shape or np.isnan(bmatrix).any() or np.isnan(rmatrix).any():
        raise ValueError("invalid paired baseline/refinement score arrays")
    delta = rmatrix - bmatrix
    gate = float(refined["rows"][0]["summary"]["threshold"])
    return {
        "baseline": source_ref(bp, bsp),
        "refinement": source_ref(rp, rsp),
        "paired_path_identities": [{"manifest_sha256": x[0], "noise_seed": x[1],
                                     "truth_bit": int(rrows[refined_ids[x]]["transmitted_bit"])} for x in shared],
        "baseline_grid": {"phase_states": baseline["configuration"]["phase_states"],
                          "frequency_states": baseline["rows"][0]["receiver_diagnostics"]["signal"]["frequency_states"],
                          "frequency_spacing_hz": baseline["rows"][0]["receiver_diagnostics"]["signal"]["frequency_spacing_hz"]},
        "refinement_grid": {"phase_states": refined["configuration"]["phase_states"],
                            "frequency_states": refined["rows"][0]["receiver_diagnostics"]["signal"]["frequency_states"],
                            "frequency_spacing_hz": refined["rows"][0]["receiver_diagnostics"]["signal"]["frequency_spacing_hz"]},
        "gate_log_likelihood_ratio": gate,
        "baseline_signal_scores": bmatrix.tolist(),
        "refined_signal_scores": rmatrix.tolist(),
        "refined_minus_baseline": delta.tolist(),
        "max_absolute_score_difference": float(np.max(np.abs(delta))),
        "mean_absolute_score_difference": float(np.mean(np.abs(delta))),
        "rms_score_difference": float(np.sqrt(np.mean(delta * delta))),
        "candidate_argmax_changes": int(np.count_nonzero(np.argmax(bmatrix, axis=1) != np.argmax(rmatrix, axis=1))),
        "threshold_admission_changes": int(np.count_nonzero((np.max(bmatrix, axis=1) >= gate) != (np.max(rmatrix, axis=1) >= gate))),
        "scope": "exact paired NPZ score comparison for the first two baseline paths; no claim beyond these inputs",
    }


def failed_rate36_export() -> dict[str, Any]:
    log = REMOTE / "rate36-two-day.log"
    text = log.read_text(errors="replace")
    marker = "timed out after 719.999994450016 seconds"
    if marker not in text:
        raise ValueError("expected 720-second Rate-36 export timeout missing from run log")
    manifests = list((REMOTE / "hf-colored-rate36-two-day").glob("path-*/manifest.json")) if (REMOTE / "hf-colored-rate36-two-day").exists() else []
    reports = list(REMOTE.glob("*rate36*.json"))
    return {"log": log.name, "log_sha256": digest(log), "failure": "2-path 172800-second Rate-36 HF-colored export process timed out after 719.999994450016 seconds",
            "manifest_count": len(manifests), "matching_json_report_count": len(reports),
            "scope": "failed acquisition/export setup; no Rate-36 waveform/decoder results available"}


def main() -> None:
    comparisons = [
        state_numeric_pair("numeric-hour-p512-fp32", "numeric-hour-p512-fp64", "1-hour P512 FP32 vs FP64"),
        state_numeric_pair("numeric-hour-p512-fp32", "numeric-hour-p1024-coarse-frequency", "1-hour P512 vs P1024 at matched coarse frequency grid"),
        state_numeric_pair("numeric-hour-p1024-coarse-frequency", "numeric-hour-p1024-fine-frequency", "1-hour P1024 coarse vs fine frequency grid"),
        state_numeric_pair("numeric-two-day-p512-fp32", "numeric-two-day-p512-fp64", "2-day P512 FP32 vs FP64"),
    ]
    result = {
        "schema": "triad-final-numerics-v1",
        "scope": "offline analysis of extracted final reports and paired score NPZ files; no new simulations launched",
        "inputs_directory": str(REMOTE),
        "numeric_parity": comparisons,
        "two_day_minus28_hmm_shards": combine_hmm_shards(),
        "paired_gaussian_minus28_vs_hmm": paired_gaussian_vs_hmm(),
        "two_day_minus26_gaussian_300_paths": gaussian_minus26(),
        "fixed_gaussian_minus28_reclassification": fixed_gaussian_minus28(),
        "long_grid_refinement": long_refinement(),
        "long_grid_refinement_vs_phase_lower_baseline": long_refinement_against_baseline(),
        "rate36_export_failure": failed_rate36_export(),
        "limitations": [
            "FP32/FP64 comparisons share each report's input and noise seed and therefore measure arithmetic differences, not independent trials.",
            "Coarse/fine grid comparisons alter the finite frequency-grid approximation and are not continuous-parameter optimality proofs.",
            "Path-level confidence bounds require independent paths; conditional noise batches on one physical path are reported separately.",
            "The Rate-36 waveform export timed out before producing manifests, so that requested condition is untested.",
        ],
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(f"wrote {OUTPUT}")


if __name__ == "__main__":
    main()

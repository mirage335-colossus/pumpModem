"""Assemble compact technical evidence; omit raw workspaces and cloud account data."""
import hashlib, io, json, pathlib, subprocess, tarfile

repo=pathlib.Path(__file__).resolve().parents[2]
study=repo/'local-evidence/triad-v3-weak'
out=repo/'docs/validation-data/triad-v3/2026-11-01-state'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
entries={}
def add(p,name):
 if not p.is_file() or p.suffix=='.pyc':return
 if p.stat().st_size>20_000_000:raise ValueError(f'Unexpected large artifact {p}')
 entries[name]=p
for p in sorted((study/'remote').rglob('*')):
 if '__pycache__' not in p.parts:add(p,'remote/'+p.relative_to(study/'remote').as_posix())
for p in sorted(study.iterdir()):
 if p.suffix in {'.json','.log','.npz','.py'}:add(p,'local/'+p.name)
for p in sorted((study/'noise-mismatch').iterdir()):add(p,'local/noise-mismatch/'+p.name)
for area,pat in [('tools','triad*'),('tests','test_triad*')]:
 for p in sorted((repo/area).glob(pat)):add(p,'current-source/'+area+'/'+p.name)
for name in ['analyze_results.py','summary.json','reception.png']:
 add(out/name,'analysis/'+name)
patch=subprocess.check_output(['git','diff','--','tools','tests'],cwd=repo)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
source_entries=[{'path':n.removeprefix('current-source/'),'sha256':sha(p)} for n,p in entries.items() if n.startswith('current-source/')]
(out/'final-source.sha256').write_text(''.join(f'{e["sha256"]}  {e["path"]}\n' for e in source_entries))
contents=[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(entries.items())]
contents.append({'path':'current-source/tracked-source.patch','bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()})
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(entries.items()):t.add(p,arcname=n)
 info=tarfile.TarInfo('current-source/tracked-source.patch');info.size=len(patch);t.addfile(info,io.BytesIO(patch))
workspaces=[]
for p in sorted((study/'remote').glob('*/path-*/manifest.json')):
 d=json.loads(p.read_text())
 workspaces.append({'path':p.parent.relative_to(study/'remote').as_posix(),'sample_count':d['sample_count'],'sample_rate':d['sample_rate'],'actual_noisy_projection':bool(d.get('observation_file'))})
inventory=json.loads((study/'remote/workspace-inventory-final.json').read_text())
partial_entries=[e for e in inventory['files'] if e['path'].endswith(('.partial','.tmp'))]
manifest={'schema':'triad-state-evidence-package-v1','base_commit':base,
 'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},
 'files':contents,'source_hash_file':'final-source.sha256','source_hash_sha256':sha(out/'final-source.sha256'),
 'completed_remote_workspaces':len(workspaces),'workspace_array_inventory_files':len(inventory['files']),
 'workspace_array_inventory_bytes':sum(x['bytes'] for x in inventory['files']),
 'incomplete_temporary_file_count':len(partial_entries),
 'incomplete_temporary_file_bytes':sum(x['bytes'] for x in partial_entries),
 'completed_workspace_file_bytes':sum(x['bytes'] for x in inventory['files'])-sum(x['bytes'] for x in partial_entries),
 'total_sample_coordinates_across_completed_exports':sum(x['sample_count'] for x in workspaces),
 'counting_scope':'680 completed independent physical-path exports; coordinate count is not independent hypotheses or trials; development fixtures and incomplete exports excluded; second sampled noisy passes are not multiplied into this total.',
 'retention':{'included':'All completed remote manifests and workspace SHA-256 hashes; scores, reports, technical logs, exact executed Python/C++ sources and current study source; local test and diagnostic evidence.',
  'excluded':'Full completed workspace files (about 6.68 GB), incomplete temporary arrays (about 0.255 GB), and unrelated repository source; all cloud account, endpoint, credentials, billing and screenshot metadata.',
  'local_representatives':'Ignored local-evidence/triad-v3-weak/representative retains balanced pairs from seven profiles/shards, plus local development workspaces.',
  'regeneration':'Checkout base_commit, apply current-source/tracked-source.patch, overlay current-source/tools and tests; inspect remote/executed-source for the exact executed Python snapshots and campaign manifests for C++ source hashes. Full sample workspaces require regeneration.'},
 'cloud_cleanup':{'gpu_run_complete':True,'temporary_pod_deleted':True,'temporary_container_storage_removed':True,'active_reservation':False,'private_confirmation_kept_outside_repository':True},
 'limits':['Rate36 two-day export timed out before complete manifests; no decoding result.',
 'Operational false-admission control assumes declared known white-noise variance; mismatch diagnostic fails.',
 'No ordinary Robust integration or regression qualification.']}
(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['archive','completed_remote_workspaces','workspace_array_inventory_bytes','total_sample_coordinates_across_completed_exports']},indent=2))

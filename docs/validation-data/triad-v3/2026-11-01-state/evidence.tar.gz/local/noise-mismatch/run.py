#!/usr/bin/env python3
"""Paired H0 noise-variance mismatch sensitivity diagnostic (no signal truth)."""
import argparse, importlib.util, json, math, pathlib, platform, sys, time
import numpy as np
from types import SimpleNamespace

ROOT = pathlib.Path(__file__).resolve().parents[3]
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))
spec = importlib.util.spec_from_file_location("study", TOOLS / "triad-state-study.py")
study = importlib.util.module_from_spec(spec); spec.loader.exec_module(study)
from triad_state_workspace import BlockWorkspace, DetectorBlock

p = argparse.ArgumentParser()
p.add_argument("--input", type=pathlib.Path, required=True)
p.add_argument("--output", type=pathlib.Path, required=True)
p.add_argument("--draws", type=int, default=1024)
p.add_argument("--seed", type=int, default=930015)
p.add_argument("--cn0", type=float, default=-14.)
p.add_argument("--ratios", type=float, nargs="+", default=[1.,1.1,1.25,1.5,2.])
p.add_argument("--gate", type=float, default=18.2745)
p.add_argument("--threads", type=int, default=2)
a = p.parse_args()
if a.draws != 1024 or a.threads not in (1,2) or any(x <= 0 or not math.isfinite(x) for x in a.ratios):
    raise ValueError("this diagnostic is fixed to 1024 draws, <=2 threads, positive finite ratios")
ws = BlockWorkspace(a.input)
selected = [i for i,m in enumerate(ws.column_mapping) if len(m)==2]
labels = np.asarray([ws.candidates[i]["bit"] for i in selected])
if set(labels.tolist()) != {0,1}:
    raise ValueError("expected public two-bit/two-tap candidate bank")
args = SimpleNamespace(device="cpu",precision="fp64",methods=["gaussian"],coherences=[16.,64.,256.,1024.],taps=2)
import torch
torch.set_num_threads(a.threads)
variance = ws.sample_rate/(10.**(a.cn0/10.))
ratio_count = len(a.ratios)
rng = np.random.default_rng(a.seed)
covariance_check = [None]

def blocks():
    previous_center = None
    for tile in ws.iter_public():
        for Graw, interval, valid in zip(tile.gram,tile.intervals,tile.valid_rows):
            values,vectors = np.linalg.eigh((Graw+Graw.conj().T)*.5)
            scale=max(float(values[-1]),1.)
            if values[0] < -ws.psd_tolerance*scale:
                raise ValueError("public Gram is not positive semidefinite")
            L=vectors*np.sqrt(np.maximum(values,0.))[None,:]
            z=(rng.standard_normal((a.draws,ws.dimension))+1j*rng.standard_normal((a.draws,ws.dimension)))/math.sqrt(2.)
            raw=z@L.T
            # raw has covariance Graw (unit complex-noise variance). The
            # sufficient statistic divides samples by sigma, not sigma^2.
            r0=raw/math.sqrt(variance)
            G0=Graw/variance
            if covariance_check[0] is None:
                empirical=(r0.T@r0.conj())/a.draws
                trace=float(np.trace(G0).real)
                trace2=float(np.trace(G0@G0).real)
                effective_rank=trace*trace/trace2 if trace2>0 else 0.
                observed_trace=float(np.mean(np.sum(np.abs(r0)**2,axis=1)))
                trace_se=trace/math.sqrt(a.draws*effective_rank) if effective_rank>0 else 0.
                trace_z=(observed_trace-trace)/trace_se if trace_se>0 else 0.
                if abs(trace_z)>6.:
                    raise RuntimeError(f"normalized noise power failed public Gram check: {trace_z:.3f} sigma")
                covariance_check[0]={"block_index":0,"draws":a.draws,
                                  "expected_trace":trace,"empirical_trace":observed_trace,
                                  "effective_rank":effective_rank,"trace_standard_error":trace_se,
                                  "trace_error_standard_deviations":trace_z,
                                  "relative_covariance_frobenius_error":float(np.linalg.norm(empirical-G0)/max(np.linalg.norm(G0),1e-300)),
                                  "assertion":"empirical covariance trace within six analytic Monte Carlo standard errors of public G/noise_variance"}
            batch_r=np.concatenate([r0*math.sqrt(q) for q in a.ratios],axis=0)
            batch_G=np.broadcast_to(G0,(ratio_count,)+G0.shape).reshape((ratio_count,)+G0.shape)
            batch_G=np.repeat(batch_G,a.draws,axis=0)
            center=(int(interval[0])+int(interval[1]))/(2*ws.sample_rate)
            dt=0. if previous_center is None else center-previous_center
            previous_center=center
            yield DetectorBlock(batch_r,batch_G,dt,(int(interval[0]),int(interval[1])),int(valid),0,center)

started=time.perf_counter()
scores,diagnostics,elapsed=study.evaluate(ws,blocks(),args,selected,labels,a.draws*ratio_count)
scores=scores["gaussian"].reshape((ratio_count,a.draws,2))
rows=[]
for i,q in enumerate(a.ratios):
    maxima=scores[i].max(axis=1)
    admissions=int(np.sum(maxima>=a.gate))
    rows.append({"variance_ratio":q,"draws":a.draws,"admissions_at_fixed_gate":admissions,
                 "empirical_rate":float(np.mean(maxima>=a.gate)),
                 "empirical_rate_one_sided_95_cp":study.interval(admissions,a.draws),
                 "maximum_log_lr":float(maxima.max()),
                 "log_lr_quantiles_0_50_90_95_99_100":np.quantile(maxima,[0,.5,.9,.95,.99,1]).tolist(),
                 "per_bit_log_lr_quantiles_0_50_90_95_99_100":np.quantile(scores[i],[0,.5,.9,.95,.99,1],axis=0).T.tolist()})
report={"schema":"triad-noise-variance-mismatch-v1","scope":"conditional Gaussian H0 sensitivity diagnostic; not operational false-admission qualification",
        "command_argv":sys.argv,
        "execution_command":["timeout","--signal=TERM","290s",sys.executable,*sys.argv],
        "input_manifest_sha256":__import__('hashlib').sha256(ws.manifest_path.read_bytes()).hexdigest(),
        "input":str(a.input),"sampled_blocks":ws.block_count,"captured_sample_span_seconds":ws.sample_count/ws.sample_rate,
        "declared_cn0_db_hz":a.cn0,"sample_rate":ws.sample_rate,"declared_noise_variance":variance,
        "public_dimension":ws.dimension,"selected_candidates":len(selected),"candidate_bits":labels.tolist(),
        "signal_means_used":False,"payload_used":False,"null_draws":a.draws,"paired_noise_seed":a.seed,
        "first_block_normalized_covariance_check":covariance_check[0],
        "ratios":a.ratios,"gate_log_lr":a.gate,"attempts_per_day":1440,"selection_methods":3,
        "elapsed_seconds":time.perf_counter()-started,"receiver_core_seconds":elapsed,
        "state_diagnostics":diagnostics["gaussian"],"rows":rows,
        "limitations":["All 1024 draws are conditional on one fixed public channel Gram sequence; they are not independent channel or oscillator paths.",
                       "The model assumes known white complex-Gaussian variance. Ratios above one evaluate covariance mismatch without re-estimating noise.",
                       "The fixed threshold is diagnostic only; this sample size cannot validate a 1e-4/day operating rate."]}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
print(json.dumps({"output":str(a.output),"wall_seconds":report["elapsed_seconds"],"rows":[{k:r[k] for k in ("variance_ratio","admissions_at_fixed_gate","maximum_log_lr","log_lr_quantiles_0_50_90_95_99_100")} for r in rows]}),flush=True)

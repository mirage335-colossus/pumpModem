import subprocess,sys,pathlib,json
root=pathlib.Path('/tmp/triad-data')
cases=[
 ('numeric-hour-p512-fp32','dev-hour-0',-20,16,512,'fp32',None),
 ('numeric-hour-p512-fp64','dev-hour-0',-20,16,512,'fp64',None),
 ('numeric-hour-p1024-coarse-frequency','dev-hour-0',-20,16,1024,'fp32',.0009765625),
 ('numeric-hour-p1024-fine-frequency','dev-hour-0',-20,16,1024,'fp32',None),
 ('numeric-two-day-p512-fp32','dev-two-day-1',-28,1,512,'fp32',None),
 ('numeric-two-day-p512-fp64','dev-two-day-1',-28,1,512,'fp64',None),
]
with (root/'phase-numeric-cuda.json').open('w') as f:
 subprocess.run([sys.executable,'tests/test_triad_phase_frequency.py','--device','cuda:0'],stdout=f,check=True,timeout=120)
for name,dataset,cn0,trials,phase,precision,step in cases:
 cmd=[sys.executable,'tools/triad-state-study.py',str(root/dataset),'--output',str(root/(name+'.json')),'--cn0',str(cn0),'--trials',str(trials),'--methods','phase-frequency','--phase-states',str(phase),'--relative-phase-states','8','--threads','2','--precision',precision,'--phase-diffusion','.0153','--device','cuda:0','--memory-mib','16384']
 if step is not None:cmd+=['--frequency-step',str(step)]
 print(json.dumps(cmd),flush=True)
 with (root/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=300)

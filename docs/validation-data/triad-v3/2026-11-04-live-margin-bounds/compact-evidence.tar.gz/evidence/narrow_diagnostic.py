from pathlib import Path
import json,sys,numpy as np
from scipy import signal
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
import triad_live_narrowband as nb
import triad_live_level_analysis as la
base=Path(__file__).resolve().parent;d=json.loads((base/'level-analysis/results.json').read_text());rows=[]
fixtures=ROOT/'local-evidence/triad-live-reception-001/calibration-002/fixtures'
for row in d['rows']:
 f=json.loads((fixtures/row['case']/'fixture.json').read_text());a=np.load(base/'level-analysis'/row['workspace']);op=nb.NarrowbandFilter(f['receiver_sample_rate'],f['bandwidth'])
 y=np.asarray([op.filter_observation(z) for z in a['physical']]);p=op.filter_observation(a['deterministic_prediction']);n=op.filter_observation(a['simulated_residual']);v=op.valid_mask(a['valid']);m=la.repeated_metrics(y,p,v);m['model_noise_power']=float(np.mean(abs(n[v])**2))
 ratio=10*np.log10(np.array(m['actual_power'])/(m['predicted_deterministic_power']+m['model_noise_power']))
 r=dict(index=row['index'],case=row['case'],kind=row['kind'],noise_rms=row['noise_rms'],metrics=m,actual_to_total_model_db=ratio.tolist())
 if row['kind']=='silence':
  b=np.load(fixtures/row['case']/'basis.npy');b,_,info=op.filter_basis(b,a['valid'],max_lag=max(f['lags']));freq,psd=signal.welch(y[:,v],fs=f['receiver_sample_rate'],nperseg=f['receiver_sample_rate'],return_onesided=False,axis=-1);_,pn=signal.welch(n[v],fs=f['receiver_sample_rate'],nperseg=f['receiver_sample_rate'],return_onesided=False)
  order=np.argsort(freq); fq=np.fft.fftfreq(len(p),1/f['receiver_sample_rate']);vv=[]
  for bit in (0,1):
   template=b[bit,:,0].copy();template[~v]=0;weight=abs(np.fft.fft(template))**2
   vm=float(np.sum(np.interp(fq,freq[order],pn[order])*weight));vp=[float(np.sum(np.interp(fq,freq[order],pr[order])*weight)) for pr in psd]
   vv.append([10*np.log10(q/vm) for q in vp])
  r['template_weighted_quiet_variance_ratio_db']=vv
 rows.append(r)
(base/'narrow-diagnostic.json').write_text(json.dumps({'rows':rows,'scope':'diagnostic reuse; no receiver gate; template-weighted PSD proxy assumesstationary spectrum within windows'},indent=2)+'\n')
for name in ('baseline','edge'):
 for level in (0.,.0001,.001,.03,.1):
  s=[r for r in rows if r['case']==name and r['noise_rms']==level];print(name,level,'narrowtotal dB',np.round([v for r in s for v in r['actual_to_total_model_db']],3).tolist())
  if level==0:print(' template-weighted quiet', [np.round(r['template_weighted_quiet_variance_ratio_db'],3).tolist() for r in s])

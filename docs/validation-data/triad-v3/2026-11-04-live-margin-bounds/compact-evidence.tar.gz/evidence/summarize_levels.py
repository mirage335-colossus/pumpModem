from pathlib import Path
import json,numpy as np
root=Path(__file__).resolve().parent
d=json.loads((root/'level-analysis/results.json').read_text()); out={}
for name in ('baseline','edge'):
 levels={}
 for level in (0.,.0001,.001,.03,.1):
  rows=[r for r in d['rows'] if r['case']==name and r['noise_rms']==level]
  z=[]
  for r in rows:
   m=r['metrics'];p=m['predicted_residual_power'];den=m['predicted_deterministic_power']+p
   z.append(dict(index=r['index'],kind=r['kind'],truth=r['truth'],
    predicted_hardware_noise_fraction=p/den,
    actual_to_total_model_db=[10*np.log10(a/den) for a in m['actual_power']],
    repeat_noise_to_model_db=10*np.log10(m['repeat_difference_power_over_two']/p),
    residual_to_model_db=[10*np.log10(v/p) for v in m['residual_power']],
    residual_cross_to_model=m['residual_cross_power']/p,
    diagnostic_projection=m['evaluation_only_complex_projection'],
    early_late_residual_db=[10*np.log10(a/b) for a,b in m['residual_power_early_late']],
    carrier_residual_to_model_db=[[10*np.log10(v/c['model_noise_density']) for v in c['physical_residual_density']] for c in r['carrier_noise']]))
  levels[str(level)]=z
 out[name]=levels
(root/'level-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for name,levels in out.items():
 for level,rows in levels.items():
  print(name,level,'totalpower dB',np.round([v for r in rows for v in r['actual_to_total_model_db']],3).tolist(), 'repeatnoise dB',np.round([r['repeat_noise_to_model_db'] for r in rows],3).tolist(), 'quiet/residual dB',np.round([v for r in rows for v in r['residual_to_model_db']],3).tolist())

from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
BASE=Path(__file__).resolve().parent; ROOT=BASE.parents[1]
data=json.loads((BASE/'low-validation-analysis/results.json').read_text())
fig,axes=plt.subplots(2,2,figsize=(10,7.5),sharex=True,sharey=True)
for i,mode in enumerate(('wide','narrow')):
 for j,case in enumerate(('baseline','edge')):
  ax=axes[i,j]
  for kind,color,marker,style in [('physical','#1768aa','o','-'),('simulated','#d66d12','s','--')]:
   rows=sorted([r for r in data['summaries'] if r['gate_key']==f'{case}/{mode}' and r['kind']==kind and r['cn0_db_hz'] is not None],key=lambda r:r['cn0_db_hz'])
   x=np.array([r['cn0_db_hz'] for r in rows]);y=np.array([r['counts']['correct_admission']/r['trials'] for r in rows]);ci=np.array([r['pointwise_intervals_95']['correct_admission'] for r in rows]);err=np.array([y-ci[:,0],ci[:,1]-y])
   ax.errorbar(x,y,yerr=err,color=color,marker=marker,linestyle=style,label=kind.capitalize(),capsize=3,elinewidth=1,alpha=.8,markerfacecolor=color if kind=='physical' else 'white')
  ax.set_title(('Original wide workspace' if mode=='wide' else 'Fixed narrow frontend')+' · '+('Rate 3600' if case=='baseline' else 'Rate 24000'))
  ax.grid(alpha=.18);ax.set_ylim(-.04,1.04);ax.set_xticks([0,3,6]);ax.set_yticks([0,.25,.5,.75,1])
  if j==0:ax.set_ylabel('Correct admissions / trials')
  if i==1:ax.set_xlabel('Nominal pre-DAC C/N₀ (dB-Hz)')
handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=2,bbox_to_anchor=(.5,.955))
fig.suptitle('Independent low-level cable reception and frozen simulation',fontsize=15,y=.995)
fig.text(.5,.018,'Eight trials per point; pointwise 95% exact binomial intervals. Same raw capture feeds both frontends.\nAnalog and modeled residual noise are independent. Null and wrong-admission counts are retained in the report.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.065,1,.91));dest=ROOT/'docs/validation-data/triad-v3/2026-11-04-live-margin-bounds/reception-comparison.png';fig.savefig(dest,dpi=170);print(dest)

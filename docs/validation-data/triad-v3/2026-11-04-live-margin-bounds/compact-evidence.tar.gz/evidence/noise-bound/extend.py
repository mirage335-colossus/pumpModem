#!/usr/bin/env python3
"""Reuse completed fresh null captures; no hardware, model tuning or likelihoods."""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];BASE=HERE.parent
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_margins as campaign
import triad_live_model as model
import triad_live_narrowband as narrow
spec=importlib.util.spec_from_file_location('original_bound',HERE/'analyze.py');original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
read=original.read;write=original.write;digest=original.digest


def identities():
 paths=[HERE/'analyze.py',HERE/'results.json',BASE/'level-analysis/results.json',BASE/'level-probe/profile.json',
  Path(campaign.__file__),Path(model.__file__),Path(narrow.__file__),Path(campaign.wave.__file__)]
 for case in ('baseline','edge'):paths += [original.FIXTURES/case/'fixture.json',original.FIXTURES/case/'basis.npy']
 return {str(p.relative_to(ROOT)):digest(p) for p in paths}


def make_plan(path):
 if path.exists():raise FileExistsError(path)
 p=dict(schema='triad-live-noise-bound-extension-plan-v1',created_unix=time.time(),source_sha256=digest(__file__),
  input_sha256=identities(),old_result_preserved=True,stages=['calibration','validation'],
  noise_rms=.0001,null_records_only=True,old_public_templates=True,model_refit=False,
  uncertainty='same alpha=.05/4 component allocation and Student formulas as original; retain individual-window, physical-pass and source-record grouping',
  observation='new residual is actual minus exact continuous deterministic prediction, retaining coherent mismatch and hardware noise; no residual model draw is subtracted',
  alignment='reuse completed source-bound receiver public fits; verify first public marker and exact local-origin recurrence, float64 sinc input',
  counterfactual='no receiver scores, changes, admission tuning or physical retries',
  validation_hold='validation stage must not run until root explicitly confirms completed capture and receiver analysis')
 write(path,p);print(json.dumps(p,indent=2))


def summarize(rows):
 out={}
 for case in ('baseline','edge'):
  bs={}
  for bit in (0,1):
   nr=[r for r in rows if r['case']==case and r['bit']==bit and r['kind']=='noise'];gr=[r for r in rows if r['case']==case and r['bit']==bit and r['kind']=='gain'];methods={}
   for label,nv,gv in [
    ('record_conditional',[r['noise_ratio_db'] for r in nr],[r['gain_db'] for r in gr]),
    ('pass_cluster',original.cluster(nr,'pass_id','noise_ratio_db'),original.cluster(gr,'pass_id','gain_db')),
    ('source_record_cluster',original.cluster(nr,'source_record','noise_ratio_db'),original.cluster(gr,'source_record','gain_db'))]:
    ni=original.student(nv,.05/4);gi=original.student(gv,.05/4)
    methods[label]=dict(noise=ni,gain=gi,loss_mean_db=ni['mean_db']-gi['mean_db'],loss_interval_db=[ni['interval_db'][0]-gi['interval_db'][1],ni['interval_db'][1]-gi['interval_db'][0]])
   passes={p:dict(noise_mean_db=float(np.mean([r['noise_ratio_db'] for r in nr if r['pass_id']==p])),gain_mean_db=float(np.mean([r['gain_db'] for r in gr if r['pass_id']==p])),noise_windows=sum(r['pass_id']==p for r in nr),gain_windows=sum(r['pass_id']==p for r in gr)) for p in sorted({r['pass_id'] for r in nr})}
   for p,v in passes.items():v['loss_mean_db']=v['noise_mean_db']-v['gain_mean_db']
   bs[str(bit)]=dict(methods=methods,passes=passes,noise_observed_range_db=[min(r['noise_ratio_db'] for r in nr),max(r['noise_ratio_db'] for r in nr)],gain_observed_range_db=[min(r['gain_db'] for r in gr),max(r['gain_db'] for r in gr)])
  out[case]=dict(bits=bs,per_case_both_bit_intervals={m:[min(v['methods'][m]['loss_interval_db'][0] for v in bs.values()),max(v['methods'][m]['loss_interval_db'][1] for v in bs.values())] for m in ('record_conditional','pass_cluster','source_record_cluster')},component_alpha=.0125,case_error_budget=.05)
 return out


def run(args):
 start=time.perf_counter();protocol=read(args.plan)
 if digest(__file__)!=protocol['source_sha256'] or identities()!=protocol['input_sha256']:raise ValueError('frozen extension changed')
 out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
 old=read(HERE/'results.json')
 if args.include:
  previous=read(args.include)
  if previous['protocol_sha256']!=digest(args.plan):raise ValueError('previous stage protocol differs')
  rows=previous['rows'];passes=previous['included_stages']
 else:
  rows=[dict(r,pass_id=f"diagnostic-{r['repeat']+1}",source_record=f"diagnostic-{r['record']}") for r in old['rows']];passes=[]
 if args.stage in passes:raise ValueError('stage already included')
 if args.stage=='validation' and passes!=['calibration']:raise ValueError('validation requires completed calibration extension')
 src=BASE/('low-'+args.stage);analysis=BASE/('low-'+args.stage+'-analysis/results.json')
 completed=read(analysis);plan=read(src/'plan.json');profile=read(src/'profile.json');receipt=read(src/'capture.json')
 if completed.get('synthetic_only',True):raise ValueError('completed real analysis required')
 for p,want in [(src/'plan.json',completed['plan_sha256']),(src/'capture.f32',completed['capture_sha256']),
  (src/'capture.json',completed['metadata_sha256']),(src/'profile.json',completed['profile_sha256']),
  (src/'stimulus.f32',plan['stimulus_sha256'])]:
  if digest(p)!=want:raise ValueError('source-bound capture/input changed')
 if profile!=read(BASE/'level-probe/profile.json') or plan['noise_rms']!=protocol['noise_rms']:
  raise ValueError('noise or forward profile changed')
 tx=np.memmap(src/'stimulus.f32',dtype='<f4',mode='r');rx=np.memmap(src/'capture.f32',dtype='<f4',mode='r');campaign.validate_capture(receipt,len(rx))
 if np.max(abs(rx))>=.999:raise ValueError('clipping')
 align=completed['alignments']
 if len(align)!=len(plan['records']):raise ValueError('alignment record mismatch')
 first=plan['records'][0];delay=model._marker_delay(np.asarray(tx[:first['samples']]),np.asarray(rx[:first['samples']+2*campaign.FS]),campaign.FS,first['markers']['markers'][0])['delay_samples']
 state=model.AudioModelState(profile);prepared={};new=[]
 for case in ('baseline','edge'):
  f=read(original.FIXTURES/case/'fixture.json');op=narrow.NarrowbandFilter(f['receiver_sample_rate'],f['bandwidth']);_,valid,_=campaign.convert(np.zeros(f['payload_audio_samples']),f)
  basis,nv,meta=op.filter_basis(np.load(original.FIXTURES/case/'basis.npy'),valid,max_lag=max(f['lags']));weights=[]
  for bit in (0,1):
   t=basis[bit,:,0].copy();t[~nv]=0;weights.append(abs(np.fft.fft(t.astype(np.complex128)))**2)
  prepared[case]=(f,op,nv,weights,np.fft.fftfreq(len(nv),1/f['receiver_sample_rate']))
 for rec,fit in zip(plan['records'],align):
  if fit['index']!=rec['index']:raise ValueError('public fit index mismatch')
  off,n=rec['offset'],rec['samples'];chunk=np.asarray(tx[off:off+n]);pred=state.process(model.quantize_production_playback(chunk))
  a=max(0,int(off+delay-campaign.FS));b=min(len(rx),int(off+delay+n+campaign.FS));delay=a+fit['offset_samples']-off
  if abs(delay-fit['global_delay_samples'])>1e-7:raise ValueError('public alignment recurrence changed')
  if rec['truth'] is not None:continue
  if hashlib.sha256(chunk.tobytes()).hexdigest()!=rec['stimulus_sha256']:raise ValueError('null waveform changed')
  positions=np.arange(n,dtype=np.float64)*fit['sample_rate_ratio']+fit['offset_samples']-fit['causal_guard_samples']
  actual,amask=model._sinc_sample(model._samples(np.asarray(rx[a:b])),positions)
  model_residual=campaign.fixed_noise(profile,n,rec['noise_seed']+991000)
  lo=rec['markers']['payload']['start']
  for case,(f,op,valid,weights,target) in prepared.items():
   hi=lo+f['payload_audio_samples'];fs=f['receiver_sample_rate']
   if hi>lo+rec['markers']['payload']['samples'] or not amask[lo:hi].all():raise ValueError('old common template lacks capture payload support')
   y=op.filter_observation(campaign.convert(actual[lo:hi],f)[0]);p=op.filter_observation(campaign.convert(pred[lo:hi],f)[0]);mn=op.filter_observation(campaign.convert(model_residual[lo:hi],f)[0]);err=y[valid]-p[valid]
   freq,pe=original.welch(err,fs);fm,pm=original.welch(mn[valid],fs);fx,px=original.welch(p[valid],fs);fc,cross=original.csd(p[valid],y[valid],fs)
   if not np.array_equal(fx,fc) or np.any(px<=0):raise ValueError('unidentified transfer')
   h=cross/px;split=len(err)//2;fitgain=np.vdot(p[valid],y[valid])/np.vdot(p[valid],p[valid]);after=y[valid]-fitgain*p[valid]
   for bit,w in enumerate(weights):
    vp=original.weighted_variance(freq,pe,w,target,fs);vm=original.weighted_variance(fm,pm,w,target,fs);gain=np.sum(w*original.interp_periodic(target,fx,h,fs))/np.sum(w)
    if abs(gain)<=0 or not np.isfinite(gain):raise ValueError('invalid transfer')
    common=dict(case=case,record=rec['index'],repeat=None,bit=bit,pass_id=args.stage,source_record=f"{args.stage}-{rec['index']}")
    nr=dict(**common,kind='noise',physical_matched_variance=vp,model_matched_variance=vm,noise_ratio_db=float(10*np.log10(vp/vm)),early_late_power_ratio_db=float(10*np.log10(np.mean(abs(err[:split])**2)/np.mean(abs(err[split:])**2))),whole_residual_power=float(np.mean(abs(err)**2)),residual_power_after_evaluation_scalar_fit=float(np.mean(abs(after)**2)),scope='all actual-minus-deterministic residual retained, including any transfer mismatch; scalar-fit residual diagnostic not used as noise input')
    gr=dict(**common,kind='gain',probe_kind='noise',gain_real=float(gain.real),gain_imag=float(gain.imag),gain_db=float(20*np.log10(abs(gain))),phase_degrees=float(np.angle(gain,deg=True)),fitted_gain_applied=False)
    new.extend([nr,gr])
  print('processed null',rec['index'],flush=True)
 rows.extend(new);summaries=summarize(rows)
 result=dict(schema='triad-live-noise-bound-extension-v1',stage=args.stage,included_stages=[*passes,args.stage],rows=rows,summaries=summaries,protocol_sha256=digest(args.plan),source_sha256=digest(__file__),original_bound_sha256=digest(HERE/'results.json'),prior_stage_sha256=digest(args.include) if args.include else None,
  new_input_sha256={str(p.relative_to(ROOT)):digest(p) for p in [analysis,src/'plan.json',src/'profile.json',src/'capture.json',src/'capture.f32',src/'stimulus.f32']},new_null_records=len(new)//8,wall_seconds=time.perf_counter()-start,
  original_limits=old['inference_limits'],additional_limits=['Null-residual probes include coherent transfer mismatch rather than removing it; this is a conservative total-residual proxy, not identified thermal noise.','Original quiet payloads and new transmitted-noise payloads differ; pooling assumes their small-signal hardware innovations are sufficiently comparable, checked by pass-specific estimates, not proven.','The number of windows is not the number of hardware populations. Pass clustering uses one aggregate per complete physical capture; four captures on one codec/session remain far from independent future-device qualification.','No receiver, gate, profile or waveform is retuned with these estimates.'])
 write(out/'results.json',result);print(json.dumps({'stage':args.stage,'nulls':result['new_null_records'],'wall_seconds':result['wall_seconds'],'intervals':{k:v['per_case_both_bit_intervals'] for k,v in summaries.items()}},indent=2))


def main():
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='command',required=True);a=s.add_parser('plan');a.add_argument('--output',type=Path,required=True);b=s.add_parser('run');b.add_argument('--plan',type=Path,required=True);b.add_argument('--stage',choices=['calibration','validation'],required=True);b.add_argument('--include',type=Path);b.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.command=='plan':make_plan(a.output)
 else:run(a)
if __name__=='__main__':main()

# Conditional noise/gain loss proxy from retained physical repeats

This calculation reuses the two completed level-probe captures. It opens no audio
hardware, changes no receiver observation, fits no new forward profile, and runs
no likelihood/admission campaign. The source, workspace and public-template
identities are retained in `results.json`. Computation took **2.46 seconds** using
at most two numerical threads. Two small mathematical checks passed in 0.52 s.

The fixed 115-tap narrow frontend is applied to all observations and to the
original public baseline/edge templates. Its validity mask excludes full causal
startup support. For each public bit, the template-weighted stationary-noise
proxy is

`V = Fs/N * sum_k PSD(f_k) * abs(FFT(masked_template)[k])**2`.

The PSD is estimated from the actual quiet residual, **not** from the difference
between physical repeats. Thus shared hum or interference is not intentionally
cancelled. Four quiet observations are available: two record locations in each
of two physical passes. The matched model-noise PSD comes from the retained
independent model residual for that record; this draw is shared across the two
physical passes and is a finite Monte Carlo realization, not exact model variance.

For gain, the three known-composite records at pre-DAC noise RMS 0.0001 in each
case/pass supply `CSD(prediction, actual)/PSD(prediction)`. The resulting complex
relative transfer is integrated with each public template's spectral energy.
This accounts for frequency-dependent complex response rather than substituting
an unweighted carrier-band gain. The source record is known only in this
evaluation; no estimated gain is supplied to the receiver. Template weight at
weakly excited transfer bins is below 2.5e-15; excluding those bins changes gain
by less than 2.2e-14 dB in these observations.

Welch estimates use one-second Hann windows, 50% overlap and **no detrending**,
so a component at the complex carrier center is retained. Welch segments and
frequency bins are not counted as independent hardware observations.

The proxy loss is `L = 10log10(Vphysical/Vmodel) - 20log10(abs(gain))`.
Positive loss means more required C/N0 for this fixed matched-filter proxy.
It is **not the full acquisition/admission receiver's sensitivity shift**.

## Results

| Case | Noise-ratio observed range across both templates/windows | Gain observed range | Mean proxy loss, bits 0 / 1 |
|---|---:|---:|---:|
| Baseline | −0.0497 to +0.1088 dB | −0.0568 to +0.1422 dB | +0.0104 / −0.00155 dB |
| Edge | −0.00254 to +0.05095 dB | −0.01709 to +0.04736 dB | +0.01088 / +0.01535 dB |

The conditional Student calculations allocate the 5% **per-case** error budget
across four intervals: noise and gain for each of the two public bits. Their
extreme endpoints are combined, and the table below takes the envelope over both
bits. The bits use the same physical samples and are not independent replications.
Cases also share quiet observations; no joint two-case coverage claim is made.

| Statistical grouping | Baseline proxy-loss interval | Edge proxy-loss interval |
|---|---:|---:|
| Individual windows, conditional on fixed probes/model draws (noise n=4, gain n=6) | **[−0.288, +0.284] dB** | **[−0.083, +0.105] dB** |
| Physical-pass means (only n=2 passes) | **[−3.131, +3.128] dB** | **[−1.060, +1.082] dB** |
| Source-record means (noise n=2, gain n=3) | **[−2.557, +2.554] dB** | **[−0.525, +0.547] dB** |

These are **assumption-dependent engineering intervals**, not empirical
certificates that a future run stays within those bounds. The individual-window
calculation assumes independent, approximately normal log estimates and
stationary covariance, conditional on the fixed model draws and deterministic
probe. Repeated windows share source/model inputs and physical session state.
The much wider pass/source-cluster calculations expose the weak replication at
those levels; they do not establish a narrow future-pass bound. Conversely,
those wide intervals are not measured multi-dB hardware loss.

After narrowing, early/late quiet-residual power differences range from
+0.002 to +0.140 dB for baseline and −0.065 to +0.020 dB for edge. The payloads
follow fixed-amplitude public markers. This small observed settling difference
does not qualify marker-free, day-scale or other-device stationarity.

The original quiet-noise profile and both retained model draws have finite
estimation error. No separate rigorous Monte Carlo/profile-uncertainty bound or
distribution-free guarantee is claimed. Independent full receiver trial counts
remain necessary complementary evidence. Nothing here qualifies operational
false-admission rates, blind acquisition, RF AGC/oscillators or BER reliability.

## Reproduction

From the repository root, with the retained ignored workspaces available:

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 /tmp/triad-weak-env/bin/python \
  local-evidence/triad-live-margin-bounds-001/noise-bound/check_helpers.py
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 /tmp/triad-weak-env/bin/python \
  local-evidence/triad-live-margin-bounds-001/noise-bound/analyze.py
```

`results.json` contains all 40 per-case/bit/window estimates, component Student
intervals, weak-bin diagnostics, early/late powers and identities. Re-running the
script regenerates its result file; preserve the source-bound recorded result
before changing methods. This is a focused diagnostic, not a new physical trial.

## Staged extension using existing new null recordings

`extend.py` and `extension-protocol.json` freeze the same formulas and alpha
allocation before the additional residual analysis. The original result above
is preserved; its weak two-pass intervals are not overwritten.

The completed calibration capture supplies **39 additional known-noise null
records** at pre-DAC RMS 0.0001. Public alignment fits and capture/source hashes
are reused from the completed receiver analysis. A first public marker check
reconstructs the exact local-origin recurrence; float32 capture is promoted to
float64 before the same sinc interpolator. The deterministic model runs through
the complete chronological playlist, including source tails and guards.

For these nulls, the noise proxy uses `actual - deterministic_prediction`.
It retains any repeatable transfer mismatch instead of subtracting a fitted
amplitude or phase. Under independent zero-mean innovations, that extra error
increases expected residual power; this is not a pointwise conservativity proof.
An evaluation-only scalar projection lowers observed calibration residual power
by at most **0.00089 dB baseline / 0.00184 dB edge**, indicating little coherent
mismatch contamination at this low level. This fit is never used in the variance
estimate, model or receiver.

| Interval for mean proxy loss after calibration extension | Baseline | Edge |
|---|---:|---:|
| Individual-window conditional | [−0.0421, +0.0572] dB | [+0.00394, +0.04534] dB |
| **Physical-pass means, n=3 passes** | **[−0.3161, +0.3168] dB** | **[−0.1073, +0.1374] dB** |
| Source-record means | [−0.0421, +0.0579] dB | [+0.00446, +0.04616] dB |

The calibration-only pass estimates are +0.0119/+0.0041 dB for baseline bits 0/1
and +0.0234/+0.0283 dB for edge. Their early/late residual power differences range
from −0.161 to +0.132 dB (baseline) and −0.057 to +0.047 dB (edge).

The calibration extension cost **83.86 seconds**, including raw alignment,
continuous forward processing, DDC, spectral estimates and hashes. It performs
no receiver likelihood evaluations and adds no hardware time. Reusing the old
public templates keeps the evaluation weighting fixed across physical passes;
it does not turn those templates into new physical patterns.

All original inference limits remain. In addition, pooling quiet payloads with
known transmitted-noise nulls assumes their small-signal hardware innovations
are comparable. Per-pass results test consistency but do not prove that law.
The pass-level intervals estimate the **mean** discrepancy under the stated
Student assumptions; they are not prediction intervals for an individual future
pass. All passes use one codec and session, not independent hardware populations.

The validation extension was held until the parent confirmed its complete clean
capture and receiver analysis. It then reused the same frozen method on only
the declared fresh null records, with this command:

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 /tmp/triad-weak-env/bin/python \
  local-evidence/triad-live-margin-bounds-001/noise-bound/extend.py run \
  --plan local-evidence/triad-live-margin-bounds-001/noise-bound/extension-protocol.json \
  --stage validation \
  --include local-evidence/triad-live-margin-bounds-001/noise-bound/calibration-extension/results.json \
  --output local-evidence/triad-live-margin-bounds-001/noise-bound/validation-extension
```

The stage command requires a fresh output directory and completed clean,
source-bound input evidence. It never changes model or receiver settings in
response to the bound.

The numerical pass-cluster interval is wider than the window interval here,
but it is **not proven conservative**. Exact Student coverage would also need
approximately equal-variance independent pass effects. Within-pass record
counts differ substantially (2 quiet/3 gain probes versus 39 nulls), so equal
precision is not established. Treat the reported nominal levels as conditional
engineering uncertainty, not certification of their repeated-sampling coverage.


## Completed four-pass extension

The released validation stage processed **16 fresh null records** in
**36.52 seconds**, reusing the final receiver analysis's public alignments and
receipt hashes. It added no hardware time and ran no likelihoods. No model,
receiver, gate or method was changed after the stage freeze. The source-bound
result is `validation-extension/results.json`; it includes 59 noise-window and
61 gain-window estimates per case/bit, grouped into **four physical captures**.
Those windows are not 59 or 61 hardware populations. Both earlier bound stages
remain intact.

| Completed mean-loss interval | Baseline | Edge |
|---|---:|---:|
| Individual-window conditional | [−0.0420, +0.0433] dB | [+0.0124, +0.0501] dB |
| **Physical-pass means, n=4** | **[−0.1536, +0.1434] dB** | **[−0.0434, +0.0905] dB** |
| Source-record means | [−0.0422, +0.0435] dB | [+0.0130, +0.0509] dB |

The validation pass alone estimates losses of −0.0121/−0.0214 dB for baseline
bits 0/1 and +0.0443/+0.0532 dB for edge. Its early/late residual-power differences
are −0.061 to +0.082 dB (baseline) and −0.031 to +0.050 dB (edge). Evaluation-only
scalar fitting changes validation residual power by at most 0.000542 dB and
0.001829 dB respectively; the unfitted residual remains the calculation input.

These tighter **conditional mean-proxy** intervals do not retroactively erase
the original weak two-pass result, establish a distribution-free confidence
level, or bound an individual future pass. Small cluster counts, unequal
within-pass precision, stationarity, approximate log-normality and the fixed
codec/session remain material assumptions. Independent marginal reception
outcomes belong to the parent's separate receiver comparison and are not
inferred from these PSD/transfer calculations.

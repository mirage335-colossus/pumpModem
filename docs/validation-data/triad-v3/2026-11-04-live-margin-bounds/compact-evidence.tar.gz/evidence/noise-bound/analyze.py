#!/usr/bin/env python3
"""Conditional template-weighted cable SNR proxy; no hardware or admissions."""
from __future__ import annotations
import hashlib,json,math,sys,time
from pathlib import Path
import numpy as np
from scipy import signal,stats
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import triad_live_narrowband as narrow
BASE=HERE.parent
SOURCE=BASE/'level-analysis/results.json'
FIXTURES=ROOT/'local-evidence/triad-live-reception-001/calibration-002/fixtures'


def digest(path):
 with Path(path).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()

def read(path):return json.loads(Path(path).read_text())
def write(path,x):Path(path).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')

def interp_periodic(target,freq,value,fs):
 order=np.argsort(freq)
 return np.interp(target,freq[order],value[order],period=fs)

def welch(x,fs):
 return signal.welch(x,fs=fs,nperseg=round(fs),noverlap=round(fs)//2,
  window='hann',detrend=False,return_onesided=False,scaling='density',axis=-1)

def csd(x,y,fs):
 return signal.csd(x,y,fs=fs,nperseg=round(fs),noverlap=round(fs)//2,
  window='hann',detrend=False,return_onesided=False,scaling='density',axis=-1)

def weighted_variance(freq,psd,weight,target,fs):
 # Var(a^H n) = Fs/N sum_k S_n(f_k)|A_k|^2 under stationary covariance.
 return float(fs/len(target)*np.sum(interp_periodic(target,freq,psd,fs)*weight))

def student(values,alpha):
 values=np.asarray(values,float)
 n=len(values)
 if n<2 or not np.isfinite(values).all():raise ValueError('at least two finite cluster values required')
 mean=float(values.mean());sd=float(values.std(ddof=1));half=float(stats.t.ppf(1-alpha/2,n-1)*sd/math.sqrt(n))
 return dict(n=n,mean_db=mean,sd_db=sd,standard_error_db=sd/math.sqrt(n),interval_db=[mean-half,mean+half],
  component_alpha=alpha,df=n-1,assumptions='independent approximately normal cluster log-estimates; conditional on this fixed model/probe and noise stationarity')

def cluster(rows,key,value):
 labels=sorted({r[key] for r in rows})
 return [float(np.mean([r[value] for r in rows if r[key]==label])) for label in labels]

def estimate():
 begun=time.perf_counter();data=read(SOURCE)
 if data.get('synthetic_only',True):raise ValueError('real repeat receipt required')
 records=[];bound={str(SOURCE.relative_to(ROOT)):digest(SOURCE)};summaries={}
 for case in ('baseline','edge'):
  f=read(FIXTURES/case/'fixture.json');basis=np.load(FIXTURES/case/'basis.npy')
  bound[str((FIXTURES/case/'fixture.json').relative_to(ROOT))]=digest(FIXTURES/case/'fixture.json')
  bound[str((FIXTURES/case/'basis.npy').relative_to(ROOT))]=digest(FIXTURES/case/'basis.npy')
  fs=f['receiver_sample_rate'];op=narrow.NarrowbandFilter(fs,f['bandwidth'])
  selected=[r for r in data['rows'] if r['case']==case and (r['kind']=='silence' or r['noise_rms']==.0001)]
  case_rows=[]
  for row in selected:
   path=BASE/'level-analysis'/row['workspace']
   if digest(path)!=row['workspace_sha256']:raise ValueError('workspace identity changed')
   bound[str(path.relative_to(ROOT))]=row['workspace_sha256']
   z=np.load(path);valid=op.valid_mask(z['valid'])
   nb,public_valid,meta=op.filter_basis(basis,z['valid'],max_lag=max(f['lags']))
   if not np.array_equal(valid,public_valid):raise ValueError('public/observation mask mismatch')
   y=np.asarray([op.filter_observation(x) for x in z['physical']])
   pred=op.filter_observation(z['deterministic_prediction']);model_noise=op.filter_observation(z['simulated_residual'])
   n=len(pred);target=np.fft.fftfreq(n,1/fs)
   weights=[]
   for bit in (0,1):
    template=nb[bit,:,0].copy();template[~valid]=0
    weights.append(abs(np.fft.fft(template.astype(np.complex128)))**2)
   if row['kind']=='silence':
    errors=y[:,valid]-pred[valid]
    freq,physical_psd=welch(errors,fs);fm,model_psd=welch(model_noise[valid],fs)
    for bit,weight in enumerate(weights):
     vm=weighted_variance(fm,model_psd,weight,target,fs)
     for repeat in (0,1):
      vp=weighted_variance(freq,physical_psd[repeat],weight,target,fs)
      half=errors.shape[-1]//2; early=float(np.mean(abs(errors[repeat,:half])**2));late=float(np.mean(abs(errors[repeat,half:])**2))
      r=dict(case=case,record=row['index'],repeat=repeat,bit=bit,kind='noise',
       physical_matched_variance=vp,model_matched_variance=vm,noise_ratio_db=float(10*np.log10(vp/vm)),
       early_late_power_ratio_db=float(10*np.log10(early/late)),
       whole_residual_power=float(np.mean(abs(errors[repeat])**2)))
      case_rows.append(r)
   else:
    x=pred[valid]
    freq,px=welch(x,fs)
    for repeat in (0,1):
     fc,cross=csd(x,y[repeat,valid],fs)
     if not np.array_equal(freq,fc) or np.any(px<=0):raise ValueError('unidentifiable transfer PSD')
     h=cross/px
     for bit,weight in enumerate(weights):
      hh=interp_periodic(target,freq,h,fs)
      gain=np.sum(weight*hh)/np.sum(weight)
      exposure=interp_periodic(target,freq,px,fs)
      weak=exposure<np.max(px)*1e-10
      fraction=float(np.sum(weight[weak])/np.sum(weight))
      if fraction>1e-5:raise ValueError('template transfer insufficiently excited')
      strong_gain=np.sum(weight[~weak]*hh[~weak])/np.sum(weight[~weak])
      if not np.isfinite(gain) or abs(gain)<=0:raise ValueError('nonfinite or zero transfer')
      r=dict(case=case,record=row['index'],repeat=repeat,bit=bit,kind='gain',probe_kind=row['kind'],
       gain_real=float(gain.real),gain_imag=float(gain.imag),gain_db=float(20*np.log10(abs(gain))),phase_degrees=float(np.angle(gain,deg=True)),
       weakly_excited_template_weight_fraction=fraction,
       weak_bin_exclusion_gain_change_db=float(20*np.log10(abs(gain)/abs(strong_gain))),
       fitted_gain_applied=False,scope='known composite cross-spectrum relative to deterministic prediction, evaluated with the public template spectral weight; no receiver input adjustment')
      case_rows.append(r)
  records.extend(case_rows)
  # Allocate 5% across two bits x two components for per-case union coverage,
  # only if the stated Student assumptions actually hold. No two-case union claim.
  alpha=.05/4;bit_summaries={}
  for bit in (0,1):
   noise_rows=[r for r in case_rows if r['bit']==bit and r['kind']=='noise']
   gain_rows=[r for r in case_rows if r['bit']==bit and r['kind']=='gain']
   methods={}
   for method,noise_values,gain_values in [
    ('record_conditional',[r['noise_ratio_db'] for r in noise_rows],[r['gain_db'] for r in gain_rows]),
    ('pass_cluster',cluster(noise_rows,'repeat','noise_ratio_db'),cluster(gain_rows,'repeat','gain_db')),
    ('source_record_cluster',cluster(noise_rows,'record','noise_ratio_db'),cluster(gain_rows,'record','gain_db'))]:
    ni=student(noise_values,alpha);gi=student(gain_values,alpha)
    methods[method]=dict(noise=ni,gain=gi,loss_mean_db=ni['mean_db']-gi['mean_db'],
     loss_interval_db=[ni['interval_db'][0]-gi['interval_db'][1],ni['interval_db'][1]-gi['interval_db'][0]])
   bit_summaries[str(bit)]=dict(methods=methods,noise_observed_range_db=[min(r['noise_ratio_db'] for r in noise_rows),max(r['noise_ratio_db'] for r in noise_rows)],
    gain_observed_range_db=[min(r['gain_db'] for r in gain_rows),max(r['gain_db'] for r in gain_rows)],
    model_variance_per_quiet_record={str(r['record']):r['model_matched_variance'] for r in noise_rows})
  summaries[case]=dict(bits=bit_summaries,
   per_case_both_bit_intervals={m:[min(v['methods'][m]['loss_interval_db'][0] for v in bit_summaries.values()),max(v['methods'][m]['loss_interval_db'][1] for v in bit_summaries.values())] for m in ('record_conditional','pass_cluster','source_record_cluster')},
   hardware_quiet_windows=4,physical_passes=2,gain_windows=6,quiet_source_records=2,gain_source_records=3,
   component_alpha=alpha,case_error_budget=.05,
   interpretation='positive loss means additional required C/N0 for this fixed matched-filter proxy, not acquisition/admission/BER sensitivity')
 result=dict(schema='triad-live-conditional-noise-gain-bound-v1',rows=records,summaries=summaries,
  source_sha256={str(Path(__file__).relative_to(ROOT)):digest(__file__),str(Path(narrow.__file__).relative_to(ROOT)):digest(narrow.__file__)},
  input_sha256=bound,wall_seconds=time.perf_counter()-begun,
  PSD_method=dict(window='Hann',seconds=1,overlap_fraction=.5,detrend=False,two_sided=True,template_weight='squared absolute FFT of masked public filtered column0, both bit alternatives',
   covariance_assumption='stationary smooth covariance within each finite observation; Welch segments and bins are NOT statistical hardware replicates'),
  inference_limits=[
   'No operational false-admission, blind-acquisition, BER or universal future sensitivity bound.',
   'Student intervals are conditional engineering estimates, not distribution-free confidence guarantees; cluster normality/independence and stationarity are assumptions with very small cluster counts.',
   'The record-conditional interval treats repeated physical innovations as independent and conditions on cached model-noise draws. The same model draw and deterministic probe are reused across passes; source-record and pass-cluster alternatives reveal that dependence.',
   'Two model-noise draws per case are finite Monte Carlo realizations, not exact model variance. Source-record intervals retain their shared variation; no formal separate Monte Carlo error guarantee is claimed.',
   'Both public bits use the same physical windows and are dependent. The .05 per-case budget is split across four component intervals; cases share physical quiet records and no joint two-case coverage claim is made.',
   'Quiet and low-level payloads follow fixed public markers. Early/late residual powers are retained; no marker-free or long-term noise law is identified.',
   'Gain estimates use known transmitted composite/noise realization only for evaluation. No payload gain is supplied to the operational receiver.',
   'All confidence and dB limits refer to this codec, route, levels, session and fixed frontend. Different radio/clock/antenna paths remain untested.'
  ])
 write(HERE/'results.json',result)
 print(json.dumps({'wall_seconds':result['wall_seconds'],'intervals':{k:v['per_case_both_bit_intervals'] for k,v in summaries.items()}},indent=2))
 return result

if __name__=='__main__':estimate()

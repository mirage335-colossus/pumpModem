from pathlib import Path
import importlib.util,json,platform,hashlib
import numpy as np
import scipy
p=Path(__file__).with_name('analyze.py');s=importlib.util.spec_from_file_location('noise_bounds',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rng=np.random.default_rng(97113);fs=1000;n=4096;a=rng.normal(size=n)+1j*rng.normal(size=n);w=abs(np.fft.fft(a))**2;freq=np.fft.fftfreq(1000,1/fs);target=np.fft.fftfreq(n,1/fs);sigma2=.37
v=m.weighted_variance(freq,np.full(1000,sigma2/fs),w,target,fs);expected=sigma2*np.sum(abs(a)**2)
assert np.isclose(v,expected,rtol=1e-13,atol=0),(v,expected)
x=rng.normal(size=n)+1j*rng.normal(size=n);gain=1.2*np.exp(.4j);fq,px=m.welch(x,fs);_,cross=m.csd(x,gain*x,fs);h=cross/px
assert np.max(abs(h-gain))<1e-12,np.max(abs(h-gain))
report={'checks':['white PSD normalization equals sigma_squared times template energy','CSD ratio recovers independent prescribed complex gain'],'passed':2,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'scope':'small mathematical helper checks; no hardware/admission/interval-distribution validation'}
Path(__file__).with_name('checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

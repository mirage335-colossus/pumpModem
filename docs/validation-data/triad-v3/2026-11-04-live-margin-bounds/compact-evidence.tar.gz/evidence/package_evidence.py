#!/usr/bin/env python3
"""Create and verify a compact, deterministic evidence archive.

This script is deliberately separate from the capture and receiver tools. It
hashes large PCM/array files into a manifest but never copies those samples
into the maintained evidence directory. Run once after root has frozen all
validation outputs and explicitly releases packaging.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEST = ROOT / "docs/validation-data/triad-v3/2026-11-04-live-margin-bounds"
ARCHIVE = DEST / "compact-evidence.tar.gz"
INVENTORY = HERE / "raw-input-inventory.json"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def raw_inventory() -> dict:
    """Stream-hash raw PCM, stimuli, and numerical arrays without loading them."""
    scopes = (
        ROOT / "local-evidence/triad-live-margin-bounds-001",
        ROOT / "local-evidence/triad-live-reception-001",
        ROOT / "local-evidence/triad-live-margin-preparer-smoke",
    )
    suffixes = {".f32", ".s16le", ".npy", ".npz", ".c64", ".bin", ".iq16"}
    entries = []
    for scope in scopes:
        if not scope.exists():
            continue
        for path in sorted(scope.rglob("*")):
            if not path.is_file() or path.is_symlink() or "__pycache__" in path.parts:
                continue
            if path.suffix.lower() not in suffixes:
                continue
            entries.append({
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                "kind": "raw_audio_or_transmitted_pcm" if path.suffix.lower() in {".f32", ".s16le"}
                        else "numerical_array_or_native_waveform",
                "embedded": path.suffix.lower() == ".npz" and path.stat().st_size <= 1_000_000
                            and path.name.startswith("quiet-spectrum-"),
            })
    return {
        "schema": "triad-live-margin-raw-input-inventory-v1",
        "scopes": [p.relative_to(ROOT).as_posix() for p in scopes],
        "entries": entries,
        "entry_count": len(entries),
        "total_bytes": sum(x["bytes"] for x in entries),
        "scope_note": (
            "PCM, S16 transport, transmitted stimulus and native/numerical arrays are inventoried by "
            "streamed SHA256; large files remain in ignored local-evidence. Only the four small "
            "quiet-spectrum diagnostic NPZ files are eligible for archive inclusion. Physical audio "
            "contains independent hardware noise and cannot be regenerated from a software seed."
        ),
    }


def evidence_files() -> dict[str, Path]:
    files: dict[str, Path] = {}
    for path in sorted(HERE.rglob("*")):
        if not path.is_file() or path.is_symlink() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(HERE)
        if relative.name == "package_evidence.py":
            files[f"evidence/{relative.as_posix()}"] = path
            continue
        suffix = path.suffix.lower()
        if suffix in {".json", ".py", ".log", ".txt", ".md"}:
            files[f"evidence/{relative.as_posix()}"] = path
        elif suffix == ".npz" and path.name.startswith("quiet-spectrum-") and path.stat().st_size <= 1_000_000:
            files[f"evidence/{relative.as_posix()}"] = path

    # Keep the validated correction that explains the previously hidden
    # baseline and high-edge discrepancies.
    upper_edge_profile = HERE / "../triad-live-reception-001/upper-edge/profile.json"
    files["evidence/audio-profile-upper-edge.json"] = upper_edge_profile.resolve()

    source_names = {
        "tools/triad_live_frontend_compare.py",
        "tools/triad_live_level_analysis.py",
        "tools/triad_live_level_probe.py",
        "tools/triad_live_narrowband.py",
        "tools/triad_live_margins.py",
        "tools/triad_live_receiver.py",
        "tools/triad_live_model.py",
        "tools/triad_live_waveforms.py",
        "tools/triad_live_alsa.py",
        "tools/triad_audio_capture.cpp",
        "tools/triad_long.cpp",
        "tools/triad_fft_acquire.py",
        "tools/triad_group_acquire.py",
        "tools/triad_gaussian_window.py",
        "tools/triad_noise_likelihood.py",
        "src/audio.cpp",
        "include/datapump/audio.hpp",
        "include/datapump/channel.hpp",
    }
    for path in sorted(ROOT.glob("src/triad*")):
        if path.is_file():
            source_names.add(path.relative_to(ROOT).as_posix())
    for path in sorted(ROOT.glob("include/datapump/triad*")):
        if path.is_file():
            source_names.add(path.relative_to(ROOT).as_posix())
    for path in sorted(ROOT.glob("src/channel_*.hpp")):
        if path.is_file():
            source_names.add(path.relative_to(ROOT).as_posix())
    for path in sorted((ROOT / "tests").glob("test_triad_live_*.py")):
        if path.is_file():
            source_names.add(path.relative_to(ROOT).as_posix())
    for name in sorted(source_names):
        path = ROOT / name
        if not path.is_file():
            continue
        files[f"snapshot/{name}"] = path
    return files


def package() -> dict:
    if ARCHIVE.exists():
        raise FileExistsError(ARCHIVE)
    DEST.mkdir(parents=True, exist_ok=True)
    inventory = raw_inventory()
    write_json(INVENTORY, inventory)

    files = evidence_files()
    files["evidence/raw-input-inventory.json"] = INVENTORY
    # Never package arbitrary symlinks or two physical inputs under one name.
    if len(files) != len(set(files)):
        raise ValueError("duplicate archive member path")
    if any(p.is_symlink() or not p.is_file() for p in files.values()):
        raise ValueError("archive source is not a regular file")

    entries = []
    with ARCHIVE.open("xb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=6) as gz:
            with tarfile.open(fileobj=gz, mode="w") as tar:
                for name, path in sorted(files.items()):
                    data = path.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    tar.addfile(info, io.BytesIO(data))
                    entries.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

    manifest = {
        "schema": "triad-live-margin-bounds-artifact-manifest-v1",
        "archive": ARCHIVE.name,
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": sha256(ARCHIVE),
        "source_head_at_packaging": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "raw_input_inventory_sha256": sha256(INVENTORY),
        "raw_input_count": inventory["entry_count"],
        "raw_input_total_bytes": inventory["total_bytes"],
        "entries": entries,
        "archive_scope": (
            "Compact per-record scores, calibration and validation receipts, frozen source snapshots, "
            "diagnostic recipes and small quiet spectra. Large PCM, S16 recordings and native arrays "
            "are excluded from the archive but covered by raw-input-inventory.json. Final report is "
            "maintained beside this archive; historical inputs are bound by the archived plan hashes."
        ),
    }
    manifest_path = DEST / "artifact-manifest.json"
    write_json(manifest_path, manifest)
    return manifest


def verify(manifest: dict) -> dict:
    """Independently stream-check the completed archive against its manifest."""
    seen = set()
    with tarfile.open(ARCHIVE, mode="r:gz") as tar:
        members = tar.getmembers()
        for member, expected in zip(members, manifest["entries"], strict=True):
            if not member.isfile() or member.name != expected["path"] or member.name in seen:
                raise ValueError("archive contains a non-regular, duplicate or unexpected entry")
            if member.name.startswith("/") or ".." in Path(member.name).parts:
                raise ValueError("unsafe archive path")
            seen.add(member.name)
            stream = tar.extractfile(member)
            if stream is None:
                raise ValueError("archive member cannot be read")
            h = hashlib.sha256()
            size = 0
            while True:
                block = stream.read(1024 * 1024)
                if not block:
                    break
                h.update(block)
                size += len(block)
            if size != expected["bytes"] or h.hexdigest() != expected["sha256"]:
                raise ValueError("archive member differs from manifest: " + member.name)
    if len(seen) != len(manifest["entries"]):
        raise ValueError("archive member count differs from manifest")
    if sha256(ARCHIVE) != manifest["archive_sha256"] or ARCHIVE.stat().st_size != manifest["archive_bytes"]:
        raise ValueError("whole-archive hash/size mismatch")
    return {"verified_entries": len(seen), "archive_bytes": ARCHIVE.stat().st_size,
            "archive_sha256": sha256(ARCHIVE)}


if __name__ == "__main__":
    manifest = package()
    verification = verify(manifest)
    print(json.dumps({k: v for k, v in manifest.items() if k not in {"entries", "archive_scope"}}))
    print(json.dumps(verification))

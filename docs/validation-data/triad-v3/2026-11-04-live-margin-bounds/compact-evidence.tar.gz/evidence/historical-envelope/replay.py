#!/usr/bin/env python3
"""Frozen historical cable receiver: exact quantized gain-envelope replay.

No hardware access. `plan` binds immutable historical evidence and this script.
`run` requires the plan and root authorization; it reuses physical scores, never
rescoring or normalizing them. Gain offsets change only the known signal in a
simulated counterfactual. Both public bit hypotheses remain in every receiver.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

import numpy as np
import scipy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
BASE=ROOT/'local-evidence/triad-live-reception-001'
sys.path.insert(0,str(ROOT/'tools'))
OFFSETS=(-1.,-.5,0.,.5,1.)
SCORE_ATOL=1e-7
SCORE_RTOL=1e-8
MIN_SLOPE=.01


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):return json.loads(Path(path).read_text())
def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def load_frozen_campaign():
    path=HERE/'frozen_triad_live_margins.py'
    wanted=read(BASE/'execution-freeze.json')['source_and_input_sha256']['tools/triad_live_margins.py']
    if digest(path)!=wanted:raise ValueError('frozen historical campaign source changed')
    spec=importlib.util.spec_from_file_location('frozen_triad_live_margins',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def threshold(calibration):
    """Strict upper rank threshold; preserve conservative score ties."""
    values=np.asarray(calibration['sorted_null_scores'],float)
    n=len(values); allowed=int(np.floor(calibration['alpha']*(n+1)-1+1e-12))
    if n!=calibration['null_count'] or allowed<0 or allowed>=n or np.any(np.diff(values)<0):
        raise ValueError('unsupported empirical rank gate')
    return float(values[-allowed-1])


def true_margin(outcome,truth,tau):
    scores=np.asarray(outcome['bit_log_likelihoods'],float)
    if scores.shape!=(2,) or truth not in (0,1) or not np.isfinite(scores).all():
        raise ValueError('invalid two-bit evaluation score')
    return float(min(scores[truth]-tau,scores[truth]-scores[1-truth]))


def invert_margin(offsets,margins,physical_margin):
    x=np.asarray(offsets,float);y=np.asarray(margins,float)
    if x.ndim!=1 or len(x)<2 or x.shape!=y.shape or not np.isfinite(y).all() or not np.isfinite(physical_margin):
        raise ValueError('invalid local margin curve')
    slopes=np.diff(y)/np.diff(x)
    if np.any(np.diff(x)<=0):raise ValueError('gain offsets must increase')
    common=dict(minimum_slope=float(np.min(slopes)),maximum_slope=float(np.max(slopes)),
                linear_interpolation_only=True)
    if np.any(slopes<=0):return dict(status='nonmonotonic_or_flat',equivalent_shift_db=None,**common)
    if np.min(slopes)<MIN_SLOPE:return dict(status='insufficient_local_slope',equivalent_shift_db=None,**common)
    if not y[0]<=physical_margin<=y[-1]:return dict(status='unbracketed',equivalent_shift_db=None,**common)
    return dict(status='identified_on_declared_grid',equivalent_shift_db=float(np.interp(physical_margin,y,x)),**common)


def paths():
    return dict(execution_freeze=BASE/'execution-freeze.json',
        prepared=BASE/'validation',primary=BASE/'validation-analysis/results.json',
        gates=BASE/'calibration-analysis/gates.json',primary_gates=BASE/'validation-analysis/gates.json',
        corrected=BASE/'upper-edge/independent-replay-002/results.json',
        profile=BASE/'upper-edge/profile.json',profile_freeze=BASE/'upper-edge/freeze.json',
        corrected_script=BASE/'upper-edge/replay_forward.py',
        frozen_campaign=HERE/'frozen_triad_live_margins.py')


def verify_inputs():
    p=paths(); frozen=read(p['execution_freeze'])
    for name,want in frozen['source_and_input_sha256'].items():
        source=p['frozen_campaign'] if name=='tools/triad_live_margins.py' else ROOT/name
        if digest(source)!=want:raise ValueError('historical input/source changed: '+name)
    primary=read(p['primary']); corrected=read(p['corrected']); plan=read(p['prepared']/'plan.json')
    if primary.get('synthetic_only',True):raise ValueError('historical result is not physical')
    bindings=[(p['primary'],corrected['primary_results_sha256']),
        (p['prepared']/'plan.json',primary['plan_sha256']),
        (p['prepared']/'stimulus.f32',plan['stimulus_sha256']),
        (p['prepared']/'profile.json',primary['profile_copy_sha256']),
        (p['profile'],corrected['corrected_profile_sha256']),
        (p['profile_freeze'],corrected['profile_freeze_sha256']),
        (p['gates'],corrected['original_gates_sha256']),
        (p['corrected_script'],corrected['source_sha256'])]
    for path,wanted in bindings:
        if digest(path)!=wanted:raise ValueError('historical binding changed: '+str(path))
    if digest(p['gates'])!=digest(p['primary_gates']):raise ValueError('physical gate identity differs')
    if np.__version__!=frozen['environment']['numpy'] or scipy.__version__!=frozen['environment']['scipy']:
        raise ValueError('historical NumPy/SciPy environment changed')
    signal_count=sum(rec['truth'] is not None for rec in plan['records'])
    if signal_count!=72:raise ValueError('expected exactly 72 historical signal records')
    return p,plan,primary,corrected


def make_plan(destination):
    p,plan,primary,corrected=verify_inputs()
    destination=Path(destination)
    if destination.exists():raise FileExistsError(destination)
    bound={name:digest(path) for name,path in p.items() if path.is_file()}
    bound['prepared_plan']=digest(p['prepared']/'plan.json')
    bound['stimulus']=digest(p['prepared']/'stimulus.f32')
    result=dict(schema='triad-live-historical-gain-envelope-plan-v1',
        script_sha256=digest(__file__),input_sha256=bound,created_unix=time.time(),
        offsets_db=list(OFFSETS),score_agreement_atol=SCORE_ATOL,score_agreement_rtol=SCORE_RTOL,
        minimum_inverse_slope_score_per_db=MIN_SLOPE,signals=72,
        chronological_records=len(plan['records']),cases=plan['cases'],
        root_execution_approval_required=True,
        counterfactual='change only current signal payload; preserve original preceding state, transmitted noise, markers and model residual draw; exact complete-composite S16 requantization',
        frozen_receiver='actual archived campaign source and unchanged current kernels; original receiver ID must match physical rows and gates',
        physical_use='reuse source-bound physical score rows and decisions; no payload alignment, fitting or physical rescoring',
        interpretation='evaluation-only local equivalent gain shift and decision envelope; no probability/sensitivity confidence bound follows from score interpolation',
        retained_failures='nonmonotonic, shallow and unbracketed curves remain explicit; zero-offset consistency failure stops the campaign and preserves completed rows')
    write(destination,result);return result


def run(plan_path,output,limit):
    begun=time.perf_counter();protocol=read(plan_path)
    if protocol['script_sha256']!=digest(__file__):raise ValueError('replay script differs from frozen protocol')
    if protocol['offsets_db']!=list(OFFSETS):raise ValueError('offset protocol changed')
    p,plan,primary,corrected=verify_inputs()
    actual_bind={name:digest(path) for name,path in p.items() if path.is_file()}
    actual_bind.update(prepared_plan=digest(p['prepared']/'plan.json'),stimulus=digest(p['prepared']/'stimulus.f32'))
    if actual_bind!=protocol['input_sha256']:raise ValueError('input differs from frozen protocol')
    campaign=load_frozen_campaign();model=campaign.model
    from triad_live_receiver import EmpiricalReceiver,empirical_decision,evaluate
    import torch
    if torch.__version__!=read(p['execution_freeze'])['environment']['torch']:
        raise ValueError('historical PyTorch environment changed')
    out=Path(output);out.mkdir(parents=True,exist_ok=False)
    rows=[]
    try:
        gates=read(p['gates']);fixtures_dir=Path(plan['fixtures_directory']);fixtures={};receivers={}
        physical={(r['index'],r['case']):r for r in primary['rows'] if r['kind']=='physical'}
        original={(r['index'],r['case']):r for r in corrected['rows']}
        prep_start=time.perf_counter()
        for name in plan['cases']:
            f=campaign.read_json(fixtures_dir/name/'fixture.json');fixtures[name]=f
            if campaign.digest(fixtures_dir/name/'fixture.json')!=plan['fixture_json_sha256'][name]:
                raise ValueError('historical fixture metadata changed')
            campaign.verify_fixture(fixtures_dir/name,f)
            _,valid,_=campaign.convert(np.zeros(f['payload_audio_samples']),f)
            receivers[name]=EmpiricalReceiver(np.load(fixtures_dir/name/'basis.npy'),f['receiver_sample_rate'],np.asarray(f['lags']),
                key=f['public_key'],valid=valid,reference_variance=f['reference_variance'],
                frequency_offsets=tuple(f['frequency_offsets_hz']),precision='fp32',
                preprocessing_identity=json.dumps(dict(fixture=f['preprocessing_identity'],
                    sources=campaign.preprocessing_sources(),campaign_source=digest(campaign.__file__),
                    numpy=np.__version__,scipy=scipy.__version__),sort_keys=True))
            if receivers[name].receiver_id!=gates[name]['receiver_id']:raise ValueError('receiver identity differs from original gate')
        for (index,name),row in physical.items():
            if row['receiver_id']!=receivers[name].receiver_id:raise ValueError('physical score identity changed')
            if evaluate(empirical_decision(row,gates[name]),row['truth'])!=row['classification']:
                raise ValueError('stored physical decision fails replay')
        preparation_seconds=time.perf_counter()-prep_start
        profile=read(p['profile']);state=model.AudioModelState(profile)
        tx=np.memmap(p['prepared']/'stimulus.f32',dtype='<f4',mode='r')
        signal_cache={}
        process_start=time.perf_counter()
        for rec in plan['records']:
            off,n=rec['offset'],rec['samples'];chunk=np.asarray(tx[off:off+n])
            if hashlib.sha256(chunk.tobytes()).hexdigest()!=rec['stimulus_sha256']:raise ValueError('original record changed')
            before=copy.deepcopy(state)
            nominal_prediction=state.process(model.quantize_production_playback(chunk))
            if rec['truth'] is None:continue
            name=rec['case'];f=fixtures[name];truth=rec['truth'];signal_key=(name,truth)
            if signal_key not in signal_cache:
                signal_cache[signal_key]=np.fromfile(fixtures_dir/name/f'signal-{truth}.f32',dtype='<f4')
            source=signal_cache[signal_key];lo=rec['markers']['payload']['start'];count=rec['markers']['payload']['samples']
            noise=np.random.default_rng(rec['noise_seed']).normal(0.,plan['noise_rms'],count).astype(np.float32)
            residual=campaign.fixed_noise(profile,n,rec['noise_seed']+991000)
            curve=[];zero_error=None
            for offset in OFFSETS:
                payload=noise.copy();gain=rec['gain']*10**(offset/20.)
                payload[:len(source)]+=gain*source
                changed=chunk.copy();changed[lo:lo+count]=payload
                if offset==0:
                    if not np.array_equal(changed,chunk):raise ValueError('zero-gain recomposition does not reproduce original PCM')
                    prediction=nominal_prediction
                else:
                    prediction=copy.deepcopy(before).process(model.quantize_production_playback(changed))
                z,_,_=campaign.convert((prediction+residual)[lo:lo+f['payload_audio_samples']],f)
                outcome=receivers[name].score(z);decision=empirical_decision(outcome,gates[name])
                if offset==0:
                    old=original[(rec['index'],name)]
                    zero_error=np.asarray(outcome['bit_log_likelihoods'])-np.asarray(old['bit_log_likelihoods'])
                    if not np.allclose(outcome['bit_log_likelihoods'],old['bit_log_likelihoods'],rtol=SCORE_RTOL,atol=SCORE_ATOL):
                        raise ValueError(f'zero-offset corrected score mismatch at record {rec["index"]}: {zero_error.tolist()}')
                    if evaluate(decision,truth)!=old['classification']:raise ValueError('zero-offset corrected classification changed')
                curve.append(dict(offset_db=offset,gain=gain,**outcome,decision=decision,
                    classification=evaluate(decision,truth),true_bit_margin=true_margin(outcome,truth,threshold(gates[name]))))
            observed=physical[(rec['index'],name)];pm=true_margin(observed,truth,threshold(gates[name]))
            inversion=invert_margin(OFFSETS,[c['true_bit_margin'] for c in curve],pm)
            envelope={}
            for width in (.5,1.):
                subset=[c for c in curve if abs(c['offset_db'])<=width]
                envelope[str(width)]=dict(physical_classification=observed['classification'],
                    simulated_classifications=[c['classification'] for c in subset],
                    classification_in_discrete_envelope=observed['classification'] in {c['classification'] for c in subset},
                    physical_margin_in_score_envelope=min(c['true_bit_margin'] for c in subset)<=pm<=max(c['true_bit_margin'] for c in subset),
                    scope='declared grid, not a continuous-gain or probability guarantee')
            row=dict(index=rec['index'],case=name,truth=truth,cn0_db_hz=rec['cn0_db_hz'],
                physical=observed,physical_true_bit_margin=pm,strict_admission_threshold=threshold(gates[name]),
                zero_score_difference=zero_error.tolist(),curve=curve,inversion=inversion,envelope=envelope)
            rows.append(row);write(out/f'record-{rec["index"]:04d}-{name}.json',row)
            print(f'gain envelope {len(rows)}/72 record {rec["index"]} {name} {inversion["status"]}',flush=True)
            if limit and len(rows)>=limit:break
        summary={}
        for name in plan['cases']:
            selected=[r for r in rows if r['case']==name]
            status={s:sum(r['inversion']['status']==s for r in selected) for s in sorted({r['inversion']['status'] for r in selected})}
            shifts=[r['inversion']['equivalent_shift_db'] for r in selected if r['inversion']['equivalent_shift_db'] is not None]
            summary[name]=dict(signals=len(selected),inverse_status=status,
                equivalent_shift_db_percentiles=np.percentile(shifts,[0,25,50,75,100]).tolist() if shifts else None,
                envelope={str(w):dict(classification_violations=sum(not r['envelope'][str(w)]['classification_in_discrete_envelope'] for r in selected),
                    margin_violations=sum(not r['envelope'][str(w)]['physical_margin_in_score_envelope'] for r in selected)) for w in (.5,1.)})
        result=dict(schema='triad-live-historical-gain-envelope-v1',rows=rows,summary=summary,
            complete=len(rows)==72,signals=len(rows),requested_limit=limit,
            protocol_sha256=digest(plan_path),source_sha256=digest(__file__),input_sha256=actual_bind,
            runtime_seconds=dict(total=time.perf_counter()-begun,receiver_preparation=preparation_seconds,
                chronological_model_and_gain_scoring=time.perf_counter()-process_start),
            physical_rescored=False,physical_capture_repeated=False,physical_scores_modified=False,
            limits=protocol['interpretation'],equivalent_shift_sign='positive means physical margin equals a stronger model signal; no new analog measurement')
        write(out/'results.json',result)
        print(json.dumps({'complete':result['complete'],'signals':len(rows),'summary':summary,'runtime_seconds':result['runtime_seconds']},indent=2))
    except Exception as exc:
        write(out/'failure.json',dict(error=f'{type(exc).__name__}: {exc}',completed_signals=len(rows),
            protocol_sha256=digest(plan_path),source_sha256=digest(__file__),elapsed_seconds=time.perf_counter()-begun))
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('plan');p.add_argument('--output',required=True)
    r=sub.add_parser('run');r.add_argument('--plan',required=True);r.add_argument('--output',required=True)
    r.add_argument('--limit-signals',type=int,default=0)
    a=parser.parse_args()
    if a.command=='plan':print(json.dumps(make_plan(a.output),indent=2))
    else:
        if a.limit_signals<0 or a.limit_signals>72:parser.error('limit must be 0..72')
        run(a.plan,a.output,a.limit_signals)


if __name__=='__main__':main()

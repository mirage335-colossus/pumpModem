import unittest
from replay import threshold, true_margin, invert_margin, MIN_SLOPE


class EvaluationHelpers(unittest.TestCase):
    def test_threshold_retains_strict_rank_ties(self):
        gate=dict(sorted_null_scores=list(range(39)),null_count=39,alpha=.05)
        self.assertEqual(threshold(gate),37.)
        self.assertEqual(true_margin({'bit_log_likelihoods':[40.,2.]},0,37),3.)
        self.assertEqual(true_margin({'bit_log_likelihoods':[40.,41.]},0,37),-1.)

    def test_monotonic_inverse_and_failure_categories(self):
        offsets=[-1.,-.5,0.,.5,1.]
        r=invert_margin(offsets,[-2.,-1.,0.,1.,2.],.7)
        self.assertAlmostEqual(r['equivalent_shift_db'],.35)
        self.assertEqual(invert_margin(offsets,[-2.,-1.,0.,1.,2.],3.)['status'],'unbracketed')
        self.assertEqual(invert_margin(offsets,[-2.,-1.,-.1,-.2,2.],0.)['status'],'nonmonotonic_or_flat')
        self.assertEqual(invert_margin(offsets,[-.001,-.0005,0,.0005,.001],0.)['status'],'insufficient_local_slope')


if __name__=='__main__':unittest.main()

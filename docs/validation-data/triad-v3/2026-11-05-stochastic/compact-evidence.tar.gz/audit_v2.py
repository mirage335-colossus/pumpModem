#!/usr/bin/env python3
"""Independent receipt-only scan equivalence and blind-bank outcome audit."""
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path
import time
from scipy.stats import beta

ROOT=Path(__file__).resolve().parent
V1=ROOT/'remote-v1/stochastic-results'
V2=ROOT/'remote-v2'
ERRORS=[]

def read(p): return json.loads(p.read_text())
def rows(p): return [json.loads(x) for x in p.read_text().splitlines()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,label):
    if not ok: ERRORS.append(label)
def close(a,b,label): check(math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9),label)
def lse(x):
    m=max(x)
    return m+math.log(sum(math.exp(v-m) for v in x))
def cp(k,n,alpha=.05):
    return [0 if not k else float(beta.ppf(alpha/2,k,n-k+1)),1 if k==n else float(beta.ppf(1-alpha/2,k+1,n-k))]
def label(row,arm):
    d=row['decisions'][arm]
    if row['trial']['phase']=='signal':
        return 'miss' if not d['accepted'] else 'correct' if d['bit']==row['evaluator']['source_bit'] else 'wrong'
    return 'false_admission' if d['accepted'] else 'rejected_null'

def recount(folder,coherences):
    r=rows(folder/'trials.jsonl');p=read(folder/'protocol.json');g=read(folder/'gate.json');s=read(folder/'summary.json')
    check([x['trial'] for x in r]==p['trial_schedule'],str(folder)+': frozen schedule')
    check(len(r)==103==s['completed_trials'],str(folder)+': count')
    check(sha(folder/'protocol.json')==s['protocol_sha256'],str(folder)+': protocol hash')
    check(sha(folder/'gate.json')==s['gate_sha256'],str(folder)+': gate hash')
    check(g['count']==39 and g['alpha']==.05,str(folder)+': gate scope')
    finite=[i for i,x in enumerate(coherences) if x!='inf'];static=coherences.index('inf')
    totals={a:dict(correct_admitted=0,wrong_admitted=0,missed=0,raw_bit_errors=0,false_admitted=0) for a in ('static','dynamic')}
    strata={a:{b:collections.Counter() for b in (0,1)} for a in totals}
    for i,row in enumerate(r):
        ev=row['hypothesis_log_evidence']
        mixed=[lse([ev[m][h] for m in finite])-math.log(len(finite)) for h in range(3)]
        for a,v in [('static',ev[static]),('dynamic',mixed)]:
            ll=[v[b+1]-v[0] for b in (0,1)];bit=0 if ll[0]>=ll[1] else 1;presence=lse(ll)-math.log(2)
            for b in (0,1): close(ll[b],row[a]['bit_log_likelihoods'][b],str(folder)+': mixture')
            close(presence,row[a]['working_presence'],str(folder)+': presence')
            check(bit==row[a]['bit'],str(folder)+': bit')
            if row['trial']['phase']=='calibration':
                close(presence,g['scores'][a][i],str(folder)+': calibration')
            else:
                pv=(1+sum(x>=presence for x in g['scores'][a]))/40;accept=pv<=.05
                close(pv,row['decisions'][a]['p_value'],str(folder)+': rank')
                check(accept==row['decisions'][a]['accepted'],str(folder)+': admission')
                if row['trial']['phase']=='signal':
                    truth=row['evaluator']['source_bit'];key='missed' if not accept else 'correct_admitted' if bit==truth else 'wrong_admitted'
                    totals[a][key]+=1;strata[a][truth][key]+=1
                    totals[a]['raw_bit_errors']+=bit!=truth;strata[a][truth]['raw_bit_errors']+=bit!=truth
                else: totals[a]['false_admitted']+=accept
    out={}
    for arm,c in totals.items():
        expected=s['outcomes'][arm]
        check({k:v for k,v in c.items() if k!='false_admitted'}==expected['signal']['counts'],str(folder)+': signal counts')
        check(c['false_admitted']==expected['null']['false_admitted'],str(folder)+': null counts')
        bounds=[cp(strata[arm][b]['correct_admitted'],16,.025) for b in (0,1)]
        balanced=[sum(x[i] for x in bounds)/2 for i in (0,1)]
        for i in (0,1):close(balanced[i],expected['signal']['balanced_population']['correct_admitted']['two_sided'][i],str(folder)+': balanced CI')
        out[arm]=dict(counts=c,balanced_correct_95_interval=balanced,null_95_interval=cp(c['false_admitted'],32))
    return r,p,g,s,out

started=time.monotonic();replays=[]
for name in ('helper0','wide-nohelper8'):
    d=V2/'stochastic-results'/(name+'-scan');p=read(d/'protocol.json')
    new,p,gate,summary,outcomes=recount(d,p['configuration']['coherences'])
    old=rows(V1/name/'trials.jsonl');oldgate=read(V1/name/'gate.json');prepared=read(d/'prepared.json')
    for file in ('protocol','gate','prepared'):
        check(p['original_'+file+'_sha256']==sha(V1/name/(file+'.json')),name+': original '+file)
    check(prepared['receiver_work']['variant_policy']['execution']=='affine-parallel-scan',name+': scan selected')
    check(all(x['fallback_reason'] is None for x in prepared['receiver_work']['scan']),name+': no serial fallback')
    maxev=maxll=maxpresence=0.;changes=collections.Counter();cells={a:collections.Counter() for a in ('static','dynamic')}
    for a,b in zip(old,new):
        check(all(a[k]==b[k] for k in ('trial','input_sha256','validity_sha256','manifest_sha256','evaluator')),name+': same capture/evaluator')
        maxev=max(maxev,max(abs(x-y) for ex,ey in zip(a['hypothesis_log_evidence'],b['hypothesis_log_evidence']) for x,y in zip(ex,ey)))
        for arm in ('static','dynamic'):
            maxll=max(maxll,max(abs(x-y) for x,y in zip(a[arm]['bit_log_likelihoods'],b[arm]['bit_log_likelihoods'])))
            maxpresence=max(maxpresence,abs(a[arm]['working_presence']-b[arm]['working_presence']))
            changes[arm+'_raw_bit']+=a[arm]['bit']!=b[arm]['bit']
            if a['trial']['phase']!='calibration':
                for field in ('p_value','accepted'):
                    changes[arm+'_'+field]+=a['decisions'][arm][field]!=b['decisions'][arm][field]
                cells[arm][label(a,arm)+' / '+label(b,arm)]+=1
    calibration_rank_changes={}
    for arm in ('static','dynamic'):
        order=lambda x:sorted(range(39),key=lambda i:x['scores'][arm][i])
        calibration_rank_changes[arm]=order(gate)!=order(oldgate)
        check(dict(cells[arm])==summary['compared_with_original'][arm]['original_then_replay'],name+': paired summary')
    check(not any(changes.values()) and not any(calibration_rank_changes.values()),name+': score ranking/admission equivalence')
    replays.append(dict(name=name+'-scan',outcomes=outcomes,receipts=103,independent_new_captures=0,
                        maximum_absolute_hypothesis_evidence_change=maxev,maximum_absolute_bit_LLR_change=maxll,
                        maximum_absolute_presence_change=maxpresence,changes=dict(changes),calibration_rank_changed=calibration_rank_changes,
                        paired_categories={a:dict(v) for a,v in cells.items()},timing=summary['timing'],
                        source_hashes=p['source_hashes'],protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl')))

d=V2/'stochastic-acquisition-helper';p=read(d/'protocol.json')
br,p,g,s,out=recount(d,p['search']['coherence_seconds']);rec=read(d/'receiver.json');planned=read(d/'planned.json');inputs=read(d/'inputs.json');tiles=rows(d/'tiles.jsonl')
policy=planned['policy']
expected=set(itertools.product(policy['selected_epochs'],policy['arrival_seconds'],policy['frequencies_hz'],policy['clock_ppm']))
actual=[(t['epoch'],a,t['frequency_hz'],t['clock_ppm']) for t in tiles for a in t['arrivals']]
check(len(actual)==len(set(actual))==len(expected)==533 and set(actual)==expected,'blind disjoint full Cartesian partition')
check(len(tiles)==78 and all(t['projection_sha256']==s['work']['projection_sha256'] for t in tiles),'blind tile count/shared projection')
check(all(not t['scan_fallback_reasons'] for t in tiles),'blind no serial fallback')
check(tiles==rec['tiles'],'blind receiver tile receipts')
for k in ('preparation_seconds','correlation_seconds','state_seconds','score_wall_seconds'):
    close(sum(t[k] for t in tiles),s['timing']['receiver'][k],'blind summed '+k)
arrivals=[];griderrors=[]
for i,row in enumerate(br):
    folder=d/row['trial']['id'];truth=read(folder/'evaluator-truth.json');manifest=read(folder/'manifest.json')
    check(sha(folder/'manifest.json')==row['manifest_sha256'],'blind manifest hash')
    check(sha(folder/'evaluator-truth.json')==row['evaluator']['truth_sha256'],'blind truth hash')
    check(all(inputs['trial_inputs'][i][k]==row[k] for k in ('input_sha256','validity_sha256','manifest_sha256')),'blind inputs identity')
    check(truth['random_seed_roots']['fixture']==row['trial']['seed'] and truth['source_bit']==row['trial']['bit'],'blind seed/bit')
    check(not manifest['channel']['oscillator_effects'] and manifest['channel']['channel_evolution']=='fixed-time-gaussian-v1','blind channel/oscillator scope')
    for m in range(4):
        for h in range(3): close(rec['hypothesis_log_evidence'][m][i][h],row['hypothesis_log_evidence'][m][h],'blind aggregate evidence')
    arrival=truth['arrival_seconds'];delta=min(abs(arrival-x) for x in policy['arrival_seconds']);arrivals.append(arrival);griderrors.append(delta)
    check(policy['arrival_seconds'][0]<=arrival<=policy['arrival_seconds'][-1],'blind arrival inside prior')
    close(delta,row['evaluator']['nearest_timing_grid_error_seconds'],'blind grid mismatch')
check(len(set(arrivals))==103,'blind distinct arrivals')
for key,value in [('minimum',min(arrivals)),('maximum',max(arrivals)),('maximum_nearest_grid_error_seconds',max(griderrors))]:
    close(value,s['arrival_diagnostics'][key],'blind arrival summary')
prior=read(ROOT/'audit-v1.json');prior_sources=read(V1/'helper0/protocol.json')['source_hashes']
current_source_matches={f:Path(f).exists() and sha(Path(f))==h for f,h in p['source_hashes'].items()}
historical_source_matches={f:prior_sources.get(f)==h and prior['provenance']['frozen_source_archive_matches'].get(f,False)
                           for f,h in p['source_hashes'].items()}
check(all(current_source_matches[f] or historical_source_matches[f] for f in p['source_hashes']),
      'blind source identity covered by current source or independently verified historical archive')
blind=dict(name='stochastic-acquisition-helper',outcomes=out,receipts=103,calibration=39,signals=32,nulls=32,
           protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl'),
           search=p['search'],tiles=78,total_candidate_trial_evaluations=533*103,
           arrival_diagnostics=s['arrival_diagnostics'],timing=s['timing'],limitations=p['scope'],
           current_source_matches=current_source_matches,historical_v1_archive_matches=historical_source_matches,
           source_scope='Concurrent source development is distinct from frozen campaign evidence. triad_dynamic_campaign.py changed during review; its frozen739cdb identity is covered by the prior independently verified native/source archive.',
           status='unsuccessful reception; no causal conclusion from this audit',
           aggregation_scope='Tile metadata proves a disjoint 533-candidate partition and shared projection. Source uses count-weighted log-sum-exp of tile mean likelihoods then divides by533. Compact receipts omit per-tile evidence arrays, so only final aggregate/model/decision arithmetic is independently recalculated.')

result=dict(schema='triad-stochastic-independent-receipt-audit-v2',status='passed-with-limits' if not ERRORS else 'failed',errors=ERRORS,
            scan_replays=replays,blind_acquisition=blind,prior_audit_sha256=sha(ROOT/'audit-v1.json'),
            limits=['Scan replays establish equality of all retained decisions/ranks for these206 captures, not universal floating-point equivalence.',
                    'The blind campaign is a new failure observation, not a qualification success. Timing and epoch bank only; no oscillator acquisition.',
                    'Existing per-capture rank gate and pointwise conditional confidence limitations remain; no operational daily guarantee.',
                    'No raw I/Q rescore, waveform regeneration, or AM90 metrology review performed.'],
            audit_wall_seconds=time.monotonic()-started,reproducer_sha256=sha(Path(__file__)))
(ROOT/'audit-v2.json').write_text(json.dumps(result,indent=2)+'\n')

v1=read(ROOT/'audit-v1.json')
lines=['# Stochastic receiver result draft (independently recounted receipts)','',
       'Counts are correct admissions / wrong admissions / misses, followed by DATA-absent admissions out of 32. Each original cohort has 39 calibration, 32 signal and 32 null captures. Source bits are fixed balanced strata (16 each).','',
       '## Conditioned original sampled-waveform cohorts','',
       'All eight use Rate 36, Added ×10, HF worst margin 3× (90 Hz ray-center separation, 21 ms excess delay), Each 65% stochastic selective modulation, nominal alignment/epoch and oscillator effects off. B is random per-ray Gaussian-spectrum width (2σ), distinct from ray-center separation.','',
       '| Cohort | C/N0 dB-Hz | Actual bit duration (s) | B Hz | Static C/W/M; null | Dynamic C/W/M; null |',
       '|---|---:|---:|---:|---|---|']
def cell(out):
    c=out['counts'];return f"{c['correct_admitted']}/{c['wrong_admitted']}/{c['missed']}; {c['false_admitted']}/32"
for c in v1['cohorts']:
    if not c['replay']:
        lines.append(f"| {c['name']} | {c['cn0_db_hz']:g} | {c['actual_bit_seconds']:.1f} | {c['random_doppler_width_hz']:g} | {cell(c['outcomes']['static'])} | {cell(c['outcomes']['dynamic'])} |")
lines += ['', 'The duration column excludes the Helper lead and channel/filter tails and is not received DATA energy. Helper-enabled cohorts use both pilots except wide-highpilot8, which uses only the high pilot. The moving −6 dB-Hz pair additionally uses 0.001 ms bounded delay excursion over 100-second knots. Helper-on/off uses paired channel/noise seeds and identical emitted DATA energy. These comparisons do not isolate any single implementation loss, and the different C/N0/duration/key cohorts are not a calibrated sensitivity curve.', '',
          '## Same-I/Q pilot ablations (exploratory)','',
          'All retain transmitted Helper emissions; none/low/high names describe receiver pilot use. They reuse original calibration and held-out captures with new policy-specific gates, so they are not independent validation.', '',
          '| Replay | Static C/W/M; null | Dynamic C/W/M; null |','|---|---|---|']
for c in v1['cohorts']:
    if c['replay']:lines.append(f"| {c['name']} | {cell(c['outcomes']['static'])} | {cell(c['outcomes']['dynamic'])} |")
lines += ['', '## Same-I/Q affine-scan arithmetic qualification','', '| Replay | Static C/W/M; null | Dynamic C/W/M; null | Maximum hypothesis-evidence change |', '|---|---|---|---:|']
for c in replays:lines.append(f"| {c['name']} | {cell(c['outcomes']['static'])} | {cell(c['outcomes']['dynamic'])} | {c['maximum_absolute_hypothesis_evidence_change']:.6g} |")
lines += ['', 'Every raw bit choice, calibration score ordering, held-out rank p-value and admission matches the corresponding serial campaign on all 206 receipts. No new sensitivity trials were generated.', '',
          '## Blind timing/epoch failure (additional independent seeds)','',
          f"At +8 dB-Hz, Fs 6000 and otherwise the declared stochastic HF fixture, the 533-candidate bank produced static {cell(out['static'])}, dynamic {cell(out['dynamic'])}. Dynamic raw bit errors were 15/32. This is a failure, with cause under separate investigation. The 41 timings span −55.5 to 125.5 ms at 4.525 ms spacing; 13 epochs are searched but the emitted epoch remains nominal. All 103 randomized arrivals lie inside the prior, with maximum nearest-grid mismatch 2.255 ms. CFO and sample-clock searches remain fixed 0 with oscillators off.", '',
          'Complete driver wall 158.53 s includes native generation 13.56 s, loading/hashing 1.23 s and receiver call 143.38 s. Inside the receiver, tile preparation 120.90 s dominates correlation 21.47 s and state processing 0.824 s. These figures are not interchangeable with retained-input score-only timing.', '',
          '## Uncertainty and benchmark boundaries','',
          '- Gates use 39 null calibration captures and rank steps 0.025 at nominal marginal alpha 0.05. They do not establish fixed-gate conditional 5%, simultaneous error control, wrong-bit probability or daily false-admission targets.',
          '- Signal confidence intervals condition on the frozen gate and independent representative seeds within fixed bit strata. The implemented 95% balanced-population interval is [76.04%, 100%] for 32/32. A zero-of-32 null result has 95% one-sided upper 8.94%. Intervals are pointwise, not simultaneous across all cohorts/arms. Do not pool paired conditions or reused replay captures as independent evidence.',
          '- Outcome-selected full-known-mean oracles decode two failed noHelper captures (plus their Helper pairs) with conditional error probabilities 1.10e-5 and 8.76e-4. These are realized-channel bounds with perfect means, not achievable unknown-channel/admission performance or population estimates.',
          '- Matched both-pilot full-score timing on the same eight captures gives serial→scan CPU 2.99× single / 2.34× batch eight and GPU 7.36× / 4.52×. Optimized GPU over optimized CPU is 1.19× / 1.09×. Timers include raw transfer, correlation and state scoring, exclude preparation/loading/generation, and use three warm repeats. They provide neither sustained qualification nor predictive confidence bounds.',
          '- The synthetic 231× measurement compares GPU scan versus GPU serial state processing at 10,000 blocks; it is not a whole-receiver or CPU/GPU speedup. Earlier no-pilot serial timings use a different policy and must remain separate.',
          '- Compact audits verify retained evidence/protocol/hash relationships and arithmetic; raw waveform bytes are absent locally. The v1 binary/source relationship is supported by frozen native-source archives and remote byte-identical rebuild receipts.', '',
          'References: audit-v1.json, audit-v2.json, build-provenance/, benchmark/paired-score-benchmark.json. This scratch draft is not a maintained qualification declaration.']
(ROOT/'report-draft.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(status=result['status'],errors=ERRORS,scan_changes=[x['changes'] for x in replays],scan_max_evidence_changes=[x['maximum_absolute_hypothesis_evidence_change'] for x in replays],blind_counts={k:v['counts'] for k,v in out.items()},wall_seconds=result['audit_wall_seconds']),indent=2))

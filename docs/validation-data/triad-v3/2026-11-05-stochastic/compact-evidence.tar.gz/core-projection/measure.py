#!/usr/bin/env python3
"""Source-independent HF Helper/core-projection sampled-channel metrology.

This occasional campaign exports matched native captures for the composite,
DATA, low pilot, high pilot, auxiliary, and noise-only controls.  All signals
are propagated through the same frozen stochastic channel.  The script keeps
complete captures/tails and reports measured energy, additive-composition
residuals, and diagnostic projections onto a public static DATA template
subspace.  These are mechanism measurements, not receiver-admission results.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))

from triad_dynamic_joint import BlockProjection, _sample_cubic  # noqa: E402
from triad_dynamic_variants import core_projection_bands  # noqa: E402


ARMS = {
    "full-data": ("on", "on", "full"),
    "data-only": ("on", "off", "full"),
    "low-only": ("off", "on", "low"),
    "high-only": ("off", "on", "high"),
    "auxiliary-only": ("off", "on", "auxiliary"),
    "all-off": ("off", "off", "full"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def digest_json(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def projected_noncentrality(sample_domain_energy: float, raw_noise_variance: float) -> float:
    """Proper-complex Gaussian lambda = projected sample energy / sample variance."""
    energy = float(sample_domain_energy)
    variance = float(raw_noise_variance)
    if not math.isfinite(energy) or energy < 0 or not math.isfinite(variance) or variance <= 0:
        raise ValueError("noncentrality requires nonnegative energy and positive finite variance")
    return energy / variance


def component_geometry(manifest: dict) -> dict:
    """Matched waveform/channel geometry, intentionally excluding controls."""
    return dict(sample_rate_hz=manifest["sample_rate_hz"],
        format={k: v for k, v in manifest["format"].items()
                if k != "requested_bit_seconds"},
        calendar=manifest["calendar"], helper_plan=manifest["helper_plan"],
        channel=manifest["channel"], key_seed=manifest["key_seed"],
        epoch=manifest["public_epoch_seconds"],
        data_gain=manifest["power"]["template_data_gain"])


def run_export(command: list[str], log_path: Path) -> dict:
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, text=True)
    elapsed = time.monotonic() - start
    log_path.write_text(
        "COMMAND: " + json.dumps(command) + "\n"
        + f"RETURN_CODE: {result.returncode}\nWALL_SECONDS: {elapsed:.9f}\n"
        + "--- STDOUT ---\n" + result.stdout
        + "\n--- STDERR ---\n" + result.stderr
    )
    receipt = dict(command=command, returncode=result.returncode,
                   wall_seconds=elapsed, log=log_path.name)
    if result.returncode:
        raise RuntimeError(f"native export failed ({result.returncode}); see {log_path}: {result.stderr[-1000:]}")
    return receipt


def make_base_args(fs: int, seed: int) -> list[str]:
    # The explicit values freeze the requested HF worst-at-3x channel: D=90Hz,
    # delay=21ms, stochastic Gaussian-ray width B=.5Hz, and Each-65% AM at
    # 90Hz.  The sampled native channel remains enabled; only oscillator error
    # is disabled and the arrival is conditioned at its public zero point.
    return [
        "--case", "hf", "--rate", "36", "--added-symbols", "10",
        "--sample-rate", str(fs), "--seconds", "16", "--data-if", "1725",
        "--rf-hz", "30000000", "--data-power-w", "4", "--helper-power-w", "40",
        "--cn0", "200", "--seed", str(seed), "--key-seed", "82001",
        "--epoch", "1793850000", "--base-oscillator", "gpsdo-ocxo",
        "--shift-oscillator", "gpsdo-ocxo", "--oscillator-effects", "off",
        "--spread-preset", "hf-worst", "--margin", "3",
        "--channel-evolution", "stochastic", "--random-doppler-width-hz", "0.5",
        "--selective-perturbation", "each-65", "--selective-modulation-rate-hz", "90",
        "--fhss", "off", "--arrival-seconds", "0",
    ]


def frozen_source_receipt(exporter: Path) -> dict:
    paths = [exporter, ROOT / "tools/triad-helper-export.cpp",
             TOOLS / "triad_dynamic_joint.py", TOOLS / "triad_dynamic_variants.py",
             TOOLS / "triad_dynamic_scan.py", TOOLS / "triad_gaussian_prepared.py",
             TOOLS / "triad_gaussian_state.py",
             Path(__file__)]
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                         capture_output=True, text=True)
    return dict(git_head=git.stdout.strip() if git.returncode == 0 else None,
                git_head_returncode=git.returncode,
                code_and_binary_sha256={
                    str(p.relative_to(ROOT) if p.is_relative_to(ROOT) else p):
                    sha256(p) if p.is_file() else None for p in paths})


def _load(folder: Path, manifest: dict):
    obs_spec = manifest["observation"]
    rows = int(manifest["calendar"]["capture_samples"])
    obs = folder / obs_spec["file"]
    if tuple(obs_spec["shape"]) != (rows,) or obs.stat().st_size != rows * 16:
        raise ValueError(f"observation dimensions/bytes mismatch: {obs}")
    validity_spec = manifest["validity"]
    validity = folder / validity_spec["file"]
    if validity.stat().st_size != rows:
        raise ValueError(f"validity dimensions/bytes mismatch: {validity}")
    return np.memmap(obs, dtype="<c16", mode="r", shape=(rows,)), validity


def _signal_chunk(folder: Path, manifest: dict, noise: np.ndarray, first: int, past: int):
    raw, _ = _load(folder, manifest)
    result = np.asarray(raw[first:past]) - np.asarray(noise[first:past])
    del raw
    return result


def _sum_power(values: np.ndarray) -> float:
    power = 0.0
    block = 1_000_000
    for start in range(0, len(values), block):
        x = values[start:start + block]
        power += float(np.sum(x.real*x.real + x.imag*x.imag, dtype=np.float64))
    return power


def _sum_diff_power(full: np.ndarray, data: np.ndarray, low: np.ndarray,
                    high: np.ndarray, auxiliary: np.ndarray) -> tuple[float, float, float]:
    residual_power = expected_power = full_power = 0.0
    for start in range(0, len(full), 1_000_000):
        stop = min(len(full), start + 1_000_000)
        f = full[start:stop]
        remainder = f - data[start:stop] - low[start:stop] - high[start:stop] - auxiliary[start:stop]
        residual_power += float(np.sum(remainder.real**2 + remainder.imag**2, dtype=np.float64))
        expected_power += float(np.sum(f.real**2 + f.imag**2, dtype=np.float64))
        full_power += float(np.sum(f.real**2 + f.imag**2, dtype=np.float64))
    rms = math.sqrt(residual_power/len(full)) if len(full) else 0.
    ref = math.sqrt(full_power/len(full)) if len(full) else 0.
    return rms, ref, residual_power/expected_power if expected_power else 0.


def _layouts(samples: int, block_samples: int):
    layouts = []
    for start in range(0, samples, block_samples):
        stop = min(samples, start + block_samples)
        if 0 < samples - stop < block_samples:
            stop = samples
        if layouts and start < layouts[-1][1]:
            continue
        layouts.append((start, stop))
    return layouts


def _data_template_subspace(manifest: dict, templates: np.ndarray,
                            epoch_offsets: list[int], start: int, stop: int,
                            projection: BlockProjection) -> np.ndarray:
    """Build the fixed public H1-H0 DATA source basis, including two rays.

    The geometry follows DynamicJointReceiver.source_basis at its public
    conditioned origin (arrival/CFO/clock zero); it is a static subspace
    diagnostic. It does not fit unknown channel trajectories to observations.
    """
    fs = float(manifest["sample_rate_hz"])
    cal = manifest["calendar"]
    ch = manifest["channel"]
    lead = float(cal["capture_lead_seconds"])
    source_offset = float(cal["data_sample_offset"]) / fs
    time_rx = np.arange(start, stop, dtype=np.float64) / fs - lead
    delay = float(ch["spread_delay_ms"]) * .001
    doppler = float(ch["spread_doppler_hz"])
    rays = ((0., 0.), (delay, doppler)) if delay != 0 or doppler != 0 else ((0., 0.),)
    ray_weights = np.full(len(rays), 1 / math.sqrt(len(rays)))
    columns = []
    for epoch_index, _epoch_offset in enumerate(epoch_offsets):
        for bit in (0, 1):
            source = templates[epoch_index, bit]
            for (ray_delay, ray_doppler), gain in zip(rays, ray_weights):
                ts = time_rx - ray_delay
                positions = (ts - source_offset) * fs
                waveform = _sample_cubic(source, positions)
                waveform *= gain * np.exp(2j*np.pi*np.remainder(ray_doppler*time_rx, 1.))
                columns.append(waveform)
    raw_basis = np.asarray(columns, dtype=np.complex128)
    projected = projection.numpy(raw_basis)
    # [columns, modes] -> [modes, columns], rank-revealing SVD.
    design = projected.T
    if not np.isfinite(design).all():
        raise FloatingPointError("nonfinite public DATA basis")
    if not design.size:
        return np.empty((0, 0), np.complex128)
    u, singular, _ = np.linalg.svd(design, full_matrices=False)
    if not len(singular) or singular[0] == 0:
        return np.empty((design.shape[0], 0), np.complex128)
    tol = np.finfo(np.float64).eps * max(design.shape) * singular[0]
    rank = int(np.count_nonzero(singular > tol))
    return u[:, :rank]


def _projected_metrics(folders: dict[str, Path], manifests: dict[str, dict],
                       fs: int, templates: np.ndarray, epoch_offsets: list[int],
                       raw_noise_variance: float) -> dict:
    base = manifests["full-data"]
    rows = int(base["calendar"]["capture_samples"])
    if any(int(m["calendar"]["capture_samples"]) != rows for m in manifests.values()):
        raise ValueError("component controls have unequal capture length")
    required, excluded = core_projection_bands(base, pilot_use="both",
        frequencies_hz=(0.,), clock_ppm=(0.,), auxiliary_half_width_hz=200.)
    block_samples = max(1, round(.25 * fs))
    layouts = _layouts(rows, block_samples)
    masks = {arm: np.memmap(folder / manifest["validity"]["file"], dtype="u1", mode="r")
             for arm, (folder, manifest) in ((a, (folders[a], manifests[a])) for a in ARMS)}
    if any(not np.all(mask == 1) for mask in masks.values()):
        raise ValueError("diagnostic expects full capture masks; preserve and model erasures separately")
    common = np.memmap(folders["all-off"] / manifests["all-off"]["observation"]["file"],
                       dtype="<c16", mode="r", shape=(rows,))
    arm_energies = {arm: 0. for arm in ARMS if arm != "all-off"}
    retained = {arm: 0. for arm in ARMS if arm != "all-off"}
    subspace_energy = {arm: 0. for arm in ARMS if arm != "all-off"}
    target_nc = {str(cno): {arm: 0. for arm in ARMS if arm != "all-off"}
                 for cno in (0., 8.)}
    total_rank = 0
    total_modes = 0
    sample_count = 0
    additive_residual_power = 0.
    full_signal_power = 0.
    data_physical_power = 0.
    low_physical_power = 0.
    high_physical_power = 0.
    auxiliary_physical_power = 0.

    for start, stop in layouts:
        n = stop - start
        proj = BlockProjection.make(n, fs, required, excluded)
        q = len(proj.indices)
        U = _data_template_subspace(base, templates, epoch_offsets, start, stop, proj)
        total_rank += U.shape[1]
        total_modes += q
        sample_count += n
        sig = {arm: _signal_chunk(folders[arm], manifests[arm], common, start, stop)
               for arm in arm_energies}
        projected = {arm: proj.numpy(values) for arm, values in sig.items()}
        for arm in arm_energies:
            arm_energies[arm] += _sum_power(sig[arm]) / fs
            retained[arm] += float(np.vdot(projected[arm], projected[arm]).real) / fs
            if U.shape[1]:
                coeff = U.conj().T @ projected[arm]
                projected_sample_energy = float(np.vdot(coeff, coeff).real)
            else:
                projected_sample_energy = 0.
            subspace_energy[arm] += projected_sample_energy / fs
            for cno in (0., 8.):
                variance = fs / (10. ** (cno / 10.))
                # Lambda for proper-complex white noise is sample-domain
                # projected energy divided by raw per-sample variance.  The
                # reported joule-normalized energy is sample_sum/Fs, so do not
                # divide that already-integrated quantity by variance again.
                target_nc[str(cno)][arm] += projected_noncentrality(projected_sample_energy, variance)

        mismatch = (sig["full-data"] - sig["data-only"] - sig["low-only"] -
                    sig["high-only"] - sig["auxiliary-only"])
        additive_residual_power += _sum_power(mismatch)
        full_signal_power += _sum_power(sig["full-data"])
        data_physical_power += _sum_power(sig["data-only"])
        low_physical_power += _sum_power(sig["low-only"])
        high_physical_power += _sum_power(sig["high-only"])
        auxiliary_physical_power += _sum_power(sig["auxiliary-only"])
        del sig, projected, mismatch

    del common
    for mask in masks.values():
        del mask
    # `arm_energies` are integrated energy (sum |x|^2 / Fs); power below is
    # retained separately as this observation's total de-noised energy.
    target_variances = {str(cno): fs / (10. ** (cno / 10.)) for cno in (0., 8.)}
    return dict(
        projection=dict(kind="orthonormal block DFT rows", block_seconds=.25,
            block_samples_nominal=block_samples, block_count=len(layouts),
            required_bands_hz=required, excluded_auxiliary_bands_hz=excluded,
            retained_modes=total_modes, source_basis_rank_sum=total_rank,
            source_basis="public DATA templates: every public epoch, both bits, two static rays; H1-H0 union",
            subspace_method="rank-revealing complex128 SVD independently per public block",
            conditioned_acquisition=dict(arrival_seconds=0., frequencies_hz=[0.], clock_ppm=[0.])),
        integrated_received_signal_energy_joules_normalized=arm_energies,
        core_projected_signal_energy_joules_normalized=retained,
        core_projection_energy_fraction_of_received_signal={
            arm: retained[arm]/arm_energies[arm] if arm_energies[arm] else None
            for arm in arm_energies},
        data_subspace_projected_energy_joules_normalized=subspace_energy,
        data_template_subspace_noncentrality=target_nc,
        target_cno_db_hz=[0., 8.],
        raw_complex_noise_variance_at_targets=target_variances,
        raw_noise_variance_export=raw_noise_variance,
        actual_component_integrated_energy=dict(data=data_physical_power/fs,
            low=low_physical_power/fs, high=high_physical_power/fs,
            auxiliary=auxiliary_physical_power/fs, full_composite=full_signal_power/fs),
        additive_composition=dict(residual_rms=math.sqrt(additive_residual_power/max(sample_count, 1)),
            full_signal_rms=math.sqrt(full_signal_power/max(sample_count, 1)),
            residual_energy_fraction=additive_residual_power/full_signal_power if full_signal_power else None),
        interpretation="Genie-profile projection energy/noncentrality is a loose subspace diagnostic, not a receiver likelihood/admission result. It omits stochastic channel trajectory inference and does not estimate false admissions.")


def _rate_comparison(fs_lo: int, fs_hi: int, records: dict[int, dict], folders: dict[int, dict],
                     arms=("full-data", "data-only", "low-only", "high-only", "auxiliary-only")) -> dict:
    lo_m = records[fs_lo]["full-data"]["manifest"]
    hi_m = records[fs_hi]["full-data"]["manifest"]
    lo_lead = float(lo_m["calendar"]["capture_lead_seconds"])
    hi_lead = float(hi_m["calendar"]["capture_lead_seconds"])
    n_lo = int(lo_m["calendar"]["capture_samples"])
    n_hi = int(hi_m["calendar"]["capture_samples"])
    start_lo = max(0, math.ceil((lo_lead - hi_lead) * fs_lo))
    indices_lo = np.arange(start_lo, n_lo, dtype=np.int64)
    indices_hi = np.rint(((indices_lo / fs_lo - lo_lead) + hi_lead) * fs_hi).astype(np.int64)
    valid = (indices_hi >= 0) & (indices_hi < n_hi)
    indices_lo, indices_hi = indices_lo[valid], indices_hi[valid]
    alignment_error_s = float(np.max(np.abs((indices_lo/fs_lo-lo_lead) -
                                              (indices_hi/fs_hi-hi_lead)))) if len(indices_lo) else None
    out = dict(reference_rate_hz=fs_lo, comparison_rate_hz=fs_hi,
        shared_timestamp_alignment="capture sample timestamp n/Fs - capture_lead_seconds",
        aligned_samples=int(len(indices_lo)), max_timestamp_error_seconds=alignment_error_s,
        per_arm={})
    for arm in arms:
        low_folder = folders[fs_lo][arm]
        high_folder = folders[fs_hi][arm]
        low_noise_folder = folders[fs_lo]["all-off"]
        high_noise_folder = folders[fs_hi]["all-off"]
        low, _ = _load(low_folder, records[fs_lo][arm]["manifest"])
        high, _ = _load(high_folder, records[fs_hi][arm]["manifest"])
        noise_low, _ = _load(low_noise_folder, records[fs_lo]["all-off"]["manifest"])
        noise_high, _ = _load(high_noise_folder, records[fs_hi]["all-off"]["manifest"])
        # One aligned vector per comparison arm; the sample counts are modest
        # for these 16-second DATA captures and their retained channel tails.
        low_signal = np.asarray(low[indices_lo]) - np.asarray(noise_low[indices_lo])
        high_signal = np.asarray(high[indices_hi]) - np.asarray(noise_high[indices_hi])
        delta = low_signal - high_signal
        low_power = float(np.mean(np.abs(low_signal)**2)) if len(low_signal) else 0.
        high_power = float(np.mean(np.abs(high_signal)**2)) if len(high_signal) else 0.
        block_gain_db = []
        block_samples = max(1, round(.25 * fs_lo))
        for first in range(0, len(low_signal), block_samples):
            past = min(len(low_signal), first + block_samples)
            lp = float(np.mean(np.abs(low_signal[first:past])**2))
            hp = float(np.mean(np.abs(high_signal[first:past])**2))
            if lp > 0 and hp > 0:
                block_gain_db.append(10*math.log10(hp/lp))
        block_gain_db = np.asarray(block_gain_db, dtype=np.float64)
        out["per_arm"][arm] = dict(
            low_rate_mean_square=low_power, high_rate_mean_square=high_power,
            high_to_low_mean_square_ratio=high_power/low_power if low_power else None,
            aligned_difference_rms=math.sqrt(float(np.mean(np.abs(delta)**2))) if len(delta) else None,
            aligned_difference_rms_over_low_rms=(
                math.sqrt(float(np.mean(np.abs(delta)**2)/low_power)) if low_power else None),
            quarter_second_energy_gain_db_mean=(float(np.mean(block_gain_db))
                if len(block_gain_db) else None),
            quarter_second_energy_gain_db_variance=(float(np.var(block_gain_db, ddof=1))
                if len(block_gain_db) > 1 else None),
            quarter_second_energy_gain_db_blocks=int(len(block_gain_db)),
            low_rate_energy_gain_db=10*math.log10(low_power) if low_power else None,
            high_rate_energy_gain_db=10*math.log10(high_power) if high_power else None)
        del low, high, noise_low, noise_high, low_signal, high_signal, delta
    return out


def _capture_identity(folder: Path, manifest: dict) -> dict:
    obs_path = folder / manifest["observation"]["file"]
    valid_path = folder / manifest["validity"]["file"]
    return dict(manifest_sha256=sha256(folder / "manifest.json"),
        observation_sha256=sha256(obs_path), observation_bytes=obs_path.stat().st_size,
        validity_sha256=sha256(valid_path), validity_bytes=valid_path.stat().st_size,
        matched_geometry_sha256=digest_json(component_geometry(manifest)),
        helper_component_control=manifest.get("helper_component_control"),
        controls=dict(data=manifest.get("data_enabled"), helper=manifest.get("helper_enabled")))


def _check_matches(manifests: dict[str, dict]) -> None:
    reference = manifests["full-data"]
    for name, m in manifests.items():
        if component_geometry(m) != component_geometry(reference):
            raise ValueError(f"public waveform/channel geometry differs for {name}")
        if m["sample_rate_hz"] != reference["sample_rate_hz"]:
            raise ValueError(f"sample rate differs for {name}")
        if m["calendar"]["capture_samples"] != reference["calendar"]["capture_samples"]:
            raise ValueError(f"capture length differs for {name}")
        if m["power"]["complex_noise_variance"] != reference["power"]["complex_noise_variance"]:
            raise ValueError(f"noise variance differs for {name}")
    expected = {
        "full-data": (True, True, "full"), "data-only": (True, False, "full"),
        "low-only": (False, True, "low"), "high-only": (False, True, "high"),
        "auxiliary-only": (False, True, "auxiliary"), "all-off": (False, False, "full"),
    }
    for arm, controls in expected.items():
        m = manifests[arm]
        actual = (bool(m["data_enabled"]), bool(m["helper_enabled"]),
                  m.get("helper_component_control", "full"))
        if actual != controls:
            raise ValueError(f"component controls differ for {arm}: {actual} != {controls}")


def measure_rate_seed(exporter: Path, root: Path, fs: int, seed: int,
                      frozen: dict, include_templates: bool) -> tuple[dict, dict, dict]:
    folders = {arm: root / arm for arm in ARMS}
    receipts = {}
    for arm, (data, helper, components) in ARMS.items():
        folder = folders[arm]
        if folder.exists():
            raise FileExistsError(f"export folder must be new: {folder}")
        command = [str(exporter), *make_base_args(fs, seed), "--data", data,
                   "--helper", helper, "--helper-components", components,
                   "--output", str(folder)]
        if arm == "full-data" and include_templates:
            command.append("--templates")
        receipts[arm] = run_export(command, root / f"native-{arm}.log")

    manifests = {arm: json.loads((folder / "manifest.json").read_text())
                 for arm, folder in folders.items()}
    _check_matches(manifests)
    template_info = manifests["full-data"]["templates"]
    if not template_info["enabled"]:
        raise ValueError("full-data native export omitted public DATA templates")
    template_path = folders["full-data"] / template_info["file"]
    expected_bytes = math.prod(template_info["shape"]) * 16
    if template_path.stat().st_size != expected_bytes:
        raise ValueError("DATA template file size mismatch")
    templates = np.memmap(template_path, dtype="<c16", mode="r",
                           shape=tuple(template_info["shape"]))
    epoch_offsets = [int(x) for x in template_info["epoch_offsets_seconds"]]
    raw_noise_variance = float(manifests["full-data"]["power"]["complex_noise_variance"])
    details = _projected_metrics(folders, manifests, fs, templates,
        epoch_offsets, raw_noise_variance)
    del templates
    source_records = {arm: _capture_identity(folders[arm], manifests[arm])
                      for arm in folders}
    source_records["full-data"]["templates_sha256"] = sha256(template_path)
    source_records["full-data"]["templates_bytes"] = template_path.stat().st_size
    result = dict(schema="triad-stochastic-core-projection-metrology-v1",
        seed=seed, sample_rate_hz=fs, frozen_inputs=frozen,
        native_export_receipts=receipts, captures=source_records,
        format={k: manifests["full-data"]["format"].get(k) for k in
            ("inner_rate_hz", "added_symbols", "bit_seconds", "fine_chip_rate_hz",
             "occupied_bandwidth_hz", "pulse_shape")},
        channel={k: manifests["full-data"]["channel"].get(k) for k in
            ("spread_preset", "spread_margin", "spread_doppler_hz", "spread_delay_ms",
             "channel_evolution", "random_doppler_width_hz", "selective_perturbation",
             "selective_slow_depth", "selective_fast_depth", "selective_modulation_rate_hz",
             "relative_phase_diffusion_rad_sqrt_s", "nominal_conversion_if_hz")},
        geometry=dict(capture_samples=manifests["full-data"]["calendar"]["capture_samples"],
            capture_lead_seconds=manifests["full-data"]["calendar"]["capture_lead_seconds"],
            arrival_prior_seconds=manifests["full-data"]["calendar"]["arrival_prior_seconds"],
            data_sample_offset=manifests["full-data"]["calendar"]["data_sample_offset"],
            helper_end_seconds=manifests["full-data"]["calendar"]["helper_end_seconds"]),
        measurements=details,
        limitations=[
            "Native sampled-channel energy/projection study only; no receiver admission or false-alarm calibration.",
            "The static public two-ray basis is a genie-profile comparison and omits random trajectory inference.",
            "C/N0 target noncentralities rescale noiseless signal projection by proper-complex raw sample variance Fs/10^(C/N0/10).",
            "All captured tails are retained; the noisy all-off waveform is subtracted as the shared-seed baseline, not selected from truth.",
        ])
    return result, folders, manifests


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exporter", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--seeds", default="960001,960002",
                        help="comma-separated independent fixture/channel seeds")
    parser.add_argument("--rates", default="6000,12000",
                        help="comma-separated sample rates; paired cases are compared by timestamps")
    parser.add_argument("--dry-run", action="store_true",
                        help="print frozen command plan without creating exports")
    args = parser.parse_args()
    exporter, output = args.exporter.resolve(), args.output.resolve()
    if not exporter.is_file() or not os.access(exporter, os.X_OK):
        parser.error("--exporter must be an executable native triad_helper_export binary")
    try:
        seeds = [int(x) for x in args.seeds.split(",")]
        rates = [int(x) for x in args.rates.split(",")]
    except ValueError:
        parser.error("--seeds and --rates must be comma-separated integers")
    if not seeds or len(set(seeds)) != len(seeds) or any(x < 0 for x in seeds):
        parser.error("--seeds must be unique nonnegative integers")
    if not rates or len(set(rates)) != len(rates) or any(x < 6000 or x % 5 for x in rates):
        parser.error("--rates must be unique native sample rates >=6000 and divisible by5")
    if output.exists() and any(output.iterdir()):
        parser.error("--output must be a new or empty directory")
    frozen = dict(schema="triad-stochastic-core-projection-protocol-v1",
        frozen_before_exports=True, seeds=seeds, sample_rates_hz=rates,
        channel=dict(case="hf", inner_rate_hz=36, added_symbols=10, seconds=16,
            data_if_hz=1725, rf_hz=30e6, data_power_w=4, helper_power_w=40,
            base_and_shift_oscillator="gpsdo-ocxo; effects disabled explicitly",
            arrival_seconds=0, spread_preset="hf-worst", margin=3,
            center_doppler_hz=90, delay_seconds=.021, channel_evolution="stochastic",
            gaussian_ray_width_hz=.5, selective="each-65", selective_rate_hz=90,
            fhss=False, cn0_export_db_hz=200),
        arms={name: dict(data=data, helper=helper, helper_components=components)
              for name, (data, helper, components) in ARMS.items()},
        acquisition=dict(arrival_seconds=0, frequency_hz=0, clock_ppm=0),
        projection=dict(kind="public core projection", block_seconds=.25,
            all_public_epochs=True, both_bits=True, two_static_rays=True,
            targets_cno_db_hz=[0, 8]),
        source=frozen_source_receipt(exporter))
    commands = {}
    for seed in seeds:
        for fs in rates:
            key = f"seed-{seed}-fs-{fs}"
            commands[key] = {}
            for arm, (data, helper, components) in ARMS.items():
                target = output / key / arm
                command = [str(exporter), *make_base_args(fs, seed), "--data", data,
                           "--helper", helper, "--helper-components", components,
                           "--output", str(target)]
                if arm == "full-data":
                    command.append("--templates")
                commands[key][arm] = command
    frozen["commands"] = commands
    if args.dry_run:
        print(json.dumps(frozen, indent=2))
        return 0

    output.mkdir(parents=True, exist_ok=True)
    (output / "frozen-protocol.json").write_text(json.dumps(frozen, indent=2) + "\n")
    result = dict(schema="triad-stochastic-core-projection-results-v1",
                  protocol_sha256=sha256(output / "frozen-protocol.json"),
                  cases={}, rate_comparisons={})
    case_records, folders, manifests = {}, {}, {}
    try:
        for seed in seeds:
            for fs in rates:
                key = f"seed-{seed}-fs-{fs}"
                target = output / key
                target.mkdir()
                row, case_folders, case_manifests = measure_rate_seed(
                    exporter, target, fs, seed, frozen, include_templates=True)
                case_records[(seed, fs)] = row
                folders.setdefault(seed, {})[fs] = case_folders
                manifests.setdefault(seed, {})[fs] = {
                    arm: dict(manifest=case_manifests[arm]) for arm in case_manifests}
                (target / "result.json").write_text(json.dumps(row, indent=2) + "\n")
                result["cases"][key] = row
                (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        if len(rates) >= 2:
            for seed in seeds:
                for i, fs_lo in enumerate(rates):
                    for fs_hi in rates[i+1:]:
                        key = f"seed-{seed}-{fs_lo}-to-{fs_hi}"
                        result["rate_comparisons"][key] = _rate_comparison(
                            fs_lo, fs_hi,
                            manifests[seed], folders[seed])
                        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        result["status"] = "complete"
        result["complete_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(dict(output=str(output), results=str(output / "results.json")), indent=2))
        return 0
    except Exception:
        result["status"] = "failed_preserving_native_exports"
        result["failure_traceback"] = traceback.format_exc()
        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        raise


if __name__ == "__main__":
    raise SystemExit(main())

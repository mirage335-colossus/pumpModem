#!/usr/bin/env python3
"""Independent compact-receipt audit; no waveform generation or receiver imports."""
import collections
import hashlib
import json
import math
from pathlib import Path
import statistics
import tarfile
import time

from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'remote-v1/stochastic-results'
ERRORS = []


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(ok, context):
    if not ok:
        ERRORS.append(context)


def close(a, b, context, atol=1e-10):
    check(math.isclose(a, b, rel_tol=1e-11, abs_tol=atol), context)


def lse(values):
    m = max(values)
    return m + math.log(sum(math.exp(x-m) for x in values))


def cp(k, n, alpha=.05):
    return [0. if not k else float(beta.ppf(alpha/2, k, n-k+1)),
            1. if k == n else float(beta.ppf(1-alpha/2, k+1, n-k))]


def cpu(a):
    k, n = a
    return 1. if k == n else float(beta.ppf(.95, k+1, n-k))


started = time.monotonic()
cohorts, allrows, protocols = [], {}, {}
for d in sorted(p for p in BASE.iterdir() if (p/'summary.json').is_file()):
    name = d.name
    p, g, s, prep = [read(d/f) for f in ('protocol.json', 'gate.json', 'summary.json', 'prepared.json')]
    rows = [json.loads(line) for line in (d/'trials.jsonl').read_text().splitlines()]
    allrows[name], protocols[name] = rows, p
    replay = '-replay-' in name
    original = name.split('-replay-')[0] if replay else name
    originaldir = BASE/original
    check([x['trial'] for x in rows] == p['trial_schedule'], name+': schedule')
    check(len(rows) == s['completed_trials'] == 103, name+': trial count')
    phases = collections.Counter(x['trial']['phase'] for x in rows)
    check(phases == {'calibration':39, 'signal':32, 'null':32}, name+': phases')
    check(sha(d/'protocol.json') == s['protocol_sha256'], name+': protocol hash')
    check(sha(d/'gate.json') == s['gate_sha256'], name+': gate hash')
    check(g['count'] == 39 and g['alpha'] == .05 and g['minimum_p'] == .025, name+': gate parameters')
    if replay:
        for f in ('protocol', 'gate', 'prepared'):
            check(sha(originaldir/(f+'.json')) == p['original_'+f+'_sha256'], name+': original '+f+' hash')
        check(prep['template_sha256'] == read(originaldir/'prepared.json')['template_sha256'], name+': same templates')
    cfg = p['configuration']
    check(cfg['acquisition'] == 'conditioned' and cfg['arrivals'] == [0.] and cfg['frequencies'] == [0.] and cfg['clock_ppm'] == [0.] and cfg['epoch_offsets'] == [0], name+': conditioned scope')
    finite = [i for i,t in enumerate(cfg['coherences']) if t != 'inf']
    static = cfg['coherences'].index('inf')
    counts = {arm: dict(correct_admitted=0, wrong_admitted=0, missed=0, raw_bit_errors=0, false_admitted=0) for arm in ('static','dynamic')}
    strata = {arm: {b: dict(correct_admitted=0, wrong_admitted=0, missed=0, raw_bit_errors=0) for b in (0,1)} for arm in counts}
    evidence_max_error = 0.
    same_replay = 0
    absent_local_iq = 0
    for ri,row in enumerate(rows):
        context = name+'/'+row['trial']['id']
        for key in ('procedure_id','condition_id'):
            check(row[key] == g[key] == s[key] == prep[key], context+': '+key)
        ev = row['hypothesis_log_evidence']
        check(len(ev) == len(cfg['coherences']) and all(len(x)==3 and all(math.isfinite(y) for y in x) for x in ev), context+': evidence shape')
        mixed = [lse([ev[i][h] for i in finite])-math.log(len(finite)) for h in range(3)]
        for i, values in enumerate(ev):
            for b in (0,1):
                close(values[b+1]-values[0], row['model_bit_scores'][i][b], context+': model LLR')
        for arm, values in [('static', ev[static]), ('dynamic', mixed)]:
            ll = [values[b+1]-values[0] for b in (0,1)]
            bit = 0 if ll[0] >= ll[1] else 1
            presence = lse(ll)-math.log(2.)
            for b in (0,1):
                evidence_max_error = max(evidence_max_error, abs(ll[b]-row[arm]['bit_log_likelihoods'][b]))
                close(ll[b], row[arm]['bit_log_likelihoods'][b], context+': '+arm+' mixture')
            check(bit == row[arm]['bit'], context+': '+arm+' bit')
            close(presence, row[arm]['working_presence'], context+': '+arm+' presence')
            close(abs(ll[0]-ll[1]), row[arm]['opposite_bit_margin'], context+': '+arm+' margin')
            phase = row['trial']['phase']
            if phase == 'calibration':
                close(presence, g['scores'][arm][ri], context+': '+arm+' calibration')
                check('decisions' not in row, context+': calibration admission absent')
            else:
                pv = (1+sum(v >= presence for v in g['scores'][arm]))/40
                admitted = pv <= .05
                dec = row['decisions'][arm]
                close(pv, dec['p_value'], context+': '+arm+' p')
                check(admitted == dec['accepted'] and bit == dec['bit'], context+': '+arm+' decision')
                if phase == 'signal':
                    true = row['evaluator']['source_bit']
                    category = 'missed' if not admitted else ('correct_admitted' if bit == true else 'wrong_admitted')
                    counts[arm][category] += 1
                    strata[arm][true][category] += 1
                    counts[arm]['raw_bit_errors'] += bit != true
                    strata[arm][true]['raw_bit_errors'] += bit != true
                else:
                    counts[arm]['false_admitted'] += admitted
        folder = originaldir/row['trial']['id']
        m, truth = read(folder/'manifest.json'), read(folder/'evaluator-truth.json')
        check(sha(folder/'manifest.json') == row['manifest_sha256'], context+': manifest hash')
        check(sha(folder/'evaluator-truth.json') == row['evaluator']['truth_sha256'], context+': truth hash')
        check(truth['source_bit'] == row['trial']['bit'] == row['evaluator']['source_bit'], context+': source bit')
        check(truth['random_seed_roots']['fixture'] == row['trial']['seed'], context+': seed')
        check(m['channel']['channel_evolution'] == 'fixed-time-gaussian-v1' and not m['channel']['oscillator_effects'], context+': stochastic/no oscillator')
        check(m['channel']['selective_slow_depth'] == .65 and m['channel']['selective_fast_depth'] == .65, context+': modulation')
        check(truth['arrival_seconds'] == 0., context+': arrival')
        absent_local_iq += not (folder/m['observation']['file']).exists()
        if replay:
            originalrow = json.loads((folder/'result.json').read_text())
            matched = all(row[k] == originalrow[k] for k in ('trial','input_sha256','validity_sha256','manifest_sha256','evaluator'))
            check(matched, context+': replay identical capture/truth')
            same_replay += matched
        else:
            check(read(folder/'result.json') == row, context+': per-trial receipt')
    compact = {}
    for arm,c in counts.items():
        out = s['outcomes'][arm]
        check({k:c[k] for k in strata[arm][0]} == out['signal']['counts'], name+': '+arm+' summary signal counts')
        check(c['false_admitted'] == out['null']['false_admitted'], name+': '+arm+' summary null')
        metrics = {}
        for metric in strata[arm][0]:
            bounds = [cp(strata[arm][b][metric],16,.025) for b in (0,1)]
            interval = [sum(x[k] for x in bounds)/2 for k in (0,1)]
            for k in (0,1):
                close(interval[k], out['signal']['balanced_population'][metric]['two_sided'][k], name+': '+arm+' CI '+metric)
                check(strata[arm][k] == out['signal']['per_bit'][str(k)]['counts'], name+': '+arm+' strata')
            metrics[metric] = interval
        null_bounds = cp(c['false_admitted'],32)
        for k in (0,1):
            close(null_bounds[k], out['null']['uncertainty']['two_sided'][k], name+': null CI')
        close(cpu((c['false_admitted'],32)),out['null']['uncertainty']['one_sided_upper'],name+': null upper')
        compact[arm] = dict(counts=c, per_bit=strata[arm], balanced_correct_95_interval=metrics['correct_admitted'],
                            null_95_interval=null_bounds, null_95_upper=cpu((c['false_admitted'],32)))
    originalp = read(originaldir/'protocol.json')
    m = read(originaldir/'signal-0000/manifest.json')
    e = rows[39]['evaluator']
    cohorts.append(dict(name=name,replay=replay,phases=dict(phases),coherences=cfg['coherences'],
                        dynamic_prior_weights=[1/len(finite)]*len(finite),pilot_use=cfg['pilot_use'],
                        actual_bit_seconds=e['actual_bit_seconds'],capture_seconds=e['capture_seconds'],
                        cn0_db_hz=e['nominal_data_cn0_db_hz'],random_doppler_width_hz=m['channel']['random_doppler_width_hz'],
                        center_separation_hz=m['channel']['spread_doppler_hz'],delay_ms=m['channel']['spread_delay_ms'],
                        delay_excursion_seconds=m['channel']['delay_excursion_seconds'],outcomes=compact,
                        protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl'),
                        maximum_mixture_recalculation_error=evidence_max_error,same_iq_replay_rows=same_replay,
                        local_iq_absent_rows=absent_local_iq,exporter_sha256=originalp['exporter_sha256']))

pairs = []
for off,on in [('nohelper8','helper8'),('nohelper0','helper0'),('motion-nohelper-minus6','motion-helper-minus6'),('wide-nohelper8','wide-highpilot8')]:
    maximum_energy_delta = 0.
    for a,b in zip(allrows[off],allrows[on]):
        check(a['trial'] == b['trial'],off+': pair schedule')
        ea,eb = a['evaluator'],b['evaluator']
        delta = abs(ea['emitted_data_energy_seconds']-eb['emitted_data_energy_seconds'])
        maximum_energy_delta = max(maximum_energy_delta,delta)
        close(delta,0.,off+': same DATA source energy')
        ta,tb = [read(BASE/n/a['trial']['id']/'evaluator-truth.json') for n in (off,on)]
        for k in ('source_epoch_offset_seconds','arrival_seconds','tx','rx','random_seed_roots'):
            check(ta[k] == tb[k],off+': same physical realization '+k)
    pairs.append(dict(off=off,on=on,paired_rows=103,maximum_emitted_DATA_energy_difference_seconds=maximum_energy_delta))

oroot = ROOT/'remote-v1/stochastic-oracle'
op, osum = read(oroot/'protocol.json'), read(oroot/'summary.json')
check(sha(oroot/'protocol.json') == osum['protocol_sha256'],'oracle protocol hash')
check(sha(ROOT/'remote-v1/diagnose_failures.py') == op['script_sha256'],'oracle script hash')
for category in ('wrong_admission', 'miss'):
    first = next(r['trial']['id'] for r in allrows['nohelper0'] if r['trial']['phase']=='signal' and
                 ((r['decisions']['dynamic']['accepted'] and r['decisions']['dynamic']['bit'] != r['evaluator']['source_bit'])
                  if category=='wrong_admission' else not r['decisions']['dynamic']['accepted']))
    selected = [r for r in osum['rows'] if r['selection_category']==category]
    check(len(selected)==2 and {r['condition'] for r in selected}=={'nohelper0','helper0'} and
          all(r['trial']['id']==first for r in selected), 'oracle first selected '+category)
oracle_rows=[]
for row in osum['rows']:
    o=row['oracle']; name=row['condition']; tid=row['trial']['id']; folder=oroot/(name+'-'+tid)
    close(o['distance_squared_samples']/o['raw_complex_noise_variance'],o['distance_over_noise_variance'],name+tid+': distance')
    pe=.5*math.erfc(math.sqrt(o['distance_over_noise_variance'])/2)
    close(pe,o['conditional_equal_prior_general_mean_bit_error_probability'],name+tid+': oracle error formula',atol=1e-15)
    close(math.sqrt(o['control_complex_noise_variance']/o['raw_complex_noise_variance']),o['control_noise_amplitude_ratio'],name+tid+': control noise')
    check(o['shared_noise_corrected_oracle_bit'] == (0 if o['shared_noise_corrected_log_likelihood_bit0_minus_bit1']>0 else 1),name+tid+': oracle LLR sign')
    for receipt in row['control_receipts']:
        sub=folder/Path(receipt['folder']).name
        for file,key in [('manifest.json','manifest_sha256'),('evaluator-truth.json','evaluator_truth_sha256')]:
            check(sha(sub/file)==receipt[key],name+tid+': oracle '+file+' hash')
    source=next(x for x in allrows[name] if x['trial']['id']==tid)
    check(row['original_capture']['observation_sha256']==source['input_sha256'],name+tid+': oracle original IQ identity')
    check(row['source_gain_and_calendar_and_physical_identity_verified'],name+tid+': oracle controls identity')
    native=row['native_clean_energy_samples_by_bit_and_helper_only']
    means=o['corrected_composite_mean_energy_samples_by_bit_and_helper_only']
    for i in range(3):
        close(means[i]-native[i],row['reconstructed_minus_native_mean_energy_samples'][i],name+tid+': native energy crosscheck',atol=1e-7)
    oracle_rows.append(dict(condition=name,trial=tid,true_bit=row['trial']['bit'],
                            distance_over_variance=o['distance_over_noise_variance'],known_mean_error_probability=pe,
                            llr_bit0_minus_bit1=o['shared_noise_corrected_log_likelihood_bit0_minus_bit1'],
                            received_DATA_energy_seconds=o['received_data_energy_seconds_by_bit'],
                            maximum_native_mean_energy_residual_samples=max(map(abs,row['reconstructed_minus_native_mean_energy_samples']))))
for tid in ('signal-0007','signal-0010'):
    a,b=[x for x in oracle_rows if x['trial']==tid]
    close(a['distance_over_variance'],b['distance_over_variance'],tid+': oracle Helper-independent distance')
    for x,y in zip(a['received_DATA_energy_seconds'],b['received_DATA_energy_seconds']):
        close(x,y,tid+': oracle same received DATA energy')

bench=read(BASE/'helper0-replay-none/benchmark.json')
timings={}
for batch in ('1','8'):
    vals={device:bench['backends'][device]['measurements'][batch]['wall_seconds'] for device in ('cpu','cuda')}
    meds={k:statistics.median(v) for k,v in vals.items()}
    close(meds['cpu']/meds['cuda'],bench['comparisons'][batch]['cpu_seconds_over_cuda_seconds'],'receiver timing ratio')
    timings[batch]=dict(median_seconds=meds,CUDA_slowdown_vs_CPU=meds['cuda']/meds['cpu'])
scan=read(ROOT/'scan/gpu-10000.json')
scanratio=statistics.median(scan['resident_score_seconds']['serial'])/statistics.median(scan['resident_score_seconds']['scan'])
close(scanratio,scan['median_speedup'],'scan speedup ratio')
sources=protocols['helper0']['source_hashes']
source_matches={f:Path(f).exists() and sha(Path(f))==h for f,h in sources.items()}
archive_sources, archive_receipts = {}, []
for name in ('source.tar.gz','overlay.tar.gz'):
    path=Path('/tmp/triad-stochastic-cloud')/name
    if path.exists():
        with tarfile.open(path) as archive:
            for member in archive.getmembers():
                key=member.name.removeprefix('./')
                if member.isfile() and key in sources:
                    archive_sources[key]=hashlib.sha256(archive.extractfile(member).read()).hexdigest()
        archive_receipts.append(dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size))
archive_matches={f:archive_sources.get(f)==h for f,h in sources.items()}
check(all(archive_matches[f] for f in sources if not f.endswith('.py')),
      'frozen source plus overlay reproduces native build-input identities')
check(all(source_matches[f] for f in sources if f.endswith('.py')),
      'current Python sources reproduce campaign receiver/statistics identities')
all_original_source_sets_match=all(p['source_hashes']==sources for n,p in protocols.items() if '-replay-' not in n)
check(all_original_source_sets_match,'original cohort source identities consistent')
result=dict(schema='triad-stochastic-independent-receipt-audit-v1',scope='Eight original conditioned GPU cohorts plus six same-IQ exploratory pilot ablations; four outcome-selected oracle cases; serial receiver and synthetic scan timings.',
            status='passed-with-limits' if not ERRORS else 'failed',errors=ERRORS,
            totals=dict(original_cohorts=8,replay_cohorts=6,original_capture_exports=824,replay_receipts=618,
                        original_calibration=312,original_signal=256,original_null=256),
            cohorts=cohorts,helper_pairing=pairs,oracle=oracle_rows,
            model_semantics=dict(static='Infinite-coherence physical two-ray block state; same stochastic captures.',dynamic='Equal-prior finite-coherence mixture of joint H0/bit0/bit1 evidences, followed by likelihood ratios; not an unweighted mixture of already divided likelihood ratios.',
                                channel='Independently generated fixed-time Gaussian ray evolution plus Gaussian-erf bounded Each65 selective filter; receiver block-constant OU is an approximation.',
                                protocol_order='Matching current Python source writes protocol before exports, gate after all calibration and before signal/null, scores before truth. Receipt hashes bind the records; no independently trusted chronological timestamp.'),
            provenance=dict(all_original_source_hashes_agree=all_original_source_sets_match,current_source_matches=source_matches,
                            frozen_source_archives=archive_receipts,frozen_source_archive_matches=archive_matches,
                            archive_limit='Native build-input identities all match source+overlay. The archived triad_dynamic_joint.py is older; current Python receiver/statistics sources all exactly match the frozen protocol hashes.',
                            exporter_sha256=protocols['helper0']['exporter_sha256'],binary_build_link='Frozen native source archive independently verified. Campaign records binary hash but compact receipts do not prove binary build relationship; external build receipt or reconstruction needed.',
                            raw_iq_reaudit='Compact extraction contains manifest/truth/result receipts, not I/Q/masks/templates; input-byte hashes are cross-consistent records, not independently rehashed here.'),
            uncertainty=dict(rank='39 calibration gives p steps .025; alpha .05 is marginal per-arm/per-capture under exchangeability, not conditional fixed-gate, simultaneous, daily or wrong-bit control.',
                             signal='95% balanced-population intervals average per-bit Bonferroni Clopper-Pearson bounds; conditional on frozen gate and representative independent within-bit seeds; pointwise only.',
                             null='95% Clopper-Pearson intervals conditional on gate; zero of32 has 8.9368% one-sided upper bound. Replays/pairs must not be pooled as independent captures.',
                             validation='Original held-out signal/null seeds are distinct from their calibration seeds. Pilot ablations reuse captures after original outcomes and are exploratory, not independent validation.',
                             oracle='Outcome-selected realized channels with complete known means; no acquisition, channel inference, presence gate or population claim.'),
            timing=dict(serial_full_score=timings,serial_scope=bench['scope'],scan_speedup=scanratio,scan_scope=scan['scope'],scan_warning='231x is GPU affine scan versus GPU serial state scoring only; not CPU/GPU whole-receiver speedup.'),
            limitations=['Known nominal timing/epoch, oscillator effects off; no blind acquisition qualified by these campaigns.',
                         'Only HFworst margin3, Each65, rate36 Added10, selected stochastic widths/motion were tested here.',
                         'No operational 1e-4/day or 1%/12h false-admission qualification; 32 signals cannot certify99% correct reception.',
                         'All four full-known-mean oracle decisions correct does not imply an achievable near-bound practical receiver.',
                         'Raw-waveform rescore and independent native binary/source build reconstruction are outside this compact receipt audit.'],
            audit_wall_seconds=time.monotonic()-started,review_script_sha256=sha(Path(__file__)))
(ROOT/'audit-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],errors=ERRORS,cohorts=len(cohorts),rows=sum(len(x) for x in allrows.values()),audit_wall_seconds=result['audit_wall_seconds']),indent=2))

from pathlib import Path
import json,os,subprocess,time,signal
root=Path('/workspace/triad');out=Path('/workspace/stochastic-results');env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tools')
base=['python','tools/triad_dynamic_campaign.py','--exporter','build/dev-cli/triad_helper_export','--calibration-count','39','--signal-count','32','--null-count','32','--alpha','.05','--device','cuda','--precision','fp32','--threads','2','--batch-size','8','--export-workers','8']
cases=[
 ('motion-nohelper-minus6','--case hf --seconds 64 --cn0 -6 --channel-evolution stochastic --random-doppler-width-hz .5 --selective-modulation-rate-hz .05 --helper off --timing-policy bounded --key-seed 2401 --delay-excursion-ms .001 --delay-knot-seconds 100',940000,.25,['.1','.5','2','inf'],'both'),
 ('motion-helper-minus6','--case hf --seconds 64 --cn0 -6 --channel-evolution stochastic --random-doppler-width-hz .5 --selective-modulation-rate-hz .05 --helper on --timing-policy bounded --key-seed 2401 --delay-excursion-ms .001 --delay-knot-seconds 100',940000,.25,['.1','.5','2','inf'],'both'),
 ('wide-nohelper8','--case hf --seconds 16 --cn0 8 --channel-evolution stochastic --random-doppler-width-hz 5 --selective-modulation-rate-hz .05 --helper off --timing-policy bounded --key-seed 2402',950000,.025,['.01','.05','.2','inf'],'both'),
 ('wide-highpilot8','--case hf --seconds 16 --cn0 8 --channel-evolution stochastic --random-doppler-width-hz 5 --selective-modulation-rate-hz .05 --helper on --timing-policy bounded --key-seed 2402',950000,.025,['.01','.05','.2','inf'],'high')]
(out/'followup-plan.json').write_text(json.dumps(dict(cases=cases,base=base,scope='independentkeys/seeds + variablegeometricdelay + higherGaussianwidth; highpilotonlyforauxseparation'),indent=2))
commands=[]
for name,args,seed,block,coh,pilot in cases:commands.append((name,base+['--output',str(out/name),'--seed-base',str(seed),'--block-seconds',str(block),'--coherences',*coh,'--pilot-use',pilot,'--export-arg='+args]))
for cohort in ['helper0','helper8']:
 for pilot in ['none','low','high']:
  name=cohort+'-replay-'+pilot
  cmd=['python','tools/triad_dynamic_replay.py','--campaign',str(out/cohort),'--output',str(out/name),'--pilot-use',pilot,'--device','cuda']
  if cohort=='helper0' and pilot=='none':cmd+=['--benchmark-cpu-cuda']
  commands.append((name,cmd))
start=time.monotonic()
for name,cmd in commands:
 mark=time.monotonic()
 with (out/(name+'.log')).open('x') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=min(1800,7200-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=p.returncode
 (out/(name+'-run.json')).write_text(json.dumps(dict(returncode=rc,wall_seconds=time.monotonic()-mark,command=cmd),indent=2))
 print(name,rc,time.monotonic()-mark,flush=True)
 if rc:break
(out/'followup-run.json').write_text(json.dumps(dict(wall_seconds=time.monotonic()-start),indent=2))

from pathlib import Path
import json,os,subprocess,time,signal
root=Path('/workspace/triad');out=Path('/workspace/stochastic-results');out.mkdir(exist_ok=True)
base=['python','tools/triad_dynamic_campaign.py','--exporter','build/dev-cli/triad_helper_export','--calibration-count','39','--signal-count','32','--null-count','32','--alpha','.05','--block-seconds','.25','--coherences','.1','.5','2','inf','--device','cuda','--precision','fp32','--threads','2','--batch-size','8','--export-workers','8']
cohorts=[('nohelper8',920000,'off',8),('helper8',920000,'on',8),('nohelper0',930000,'off',0),('helper0',930000,'on',0)]
env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tools')
plan=dict(cohorts=cohorts,base=base,conditional_scope='Known nominal timing/epoch and oscillatoroff; actualrandomchannel unknown',comparison='static vs dynamic, sameobservations, separatefrozenalpha.05gates; notdailyFA',paired='samechannel/noiseseeds on/off helper; independentCNO8/CNO0 families',deadline_seconds=7200)
(out/'plan.json').write_text(json.dumps(plan,indent=2));start=time.monotonic()
for name,seed,helper,cn0 in cohorts:
 args=f'--case hf --seconds 16 --cn0 {cn0} --channel-evolution stochastic --random-doppler-width-hz .5 --selective-modulation-rate-hz .05 --helper {helper} --timing-policy bounded'
 cmd=base+['--output',str(out/name),'--seed-base',str(seed),'--export-arg='+args]
 mark=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=min(1800,7200-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   rc=p.returncode
 (out/(name+'-run.json')).write_text(json.dumps(dict(returncode=rc,wall_seconds=time.monotonic()-mark,command=cmd),indent=2))
 print(name,rc,time.monotonic()-mark,flush=True)
 if rc:break
(out/'run.json').write_text(json.dumps(dict(wall_seconds=time.monotonic()-start),indent=2))

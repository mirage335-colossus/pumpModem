#!/usr/bin/env python3
"""New receipt-only audit; reuse independent arithmetic without prior campaigns."""
import ast
import hashlib
import json
from pathlib import Path
import math
import time

ROOT=Path(__file__).resolve().parent
V2=ROOT/'remote-v2'
# Only import/function definitions: do not execute or overwrite the prior audit.
source=ROOT/'audit_v2.py';tree=ast.parse(source.read_text())
defs=ast.Module(body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[])
ns={'ERRORS':[]};exec(compile(defs,str(source),'exec'),ns)
read,rows,sha,check,close,recount,label=[ns[n] for n in ('read','rows','sha','check','close','recount','label')]
started=time.monotonic();cohorts=[]
for name in ('core-helper8','core-helper0','core-weak-helper8-fixed-cli'):
    d=V2/'stochastic-results'/name;p=read(d/'protocol.json');r,p,g,s,o=recount(d,p['configuration']['coherences'])
    prep=read(d/'prepared.json')
    check(p['configuration']['projection']=='core' and p['configuration']['execution']=='scan',name+': variant')
    match={f:Path(f).exists() and sha(Path(f))==h for f,h in p['source_hashes'].items()}
    check(all(match.values()),name+': current source identities')
    for row in r:
        sub=d/row['trial']['id'];m=read(sub/'manifest.json');t=read(sub/'evaluator-truth.json')
        check(sha(sub/'manifest.json')==row['manifest_sha256'],name+': manifest hash')
        check(sha(sub/'evaluator-truth.json')==row['evaluator']['truth_sha256'],name+': truth hash')
        check(read(sub/'result.json')==row,name+': per-trial result')
        check(t['random_seed_roots']['fixture']==row['trial']['seed'] and t['source_bit']==row['trial']['bit'],name+': truth identity')
        check(m['channel']['selective_modulation_rate_hz']==90 and m['channel']['random_doppler_width_hz']==.5 and not m['channel']['oscillator_effects'],name+': channel scope')
        check(row['procedure_id']==g['procedure_id']==prep['procedure_id']==s['procedure_id'],name+': procedure identity')
        check(row['condition_id']==g['condition_id']==prep['condition_id']==s['condition_id'],name+': condition identity')
    m=read(d/'signal-0000/manifest.json')
    cohorts.append(dict(name=name,outcomes=o,protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl'),
                        source_hashes=p['source_hashes'],current_source_matches=match,exporter_sha256=p['exporter_sha256'],
                        power=m['power'],timing=s['timing'],status='held-out diagnostic successes; not operational admission qualification'))

failed=V2/'stochastic-results/core-weak-helper8';failure=read(failed/'failure.json')
check(failure['completed_trials']==0,'weak CLI no completed trials')
check(not (failed/'summary.json').exists() and not (failed/'gate.json').exists(),'weak CLI no final gate/summary')
check('unknown option: --helper-power' in (failed/'calibration-0000-export.log').read_text(),'weak CLI exact setup error')
check(not list(failed.glob('*/manifest.json')),'weak CLI no captured manifest')
weak_setup=dict(classification='setup failure, excluded from signal/null counts',completed_trials=0,error='triad_helper_export: unknown option: --helper-power',
                corrected_flag='--helper-power-w .004',failure_sha256=sha(failed/'failure.json'),automatic_retry=failure['automatic_retry'])

d=V2/'stochastic-acquisition-none';p=read(d/'protocol.json');old=V2/'stochastic-acquisition-helper'
r,p,g,s,o=recount(d,['0.1','0.5','2.0','inf'])
original=rows(old/'trials.jsonl');planned=read(d/'planned.json');oldplanned=read(old/'planned.json')
for filename in ('protocol','planned','summary'):
    check(p['original_'+filename+'_sha256']==sha(old/(filename+'.json')),'none original '+filename)
for field in ('selected_epochs','arrival_seconds','frequencies_hz','clock_ppm','total_candidates','tile_count'):
    check(planned['policy'][field]==oldplanned['policy'][field],'none preserves '+field)
check(planned['policy']['pilot_use']=='none','none pilot use')
import collections
paired={a:collections.Counter() for a in ('static','dynamic')}
for a,b in zip(original,r):
    check(all(a[k]==b[k] for k in ('trial','input_sha256','validity_sha256','manifest_sha256')),'none same IQ')
    check(set(a['evaluator'])-set(b['evaluator'])=={'nearest_timing_grid_error_seconds','arrival_inside_public_prior'},'none omitted derived timing diagnostics only')
    check(all(a['evaluator'][k]==v for k,v in b['evaluator'].items()),'none same physical evaluator/truth hash')
    if a['trial']['phase']!='calibration':
        for arm in paired:paired[arm][label(a,arm)+' / '+label(b,arm)]+=1
for arm,c in paired.items():check(dict(c)==s['compared_with_original'][arm]['original_then_replay'],'none paired summary')
none=dict(outcomes=o,protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl'),source_hashes=p['source_hashes'],
          current_source_matches={f:Path(f).exists() and sha(Path(f))==h for f,h in p['source_hashes'].items()},
          paired_categories={a:dict(c) for a,c in paired.items()},work=s['work'],timing=s['timing'],
          scope='All original533 hypotheses and103 captures replayed with DATA-band receiver and separate gate. Helper remains physically transmitted; post-outcome diagnostic, not independent validation.')

d=V2/'stochastic-acquisition-guarded';p=read(d/'protocol.json')
gr,p,g,gs,go=recount(d,p['search']['coherence_seconds']);gp=read(d/'planned.json');guard=gp['policy']['pilot_timing_guard']
check(all(Path(f).exists() and sha(Path(f))==h for f,h in p['source_hashes'].items()),'guard frozen source matches')
check(gp['policy']['pilot_use']=='none' and gp['policy']['requested_pilot_use']=='both','guard resolves DATA-only')
check(guard['guard_applied'] and guard['reason']=='helper_phase_timing_unresolved','guard reason')
close(guard['allowed_cover_radius_seconds'],math.acos(10**(-.5/20))/(math.pi*1850),'guard engineering threshold')
close(guard['continuous_cover_radius_seconds'],.004525/2,'guard continuous radius')
check(gp['policy']['total_candidates']==533 and gp['policy']['tile_count']==78,'guard complete bank')
check(p['configuration']['seed_base']==1010000 and set(x['trial']['seed'] for x in gr).isdisjoint(x['trial']['seed'] for x in original),'guard independent validation seeds')
for row in gr:
    sub=d/row['trial']['id'];m=read(sub/'manifest.json');t=read(sub/'evaluator-truth.json')
    check(sha(sub/'manifest.json')==row['manifest_sha256'] and sha(sub/'evaluator-truth.json')==row['evaluator']['truth_sha256'],'guard capture/evaluator identity')
    check(m['key_seed']==2407 and not m['channel']['oscillator_effects'],'guard new key and oscillator-off scope')
    check(row['procedure_id']==gs['procedure_id']==g['procedure_id'] and row['condition_id']==gs['condition_id']==g['condition_id'],'guard gate/procedure identity')
guarded=dict(outcomes=go,protocol_sha256=sha(d/'protocol.json'),trials_sha256=sha(d/'trials.jsonl'),source_hashes=p['source_hashes'],
             effective_pilot_use=gp['policy']['pilot_use'],public_timing_guard=guard,procedure_id=gs['procedure_id'],condition_id=gs['condition_id'],
             seed_base=1010000,key_seed=2407,work=gs['work'],timing=gs['timing'],
             scope='New key/seeds validate publicly resolved DATA-only policy before scoring. Not successful joint pilot phase assistance, continuous timing ML or oscillator acquisition.')

met=V2/'stochastic-core-metrology';raw=read(met/'results.json');corrected=read(met/'results-units-corrected-v2.json')
check(corrected['source_results_sha256']==sha(met/'results.json'),'metrology original hash')
noncentrality=[];fractions={k:[] for k in ('data-only','low-only','high-only','auxiliary-only')}
for name,c in corrected['cases'].items():
    m=raw['cases'][name]['measurements'];fs=c['sample_rate_hz']
    check(c['source_projected_energy_joules_normalized']==m['data_subspace_projected_energy_joules_normalized'],'metrology retained energy identity')
    check(c['v1_stored_noncentrality']==m['data_template_subspace_noncentrality'],'metrology original value identity')
    for cn0,values in c['corrected_noncentrality'].items():
        rho=10**(float(cn0)/10)
        for arm,value in values.items():
            close(value,m['data_subspace_projected_energy_joules_normalized'][arm]*rho,'metrology corrected units')
            close(value,c['v1_stored_noncentrality'][cn0][arm]*fs,'metrology exact missing Fs factor')
    noncentrality.append(c['corrected_noncentrality']['8.0']['auxiliary-only'])
    for arm in fractions:fractions[arm].append(m['core_projection_energy_fraction_of_received_signal'][arm])
metrology=dict(original_sha256=sha(met/'results.json'),derivative_sha256=sha(met/'results-units-corrected-v2.json'),
               correction='lambda_complex = projected sample energy / raw complex noise variance = (sample energy/Fs)*10^(CN0/10); prior record had extra1/Fs.',
               corrected_auxiliary_lambda_at8_range=[min(noncentrality),max(noncentrality)],
               core_energy_retention_ranges={k:[min(v),max(v)] for k,v in fractions.items()},
               scope='Arithmetic/unit correction from existing retained energies; original unchanged; no waveform regeneration or renewed physical metrology.')

diagnostic_path=V2/'stochastic-acquisition-diagnosis/summary.json';diagnostic=read(diagnostic_path);diagnostic_rows=[]
for row in diagnostic['rows']:
    earlier=next(x for x in original if x['trial']['id']==row['trial_id'])
    check(all(row['input_receipt'][k]==earlier[k] for k in ('input_sha256','validity_sha256','manifest_sha256')),'timing diagnosis original inputs')
    for mode,value in row['comparisons'].items():
        ev=value['hypothesis_log_evidence'][0][0];ll=[ev[b+1]-ev[0] for b in (0,1)]
        for b in (0,1):close(ll[b],value['bit_scores'][b],'timing diagnosis LLR')
        close(ns['lse'](ll)-math.log(2),value['working_presence'],'timing diagnosis presence')
        check((0 if ll[0]>=ll[1] else 1)==value['bit'],'timing diagnosis bit')
    diagnostic_rows.append(dict(trial_id=row['trial_id'],comparisons={k:dict(working_presence=v['working_presence'],raw_correct=v['raw_correct']) for k,v in row['comparisons'].items()}))
diagnostic_receipt=dict(summary_sha256=sha(diagnostic_path),rows=diagnostic_rows,scope=diagnostic['scope'])

draft=Path('docs/validation-data/triad-v3/2026-11-05-stochastic/README.md')
issues=[dict(severity='documentation update needed',text='Fresh guarded cohort now independently recounts dynamic30/0/2 with1/32 null and static10/0/22 with0/32 null. Add it explicitly; effective policy is DATA-only, not successful joint pilot phase assistance.'),
        dict(severity='clarify scope',text='In Strong, fast selective modulation, replace ambiguous "It retains the actual broad sidebands" with "Native captures retain the actual broad sidebands; the core receiver deliberately discards some bins." The preceding fixed-core description is otherwise accurate.'),
        dict(severity='clarify injected versus physical C/N0',text='Table C/N0 values use a noise override. The nominal4W/180dB/noise-density metadata gives20.0206dB-Hz before override; tested8/0/-6 values must not be read as that physical link budget.')]
result=dict(schema='triad-stochastic-independent-receipt-audit-v3',status='passed-with-limits' if not ns['ERRORS'] else 'failed',errors=ns['ERRORS'],
            new_core_cohorts=cohorts,failed_weak_cli=weak_setup,DATA_only_acquisition_replay=none,fresh_guarded_acquisition=guarded,corrected_metrology=metrology,selected_timing_diagnostic=diagnostic_receipt,
            documentation_review=dict(path=str(draft),sha256=sha(draft),issues=issues,
                limits='Selected four-arrival retained evidence arithmetic checked; source implementation of the guard was not independently reviewed in this task. Its public resolution/formula/procedure and new cohort counts were checked. No maintained documents edited.'),
            limitations=['39 calibration/32 signal/32 null per cohort is diagnostic, not operational daily false-admission qualification.',
                         'Core cohorts use different keys and seeds; no paired full-projection/core receiver comparison or universal pilot-lock conclusion follows.',
                         'DATA-only acquisition is same-capture recovery, not fresh validation; all receiver-input hashes and original533 hypotheses match.',
                         'Raw waveform bytes are absent from compact extraction; manifests/truth/result identities and arithmetic are audited.'],
            audit_wall_seconds=time.monotonic()-started,reproducer_sha256=sha(Path(__file__)),arithmetic_reuse_source_sha256=sha(source))
(ROOT/'audit-v3.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],errors=ns['ERRORS'],core_counts={x['name']:{a:o['counts'] for a,o in x['outcomes'].items()} for x in cohorts},none_counts={a:v['counts'] for a,v in o.items()},metrology=metrology),indent=2))

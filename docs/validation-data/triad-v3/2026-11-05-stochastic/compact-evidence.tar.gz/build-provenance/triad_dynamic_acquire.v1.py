#!/usr/bin/env python3
"""Bounded-memory execution tiling of the existing dynamic acquisition bank.

This changes execution layout, not the detector. Every public Cartesian
candidate is scored exactly once. All tiles use a common projection planned
from the COMPLETE frequency/clock bank. Tile log means are converted back to
weighted sums before combining H0, bit0 and bit1 separately. No candidate is
pruned using its observed score, Helper result or evaluator truth.

Preparation is amortized over every supplied trial batch before a tile is
released. A subsequent ``score`` call prepares the tiles again. Keep independent
captures in one call where memory permits; do not call once per capture and
mistake repeated preparation for intrinsic receiver cost. The wrapper does not
calibrate admission or assert that a finite bank covers continuous uncertainty.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import hashlib
import itertools
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.special import logsumexp
import torch

from triad_dynamic_joint import DynamicJointReceiver, public_spectral_bands
from triad_dynamic_variants import ScanJointReceiver, core_projection_bands


def _bank(values, name, *, integral=False):
    original = tuple(values)
    if not original:
        raise ValueError(f'{name} must be nonempty')
    if integral:
        if any(isinstance(x, (bool, np.bool_)) or not isinstance(x, (int, np.integer)) for x in original):
            raise ValueError(f'{name} requires integer coordinates')
        result = tuple(int(x) for x in original)
    else:
        result = tuple(float(x) for x in original)
        if not all(math.isfinite(x) for x in result):
            raise ValueError(f'{name} requires finite coordinates')
    if len(set(result)) != len(result):
        raise ValueError(f'{name} must contain unique coordinates')
    return result


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False,
                                    separators=(',', ':')).encode()).hexdigest()


def projection_digest(receiver):
    """Physical block boundaries, operator kind and exact retained rows/bins."""
    value = hashlib.sha256()
    for start, stop, projection, *_ in receiver.blocks:
        value.update(np.asarray([start, stop], dtype='<i8').tobytes())
        value.update(projection.kind.encode())
        value.update(np.asarray(projection.indices, dtype='<i8').tobytes())
    return value.hexdigest()


@dataclass(frozen=True)
class AcquisitionTile:
    epoch: int
    arrivals: tuple[float, ...]
    frequency: float
    clock_ppm: float

    @property
    def candidates(self):
        return len(self.arrivals)

    def coordinates(self):
        return tuple((self.epoch, arrival, self.frequency, self.clock_ppm) for arrival in self.arrivals)


class TiledAcquisition:
    """Public bank descriptor; one bounded receiver workspace lives at a time.

    ``memory_limit_bytes`` is an explicit-array engineering budget covering the
    supplied raw input, public template array, validity, result aggregation and
    one receiver workspace. It is not an OS RSS, CUDA allocator-cache or library
    scratch guarantee. Inputs are borrowed without a full copy; the raw buffer
    is nevertheless reserved in this total accounting. The input may be a NumPy
    memmap. CPU and CUDA source arithmetic follow the existing receiver controls.
    """

    def __init__(self, manifest, raw_templates, epoch_offsets, *,
                 arrival_seconds=(0.,), frequencies_hz=(0.,), clock_ppm=(0.,),
                 selected_epochs=None, timing_tile_size=8, block_seconds=.25,
                 coherence_seconds=(.5, math.inf), pilot_use='both',
                 execution='scan', projection='full-envelope',
                 auxiliary_half_width_hz=200., device='cpu', precision='fp32',
                 memory_limit_bytes=2*1024**3, maximum_candidates=1_000_000):
        started = time.perf_counter()
        self.manifest = copy.deepcopy(manifest)
        self.templates = np.asarray(raw_templates)
        self.epochs = _bank(epoch_offsets, 'template epochs', integral=True)
        if (self.templates.ndim != 3 or self.templates.shape[:2] != (len(self.epochs), 2) or
                not np.iscomplexobj(self.templates) or self.templates.shape[-1] < 1):
            raise ValueError('complex public templates need [epochs,2,samples]')
        self.selected_epochs = _bank(self.epochs if selected_epochs is None else selected_epochs,
                                     'selected epochs', integral=True)
        if any(epoch not in self.epochs for epoch in self.selected_epochs):
            raise ValueError('selected epoch missing from public template bank')
        self.arrivals = _bank(arrival_seconds, 'arrival bank')
        self.frequencies = _bank(frequencies_hz, 'frequency bank')
        self.clocks = _bank(clock_ppm, 'clock bank')
        if any(1+clock*1e-6 <= 0 for clock in self.clocks):
            raise ValueError('clock scales must be positive')
        prior = self.manifest['calendar']['arrival_prior_seconds']
        if min(self.arrivals) < prior[0] or max(self.arrivals) > prior[1]:
            raise ValueError('arrival bank leaves public arrival prior')
        if (not isinstance(timing_tile_size, int) or isinstance(timing_tile_size, bool) or
                not 1 <= timing_tile_size <= 4096):
            raise ValueError('timing tile size must be an integer in [1,4096]')
        if (not isinstance(memory_limit_bytes, int) or isinstance(memory_limit_bytes, bool) or
                memory_limit_bytes < 1):
            raise ValueError('positive integer memory limit required')
        if not isinstance(maximum_candidates, int) or maximum_candidates < 1:
            raise ValueError('positive integer candidate cap required')
        if not math.isfinite(block_seconds) or block_seconds <= 0:
            raise ValueError('positive finite block duration required')
        self.coherences = tuple(float(x) for x in coherence_seconds)
        if (not self.coherences or len(set(self.coherences)) != len(self.coherences) or
                any(math.isnan(x) or x <= 0 for x in self.coherences)):
            raise ValueError('distinct positive coherence values required')
        if execution not in ('serial', 'scan') or projection not in ('full-envelope', 'core'):
            raise ValueError('execution must be serial/scan; projection must be full-envelope/core')
        if precision not in ('fp32', 'fp64'):
            raise ValueError('precision must be fp32/fp64')
        self.candidates = math.prod(map(len, (self.selected_epochs, self.arrivals,
                                            self.frequencies, self.clocks)))
        if self.candidates > maximum_candidates:
            raise ValueError('public Cartesian bank exceeds declared total candidate cap')
        if self.templates.nbytes >= memory_limit_bytes:
            raise MemoryError('public template input alone exceeds total memory budget')
        self.tile_size, self.block_seconds = timing_tile_size, float(block_seconds)
        self.execution, self.projection = execution, projection
        self.device, self.precision, self.pilot_use = device, precision, pilot_use
        self.memory_limit_bytes = memory_limit_bytes
        self.auxiliary_half_width_hz = float(auxiliary_half_width_hz)
        # Never plan from the current tile's smaller bank. Likelihoods using
        # different observation projections are not interchangeable tile terms.
        if projection == 'core':
            required, excluded = core_projection_bands(self.manifest, pilot_use=pilot_use,
                frequencies_hz=self.frequencies, clock_ppm=self.clocks,
                auxiliary_half_width_hz=auxiliary_half_width_hz)
        else:
            required, excluded = public_spectral_bands(self.manifest, pilot_use=pilot_use,
                cfo_bound_hz=max(map(abs, self.frequencies)),
                clock_bound_ppm=max(map(abs, self.clocks)),
                auxiliary_half_width_hz=auxiliary_half_width_hz)
        self.required_bands_hz, self.excluded_bands_hz = required, excluded
        self.tile_count = (len(self.selected_epochs)*len(self.frequencies)*len(self.clocks)*
                           math.ceil(len(self.arrivals)/self.tile_size))
        sources = {name: hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
                   for name in ('triad_dynamic_acquire.py', 'triad_dynamic_joint.py',
                                'triad_dynamic_variants.py', 'triad_dynamic_scan.py',
                                'triad_gaussian_prepared.py', 'triad_gaussian_state.py')}
        self.policy = dict(schema='triad-dynamic-tiled-acquisition-v1',
            selected_epochs=self.selected_epochs, arrival_seconds=self.arrivals,
            frequencies_hz=self.frequencies, clock_ppm=self.clocks,
            timing_tile_size=self.tile_size, total_candidates=self.candidates, tile_count=self.tile_count,
            block_seconds=self.block_seconds, coherences=[str(x) for x in self.coherences],
            pilot_use=pilot_use, execution=execution, projection=projection,
            required_bands_hz=required, auxiliary_exclusion_hz=excluded,
            device=str(device), precision=precision, source_hashes=sources,
            template_sha256=hashlib.sha256(np.ascontiguousarray(self.templates).view(np.uint8)).hexdigest(),
            mixture='Equal complete-Cartesian candidate prior under H0 and both bits; no pruning.',
            projection_scope='One full-bank public projection shared by every tile; core is explicitly lossy.'
                if projection == 'core' else 'One full-bank public envelope projection shared by every tile.',
            scope='Finite public timing/frequency/clock/epoch bank. No continuous-grid or operational admission guarantee.')
        public = {name: self.manifest[name] for name in ('format', 'calendar', 'channel', 'helper_plan', 'power')}
        public['helper_enabled'] = bool(self.manifest.get('helper_enabled', True))
        self.procedure_id = _digest(dict(policy=self.policy, public_geometry=public))
        self.planning_seconds = time.perf_counter()-started

    def tiles(self):
        """Disjoint rectangles; nonuniform final timing tiles are intentional."""
        for epoch, frequency, clock in itertools.product(self.selected_epochs, self.frequencies, self.clocks):
            for first in range(0, len(self.arrivals), self.tile_size):
                yield AcquisitionTile(epoch, self.arrivals[first:first+self.tile_size], frequency, clock)

    def _receiver(self, tile, valid, memory_budget):
        cls = ScanJointReceiver if self.execution == 'scan' else DynamicJointReceiver
        return cls(self.manifest, self.templates, self.epochs,
            selected_epochs=(tile.epoch,), arrival_seconds=tile.arrivals,
            frequencies_hz=(tile.frequency,), clock_ppm=(tile.clock_ppm,),
            block_seconds=self.block_seconds, coherence_seconds=self.coherences,
            pilot_use=self.pilot_use, required_bands_hz=self.required_bands_hz,
            auxiliary_exclusion_hz=self.excluded_bands_hz,
            auxiliary_half_width_hz=self.auxiliary_half_width_hz, valid=valid,
            device=self.device, precision=self.precision, memory_limit_bytes=memory_budget)

    def score(self, raw, valid=None, *, trial_batch_size=None, progress=None):
        started = time.perf_counter()
        data = np.asarray(raw)
        if data.ndim == 1:
            data = data[None, :]
        samples = int(self.manifest['calendar']['capture_samples'])
        if (data.ndim != 2 or data.shape[0] < 1 or data.shape[1] != samples or
                not np.iscomplexobj(data)):
            raise ValueError('complex raw input needs [trials,public capture samples]')
        trials = data.shape[0]
        if trial_batch_size is None:
            trial_batch_size = trials
        if (not isinstance(trial_batch_size, int) or isinstance(trial_batch_size, bool) or
                trial_batch_size < 1):
            raise ValueError('trial batch size must be a positive integer')
        valid = np.ones(samples, bool) if valid is None else np.asarray(valid)
        if valid.shape != (samples,) or not np.isin(valid, (0, 1)).all():
            raise ValueError('public validity must be a binary raw-sample vector')
        valid = valid.astype(bool, copy=True)
        accumulator_bytes = len(self.coherences)*trials*3*8
        # Three evidence arrays allow accumulator, tile result and logaddexp
        # scratch; input/template borrowing is still reserved in total cost.
        reserved = data.nbytes+self.templates.nbytes+valid.nbytes+3*accumulator_bytes
        tile_budget = self.memory_limit_bytes-reserved
        if tile_budget <= 0:
            raise MemoryError('raw/template/result inputs leave no memory for a tile workspace')
        combined = np.full((len(self.coherences), trials, 3), -np.inf, np.float64)
        receipt = []
        projection_hash = None
        candidate_count = 0
        preparation = correlation = state = scoring_wall = 0.
        peak_owned = peak_preparation = 0
        cls_device = torch.device(self.device)
        for tile_index, tile in enumerate(self.tiles()):
            mark = time.perf_counter()
            receiver = self._receiver(tile, valid, tile_budget)
            if cls_device.type == 'cuda':
                torch.cuda.synchronize(cls_device)
            prep_seconds = time.perf_counter()-mark
            preparation += prep_seconds
            resolved = projection_digest(receiver)
            if projection_hash is None:
                projection_hash = resolved
            elif projection_hash != resolved:
                raise RuntimeError('resolved observation projection changed across acquisition tiles')
            if receiver.candidates != tile.candidates:
                raise RuntimeError('tile receiver candidate count differs from public partition')
            tile_correlation = tile_state = tile_wall = 0.
            fallback = []
            for first in range(0, trials, trial_batch_size):
                stop = min(trials, first+trial_batch_size)
                mark = time.perf_counter()
                result = receiver.score(data[first:stop])
                if cls_device.type == 'cuda':
                    torch.cuda.synchronize(cls_device)
                elapsed = time.perf_counter()-mark
                evidence = np.asarray(result['hypothesis_log_evidence'], np.float64)
                if evidence.shape != (len(self.coherences), stop-first, 3) or not np.isfinite(evidence).all():
                    raise ValueError('tile returned invalid hypothesis evidence')
                # A tile result is log(mean candidate likelihood), not a sum.
                # Weight by its actual count (including the short last tile).
                combined[:, first:stop] = np.logaddexp(combined[:, first:stop],
                                                       evidence+math.log(tile.candidates))
                tile_correlation += float(result['correlation_seconds'])
                tile_state += float(result['state_seconds'])
                tile_wall += elapsed
                for backend in result.get('scan_backend', ()):
                    if backend.get('fallback_reason') and backend['fallback_reason'] not in fallback:
                        fallback.append(backend['fallback_reason'])
            work = receiver.work()
            peak_owned = max(peak_owned, int(work['owned_bytes_estimate']))
            peak_preparation = max(peak_preparation, int(work['preparation_peak_bytes_estimate']))
            receipt.append(dict(index=tile_index, epoch=tile.epoch, arrivals=tile.arrivals,
                frequency_hz=tile.frequency, clock_ppm=tile.clock_ppm, candidates=tile.candidates,
                projection_sha256=resolved, receiver_procedure_id=receiver.procedure_id,
                preparation_seconds=prep_seconds, correlation_seconds=tile_correlation,
                state_seconds=tile_state, score_wall_seconds=tile_wall,
                owned_bytes_estimate=work['owned_bytes_estimate'],
                preparation_peak_bytes_estimate=work['preparation_peak_bytes_estimate'],
                scan_fallback_reasons=fallback))
            if progress is not None:
                progress(dict(receipt[-1]))
            candidate_count += tile.candidates
            correlation += tile_correlation
            state += tile_state
            scoring_wall += tile_wall
            # Drop the workspace before constructing the next one. CUDA's
            # allocator may cache freed blocks; that is not a live second tile.
            del receiver, result
        if candidate_count != self.candidates or len(receipt) != self.tile_count:
            raise RuntimeError('tiled bank did not visit exactly the declared candidate count')
        combined -= math.log(self.candidates)
        mixed = logsumexp(combined, axis=0)-math.log(len(self.coherences))
        validity_hash = hashlib.sha256(valid.tobytes()).hexdigest()
        return dict(hypothesis_log_evidence=combined,
            model_bit_scores=combined[:, :, 1:]-combined[:, :, :1],
            bit_scores=mixed[:, 1:]-mixed[:, :1],
            procedure_id=_digest(dict(base=self.procedure_id, valid_sha256=validity_hash,
                                      resolved_projection_sha256=projection_hash)),
            policy=self.policy, tiles=receipt,
            work=dict(trials=trials, samples=samples, candidates=self.candidates, tiles=self.tile_count,
                maximum_candidates_per_tile=min(len(self.arrivals), self.tile_size),
                trial_batch_size=trial_batch_size, total_candidate_trial_evaluations=trials*self.candidates,
                input_template_result_reserved_bytes=reserved, per_tile_memory_budget=tile_budget,
                peak_tile_owned_bytes_estimate=peak_owned,
                peak_tile_preparation_bytes_estimate=peak_preparation,
                total_preparation_peak_bytes_estimate=reserved+peak_preparation,
                projection_sha256=projection_hash, validity_sha256=validity_hash,
                device=str(self.device), precision=self.precision),
            timing=dict(planning_seconds=self.planning_seconds, preparation_seconds=preparation,
                correlation_seconds=correlation, state_seconds=state, score_wall_seconds=scoring_wall,
                total_score_call_seconds=time.perf_counter()-started,
                scope='Complete tiled score call includes every tile preparation and trial batch. '
                      'Native generation, input loading and object planning are separate.'))

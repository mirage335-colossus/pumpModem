#!/usr/bin/env python3
"""Review new build/timing receipts without repeating the original cohort audit."""
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


audit = read(ROOT/'audit-v1.json')
assert audit['status'] == 'passed-with-limits' and not audit['errors']
builddir = ROOT/'build-provenance'
receipt = builddir/'v1-reproducibility.sha256'
entries = [line.split(maxsplit=1) for line in receipt.read_text().splitlines()]
assert len(entries) == 2
assert all(x[0] == audit['provenance']['exporter_sha256'] for x in entries)
assert [x[1] for x in entries] == ['build/dev-cli/triad_helper_export', '/workspace/triad_helper_export.v1']
assert 'Building CXX object CMakeFiles/triad_helper_export.dir/tools/triad-helper-export.cpp.o' in (builddir/'rebuild-v1-provenance.log').read_text()
assert 'Linking CXX executable triad_helper_export' in (builddir/'rebuild-v1-provenance.log').read_text()
audit['provenance']['binary_build_link'] = ('Accepted with retained native-source archive identities and same-directory restored-v1 compiler/linker log plus byte-identical rebuilt/frozen binary SHA256 receipt. The audit inspects remote receipts; it does not itself repeat compilation or hash remote binary bytes.')
audit['provenance']['binary_rebuild_receipts'] = {p.name:sha(p) for p in builddir.iterdir() if p.is_file()}
audit['provenance']['compiler'] = (builddir/'compiler.txt').read_text().splitlines()[0]

path = ROOT/'benchmark/paired-score-benchmark.json'
bench = read(path)
original = ROOT/'remote-v1/stochastic-results/helper0'
assert bench['protocol_sha256'] == sha(original/'protocol.json')
rows = [json.loads(line) for line in (original/'trials.jsonl').read_text().splitlines()]
rows = [r for r in rows if r['trial']['phase']=='signal'][:8]
assert bench['inputs'] == [{k:r[k] for k in ('input_sha256','validity_sha256','manifest_sha256')} for r in rows]
assert all(sha(Path('tools')/name)==digest for name,digest in bench['source_hashes'].items())
script = ROOT/'benchmark/paired.py'
text = script.read_text()
assert "config['pilot_use']='both'" in text and "projection='full-envelope'" in text
assert "for backend in ['serial','scan']" in text
summary = {}
for device in ('cpu','cuda'):
    arms = {arm:bench['results'][arm]['backends'][device] for arm in ('serial','scan')}
    for key in ('raw_samples','blocks','taps','candidates','models','projected_modes','erased_samples','bulk_dtype','preparation_dtype','score_dtype','covariance_model','projection'):
        assert arms['serial']['work'][key] == arms['scan']['work'][key]
    assert all(x['fallback_reason'] is None for x in arms['scan']['work']['scan'])
    summary[device] = {}
    for batch in ('1','8'):
        medians = {arm:statistics.median(value['measurements'][batch]['wall_seconds']) for arm,value in arms.items()}
        for arm in arms:
            assert medians[arm] == arms[arm]['measurements'][batch]['median_wall_seconds']
        ratio = medians['serial']/medians['scan']
        assert abs(ratio-bench['scan_speedup'][device][batch]) < 1e-12
        summary[device][batch] = dict(median_seconds=medians,scan_speedup_over_serial=ratio)
gpu_vs_cpu = {batch:summary['cpu'][batch]['median_seconds']['scan']/summary['cuda'][batch]['median_seconds']['scan'] for batch in ('1','8')}
for batch in ('1','8'):
    assert abs(gpu_vs_cpu[batch]-bench['results']['scan']['comparisons'][batch]['cpu_seconds_over_cuda_seconds']) < 1e-12
    for arm in ('serial','scan'):
        assert bench['results'][arm]['comparisons'][batch]['changed_raw_bit_choices'] == {'static':0,'dynamic':0}
audit['timing']['historical_serial_policy'] = 'The earlier serial CPU/GPU measurements used pilot_use=none; keep separate from this matched both-pilot comparison.'
audit['timing']['matched_both_pilot_full_score'] = dict(
    benchmark_sha256=sha(path),script_sha256=sha(script),inputs_matched_to_original=True,
    current_source_hashes_match=True,raw_samples=1120629,blocks=249,projected_modes=49059,
    policy='Both pilots, identical full-envelope projection, models, input captures, validity and fp32 bulk arithmetic; only serial versus affine-scan execution changes.',
    results=summary,scan_GPU_speedup_over_scan_CPU=gpu_vs_cpu,
    scope=bench['scope'],timer_boundary=bench['results']['scan']['scope'],
    comparison_limit='Three warm repetitions only; not sustained timing or a confidence-qualified forecast. CPU/GPU raw bit choices agree within each execution mode. This timing receipt does not retain a direct serial-versus-scan score/admission comparison; campaign replay evidence is a separate follow-up.',
    preparation_seconds={arm:{device:bench['results'][arm]['backends'][device]['preparation_seconds'] for device in ('cpu','cuda')} for arm in ('serial','scan')})
audit['limitations'] = [x for x in audit['limitations'] if x != 'Raw-waveform rescore and independent native binary/source build reconstruction are outside this compact receipt audit.']
audit['limitations'].append('Raw-waveform rescore remains outside this compact receipt audit. Native source/binary binding is supported by the inspected retained source archive and remote byte-identical rebuild receipts; the reviewer did not repeat that build.')
audit['build_timing_addendum'] = dict(status='accepted-with-limits',script_sha256=sha(Path(__file__)),
    prior_cohort_counts_unchanged=True,reproduction='Run audit_v1.py for the original recount, then audit_v1_addendum.py for the new build and matched timing receipts.')
(ROOT/'audit-v1.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(dict(status='accepted-with-limits',scan_speedups=summary,scan_GPU_speedup_over_scan_CPU=gpu_vs_cpu),indent=2))

from pathlib import Path
import json,sys
from functools import partial
import numpy as np,torch
from triad_dynamic_campaign import public_geometry,read_templates,digest
from triad_dynamic_replay import load_batch,timing_benchmark
from triad_dynamic_variants import make_receiver
p=Path(sys.argv[1]);out=Path(sys.argv[2]);protocol=json.loads((p/'protocol.json').read_text());config=protocol['configuration'];config['coherences']=[float(x) for x in config['coherences']];config['pilot_use']='both';torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False;torch.set_float32_matmul_precision('highest')
schedule=[x for x in protocol['trial_schedule'] if x['phase']=='signal'][:8]
m=json.loads((p/'calibration-0000'/'manifest.json').read_text());templates,epochs,receipt=read_templates(p/'calibration-0000',m)
loaded,raw,valid,loading=load_batch(p,schedule,public_geometry(m),8*1024**3)
r={'protocol_sha256':digest(p/'protocol.json'),'inputs':[x[3] for x in loaded],'source_hashes':{n:digest(Path('tools')/n) for n in ['triad_dynamic_joint.py','triad_dynamic_variants.py','triad_dynamic_scan.py','triad_gaussian_prepared.py','triad_gaussian_state.py']},'results':{},'scope':'Same eight actual sampled captures, both-pilot policy; fresh preparation and 3 warm synchronized repetitions; source generation and loading excluded from score timer; no predictive CI bound.'}
for backend in ['serial','scan']:
 r['results'][backend]=timing_benchmark(receiver_factory=partial(make_receiver,execution=backend,projection='full-envelope'),config=config,manifest=m,templates=templates,epochs=epochs,valid=valid,raw=raw,trials=schedule,repeats=3,torch=torch)
for dev in ['cpu','cuda']:
 r.setdefault('scan_speedup',{})[dev]={n:r['results']['serial']['backends'][dev]['measurements'][n]['median_wall_seconds']/r['results']['scan']['backends'][dev]['measurements'][n]['median_wall_seconds'] for n in ['1','8']}
out.write_text(json.dumps(r,indent=2));print(json.dumps(r['scan_speedup']))

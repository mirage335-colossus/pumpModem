#define main triad_export_fixture_main
#include "../../../tools/triad-helper-export.cpp"
#undef main
int main() {
    double maximum=0;
    std::uint64_t checks=0;
    for (const bool gated : {false,true}) for (const auto epoch : {1793850000ULL,1793850001ULL})
    for (const auto high_hz : {2400.,2654.1666666666665}) {
        datapump::helper::Options options; options.power_w=44;options.data_power_w=4;
        options.timecode=false;
        datapump::helper::Plan both_plan{high_hz,.1,.1,44,0,550,gated};
        auto high_plan=both_plan;high_plan.low_frequency_hz=0;
        datapump::helper::Generator both(options,both_plan,epoch), high(options,high_plan,epoch);
        constexpr long double begin=22.25L,end=61.239L;
        for (unsigned i=0;i<10001;++i) {
            const auto t=begin-.01L+(end-begin+.02L)*i/10000;
            const auto actual=public_helper_pilots(both_plan,epoch,t,begin,end);
            maximum=std::max(maximum,std::abs(actual[0]+actual[1]-both.mix_analytic({},t,6000,end,begin)));
            maximum=std::max(maximum,std::abs(actual[0]-high.mix_analytic({},t,6000,end,begin)));
            ++checks;
        }
        for (const auto t : {begin,begin+.001L,begin+.004L,22.4L,22.402L,22.796L,22.798L,22.8L,end-.004L,end-.001L,end}) {
            const auto actual=public_helper_pilots(both_plan,epoch,t,begin,end);
            maximum=std::max(maximum,std::abs(actual[0]+actual[1]-both.mix_analytic({},t,6000,end,begin)));
            ++checks;
        }
    }
    std::cout<<std::setprecision(17)<<"{\"checks\":"<<checks<<",\"maximum_absolute_error\":"<<maximum<<",\"scope\":\"public diagnostic pilot synthesis compared directly with production Generator pilot-only laboratory plans, two epoch parities, two high frequencies, both gating modes and fractional endpoints\"}\n";
    return maximum>1e-14 ? 1 : 0;
}

# Stochastic receiver result draft (independently recounted receipts)

Counts are correct admissions / wrong admissions / misses, followed by DATA-absent admissions out of 32. Each original cohort has 39 calibration, 32 signal and 32 null captures. Source bits are fixed balanced strata (16 each).

## Conditioned original sampled-waveform cohorts

All eight use Rate 36, Added ×10, HF worst margin 3× (90 Hz ray-center separation, 21 ms excess delay), Each 65% stochastic selective modulation, nominal alignment/epoch and oscillator effects off. B is random per-ray Gaussian-spectrum width (2σ), distinct from ray-center separation.

| Cohort | C/N0 dB-Hz | Actual bit duration (s) | B Hz | Static C/W/M; null | Dynamic C/W/M; null |
|---|---:|---:|---:|---|---|
| helper0 | 0 | 23.2 | 0.5 | 5/1/26; 0/32 | 32/0/0; 0/32 |
| helper8 | 8 | 23.2 | 0.5 | 23/1/8; 6/32 | 32/0/0; 4/32 |
| motion-helper-minus6 | -6 | 69.6 | 0.5 | 3/0/29; 0/32 | 28/1/3; 1/32 |
| motion-nohelper-minus6 | -6 | 69.6 | 0.5 | 4/1/27; 5/32 | 10/2/20; 4/32 |
| nohelper0 | 0 | 23.2 | 0.5 | 3/0/29; 0/32 | 26/1/5; 3/32 |
| nohelper8 | 8 | 23.2 | 0.5 | 20/0/12; 0/32 | 32/0/0; 4/32 |
| wide-highpilot8 | 8 | 23.2 | 5 | 2/0/30; 1/32 | 32/0/0; 1/32 |
| wide-nohelper8 | 8 | 23.2 | 5 | 2/3/27; 1/32 | 30/0/2; 1/32 |

The duration column excludes the Helper lead and channel/filter tails and is not received DATA energy. Helper-enabled cohorts use both pilots except wide-highpilot8, which uses only the high pilot. The moving −6 dB-Hz pair additionally uses 0.001 ms bounded delay excursion over 100-second knots. Helper-on/off uses paired channel/noise seeds and identical emitted DATA energy. These comparisons do not isolate any single implementation loss, and the different C/N0/duration/key cohorts are not a calibrated sensitivity curve.

## Same-I/Q pilot ablations (exploratory)

All retain transmitted Helper emissions; none/low/high names describe receiver pilot use. They reuse original calibration and held-out captures with new policy-specific gates, so they are not independent validation.

| Replay | Static C/W/M; null | Dynamic C/W/M; null |
|---|---|---|
| helper0-replay-high | 10/1/21; 1/32 | 31/0/1; 0/32 |
| helper0-replay-low | 10/1/21; 0/32 | 31/0/1; 3/32 |
| helper0-replay-none | 3/0/29; 0/32 | 27/0/5; 3/32 |
| helper8-replay-high | 17/1/14; 5/32 | 32/0/0; 2/32 |
| helper8-replay-low | 24/1/7; 6/32 | 32/0/0; 4/32 |
| helper8-replay-none | 20/0/12; 1/32 | 32/0/0; 4/32 |

## Same-I/Q affine-scan arithmetic qualification

| Replay | Static C/W/M; null | Dynamic C/W/M; null | Maximum hypothesis-evidence change |
|---|---|---|---:|
| helper0-scan | 5/1/26; 0/32 | 32/0/0; 0/32 | 0.000116993 |
| wide-nohelper8-scan | 2/3/27; 1/32 | 30/0/2; 1/32 | 8.95485e-06 |

Every raw bit choice, calibration score ordering, held-out rank p-value and admission matches the corresponding serial campaign on all 206 receipts. No new sensitivity trials were generated.

## Blind timing/epoch failure (additional independent seeds)

At +8 dB-Hz, Fs 6000 and otherwise the declared stochastic HF fixture, the 533-candidate bank produced static 1/0/31; 3/32, dynamic 3/2/27; 2/32. Dynamic raw bit errors were 15/32. This is a failure, with cause under separate investigation. The 41 timings span −55.5 to 125.5 ms at 4.525 ms spacing; 13 epochs are searched but the emitted epoch remains nominal. All 103 randomized arrivals lie inside the prior, with maximum nearest-grid mismatch 2.255 ms. CFO and sample-clock searches remain fixed 0 with oscillators off.

Complete driver wall 158.53 s includes native generation 13.56 s, loading/hashing 1.23 s and receiver call 143.38 s. Inside the receiver, tile preparation 120.90 s dominates correlation 21.47 s and state processing 0.824 s. These figures are not interchangeable with retained-input score-only timing.

## Uncertainty and benchmark boundaries

- Gates use 39 null calibration captures and rank steps 0.025 at nominal marginal alpha 0.05. They do not establish fixed-gate conditional 5%, simultaneous error control, wrong-bit probability or daily false-admission targets.
- Signal confidence intervals condition on the frozen gate and independent representative seeds within fixed bit strata. The implemented 95% balanced-population interval is [76.04%, 100%] for 32/32. A zero-of-32 null result has 95% one-sided upper 8.94%. Intervals are pointwise, not simultaneous across all cohorts/arms. Do not pool paired conditions or reused replay captures as independent evidence.
- Outcome-selected full-known-mean oracles decode two failed noHelper captures (plus their Helper pairs) with conditional error probabilities 1.10e-5 and 8.76e-4. These are realized-channel bounds with perfect means, not achievable unknown-channel/admission performance or population estimates.
- Matched both-pilot full-score timing on the same eight captures gives serial→scan CPU 2.99× single / 2.34× batch eight and GPU 7.36× / 4.52×. Optimized GPU over optimized CPU is 1.19× / 1.09×. Timers include raw transfer, correlation and state scoring, exclude preparation/loading/generation, and use three warm repeats. They provide neither sustained qualification nor predictive confidence bounds.
- The synthetic 231× measurement compares GPU scan versus GPU serial state processing at 10,000 blocks; it is not a whole-receiver or CPU/GPU speedup. Earlier no-pilot serial timings use a different policy and must remain separate.
- Compact audits verify retained evidence/protocol/hash relationships and arithmetic; raw waveform bytes are absent locally. The v1 binary/source relationship is supported by frozen native-source archives and remote byte-identical rebuild receipts.

References: audit-v1.json, audit-v2.json, build-provenance/, benchmark/paired-score-benchmark.json. This scratch draft is not a maintained qualification declaration.

#!/usr/bin/env python3
"""Post-outcome complete-channel oracle; never an input to the practical receiver.

Select the first dynamic wrong admission and first miss in nohelper0, in frozen
schedule order, and the same two signal IDs in helper0. Reexport bit0, bit1 and
DATA-off with the exact original channel/Helper/calendar at C/N0=200 dB-Hz.
The original noisy captures MUST be retained. No retry or extra cases occur.

Run on the campaign host, for example:
  OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python diagnose_failures.py \
    --campaign-root /workspace/stochastic-results \
    --exporter /workspace/pumpModem/build/dev-cli/triad_helper_export \
    --output /workspace/stochastic-oracle
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np


CONTROL_CN0 = 200.0
CNO_FIELDS = {'data_cn0_db_hz', 'effective_helper_cn0_db_hz',
              'complex_noise_variance', 'cn0_override'}
PHYSICAL_FIELDS = ('source_epoch_offset_seconds', 'arrival_seconds',
                   'arrival_override', 'unmodified_arrival_draw_seconds',
                   'tx', 'rx', 'random_seed_roots')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def identity_without_noise(manifest):
    ignored = {'cost', 'templates', 'data_enabled'}
    result = {k: v for k, v in manifest.items() if k not in ignored}
    for key in ('power', 'physics'):
        result[key] = {k: v for k, v in result[key].items() if k not in CNO_FIELDS}
    return result


def capture(folder):
    folder = Path(folder)
    manifest = load_json(folder / 'manifest.json')
    truth_path = folder / manifest['evaluator_truth_file']
    truth = load_json(truth_path)
    shape = tuple(manifest['observation']['shape'])
    if len(shape) != 1 or shape[0] < 1 or manifest['observation']['dtype'] != '<c16':
        raise ValueError('one nonempty little-endian complex128 capture required')
    raw_path = folder / manifest['observation']['file']
    mask_path = folder / manifest['validity']['file']
    if raw_path.stat().st_size != 16 * shape[0] or mask_path.stat().st_size != shape[0]:
        raise ValueError('capture/validity byte count does not match the manifest')
    valid = np.memmap(mask_path, dtype='u1', mode='r', shape=shape)
    if not np.all(valid == 1):
        raise ValueError('this bounded oracle requires all raw observations, without erasures')
    raw = np.memmap(raw_path, dtype='<c16', mode='r', shape=shape)
    receipt = dict(folder=str(folder), observation_sha256=sha(raw_path),
                   validity_sha256=sha(mask_path), manifest_sha256=sha(folder / 'manifest.json'),
                   evaluator_truth_sha256=sha(truth_path), samples=shape[0])
    return manifest, truth, raw, receipt


def selected_rows(campaign_root):
    conditions = {}
    for condition in ('nohelper0', 'helper0'):
        folder = campaign_root / condition
        protocol = load_json(folder / 'protocol.json')
        summary = load_json(folder / 'summary.json')
        rows = [json.loads(line) for line in (folder / 'trials.jsonl').read_text().splitlines() if line]
        if summary['completed_trials'] != len(protocol['trial_schedule']) or len(rows) != summary['completed_trials']:
            raise ValueError('selection requires a complete frozen campaign: ' + condition)
        if [r['trial'] for r in rows] != protocol['trial_schedule']:
            raise ValueError('result order differs from the frozen schedule: ' + condition)
        conditions[condition] = (folder, protocol, {r['trial']['id']: r for r in rows})
    first = conditions['nohelper0']
    picks = []
    for category in ('wrong_admission', 'miss'):
        for trial in first[1]['trial_schedule']:
            if trial['phase'] != 'signal':
                continue
            row = first[2][trial['id']]
            decision = row['decisions']['dynamic']
            qualifies = (decision['accepted'] and decision['bit'] != row['evaluator']['source_bit']) \
                if category == 'wrong_admission' else not decision['accepted']
            if qualifies:
                picks.append((category, trial['id']))
                break
        else:
            raise ValueError('requested first ' + category + ' does not exist in nohelper0')
    selected = []
    for category, trial_id in picks:
        reference = first[2][trial_id]
        for condition, (folder, protocol, rows) in conditions.items():
            row = rows[trial_id]
            if row['trial'] != reference['trial'] or row['evaluator']['source_bit'] != reference['evaluator']['source_bit']:
                raise ValueError('paired conditions differ in scheduled seed/source: ' + trial_id)
            selected.append(dict(category=category, condition=condition, folder=folder,
                                 protocol=protocol, result=row))
    return selected, conditions


def clean_command(original, exporter, output, bit, data):
    # Exact campaign argument vector, no shell. Only the requested controls and
    # template export are replaced; Helper and every channel argument are kept.
    args, i = [], 1
    while i < len(original):
        flag = original[i]
        if flag == '--templates':
            i += 1
        elif flag in ('--output', '--cn0', '--bit', '--data'):
            if i + 1 == len(original):
                raise ValueError('incomplete original export argument: ' + flag)
            i += 2
        elif any(flag.startswith(k + '=') for k in ('--output', '--cn0', '--bit', '--data', '--templates')):
            raise ValueError('unexpected equals-form controlled campaign option')
        else:
            args.append(flag)
            i += 1
    return [str(exporter), *args, '--output', str(output), '--cn0', str(CONTROL_CN0),
            '--bit', str(bit), '--data', 'on' if data else 'off']


def oracle_metrics(y, z0, z1, zh, variance, control_variance, bit, fs):
    alpha = math.sqrt(control_variance / variance)
    if not 0 < alpha < 1e-6:
        raise ValueError('control noise is not negligible at the selected C/N0')
    difference = np.asarray(z0) - z1  # Shared tiny control noise cancels.
    distance = float(np.vdot(difference, difference).real)
    direct_residual = np.asarray(y) - (z0 if bit == 0 else z1)
    # The native teacher adds sqrt(variance) times the same seeded CN sequence
    # after propagation. Only this evaluator oracle uses the true source bit.
    noise = direct_residual / (1 - alpha)
    projection = float(np.vdot(difference, noise).real)
    direct_projection = float(np.vdot(difference, direct_residual).real)
    sign = 1 - 2 * bit
    llr_direct = (sign * distance + 2 * direct_projection) / variance
    llr_corrected = (sign * distance + 2 * projection) / variance
    corrected_means = [np.asarray(z) - alpha * noise for z in (z0, z1, zh)]
    data_energy = [float(np.vdot(np.asarray(z) - zh, np.asarray(z) - zh).real) / fs
                   for z in (z0, z1)]
    noise_energy = float(np.vdot(noise, noise).real)
    mean_energies = [float(np.vdot(z, z).real) for z in corrected_means]
    control_noise_energy = alpha * alpha * noise_energy
    selected = 0 if llr_corrected > 0 else 1 if llr_corrected < 0 else None
    return dict(samples=len(y), sample_rate_hz=fs, true_bit=bit,
        raw_complex_noise_variance=variance, control_complex_noise_variance=control_variance,
        control_noise_amplitude_ratio=alpha,
        distance_squared_samples=distance, distance_over_noise_variance=distance / variance,
        conditional_equal_prior_general_mean_bit_error_probability=.5 * math.erfc(math.sqrt(distance / (4 * variance))),
        direct_negligible_control_noise_log_likelihood_bit0_minus_bit1=llr_direct,
        shared_noise_corrected_log_likelihood_bit0_minus_bit1=llr_corrected,
        shared_noise_correction_delta_llr=llr_corrected - llr_direct,
        shared_noise_corrected_oracle_bit=selected,
        shared_noise_corrected_oracle_correct=selected == bit,
        received_data_energy_seconds_by_bit=data_energy,
        corrected_composite_mean_energy_samples_by_bit_and_helper_only=mean_energies,
        recovered_noise_energy_samples=noise_energy,
        recovered_noise_energy_over_expectation=noise_energy / (len(y) * variance),
        residual_control_noise_energy_samples=control_noise_energy,
        residual_control_noise_to_data_energy_ratio_by_bit=[control_noise_energy / (e * fs) for e in data_energy],
        complete_raw_capture_and_channel_filter_tails_retained=True)


def self_test():
    rng = np.random.default_rng(712001)
    noise = rng.normal(size=64) + 1j * rng.normal(size=64)
    means = [rng.normal(size=64) + 1j * rng.normal(size=64) for _ in range(3)]
    variance, alpha, fs = 2., 1e-10, 10.
    for bit in (0, 1):
        y = means[bit] + noise
        controls = [m + alpha * noise for m in means]
        result = oracle_metrics(y, *controls, variance, variance * alpha**2, bit, fs)
        exact = (np.vdot(y-means[1], y-means[1]).real -
                 np.vdot(y-means[0], y-means[0]).real) / variance
        assert abs(result['shared_noise_corrected_log_likelihood_bit0_minus_bit1'] - exact) < 1e-12
        assert np.allclose(result['corrected_composite_mean_energy_samples_by_bit_and_helper_only'],
                           [np.vdot(m, m).real for m in means], rtol=1e-14)
    assert clean_command(['old', '--case', 'hf', '--cn0', '0', '--helper', 'on',
                          '--templates', '--output', 'old-output', '--bit', '1', '--data', 'on'],
                         Path('/exe'), Path('/new'), 0, False) == [
                             '/exe', '--case', 'hf', '--helper', 'on', '--output', '/new',
                             '--cn0', '200.0', '--bit', '0', '--data', 'off']
    print('oracle arithmetic and command-preservation self-tests passed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign-root', type=Path)
    parser.add_argument('--exporter', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if any(getattr(args, k) is None for k in ('campaign_root', 'exporter', 'output')):
        parser.error('--campaign-root, --exporter and --output are required')
    exporter = args.exporter.resolve(strict=True)
    root = args.campaign_root.resolve(strict=True)
    selected, conditions = selected_rows(root)
    binary_hash = sha(exporter)
    if any(p['exporter_sha256'] != binary_hash for _, p, _ in conditions.values()):
        raise ValueError('exporter differs from the frozen campaign binary')
    if conditions['nohelper0'][1]['source_hashes'] != conditions['helper0'][1]['source_hashes']:
        raise ValueError('paired campaigns were not frozen to the same source identities')
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    protocol = dict(schema='triad-stochastic-failure-oracle-protocol-v1',
        selection='Post-outcome first dynamic wrong admission and first miss in nohelper0 schedule order, each paired with helper0; diagnostic, not held-out validation.',
        exporter_sha256=binary_hash, script_sha256=sha(__file__), python=sys.version,
        numpy_version=np.__version__, control_cn0_db_hz=CONTROL_CN0,
        campaign_protocols={name: dict(sha256=sha(folder / 'protocol.json'), protocol=p,
                                     trials_sha256=sha(folder / 'trials.jsonl'), summary_sha256=sha(folder / 'summary.json'))
                            for name, (folder, p, _) in conditions.items()},
        selected=[dict(category=s['category'], condition=s['condition'], result=s['result']) for s in selected],
        scope='Genie-known complete complex channel, synchronization, oscillator and both bit means; equal priors, raw white CN thermal noise. No clean truth is sent to any practical receiver. This oracle does not implement an achievable unknown-channel detector or operational presence/admission gate.',
        formulas=dict(distance='d2 = ||mu0-mu1||^2; exact equal-prior general-mean Pe = Q(sqrt(d2/(2*variance)))',
            data_energy='||mu_b-mu_helper_only||^2/Fs; shared C/N0=200 control noise cancels in this subtraction',
            noise_correction='alpha=sqrt(control_variance/actual_variance); n=(actual_y-clean_export_true_bit)/(1-alpha); mu_b=clean_export_b-alpha*n. Requires the unchanged post-channel seeded white noise law; evaluator truth bit used only here.'),
        limitations=['Selected after receiver outcomes, not independent validation or a population confidence claim.',
            'Known Helper mean cancels bit-independently; this does not demonstrate practical pilot phase transfer.',
            'Full raw timespan differs from the practical receiver observation projection/apertures.',
            'Native/source provenance is inherited from frozen campaign protocols; matching binary hash is required.',
            'Pe is conditional on each realized complete channel and two known means; no presence-search or model uncertainty is included.'])
    save(args.output / 'protocol.json', protocol)
    results = []
    paired_identities = {}
    env = dict(os.environ, OPENBLAS_NUM_THREADS='2', OMP_NUM_THREADS='2')
    try:
        for selection in selected:
            condition, original = selection['condition'], selection['result']
            trial = original['trial']
            folder = selection['folder'] / trial['id']
            m, t, raw, original_receipt = capture(folder)
            if original_receipt['observation_sha256'] != original['input_sha256'] or \
                    original_receipt['manifest_sha256'] != original['manifest_sha256'] or \
                    original_receipt['evaluator_truth_sha256'] != original['evaluator']['truth_sha256']:
                raise ValueError('original capture is not the scored campaign input')
            if original_receipt['validity_sha256'] != original['validity_sha256']:
                raise ValueError('original scored validity differs')
            if abs(m['power']['data_cn0_db_hz']) > 1e-12 or not m['data_enabled'] or \
                    m['helper_enabled'] != (condition == 'helper0'):
                raise ValueError('selected condition is not the declared 0 dB-Hz signal/Helper condition')
            if m['channel']['channel_evolution'] != 'fixed-time-gaussian-v1':
                raise ValueError('selected observation is not the stochastic channel law')
            if t['source_bit'] != trial['bit'] or t['random_seed_roots']['fixture'] != trial['seed']:
                raise ValueError('actual source bit or seed differs from the frozen trial')
            paired_manifest = identity_without_noise(m)
            paired_manifest.pop('helper_enabled')
            pair_identity = dict(manifest=paired_manifest,
                                 physical={k: t[k] for k in PHYSICAL_FIELDS},
                                 source_bit=t['source_bit'],
                                 emitted_data_energy_samples=t['source_energy']['data_energy_samples'])
            if trial['id'] in paired_identities and paired_identities[trial['id']] != pair_identity:
                raise ValueError('paired Helper setting changes DATA source/channel/calendar realization')
            paired_identities[trial['id']] = pair_identity
            target = args.output / (condition + '-' + trial['id'])
            target.mkdir()
            controls, receipts, reports = [], [], []
            for label, bit, data in (('bit0', 0, True), ('bit1', 1, True), ('helper-only', trial['bit'], False)):
                destination = target / label
                command = clean_command(original['export_command'], exporter, destination, bit, data)
                if sha(exporter) != binary_hash:
                    raise ValueError('exporter changed before native control')
                mark = time.perf_counter()
                with (target / (label + '.log')).open('x') as stream:
                    subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env=env,
                                   check=True, timeout=600)
                wall = time.perf_counter() - mark
                cm, ct, control, receipt = capture(destination)
                if identity_without_noise(cm) != identity_without_noise(m):
                    raise ValueError('control changes source/calibration/physical/calendar geometry: ' + label)
                if cm['data_enabled'] != data or ct['source_bit'] != bit or cm['power']['data_cn0_db_hz'] != CONTROL_CN0:
                    raise ValueError('control bit/DATA/CN0 differs: ' + label)
                for field in PHYSICAL_FIELDS:
                    if ct[field] != t[field]:
                        raise ValueError('control changes physical realization: ' + field)
                if ct['source_energy']['helper_energy_samples'] != t['source_energy']['helper_energy_samples']:
                    raise ValueError('Helper source waveform/power changes in control')
                if data and bit == trial['bit'] and ct['source_energy'] != t['source_energy']:
                    raise ValueError('true-bit control changes emitted source energy')
                if not data and ct['source_energy']['data_energy_samples'] != 0:
                    raise ValueError('DATA-off control has source DATA energy')
                receipt.update(command=command, export_wall_seconds=wall)
                save(target / (label + '-receipt.json'), receipt)
                controls.append(control)
                receipts.append(receipt)
                reports.append(ct['channel_report']['signal_energy_samples'])
            mark = time.perf_counter()
            variance = m['power']['complex_noise_variance']
            control_variance = m['sample_rate_hz'] / 10**(CONTROL_CN0 / 10)
            for receipt in receipts:
                cm = load_json(Path(receipt['folder']) / 'manifest.json')
                if cm['power']['complex_noise_variance'] != control_variance:
                    raise ValueError('clean variance differs from native post-channel noise scaling')
            metrics = oracle_metrics(raw, *controls, variance, control_variance, trial['bit'], m['sample_rate_hz'])
            reconstructed = metrics['corrected_composite_mean_energy_samples_by_bit_and_helper_only']
            energy_errors = [a-b for a, b in zip(reconstructed, reports)]
            if any(abs(a-b) > 2e-7 * max(1., abs(b)) for a, b in zip(reconstructed, reports)):
                raise ValueError('shared-noise corrected mean energy disagrees with native pre-noise report')
            row = dict(condition=condition, selection_category=selection['category'], trial=trial,
                practical={arm: dict(ranking=original[arm], decision=original['decisions'][arm])
                           for arm in ('static', 'dynamic')},
                actual_public_manifest=m, actual_physical_truth=t,
                original_capture=original_receipt, control_receipts=receipts,
                source_gain_and_calendar_and_physical_identity_verified=True,
                oracle=metrics, native_clean_energy_samples_by_bit_and_helper_only=reports,
                reconstructed_minus_native_mean_energy_samples=energy_errors,
                analysis_wall_seconds=time.perf_counter()-mark)
            save(target / 'oracle.json', row)
            results.append(row)
            print(json.dumps(dict(condition=condition, trial=trial['id'], category=selection['category'],
                  practical_dynamic=original['decisions']['dynamic'], oracle=metrics)), flush=True)
        if sha(exporter) != binary_hash:
            raise ValueError('native binary changed during controls')
        save(args.output / 'summary.json', dict(schema='triad-stochastic-failure-oracle-summary-v1',
             protocol_sha256=sha(args.output / 'protocol.json'), exporter_sha256=binary_hash,
             rows=results, wall_seconds=time.perf_counter()-started,
             native_export_sum_seconds=sum(r['export_wall_seconds'] for row in results for r in row['control_receipts']),
             conclusion_scope='The oracle separates known-complete-channel energy/noise discrimination from practical inference/acquisition on these exact selected failures. It does not by itself identify a practical receiver defect or its cause.'))
    except Exception as error:
        save(args.output / 'failure.json', dict(type=type(error).__name__, error=str(error),
             completed_cases=len(results), wall_seconds=time.perf_counter()-started,
             automatic_retry=False))
        raise


if __name__ == '__main__':
    main()

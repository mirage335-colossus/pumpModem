"""Tiny synthetic protocol test; no native captures and no receiver claim."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('oracle', HERE / 'diagnose_failures.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)


def dump(path, value):
    path.write_text(json.dumps(value))


with tempfile.TemporaryDirectory(prefix='synthetic-', dir=HERE) as temporary:
    base = Path(temporary)
    native = base / 'fake_exporter'
    native.write_text('''#!''' + sys.executable + '''
import argparse,copy,json,math
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('--output',type=Path,required=True)
p.add_argument('--seed',type=int,required=True)
p.add_argument('--bit',type=int,required=True)
p.add_argument('--data',choices=('on','off'),required=True)
p.add_argument('--helper',choices=('on','off'),required=True)
p.add_argument('--cn0',type=float,required=True)
a=p.parse_args();a.output.mkdir()
template=json.loads((Path(__file__).parent/'base.json').read_text())
m,t=template['manifest'],template['truth'];fs=m['sample_rate_hz'];n=64
m['data_enabled']=a.data=='on';m['helper_enabled']=a.helper=='on'
v=fs/10**(a.cn0/10)
for k in ('power','physics'):
 m[k]['data_cn0_db_hz']=a.cn0;m[k]['effective_helper_cn0_db_hz']=a.cn0+10
m['power']['complex_noise_variance']=v;m['power']['cn0_override']=True
t['source_bit']=a.bit;t['random_seed_roots']['fixture']=a.seed
x=np.arange(n);bits=[np.exp(.11j*x),np.exp(.29j*x)]
h=.7*np.exp(.03j*x) if m['helper_enabled'] else np.zeros(n,complex)
data=bits[a.bit] if m['data_enabled'] else np.zeros(n,complex)
mean=h+data;rng=np.random.default_rng(a.seed)
y=mean+math.sqrt(v/2)*(rng.normal(size=n)+1j*rng.normal(size=n))
t['source_energy']={'rows':n,'data_energy_samples':float(np.vdot(data,data).real),'helper_energy_samples':float(np.vdot(h,h).real),'composite_energy_samples':float(np.vdot(mean,mean).real)}
t['channel_report']['signal_energy_samples']=float(np.vdot(mean,mean).real)
y.astype('<c16').tofile(a.output/'observation.c128');np.ones(n,'u1').tofile(a.output/'validity.u8')
(a.output/'manifest.json').write_text(json.dumps(m));(a.output/'evaluator-truth.json').write_text(json.dumps(t))
''')
    native.chmod(0o755)
    pilot = HERE.parents[0] / 'pilot/nohelper'
    m = json.loads((pilot / 'manifest.json').read_text())
    t = json.loads((pilot / 'evaluator-truth.json').read_text())
    m['observation']['shape'] = m['validity']['shape'] = [64]
    m['calendar']['capture_samples'] = 64
    m['templates'] = {'enabled': False}
    dump(base / 'base.json', dict(manifest=m, truth=t))
    campaign = base / 'campaign'
    schedule = [dict(id=f'signal-{i:04d}', phase='signal', seed=99100+i, bit=i, data=True)
                for i in range(2)]
    env = dict(os.environ, OPENBLAS_NUM_THREADS='2', OMP_NUM_THREADS='2')
    for condition in ('nohelper0', 'helper0'):
        folder = campaign / condition
        folder.mkdir(parents=True)
        rows = []
        for i, trial in enumerate(schedule):
            dest = folder / trial['id']
            command = [str(native), '--output', str(dest), '--seed', str(trial['seed']),
                '--bit', str(trial['bit']), '--data', 'on', '--cn0', '0',
                '--helper', 'on' if condition == 'helper0' else 'off']
            subprocess.run(command, check=True, env=env)
            _, truth, _, receipt = oracle.capture(dest)
            decision = dict(accepted=i == 0, bit=1-trial['bit'])
            rows.append(dict(trial=trial, decisions={'dynamic': decision, 'static': decision},
                dynamic=dict(bit=1-trial['bit']), static=dict(bit=1-trial['bit']),
                evaluator=dict(source_bit=trial['bit'], truth_sha256=receipt['evaluator_truth_sha256']),
                export_command=command, input_sha256=receipt['observation_sha256'],
                manifest_sha256=receipt['manifest_sha256'], validity_sha256=receipt['validity_sha256']))
        dump(folder / 'protocol.json', dict(trial_schedule=schedule, exporter_sha256=oracle.sha(native),
                                           source_hashes={'synthetic': 'not-native-evidence'}))
        dump(folder / 'summary.json', dict(completed_trials=len(rows)))
        (folder / 'trials.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    output = base / 'diagnostic'
    result = subprocess.run([sys.executable, str(HERE/'diagnose_failures.py'), '--campaign-root',
        str(campaign), '--exporter', str(native), '--output', str(output)],
        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        raise AssertionError(result.stdout)
    summary = oracle.load_json(output / 'summary.json')
    assert len(summary['rows']) == 4
    assert sum(len(r['control_receipts']) for r in summary['rows']) == 12
    assert max(abs(x) for r in summary['rows'] for x in r['reconstructed_minus_native_mean_energy_samples']) < 1e-10
    # These setup errors must be rejected before generating any extra controls.
    changed = campaign / 'helper0/signal-0000/manifest.json'
    original = changed.read_text();bad = json.loads(original);bad['calendar']['capture_samples'] += 1
    changed.write_text(json.dumps(bad))
    rejected = subprocess.run([sys.executable, str(HERE/'diagnose_failures.py'), '--campaign-root',
        str(campaign), '--exporter', str(native), '--output', str(base/'changed-manifest')],
        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert rejected.returncode != 0 and 'not the scored campaign input' in rejected.stdout
    changed.write_text(original)
    print('Synthetic end-to-end: 4 selected cases, exactly 12 fake controls, metadata mismatch rejected; no native simulation run.')

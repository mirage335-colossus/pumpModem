#!/usr/bin/env python3
"""One-off complete533-candidate DATA-only replay of retained Helper captures.

Physical Helper remains in every capture. Only the receiver's use of pilot
phase is removed; its public projection excludes the pilots and auxiliary.
All original calibration/held-out observations and candidate weights remain.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import numpy as np
import torch
from triad_dynamic_acquire import TiledAcquisition
from triad_dynamic_campaign import (ARMS, _jsonable, decide, digest, evaluator_metrics,
    freeze_gate, identity, load_capture, outcomes, paired_arms, paired_outcomes,
    public_geometry, read_templates, source_hashes, write_json)
from triad_dynamic_replay import previous_comparison


def hashes():
    names = ['tools/triad_dynamic_acquire.py', 'tools/triad_dynamic_variants.py',
             'tools/triad_dynamic_scan.py', 'tools/triad_dynamic_replay.py',
             'local-evidence/triad-stochastic/acquisition/replay_none.py']
    return source_hashes() | {name: digest(ROOT/name) for name in names}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--campaign', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device', default='cuda')
    p.add_argument('--precision', choices=('fp32', 'fp64'), default='fp32')
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--trial-batch-size', type=int, default=103)
    p.add_argument('--memory-limit-bytes', type=int, default=8*1024**3)
    args = p.parse_args()
    if args.output.exists() or min(args.threads, args.trial_batch_size, args.memory_limit_bytes) < 1:
        p.error('fresh output and positive resource limits required')
    started = time.perf_counter()
    original_protocol = json.loads((args.campaign/'protocol.json').read_text())
    planned = json.loads((args.campaign/'planned.json').read_text())['policy']
    trials = original_protocol['trial_schedule']
    if (len(trials) != 103 or sum(t['phase']=='calibration' for t in trials) != 39 or
            planned['total_candidates'] != 533):
        p.error('this bounded recipe requires original103 captures and533 candidate bank')
    args.output.mkdir(parents=True)
    sources = hashes()
    write_json(args.output/'protocol.json', dict(schema='triad-acquisition-pilot-none-replay-v1',
        original_protocol_sha256=digest(args.campaign/'protocol.json'),
        original_planned_sha256=digest(args.campaign/'planned.json'),
        original_summary_sha256=digest(args.campaign/'summary.json'), source_hashes=sources,
        trial_schedule=trials, pilot_use='none', alpha=original_protocol['alpha'],
        configuration={key:str(value) if isinstance(value,Path) else value for key,value in vars(args).items()},
        scope='Paired exploratory replay on original captures; no new independent validation. '
              'Full native Helper remains. Fixed public533-candidate prior is unchanged. '
              'Separate rank gates are recalibrated on the same39 original calibration captures.',
        read_order='Original evaluator/results opened only after all replay scores and gate are frozen.'))
    rows, previous_rows, current = [], {}, 'loading-public-inputs'
    try:
        m, first_raw, first_valid, _ = load_capture(args.campaign/trials[0]['id'])
        geometry = public_geometry(m)
        source, epochs, source_receipt = read_templates(args.campaign/trials[0]['id'], m)
        if source_receipt['template_sha256'] != planned['template_sha256']:
            raise ValueError('source template hash differs from original acquisition')
        if len(trials)*first_raw.size*16+source.nbytes+first_valid.nbytes >= args.memory_limit_bytes:
            raise MemoryError('public input arrays exhaust declared memory budget')
        raw = np.empty((len(trials),first_raw.size),np.complex128)
        valid = np.asarray(first_valid,bool).copy()
        receipts, manifests = [], []
        for index, trial in enumerate(trials):
            manifest, samples, mask, receipt = load_capture(args.campaign/trial['id'],geometry)
            if not np.array_equal(valid,np.asarray(mask,bool)):
                raise ValueError('public validity masks differ')
            raw[index] = samples
            manifests.append(manifest); receipts.append(receipt)
        loading_seconds = time.perf_counter()-started
        torch.set_num_threads(args.threads)
        torch.set_float32_matmul_precision('highest')
        torch.backends.cuda.matmul.allow_tf32=False
        coherences = tuple(float(value) for value in planned['coherences'])
        receiver = TiledAcquisition(m,source,epochs,selected_epochs=planned['selected_epochs'],
            arrival_seconds=planned['arrival_seconds'],frequencies_hz=planned['frequencies_hz'],
            clock_ppm=planned['clock_ppm'],timing_tile_size=planned['timing_tile_size'],
            block_seconds=planned['block_seconds'],coherence_seconds=coherences,
            pilot_use='none',execution='scan',projection=planned['projection'],
            device=args.device,precision=args.precision,memory_limit_bytes=args.memory_limit_bytes)
        write_json(args.output/'planned.json',dict(procedure_id=receiver.procedure_id,policy=receiver.policy,
            planning_seconds=receiver.planning_seconds))
        def progress(tile):
            with (args.output/'tiles.jsonl').open('a') as stream:
                stream.write(json.dumps(tile,allow_nan=False)+'\n')
            print(json.dumps(dict(stage='tile',index=tile['index'],total=receiver.tile_count,
                preparation_seconds=tile['preparation_seconds'],score_seconds=tile['score_wall_seconds'])),flush=True)
        current='scoring-all-public-observations'
        result=_jsonable(receiver.score(raw,valid,trial_batch_size=args.trial_batch_size,progress=progress))
        write_json(args.output/'receiver.json',result)
        procedure_id=result['procedure_id']
        condition_id=identity(dict(procedure_id=procedure_id,public_geometry=geometry))
        arms=paired_arms(result['hypothesis_log_evidence'],coherences)
        for index,(trial,scored,receipt) in enumerate(zip(trials,arms,receipts)):
            rows.append(dict(trial=trial,procedure_id=procedure_id,condition_id=condition_id,**scored,**receipt,
                model_bit_scores=np.asarray(result['model_bit_scores'])[:,index,:].tolist(),
                hypothesis_log_evidence=np.asarray(result['hypothesis_log_evidence'])[:,index,:].tolist()))
        gate=freeze_gate(rows[:39],procedure_id,condition_id,original_protocol['alpha'])
        write_json(args.output/'gate.json',gate)
        current='evaluator-and-paired-outcome-accounting'
        for row,manifest in zip(rows,manifests):
            trial=row['trial']; folder=args.campaign/trial['id']
            if trial['phase']!='calibration':
                row['decisions']={arm:decide(row,gate,arm) for arm in ARMS}
            previous=json.loads((folder/'result.json').read_text())
            for name in ('input_sha256','manifest_sha256','validity_sha256'):
                if row[name]!=previous[name]:
                    raise ValueError('retained capture hash differs from original: '+name)
            row['evaluator']=evaluator_metrics(folder,manifest)
            if row['evaluator']['truth_sha256']!=previous['evaluator']['truth_sha256']:
                raise ValueError('retained evaluator truth changed')
            previous_rows[trial['id']]=previous
            write_json(args.output/(trial['id']+'.json'),row)
            with (args.output/'trials.jsonl').open('a') as stream:
                stream.write(json.dumps(row,allow_nan=False)+'\n')
        if hashes()!=sources:
            raise ValueError('implementation changed during replay')
        summary=dict(schema='triad-acquisition-pilot-none-replay-summary-v1',completed_trials=len(rows),
            procedure_id=procedure_id,condition_id=condition_id,
            outcomes={arm:outcomes(rows,arm) for arm in ARMS},paired=paired_outcomes(rows),
            compared_with_original={arm:previous_comparison(rows,previous_rows,arm) for arm in ARMS},
            work=result['work'],timing=dict(input_loading_hash_seconds=loading_seconds,
                receiver=result['timing'],complete_wall_seconds=time.perf_counter()-started),
            protocol_sha256=digest(args.output/'protocol.json'),gate_sha256=digest(args.output/'gate.json'),
            limitations=['Paired exploratory replay, not independent new validation.',
                'Native Helper remains present; receiver deliberately uses only DATA-band observations.',
                'Same continuous random arrivals, nominal actual epoch and complete finite533-candidate bank.',
                'Oscillator effects disabled; not full oscillator acquisition.',
                'Marginal per-capture5% rank gate, not operational daily false-admission qualification.'])
        write_json(args.output/'summary.json',summary)
        print(json.dumps(dict(stage='complete',outcomes=summary['outcomes']),allow_nan=False),flush=True)
    except Exception as error:
        write_json(args.output/'failure.json',dict(stage=current,error_type=type(error).__name__,
            error=str(error),wall_seconds=time.perf_counter()-started,automatic_retry=False))
        raise


if __name__=='__main__':
    main()

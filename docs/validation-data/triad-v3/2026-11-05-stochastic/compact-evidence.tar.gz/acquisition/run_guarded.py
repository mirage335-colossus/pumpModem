#!/usr/bin/env python3
"""Frozen, one-off sampled timing/epoch acquisition qualification.

This recipe deliberately retains fresh random native arrivals and searches all
13 public epochs. Oscillator errors are disabled explicitly; CFO and sample
clock are fixed at zero. It is not full oscillator-acquisition qualification.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import math
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))

import numpy as np
import torch

from triad_dynamic_acquire import TiledAcquisition
from triad_dynamic_campaign import (ARMS, _jsonable, decide, digest, evaluator_metrics,
    freeze_gate, identity, load_capture, outcomes, paired_arms, paired_outcomes,
    public_geometry, read_templates, schedule, source_hashes, write_json)


def sources():
    extra = ['tools/triad_dynamic_acquire.py', 'tools/triad_dynamic_variants.py',
             'tools/triad_dynamic_scan.py', 'local-evidence/triad-stochastic/acquisition/run_guarded.py']
    return source_hashes() | {name: digest(ROOT / name) for name in extra}


def run(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exporter', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--helper', choices=('on', 'off'), default='on')
    parser.add_argument('--seed-base', type=int, default=1010000)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--precision', choices=('fp32', 'fp64'), default='fp32')
    parser.add_argument('--threads', type=int, default=2)
    parser.add_argument('--export-workers', type=int, default=8)
    parser.add_argument('--export-timeout', type=float, default=600.)
    parser.add_argument('--trial-batch-size', type=int, default=103)
    parser.add_argument('--memory-limit-bytes', type=int, default=8*1024**3)
    args = parser.parse_args(argv)
    started = time.perf_counter()
    if args.output.exists():
        parser.error('output must be a fresh directory; no overwrites or automatic retries')
    if not args.exporter.is_file():
        parser.error('exporter binary is missing')
    if (not 1 <= args.export_workers <= 8 or min(args.threads, args.trial_batch_size, args.memory_limit_bytes) < 1 or
            not math.isfinite(args.export_timeout) or args.export_timeout <= 0):
        parser.error('invalid resource bounds; at most eight native workers')
    trials = schedule(args.seed_base, 39, 32, 32)
    exporter = args.exporter.resolve()
    native = ['--case', 'hf', '--rate', '36', '--added-symbols', '10', '--seconds', '16',
              '--cn0', '8', '--channel-evolution', 'stochastic', '--random-doppler-width-hz', '.5',
              '--selective-modulation-rate-hz', '.05', '--selective-perturbation', 'each-65',
              '--spread-preset', 'hf-worst', '--margin', '3', '--sample-rate', '6000',
              '--data-if', '1725', '--oscillator-effects', 'off', '--timing-policy', 'bounded',
              '--helper', args.helper, '--helper-components', 'full', '--fhss', 'off',
              '--shaping', 'auto', '--key-seed', '2407', '--epoch', '1793850000']
    hashes = sources()
    protocol = dict(schema='triad-stochastic-guarded-timing-epoch-protocol-v1',
        source_hashes=hashes, exporter_sha256=digest(exporter), native_arguments=native,
        trial_schedule=trials, helper=args.helper, alpha=.05,
        search=dict(epoch_offsets=list(range(-6, 7)), arrival_count=41,
            arrival_rule='np.linspace(*manifest.calendar.arrival_prior_seconds,41), endpoint-inclusive',
            expected_arrival_prior_seconds=[-.0555, .1255], expected_spacing_seconds=.004525,
            frequencies_hz=[0.], clock_ppm=[0.], total_candidates=533,
            coherence_seconds=[.1, .5, 2., 'inf'], block_seconds=.25, timing_tile_size=8,
            execution='scan', projection='full-envelope', pilot_use='both', arrival_model='continuous',
            pilot_policy='public timing-resolution guard before scoring; unresolved pilot phase uses DATA-only'),
        gate='Separate static/dynamic marginal rank gates using only39 calibration captures; no selection or stopping.',
        read_order='All public I/Q scores are computed before evaluator truth or any source-bit decisions are read. '
                   'Gate is then frozen from calibration-only scores before held-out decisions.',
        scope=['Random native arrival throughout the public bounded prior; no forced arrival.',
            '13 epoch alternatives searched; emitted true epoch remains nominal, not randomized across alternatives.',
            'Oscillator effects explicitly disabled; CFO/sample-clock fixed. Not full oscillator acquisition.',
            'The4.525ms lattice leaves continuous timing mismatch; it is not exact continuous maximum likelihood.',
            'Effective pilot policy is resolved publicly before any capture scoring and separately calibrated.',
            'Native full Helper auxiliary remains present when Helper is on; each Helper policy needs its own gate.',
            'Per-capture5% empirical diagnostic, not operational daily false-admission qualification.'],
        configuration={key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
        environment=dict(python=sys.version, platform=platform.platform(), torch_version=torch.__version__,
            cuda_version=torch.version.cuda, cuda_name=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None))
    args.output.mkdir(parents=True)
    write_json(args.output / 'protocol.json', protocol)
    receipts, rows, current = [], [], None
    timers = dict(native_export_stage_wall_seconds=0., native_export_sum_seconds=0.,
                  input_loading_hash_seconds=0.)

    def export(trial):
        folder = args.output / trial['id']
        command = [str(exporter), *native, '--output', str(folder), '--seed', str(trial['seed']),
                   '--bit', str(trial['bit']), '--data', 'on' if trial['data'] else 'off']
        if trial['id'] == trials[0]['id']:
            command.append('--templates')
        mark = time.perf_counter()
        with (args.output / (trial['id']+'-export.log')).open('x') as stream:
            subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True,
                           timeout=args.export_timeout)
        return dict(trial=trial, command=command, export_wall_seconds=time.perf_counter()-mark)

    try:
        mark = time.perf_counter()
        # Batches cap both active subprocesses and work remaining after an error.
        # The one shared source-template bank is produced only by trial zero.
        for first in range(0, len(trials), args.export_workers):
            batch = trials[first:first+args.export_workers]
            current = [trial['id'] for trial in batch]
            with ThreadPoolExecutor(max_workers=args.export_workers) as pool:
                completed = list(pool.map(export, batch))
            receipts.extend(completed)
            with (args.output / 'export-receipts.jsonl').open('a') as stream:
                for receipt in completed:
                    stream.write(json.dumps(receipt, allow_nan=False)+'\n')
            print(json.dumps(dict(stage='native-export', complete=len(receipts), total=len(trials))), flush=True)
        timers['native_export_stage_wall_seconds'] = time.perf_counter()-mark
        timers['native_export_sum_seconds'] = sum(receipt['export_wall_seconds'] for receipt in receipts)
        mark = time.perf_counter()
        first_folder = args.output / trials[0]['id']
        manifest, first_raw, first_valid, _ = load_capture(first_folder)
        geometry = public_geometry(manifest)
        prior = tuple(manifest['calendar']['arrival_prior_seconds'])
        np.testing.assert_allclose(prior, (-.0555, .1255), atol=1e-14, rtol=0.)
        arrivals = tuple(np.linspace(*prior, 41))
        templates, epochs, template_receipt = read_templates(first_folder, manifest)
        if tuple(epochs) != tuple(range(-6, 7)):
            raise ValueError('native epoch bank differs from frozen13 alternatives')
        raw_bytes = len(trials)*first_raw.size*16
        if raw_bytes+templates.nbytes+first_valid.nbytes >= args.memory_limit_bytes:
            raise MemoryError('raw inputs and public templates alone exhaust total memory budget')
        raw = np.empty((len(trials), first_raw.size), np.complex128)
        valid = np.asarray(first_valid, bool).copy()
        manifests, input_receipts = [], []
        for index, trial in enumerate(trials):
            m, samples, mask, receipt = load_capture(args.output / trial['id'], geometry)
            if not np.array_equal(valid, np.asarray(mask, bool)):
                raise ValueError('public validity differs between trials')
            raw[index] = samples
            manifests.append(m)
            input_receipts.append(receipt)
        timers['input_loading_hash_seconds'] = time.perf_counter()-mark
        write_json(args.output / 'inputs.json', dict(template_receipt=template_receipt,
            raw_shape=list(raw.shape), raw_bytes=raw.nbytes, validity_sha256=input_receipts[0]['validity_sha256'],
            trial_inputs=[dict(trial_id=trial['id'], **receipt) for trial, receipt in zip(trials, input_receipts)]))
        torch.set_num_threads(args.threads)
        torch.set_float32_matmul_precision('highest')
        torch.backends.cuda.matmul.allow_tf32 = False
        receiver = TiledAcquisition(manifest, templates, epochs, selected_epochs=epochs,
            arrival_seconds=arrivals, frequencies_hz=(0.,), clock_ppm=(0.,), timing_tile_size=8,
            block_seconds=.25, coherence_seconds=(.1, .5, 2., math.inf), pilot_use='both',
            execution='scan', projection='full-envelope', device=args.device, precision=args.precision,
            memory_limit_bytes=args.memory_limit_bytes)
        write_json(args.output / 'planned.json', dict(procedure_id=receiver.procedure_id,
            policy=receiver.policy, planning_seconds=receiver.planning_seconds))

        def progress(tile):
            with (args.output / 'tiles.jsonl').open('a') as stream:
                stream.write(json.dumps(tile, allow_nan=False)+'\n')
            print(json.dumps(dict(stage='receiver-tile', index=tile['index'], total=receiver.tile_count,
                epoch=tile['epoch'], candidates=tile['candidates'], preparation_seconds=tile['preparation_seconds'],
                score_wall_seconds=tile['score_wall_seconds'])), flush=True)

        current = 'all-public-observations-scored-before-evaluator-access'
        result = receiver.score(raw, valid, trial_batch_size=args.trial_batch_size, progress=progress)
        result = _jsonable(result)
        write_json(args.output / 'receiver.json', result)
        procedure_id = result['procedure_id']
        condition_id = identity(dict(procedure_id=procedure_id, public_geometry=geometry))
        scored = paired_arms(result['hypothesis_log_evidence'], (.1, .5, 2., math.inf))
        for index, (trial, arms, receipt, exported) in enumerate(zip(trials, scored, input_receipts, receipts)):
            rows.append(dict(trial=trial, procedure_id=procedure_id, condition_id=condition_id,
                **arms, **receipt, export_command=exported['command'],
                export_wall_seconds=exported['export_wall_seconds'],
                model_bit_scores=np.asarray(result['model_bit_scores'])[:, index, :].tolist(),
                hypothesis_log_evidence=np.asarray(result['hypothesis_log_evidence'])[:, index, :].tolist()))
        gate = freeze_gate(rows[:39], procedure_id, condition_id, .05)
        write_json(args.output / 'gate.json', gate)
        for row, m in zip(rows, manifests):
            trial = row['trial']
            if trial['phase'] != 'calibration':
                row['decisions'] = {arm: decide(row, gate, arm) for arm in ARMS}
            row['evaluator'] = evaluator_metrics(args.output / trial['id'], m)
            if row['evaluator']['source_bit'] != trial['bit']:
                raise ValueError('native source bit differs from frozen schedule')
            arrival = row['evaluator']['arrival_seconds']
            row['evaluator']['nearest_timing_grid_error_seconds'] = min(abs(arrival-value) for value in arrivals)
            row['evaluator']['arrival_inside_public_prior'] = prior[0] <= arrival <= prior[1]
            row['iq_retained'] = True
            write_json(args.output / trial['id'] / 'result.json', row)
            with (args.output / 'trials.jsonl').open('a') as stream:
                stream.write(json.dumps(row, allow_nan=False)+'\n')
        if sources() != hashes or digest(exporter) != protocol['exporter_sha256']:
            raise ValueError('source or native binary changed during frozen campaign')
        timers['complete_wall_seconds'] = time.perf_counter()-started
        timers['receiver'] = result['timing']
        timers['scope'] = 'Complete driver includes native export, input loading/hashing, all tile preparation/scoring and evidence writes.'
        signal_rows = [row for row in rows if row['trial']['phase'] == 'signal']
        summary = dict(schema='triad-stochastic-guarded-timing-epoch-summary-v1', completed_trials=len(rows),
            procedure_id=procedure_id, condition_id=condition_id,
            outcomes={arm: outcomes(rows, arm) for arm in ARMS}, paired=paired_outcomes(rows),
            timing=timers, work=result['work'],
            arrival_diagnostics=dict(minimum=min(row['evaluator']['arrival_seconds'] for row in rows),
                maximum=max(row['evaluator']['arrival_seconds'] for row in rows),
                distinct_count=len({row['evaluator']['arrival_seconds'] for row in rows}),
                all_inside_public_prior=all(row['evaluator']['arrival_inside_public_prior'] for row in rows),
                maximum_nearest_grid_error_seconds=max(row['evaluator']['nearest_timing_grid_error_seconds'] for row in rows)),
            signal_emitted_data_energy_over_n0=[row['evaluator']['emitted_data_energy_over_n0'] for row in signal_rows],
            protocol_sha256=digest(args.output / 'protocol.json'), gate_sha256=digest(args.output / 'gate.json'),
            limitations=protocol['scope'])
        write_json(args.output / 'summary.json', summary)
        print(json.dumps(dict(stage='complete', summary=summary), allow_nan=False), flush=True)
        return summary
    except Exception as error:
        write_json(args.output / 'failure.json', dict(stage=current, completed_exports=len(receipts),
            evaluated_rows=sum('evaluator' in row for row in rows), error_type=type(error).__name__,
            error=str(error), wall_seconds=time.perf_counter()-started, automatic_retry=False))
        raise


if __name__ == '__main__':
    run()

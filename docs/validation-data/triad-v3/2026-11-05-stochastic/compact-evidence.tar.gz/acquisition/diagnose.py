#!/usr/bin/env python3
"""One-off failed-capture diagnosis: true versus coarse timing, pilots versus DATA only.

The exact arrival uses evaluator truth and is explicitly an oracle diagnostic.
No new capture, gate, admission or independent qualification is produced.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import numpy as np
import torch
from scipy.special import logsumexp

from triad_dynamic_campaign import digest, load_capture, read_templates, write_json, _jsonable
from triad_dynamic_variants import ScanJointReceiver


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--campaign', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--device', default='cuda')
    p.add_argument('--precision', choices=('fp32', 'fp64'), default='fp32')
    p.add_argument('--coherence', type=float, default=.5)
    p.add_argument('--trial-ids', nargs='+', default=['signal-0000', 'signal-0001', 'signal-0002', 'signal-0003'])
    args = p.parse_args()
    if args.output.exists() or not math.isfinite(args.coherence) or args.coherence <= 0:
        p.error('fresh output and positive finite coherence required')
    if len(args.trial_ids) > 8 or not args.trial_ids or len(set(args.trial_ids)) != len(args.trial_ids):
        p.error('one to eight distinct capture IDs required')
    if any('/' in x or '..' in x for x in args.trial_ids):
        p.error('capture IDs must be single directory names')
    args.output.mkdir(parents=True)
    source_names = ['tools/triad_dynamic_joint.py', 'tools/triad_dynamic_scan.py',
                    'tools/triad_dynamic_variants.py', 'tools/triad_gaussian_prepared.py',
                    'tools/triad_gaussian_state.py', 'local-evidence/triad-stochastic/acquisition/diagnose.py']
    source_hashes = {name: digest(ROOT/name) for name in source_names}
    write_json(args.output/'protocol.json', dict(
        schema='triad-dynamic-coarse-timing-diagnostic-v1', trial_ids=args.trial_ids,
        original_protocol_sha256=digest(args.campaign/'protocol.json'),
        original_summary_sha256=digest(args.campaign/'summary.json'), source_hashes=source_hashes,
        device=args.device, precision=args.precision, coherence_seconds=args.coherence,
        block_seconds=.25, epoch_offsets=[0],
        comparisons=['evaluator true arrival versus nearest frozen41-point arrival',
                     'receiver pilot-use both versus none; physical Helper unchanged'],
        scope='Selected failed/successful-capture oracle diagnostic, not blind reception, calibration, '
              'admission or fresh independent sensitivity qualification. A single fixed coherence is used.'))
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    rows = []
    started = time.perf_counter()
    for trial_id in args.trial_ids:
        directory = args.campaign/trial_id
        m, raw, valid, receipt = load_capture(directory)
        source, epochs, source_receipt = read_templates(args.campaign/'calibration-0000', m)
        truth = json.loads((directory/m['evaluator_truth_file']).read_text())
        original = json.loads((directory/'result.json').read_text())
        for name, value in receipt.items():
            if value != original[name]:
                raise ValueError('native input receipt changed: '+name)
        arrival = float(truth['arrival_seconds'])
        grid = np.linspace(*m['calendar']['arrival_prior_seconds'], 41)
        nearest = float(grid[np.argmin(abs(grid-arrival))])
        row = dict(trial_id=trial_id, source_bit=int(truth['source_bit']), arrival_seconds=arrival,
            nearest_grid_seconds=nearest, grid_error_seconds=nearest-arrival,
            low_high_relative_phase_error_cycles=(m['helper_plan']['high_hz']-m['helper_plan']['low_hz'])*(nearest-arrival),
            input_receipt=receipt, template_receipt=source_receipt,
            original_blind_dynamic=original['dynamic'], original_blind_decision=original['decisions']['dynamic'],
            comparisons={})
        for timing, coordinate in [('exact', arrival), ('nearest', nearest)]:
            for pilot_use in ('both', 'none'):
                mark = time.perf_counter()
                receiver = ScanJointReceiver(m, source, epochs, selected_epochs=(0,),
                    arrival_seconds=(coordinate,), frequencies_hz=(0.,), clock_ppm=(0.,),
                    block_seconds=.25, coherence_seconds=(args.coherence,), pilot_use=pilot_use,
                    precision=args.precision, device=args.device, memory_limit_bytes=2*1024**3, valid=valid)
                preparation = time.perf_counter()-mark
                outcome = receiver.score(np.asarray(raw)[None, :])
                bits = np.asarray(outcome['bit_scores'])[0]
                chosen = int(np.argmax(bits))
                row['comparisons'][timing+'-'+pilot_use] = dict(
                    bit=chosen, raw_correct=chosen == row['source_bit'], bit_scores=bits.tolist(),
                    signed_correct_bit_margin=float(bits[row['source_bit']]-bits[1-row['source_bit']]),
                    working_presence=float(logsumexp(bits)-math.log(2)),
                    hypothesis_log_evidence=_jsonable(outcome['hypothesis_log_evidence']),
                    preparation_seconds=preparation, correlation_seconds=outcome['correlation_seconds'],
                    state_seconds=outcome['state_seconds'], work=receiver.work(),
                    procedure_id=receiver.procedure_id, admission='Not calibrated; no admission decision.')
                print(json.dumps(dict(trial=trial_id, timing=timing, pilot_use=pilot_use,
                    bits=bits.tolist(), raw_correct=chosen == row['source_bit'])), flush=True)
                del receiver
        write_json(args.output/(trial_id+'.json'), row)
        rows.append(row)
    if {name: digest(ROOT/name) for name in source_names} != source_hashes:
        raise ValueError('diagnostic implementation changed during execution')
    write_json(args.output/'summary.json', dict(schema='triad-dynamic-coarse-timing-diagnostic-summary-v1',
        rows=rows, wall_seconds=time.perf_counter()-started,
        scope='Selected conditional/oracle diagnostic only; no new gate or independent validation.'))


if __name__ == '__main__':
    main()

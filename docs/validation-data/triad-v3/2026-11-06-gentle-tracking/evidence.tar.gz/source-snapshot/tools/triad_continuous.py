#!/usr/bin/env python3
"""Bounded native source and fixed-bank or evolving timing-state receiver.

Initial acquisition hypotheses and timing dynamics are public before input.
Only the declared observation endpoint permits a diagnostic decision.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from fractions import Fraction
import os
import platform
from pathlib import Path
import resource
import subprocess
import sys
import time

import numpy as np
from scipy.special import logsumexp

ROOT = Path(__file__).resolve().parents[1]


def file_identity(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(1 << 20): digest.update(block)
    return dict(path=str(path), sha256=digest.hexdigest())


def read_exact(stream, count):
    chunks = bytearray()
    while len(chunks) < count:
        block = stream.read(count-len(chunks))
        if not block:
            raise EOFError('stream ended before the declared payload')
        chunks.extend(block)
    return bytes(chunks)


def carrier_phase(first, count, frequency, sample_rate):
    """Reduce the integer sample origin before converting to binary64."""
    numerator, denominator = float(frequency).as_integer_ratio()
    period = denominator*sample_rate
    initial = (int(first)*numerator) % period
    return 2*np.pi*np.remainder(initial/period + np.arange(count)*(frequency/sample_rate), 1.)


def endpoint_decision(scores, *, complete, simulated, helper_enabled, log_threshold):
    values = np.asarray(scores, dtype=float)
    if values.shape != (2,) or not np.isfinite(values).all():
        raise ValueError('two finite bit scores required')
    log_e = float(logsumexp(values)-math.log(2))
    model_pass = bool(complete and log_e >= log_threshold)
    return dict(candidate_bit=int(np.argmax(values)), log_e=log_e,
        conditional_model_pass=model_pass,
        admitted=model_pass and simulated and not helper_enabled,
        admission_scope='Conditional Gaussian model, fixed bank and endpoint only; neither correctness nor Helper/physical null qualified.')


def receiver_noise_variance(override, native_variance, *, simulated):
    variance = float(native_variance if override is None else override)
    if not math.isfinite(variance) or variance <= 0:
        raise ValueError('receiver noise variance must be finite and positive')
    if simulated and (not math.isfinite(native_variance) or native_variance <= 0 or
                      variance < native_variance):
        raise ValueError('simulation receiver variance must not underestimate the known native thermal noise')
    return variance


def validate_stream_identity(plan, descriptor):
    """Reject a live source whose advertised template identity is ambiguous.

    Historical self-contained captures do not use this handshake. A live
    service must identify both its transmitted source and on-demand basis.
    """
    supported = {'legacy-v1', 'independent-apsk-v2'}
    format_info = plan.get('format')
    if not isinstance(format_info, dict):
        raise ValueError('native plan is missing its waveform format')
    identities = []
    for info in (format_info, descriptor):
        revision = info.get('pattern_revision')
        depth = info.get('added_amplitude_depth')
        if not isinstance(revision, str) or revision not in supported:
            raise ValueError('native stream has a missing or unsupported pattern revision')
        if isinstance(depth, bool) or not isinstance(depth, (int, float)) or not math.isfinite(depth) or not 0 < depth < 1:
            raise ValueError('native stream has an invalid Added Symbols amplitude depth')
        identities.append((revision, float(depth)))
    if identities[0] != identities[1]:
        raise ValueError('native stream pattern identity disagrees with its source plan')
    return dict(pattern_revision=identities[0][0], added_amplitude_depth=identities[0][1])


class NativeStream:
    """One owner, bounded requests; binary output never contains diagnostics."""
    def __init__(self, executable, arguments, *, kind='channel', log=None):
        self.command = [str(executable), *arguments, '--stream-server', '--stream-kind', kind]
        self.process = subprocess.Popen(self.command, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=log)
        try:
            self.plan = self._header()
            self.descriptor = self._header()
            self.waveform_identity = validate_stream_identity(self.plan, self.descriptor)
        except BaseException:
            self.close()
            raise
        self.next_sample = 0

    def _header(self):
        line = self.process.stdout.readline(1 << 20)
        if not line or not line.endswith(b'\n'):
            raise RuntimeError('missing or oversized native stream header')
        result = json.loads(line)
        if not isinstance(result, dict):
            raise ValueError('native stream header must be an object')
        return result

    def _request(self, text):
        self.process.stdin.write(text.encode('ascii'))
        self.process.stdin.flush()
        return self._header()

    def next(self, count):
        if not isinstance(count, int) or not 1 <= count <= 16384:
            raise ValueError('bounded positive native chunk required')
        r = self._request(f'next {count}\n')
        n = int(r['count'])
        if not 0 <= n <= count or r['first_sample'] != self.next_sample:
            raise ValueError('native stream count or calendar changed')
        values = np.frombuffer(read_exact(self.process.stdout, n*16), dtype='<c16')
        valid = np.frombuffer(read_exact(self.process.stdout, n), dtype='u1')
        self.next_sample += n
        return values, valid

    def basis(self, first, count, rows):
        if first < 0 or not 1 <= count <= 16384 or not 1 <= len(rows) <= 128:
            raise ValueError('bounded basis coordinates required')
        lines = [f'basis {first} {count} {len(rows)}']
        for bit, epoch, arrival, frequency, clock, delay, doppler in rows:
            lines.append(f'{int(bit)} {int(epoch)} {arrival:.17g} {frequency:.17g} {clock:.17g} {delay:.17g} {doppler:.17g}')
        r = self._request('\n'.join(lines)+'\n')
        if int(r['count']) != count:
            raise ValueError('native basis response count changed')
        return np.frombuffer(read_exact(self.process.stdout, len(rows)*count*16),
            dtype='<c16').reshape(len(rows), count)

    def basis_mapped(self, first, offsets, rows, audio_center_hz):
        offsets = np.asarray(offsets, dtype='<f8')
        count = len(offsets)
        if (not isinstance(first, int) or not 0 <= first < (1 << 64) or
            not 1 <= count <= 16384 or not 1 <= len(rows) <= 128 or
            offsets.ndim != 1 or not np.isfinite(offsets).all() or offsets[0] < 0 or
            np.any(np.diff(offsets) <= 0) or offsets[-1] > 1048576 or
            not math.isfinite(audio_center_hz)):
            raise ValueError('bounded mapped basis coordinates required')
        if not self.descriptor.get('mapped_basis_supported', False):
            raise ValueError('native source lacks mapped-basis support; rebuild the isolated exporter')
        lines = [f'basis-map {first} {count} {len(rows)} {audio_center_hz:.17g}']
        for bit, epoch, arrival, frequency, clock, delay, doppler in rows:
            lines.append(f'{int(bit)} {int(epoch)} {arrival:.17g} {frequency:.17g} {clock:.17g} {delay:.17g} {doppler:.17g}')
        self.process.stdin.write(('\n'.join(lines)+'\n').encode('ascii'))
        self.process.stdin.write(offsets.tobytes())
        self.process.stdin.flush()
        response = self._header()
        if int(response['count']) != count:
            raise ValueError('native mapped basis response count changed')
        return np.frombuffer(read_exact(self.process.stdout, len(rows)*count*16),
            dtype='<c16').reshape(len(rows), count)

    def clock_target(self, seconds):
        if not math.isfinite(seconds):
            raise ValueError('finite clock correction required')
        return self._request(f'clock {seconds:.17g}\n')

    def close(self):
        process = getattr(self, 'process', None)
        if process is None:
            return
        receipt = None
        if process.poll() is None:
            try:
                process.stdin.write(b'quit\n'); process.stdin.flush()
                receipt = self._header()
                process.wait(timeout=3)
            except (BrokenPipeError, OSError, ValueError, RuntimeError, subprocess.TimeoutExpired):
                process.terminate()
                try: process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
        for stream in (process.stdin, process.stdout):
            if stream: stream.close()
        self.process = None
        return receipt


def load_bank(path):
    bank = json.loads(Path(path).read_text())
    coordinates = bank['coordinates']
    taps = bank.get('taps', [[0., 0.]])
    if not coordinates or len(coordinates)*len(taps)*2 > 128 or len(taps) > 16:
        raise ValueError('bank exceeds bounded 128 basis columns / 16 taps')
    if len({tuple(x) for x in coordinates}) != len(coordinates):
        raise ValueError('duplicate bank coordinates')
    for row in coordinates:
        if len(row) != 4 or isinstance(row[0], bool) or int(row[0]) != row[0] or abs(row[0]) > 6:
            raise ValueError('bank coordinates are [integer epoch offset, arrival seconds, frequency Hz, clock ppm]')
        if not all(math.isfinite(x) for x in row) or 1+row[3]*1e-6 <= 0:
            raise ValueError('invalid finite bank coordinate')
    if any(len(t) != 2 or not all(math.isfinite(x) for x in t) or t[0] < 0 for t in taps):
        raise ValueError('taps are [nonnegative delay seconds, Doppler Hz]')
    return bank, coordinates, taps


def disciplined_capture_extent(samples, sample_rate, maximum_correction, coordinates, taps):
    """Public endpoint envelope, not an inferred physical end or tracking proof.

    Each endpoint's logical/native rate is in [1/(1+c),1+c].
    Include both software maps, declared affine-clock candidates and positive
    arrival/echo extent. Rational arithmetic keeps large integer endpoints.
    """
    c = Fraction(str(maximum_correction))
    clock = Fraction(str(max(abs(row[3]) for row in coordinates))) / 1_000_000
    if not 0 < c <= Fraction(1, 1000) or not 0 <= clock < 1:
        raise ValueError('invalid public continuous-clock capture envelope')
    arrival = max(Fraction(0), Fraction(str(max(row[1] for row in coordinates))) +
                  Fraction(str(max(row[0] for row in taps))))
    extent = (samples + arrival*sample_rate) * (1+c)**2 / (1-clock)
    # Outward guard for decimal CLI/binary-rate conversions and the small
    # number of floating point operations defining the native rate bounds.
    # Keep the final ceil/integer arithmetic exact even at large coordinates.
    extent = extent * (1 + Fraction(64, 1 << 52)) + 2
    frames = (extent.numerator + extent.denominator - 1)//extent.denominator
    if not samples <= frames < (1 << 64):
        raise ValueError('continuous-clock capture endpoint exceeds sample counter')
    return int(frames)


def source_basis(source, coordinates, taps, offset):
    rows = [(bit, epoch, arrival+offset, frequency, clock, delay, doppler)
        for bit in (0, 1) for epoch, arrival, frequency, clock in coordinates
        for delay, doppler in taps]
    def render(first, stop):
        count = stop-first
        data = source.basis(first, count, rows)
        result = np.zeros((3, len(coordinates), len(taps), count), np.complex128)
        result[1:] = data.reshape(2, len(coordinates), len(taps), count)
        return result
    return render


def tracking_source_basis(source, coordinates, taps, offset, timing_forward, audio_center_hz,
                          *, template_backend='auto', cache_bytes=32*1024**2):
    """Physical ADC coordinates + public remote source-offset/rate states.

    Existing acquisition CFO includes the base affine-clock IF contribution.
    Subtract that contribution before mapped-basis adds the complete IF map,
    so the old CFO convention is retained rather than counted twice.
    """
    if template_backend not in ('auto', 'direct'):
        raise ValueError('tracking templates must use auto or direct')
    template_source = source
    if template_backend == 'auto':
        from triad_tracking_basis import CachedMappedBasis
        template_source = CachedMappedBasis(source, cache_bytes=cache_bytes)
    def render(states, anchor_seconds, first, stop, physical_origin, physical_offsets):
        count = stop-first
        rows = []
        for bit in (0, 1):
            for state in states:
                epoch, arrival, frequency, clock = coordinates[state.group]
                base = 1+clock*1e-6
                velocity = state.rate_index*timing_forward.rate_step_ppm*1e-6
                displacement = state.delay_index*timing_forward.delay_step_seconds
                scale = base+velocity
                if scale <= 0: raise ValueError('tracking source rate is nonpositive')
                mapped_arrival = (base*(arrival+offset)-displacement+velocity*anchor_seconds)/scale
                for delay, doppler in taps:
                    rows.append((bit, epoch, mapped_arrival,
                        frequency-audio_center_hz*(base-1), (scale-1)*1e6, delay, doppler))
        data = np.empty((len(rows), count), np.complex128)
        positions = np.asarray(physical_offsets, dtype=np.float64)
        for lo in range(0, count, 16384):
            hi = min(count, lo+16384)
            shift = math.floor(float(positions[lo]))
            for col in range(0, len(rows), 128):
                data[col:col+128, lo:hi] = template_source.basis_mapped(int(physical_origin)+shift,
                    positions[lo:hi]-shift, rows[col:col+128], audio_center_hz)
        result = np.zeros((3, len(states), len(taps), count), np.complex128)
        result[1:] = data.reshape(2, len(states), len(taps), count)
        return result
    render.cache_report = (template_source.report if template_backend == 'auto'
                           else lambda: dict(method='direct-native-mapped-reference', cache_limit_bytes=0))
    return render


def make_timing_forward(bank, descriptor, model_count):
    from triad_timing_forward import SparseTimingForward, TimingState
    raw = bank.get('tracking', {})
    if not isinstance(raw, dict):
        raise ValueError('public tracking configuration must be an object')
    config = dict(raw)
    rates = config.pop('initial_rate_indices', [0])
    delays = config.pop('initial_delay_indices', [0])
    segment_seconds = config.pop('segment_seconds', None)
    bandwidth = float(descriptor.get('nominal_triplet_bandwidth_hz', 0))
    center = abs(float(descriptor.get('data_if_hz', 0)))
    if not math.isfinite(bandwidth) or bandwidth <= 0 or not math.isfinite(center):
        raise ValueError('tracking requires finite resolved native waveform bandwidth and IF metadata')
    if segment_seconds is None:
        segment_seconds = 4.
        # Slow complex-baseband patterns need not branch every four seconds.
        # Bound within-segment envelope motion to a quarter delay cell and
        # acceleration curvature to the same scale. These are geometric design
        # budgets, not measured waveform-loss or arbitrary-trajectory promises.
        # Keep the existing short cadence for audio IF and broad/spread chips.
        if bandwidth < 1. and center < 1.:
            delay_cell = float(config.get('delay_step_seconds', 1/(4*bandwidth)))
            rate = float(config.get('maximum_rate_ppm', 2000.))*1e-6
            acceleration = float(config.get('maximum_acceleration_ppm_per_second', 20.))*1e-6
            rate_cell = float(config.get('rate_step_ppm', 50.))*1e-6
            limits = [4096.]
            if rate > 0: limits.append(.25*delay_cell/rate)
            if acceleration > 0:
                limits.append(math.sqrt(max(0., 2*delay_cell/acceleration)))
                # Envelope slowness alone does not bound common IF phase.
                # At most 1/16 cycle curvature for a local affine template.
                limits.append(math.sqrt(.5/((center+bandwidth/2)*acceleration)))
            if rate_cell > 0: limits.append(.25/((center+bandwidth/2)*rate_cell))
            segment_seconds = max(4., min(limits))
        # Oversampled low-rate input must not turn the slow update cadence into
        # an unbounded segment allocation. Explicit user durations still fail
        # preflight when they exceed the receiver's storage contract.
        fs = float(descriptor.get('sample_rate_hz', 0.))
        if fs:
            if not math.isfinite(fs) or fs <= 0:
                raise ValueError('finite positive tracking sample rate required')
            segment_seconds = min(segment_seconds, 1_048_576/fs)
        # Preserve explicit lattice indices and steps. For the automatic slow
        # envelope grid, cap midpoint frequency mismatch at 1/8 cycle (the
        # rectangular-integration design proxy is approximately 0.22 dB).
        if (bandwidth < 1. and center < 1. and 'rate_step_ppm' not in config and
            'initial_rate_indices' not in raw):
            config['rate_step_ppm'] = min(200., .25e6/((center+bandwidth/2)*segment_seconds))
    if (isinstance(segment_seconds, bool) or not isinstance(segment_seconds, (int, float)) or
        not math.isfinite(segment_seconds) or segment_seconds <= 0):
        raise ValueError('positive finite tracking segment duration required')
    if (not isinstance(rates, list) or not isinstance(delays, list) or not rates or not delays or
        any(isinstance(i, bool) or not isinstance(i, int) for i in [*rates, *delays]) or
        len(set(rates)) != len(rates) or len(set(delays)) != len(delays)):
        raise ValueError('distinct integer initial timing-state indices required')
    allowed = {'model_probabilities', 'delay_step_seconds', 'rate_step_ppm',
        'maximum_rate_ppm', 'maximum_acceleration_ppm_per_second', 'maximum_states', 'maximum_proposals'}
    if set(config)-allowed: raise ValueError('unknown public tracking configuration fields')
    config.setdefault('delay_step_seconds', 1/(4*bandwidth))
    proposal_cap = config.get('maximum_proposals', 256)
    if (isinstance(proposal_cap, bool) or not isinstance(proposal_cap, int) or
        not 1 <= proposal_cap <= 16384 or
        len(bank['coordinates'])*len(delays)*len(rates) > proposal_cap):
        raise ValueError('public initial timing grid must fit the bounded proposal cap')
    states = [TimingState(group, delay, rate) for group in range(len(bank['coordinates']))
              for delay in delays for rate in rates]
    tracker = SparseTimingForward(states, model_count=model_count, **config)
    if (tracker.maximum_acceleration_ppm_per_second > 0 and
        tracker.rate_index_bound > 0 and
        tracker.rate_step_ppm > tracker.maximum_acceleration_ppm_per_second*segment_seconds):
        raise ValueError('tracking segment is too short for a rate-grid transition; reduce rate_step_ppm or increase segment_seconds')
    return tracker, segment_seconds


def tracking_receiver_class(mode='tracking'):
    """The practical tracker keeps channel evidence across timing updates.

    The reset implementation remains an explicit numerical reference. Neither
    choice qualifies physical ADC/ASRC noise or changes endpoint admission.
    """
    from triad_tracking_receiver import PracticalTrackingReceiver, PersistentTrackingReceiver, TrackingReceiver
    if mode == 'tracking':
        return PracticalTrackingReceiver
    if mode == 'tracking-persistent':
        return PersistentTrackingReceiver
    if mode == 'tracking-reset':
        return TrackingReceiver
    raise ValueError('unknown timing receiver policy')


def tracking_resource_report(receiver, descriptor, *, template_bytes=0,
                             template_backend='auto', calibration=None,
                             cpu_ceiling_per_second=1., memory_limit_bytes=None):
    """Source/hardware-bound work accounting, without inventing CPU precision."""
    import torch
    from triad_tracking_budget import count_tracking_work, forecast_tracking_cost
    forward = receiver.timing
    if forward.observations:
        raise ValueError('tracking work must be frozen before receiving samples')
    args = receiver.receiver_arguments
    work = count_tracking_work(samples=receiver.samples, sample_rate_hz=receiver.sample_rate,
        block_samples=receiver.block_samples, segment_samples=receiver.segment_samples,
        initial_states=len(forward.states), maximum_states=forward.maximum_states,
        maximum_proposals=forward.maximum_proposals, rate_index_bound=forward.rate_index_bound,
        models=forward.model_count, taps=len(args['stationary_power']),
        precision=receiver.precision, projection_mode=args['projection_mode'],
        workspace_bytes=receiver.owned_bytes_estimate+template_bytes,
        fine_symbol_rate_hz=float(descriptor.get('fine_chip_rate_hz', 0.)),
        data_if_hz=abs(float(descriptor.get('data_if_hz', 0.))),
        maximum_relative_rate_ppm=forward.maximum_rate_ppm)
    nominal_plan = getattr(receiver, 'nominal_work_plan', None)
    if nominal_plan:
        nominal = count_tracking_work(samples=receiver.samples, sample_rate_hz=receiver.sample_rate,
            block_samples=receiver.block_samples, segment_samples=receiver.segment_samples,
            initial_states=nominal_plan['initial_states'], maximum_states=nominal_plan['maximum_states'],
            maximum_proposals=nominal_plan['maximum_proposals'], rate_index_bound=0,
            models=nominal_plan['models'], taps=nominal_plan['taps'], precision=receiver.precision,
            projection_mode=args['projection_mode'], workspace_bytes=nominal_plan['workspace_bytes'])
        # Fixed affine states retain their original anchor and execute one
        # identity transition each. Input/calendar counts remain shared; DSP
        # basis/likelihood work is performed separately and must be added.
        nominal['work']['transition_edges'] = nominal_plan['initial_states']*max(0, nominal['receiver']['segments']-1)
        work['lanes'] = dict(adaptive=dict(work['work']), initial_affine=nominal['work'])
        for key in ('basis_row_samples', 'gaussian_updates', 'transition_edges'):
            work['work'][key] += nominal['work'][key]
        work['work']['bound_scope'] += ' Includes both fixed-weight lanes; sample rows and segment calendar are shared counts.'
    cpu_model = platform.processor() or platform.machine()
    if Path('/proc/cpuinfo').exists():
        for line in Path('/proc/cpuinfo').read_text().splitlines():
            if line.startswith('model name'):
                cpu_model = line.split(':', 1)[-1].strip(); break
    identity = dict(source={name: file_identity(ROOT/'tools'/name)['sha256'] for name in
        ('triad_continuous.py', 'triad_tracking_receiver.py', 'triad_incremental_receiver.py',
         'triad_gaussian_state.py', 'triad_timing_forward.py', 'triad_tracking_basis.py',
         'triad_tracking_budget.py')}, hardware=dict(cpu=cpu_model, architecture=platform.machine(),
         torch_version=torch.__version__, threads=torch.get_num_threads()),
        regime=dict(receiver=type(receiver).__name__, sample_rate_hz=receiver.sample_rate,
            block_samples=receiver.block_samples,
            segment_samples=receiver.segment_samples, models=forward.model_count,
            taps=len(args['stationary_power']), precision=receiver.precision,
            coherence_seconds=[str(value) for value in args['coherence_seconds']],
            stationary_power=list(args['stationary_power']),
            required_bands=[list(band) for band in args['required_bands']],
            excluded_bands=[list(band) for band in args['excluded_bands']],
            waveform_descriptor={key: descriptor.get(key) for key in
                ('nominal_triplet_bandwidth_hz', 'fine_chip_rate_hz', 'data_if_hz')},
            delay_step_seconds=forward.delay_step_seconds, rate_step_ppm=forward.rate_step_ppm,
            maximum_rate_ppm=forward.maximum_rate_ppm,
            maximum_acceleration_ppm_per_second=forward.maximum_acceleration_ppm_per_second,
            projection=args['projection_mode'], template_backend=template_backend,
            template_bytes=template_bytes, maximum_states=forward.maximum_states,
            maximum_proposals=forward.maximum_proposals,
            nominal_plan=({key: nominal_plan[key] for key in
                ('initial_states', 'maximum_states', 'maximum_proposals', 'models', 'taps')}
                if nominal_plan else None)))
    # Only measured receiver timers excluding template generation are reusable
    # here. Native synthesis has its own source/build and cache identity; a
    # broad prose claim in an imported calibration is insufficient provenance.
    if calibration is not None:
        if not isinstance(calibration, dict):
            raise ValueError('tracking CPU calibration must be an object')
        if calibration.get('scope') != 'receiver-excluding-basis-v1':
            calibration = dict(calibration, identity=None)
    report = forecast_tracking_cost(work, calibration, identity,
        cpu_ceiling_seconds=cpu_ceiling_per_second*receiver.samples/receiver.sample_rate,
        memory_ceiling_bytes=memory_limit_bytes)
    report['identity'] = identity
    report['preparation_scope'] = 'Receiver construction and template-cache preparation are separate; CPU calibration scope must be receiver-excluding-basis-v1. Native synthesis, ingest, ASRC and finalization require separate measurements.'
    return report


def tracking_preflight(bank, descriptor, *, samples, sample_rate, block_seconds=.25,
                       coherences=(.5, 2., math.inf), precision='fp32', memory_mib=512,
                       chunk_samples=4096, projection_mode='valid-rows',
                       template_backend='auto', calibration=None, cpu_ceiling_per_second=1.):
    """Bounded no-waveform preflight for the isolated duration/link planner."""
    descriptor = dict(descriptor, sample_rate_hz=sample_rate)
    forward, segment_seconds = make_timing_forward(bank, descriptor, len(coherences))
    memory = memory_mib*1024**2
    template_bytes = min(32*1024**2, memory//8) if template_backend == 'auto' else 0
    taps = bank.get('taps', [[0., 0.]])
    projection = bank.get('projection', {})
    receiver = tracking_receiver_class()(sample_rate=sample_rate, samples=samples,
        block_samples=max(1, round(block_seconds*sample_rate)),
        segment_samples=max(1, round(segment_seconds*sample_rate)),
        basis_provider=lambda *args: None, timing_forward=forward,
        required_bands=projection.get('required_bands_hz', [[-.49*sample_rate, .49*sample_rate]]),
        excluded_bands=projection.get('excluded_bands_hz', []),
        stationary_power=tuple(bank.get('stationary_power', [1/len(taps)]*len(taps))),
        coherence_seconds=coherences, precision=precision, projection_mode=projection_mode,
        memory_limit_bytes=memory-template_bytes, maximum_input_chunk_samples=chunk_samples,
        audio_center_hz=float(descriptor.get('data_if_hz', 0.)))
    return tracking_resource_report(receiver, descriptor, template_bytes=template_bytes,
        template_backend=template_backend, calibration=calibration,
        cpu_ceiling_per_second=cpu_ceiling_per_second, memory_limit_bytes=memory)


class BoundedClockControl:
    """OS corrections steer only the explicitly eligible DATA source.

    Control observations are not DAC timestamps or estimates of remote clock
    motion. Never change the epoch or give this private TX trace to the RX bank.
    """
    def __init__(self, clock):
        self.clock = clock
        if not clock.available:
            raise ValueError('system clock association unavailable at stream start')
        self.origin = clock.snapshot
        self.last_target = 0.
        self.report = dict(updates=0, outside_envelope=0, unavailable_polls=0,
                           last_target_seconds=0., last_response=None, status='following')

    def _status(self, value):
        if value != self.report['status']:
            print(f'triad_continuous: bounded clock-step following: {value}; '
                  'the established source trajectory and epoch are retained', file=sys.stderr)
            self.report['status'] = value

    def poll(self, source):
        snapshot = self.clock.poll()
        if snapshot is None:
            self.report['unavailable_polls'] += 1
            self._status('clock association unavailable')
            return
        target = (snapshot.offset_ns-self.origin.offset_ns)/1e9
        uncertainty = (snapshot.uncertainty_ns+self.origin.uncertainty_ns)/1e9
        if abs(target) > 2+uncertainty:
            self.report['outside_envelope'] += 1
            self._status('correction outside original +/-2-second envelope')
            return  # Keep the continuous established trajectory; never ratchet.
        self._status('following')
        target = max(-2., min(2., target))
        if abs(target-self.last_target) < max(.001, uncertainty):
            return  # Clock-read jitter must not continually requeue the servo.
        response = source.clock_target(target)
        if not response.get('accepted'):
            raise RuntimeError('native source rejected eligible clock correction')
        self.last_target = target
        self.report.update(updates=self.report['updates']+1,
                           last_target_seconds=target, last_response=response)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode', choices=('simulate', 'transmit', 'receive'), default='simulate')
    p.add_argument('--native', type=Path, default=ROOT/'build/dev-cli/triad_helper_export')
    p.add_argument('--audio-native', type=Path, default=ROOT/'build/dev-cli/triad_audio_stream')
    p.add_argument('--bank', type=Path, help='fixed public candidate bank JSON, required for reception')
    p.add_argument('--report', type=Path, required=True)
    p.add_argument('--block-seconds', type=float, default=.25)
    p.add_argument('--chunk-samples', type=int, default=4096)
    p.add_argument('--coherences', default='0.5,2,inf')
    p.add_argument('--precision', choices=('fp32', 'fp64'), default='fp32')
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--memory-mib', type=int, default=256)
    p.add_argument('--alpha-per-day', type=float, default=1e-4)
    p.add_argument('--noise-variance', type=float, help='fixed receiver variance; required for physical capture')
    p.add_argument('--limit-seconds', type=float, help='diagnostic prefix only; cannot admit an incomplete bit')
    p.add_argument('--device', default='default')
    p.add_argument('--fixed-gain', type=float, default=.002)
    p.add_argument('--audio-arguments', default='[]', help='JSON array of extra native audio options (e.g. full-rate background noise)')
    p.add_argument('--follow-system-clock', choices=('auto', 'off', 'continuous', 'bounded-data'), default='auto',
        help='auto (default): follow UTC for live TX/RX, deterministic simulation stays off; explicit off preserves old clock policy')
    p.add_argument('--receiver', choices=('auto', 'fixed', 'tracking', 'tracking-persistent', 'tracking-reset'), default='auto',
        help='auto: persistent affine/adaptive mixture for live capture, fixed bank for deterministic simulation; persistent/reset alternatives are diagnostic references')
    p.add_argument('--tracking-templates', choices=('auto', 'direct'), default='auto',
        help='auto: bounded cached DATA with validated interpolation regimes and explicit native fallback; direct: exact native reference')
    p.add_argument('--tracking-cost-calibration', type=Path,
        help='optional exact source/hardware/regime-matched measured work record; no implicit cross-hardware extrapolation')
    p.add_argument('--tracking-cpu-ceiling', type=float, default=1.,
        help='reported receiver CPU seconds per received second ceiling; an unavailable calibration remains unknown')
    p.add_argument('--clock-max-ppm', type=float, default=1000)
    p.add_argument('--clock-phase-max-ppm', type=float, default=200,
        help='gentle UTC phase catch-up; separate from measured device-rate calibration')
    p.add_argument('--clock-slew-ppm-per-second', type=float, default=10)
    p.add_argument('--clock-phase-seconds', type=float, default=1000)
    return p


def execute(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    split = argv.index('--') if '--' in argv else len(argv)
    a = parser().parse_args(argv[:split]); native_args = argv[split+1:]
    if a.follow_system_clock == 'auto':
        a.follow_system_clock = 'off' if a.mode == 'simulate' else 'continuous'
    if a.receiver == 'auto':
        a.receiver = 'tracking' if a.mode == 'receive' else 'fixed'
    if a.report.exists(): raise FileExistsError(a.report)
    if not 1 <= a.chunk_samples <= 8192 or not 1 <= a.threads <= 64:
        raise ValueError('chunk must be 1..8192 and threads 1..64')
    if not math.isfinite(a.block_seconds) or a.block_seconds <= 0:
        raise ValueError('positive finite block duration required')
    if not math.isfinite(a.tracking_cpu_ceiling) or a.tracking_cpu_ceiling <= 0:
        raise ValueError('positive finite tracking CPU ceiling required')
    if not math.isfinite(a.fixed_gain) or a.fixed_gain <= 0:
        raise ValueError('fixed audio gain must be finite and positive')
    if a.limit_seconds is not None and (not math.isfinite(a.limit_seconds) or a.limit_seconds <= 0):
        raise ValueError('positive finite prefix duration required')
    if a.mode != 'transmit' and a.bank is None: raise ValueError('reception requires --bank')
    if a.follow_system_clock != 'off' and a.mode == 'simulate':
        raise ValueError('audio clock discipline requires dated TX/RX hardware; use the injected controller/audio tests for simulated device clocks')
    if a.follow_system_clock == 'continuous' and '--clock-follow-bounded' in native_args:
        raise ValueError('full-audio discipline cannot be combined with source-only clock steering')
    if (not 0 < a.clock_max_ppm <= 1000 or not 0 < a.clock_phase_max_ppm <= a.clock_max_ppm or
        not 0 < a.clock_slew_ppm_per_second <= 1000 or not math.isfinite(a.clock_phase_seconds) or a.clock_phase_seconds < 1):
        raise ValueError('invalid continuous audio clock limits')
    if a.mode == 'receive' and (a.noise_variance is None or a.noise_variance <= 0):
        raise ValueError('physical reception requires a declared conservative --noise-variance')
    audio_arguments = json.loads(a.audio_arguments)
    if not isinstance(audio_arguments, list) or any(not isinstance(x, str) for x in audio_arguments):
        raise ValueError('audio-arguments must be a JSON string array')
    # Do not let convenience flags rewrite the pipe format or bounded calendar.
    allowed_audio = ('--background-noise-', '--exclusive')
    for i, item in enumerate(audio_arguments):
        if item.startswith('--') and not item.startswith(allowed_audio):
            raise ValueError('audio extra flags restricted to background noise and exclusive access')
    if a.follow_system_clock == 'continuous':
        audio_arguments += ['--clock-discipline', 'continuous', '--clock-max-ppm', str(a.clock_max_ppm),
            '--clock-phase-max-ppm', str(a.clock_phase_max_ppm),
            '--clock-slew-ppm-per-second', str(a.clock_slew_ppm_per_second),
            '--clock-phase-seconds', str(a.clock_phase_seconds)]
    elif a.mode != 'simulate':
        # The native tool itself defaults to continuous. An explicit adapter
        # override (including the legacy source-only mode) must not double steer.
        audio_arguments += ['--clock-discipline', 'off']
    tracking = a.receiver in ('tracking', 'tracking-persistent', 'tracking-reset')
    mapped_capture = a.mode == 'receive' and tracking
    if mapped_capture:
        audio_arguments += ['--capture-format', 'mapped-v1']
    a.report.parent.mkdir(parents=True, exist_ok=True)
    result = dict(schema='triad-continuous-v1', mode=a.mode, complete=False,
        admitted=False, physical_null_qualified=False,
        acquisition='public initial bank; evolving timing-state inference' if tracking else 'fixed public bank',
        receiver_algorithm=a.receiver, system_clock_policy=a.follow_system_clock,
        multi_day_hardware_uptime_qualified=False,
        identities=[file_identity(p) for p in (a.native, Path(__file__),
            ROOT/'tools/triad_incremental_receiver.py', ROOT/'tools/triad_gaussian_state.py')])
    if a.mode != 'simulate': result['identities'].append(file_identity(a.audio_native))
    if a.follow_system_clock == 'continuous':
        result['clock_profile'] = dict(name='continuous-full-audio',
            source_epoch_unchanged=True, receiver_uses_private_transmitter_trace=False,
            receiver_clock_tracking_qualified=False,
            capture_transport='adjustable ASRC; white-noise covariance and physical null unqualified',
            maximum_local_software_rate_ppm=a.clock_max_ppm,
            maximum_phase_catchup_ppm=a.clock_phase_max_ppm,
            maximum_two_endpoint_relative_rate_ppm=((1+a.clock_max_ppm*1e-6)**2-1)*1e6,
            frequency_scope='software rate multiplies baseband/audio frequencies, never RF shift',
            receiver_time='original ADC coordinate from exact local map' if mapped_capture else 'disciplined output sample coordinate')
    child_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started, cpu = time.perf_counter(), time.process_time()
    source = audio = None
    clock_control = None
    if a.follow_system_clock == 'bounded-data':
        native_args += ['--clock-follow-bounded']
        result['identities'].append(file_identity(ROOT/'tools/triad_control_clock.py'))
        if a.mode == 'transmit':
            from triad_control_clock import ControlClock
            clock_control = BoundedClockControl(ControlClock())
    log_path = a.report.with_suffix('.stderr.log')
    with log_path.open('x') as log:
        try:
            source = NativeStream(a.native, native_args,
                kind='channel' if a.mode == 'simulate' else 'emitted', log=log)
            d = source.descriptor; fs = int(d['sample_rate_hz']); total = int(d['total_samples'])
            result.update(source=d, plan=source.plan, command=source.command)
            if a.follow_system_clock == 'continuous':
                result['clock_profile'].update(
                    maximum_local_data_center_shift_hz=abs(float(d['data_if_hz']))*a.clock_max_ppm*1e-6,
                    maximum_two_endpoint_data_center_shift_hz=abs(float(d['data_if_hz']))*((1+a.clock_max_ppm*1e-6)**2-1),
                    scope='Elapsed audio discipline from first dated frame; independent remote nonlinear timing remains outside fixed-bank qualification.')
            if a.follow_system_clock == 'bounded-data':
                result['clock_profile'] = dict(name='bounded-data',
                    local_corrections_steer_source=a.mode == 'transmit',
                    receiver_uses_private_transmitter_trace=False,
                    receiver_time='physical sample index; nominal affine bank unchanged')
            block_samples = max(1, round(a.block_seconds*fs))
            if 2*block_samples > 16384: raise ValueError('merged final block exceeds native bounded basis request')
            receiver = None; first = 0
            if a.mode != 'transmit':
                import torch
                from triad_incremental_receiver import IncrementalReceiver
                from triad_operational_admission import operational_threshold
                torch.set_num_threads(a.threads)
                bank, coordinates, taps = load_bank(a.bank)
                if a.mode == 'receive' and a.follow_system_clock == 'continuous':
                    total = disciplined_capture_extent(total, fs, a.clock_max_ppm*1e-6, coordinates, taps)
                    result['clock_profile'].update(nominal_source_samples=int(d['total_samples']),
                        capture_endpoint_samples=total,
                        capture_allowance_seconds=(total-int(d['total_samples']))/fs,
                        endpoint_scope='Public software plus declared affine-rate/arrival/echo envelope; unmodeled hardware or path timing remains unqualified.')
                variance = receiver_noise_variance(a.noise_variance, float(d['noise_variance']),
                    simulated=a.mode == 'simulate')
                result['receiver_noise_variance'] = variance
                offset = float(d['data_offset_samples'])/fs
                if a.mode == 'simulate': offset += float(d['capture_lead_seconds'])
                projection = bank.get('projection', {})
                if d['helper_enabled'] and not projection.get('required_bands_hz'):
                    raise ValueError('Helper reception requires explicit public DATA projection bands in bank JSON')
                required = projection.get('required_bands_hz', [[-fs*.49, fs*.49]])
                excluded = projection.get('excluded_bands_hz', [])
                projection_mode = 'dft' if d['helper_enabled'] else 'valid-rows'
                # Physical capture uses a fixed quadrature mixer and declared
                # disjoint-block DFT projection. The public bank owns analog
                # latency; neither a payload lag nor noise variance is fitted.
                if a.mode == 'receive' and not projection.get('required_bands_hz'):
                    raise ValueError('real PCM capture requires explicit analytic-sideband projection bands')
                if a.mode == 'receive': projection_mode = 'dft'
                common = dict(sample_rate=fs, samples=total, block_samples=block_samples,
                    required_bands=required, excluded_bands=excluded, noise_variance=variance,
                    stationary_power=tuple(bank.get('stationary_power', [1/len(taps)]*len(taps))),
                    coherence_seconds=tuple(float(x) for x in a.coherences.split(',')),
                    projection_mode=projection_mode, precision=a.precision, memory_limit_bytes=a.memory_mib*1024**2)
                if tracking:
                    forward, segment_seconds = make_timing_forward(bank, d, len(common['coherence_seconds']))
                    # Narrow-complex simulations retain their original CFO
                    # convention. Actual audio includes the final DATA IF.
                    center = float(d['data_if_hz']) if a.mode == 'receive' else 0.
                    template_cache_bytes = min(32*1024**2, a.memory_mib*1024**2//8) if a.tracking_templates == 'auto' else 0
                    common['memory_limit_bytes'] -= template_cache_bytes
                    basis = tracking_source_basis(source, coordinates, taps, offset, forward, center,
                        template_backend=a.tracking_templates, cache_bytes=template_cache_bytes)
                    persistent_arguments = dict(audio_center_hz=center) if a.receiver != 'tracking-reset' else {}
                    receiver = tracking_receiver_class(a.receiver)(**common, timing_forward=forward,
                        segment_samples=max(1, round(segment_seconds*fs)),
                        require_physical_map=mapped_capture,
                        maximum_input_chunk_samples=a.chunk_samples,
                        basis_provider=basis, **persistent_arguments)
                    result['tracking_resource_plan'] = tracking_resource_report(receiver,
                        dict(d, fine_chip_rate_hz=source.plan.get('format', {}).get('fine_chip_rate_hz', 0.)),
                        template_bytes=template_cache_bytes, template_backend=a.tracking_templates,
                        calibration=(json.loads(a.tracking_cost_calibration.read_text())
                            if a.tracking_cost_calibration else None),
                        cpu_ceiling_per_second=a.tracking_cpu_ceiling,
                        memory_limit_bytes=a.memory_mib*1024**2)
                    result['tracking_scope'] = dict(initial_prior='Public bank and declared residual rate/offset indices; defaults assume calibrated residual zero at first segment center.',
                        channel=('Fixed equal mixture of original affine and adaptive persistent channel evidence.'
                            if a.receiver == 'tracking' else
                            'Persistent channel posterior per timing state; conditional Gaussian moment matching at path merges.'
                            if a.receiver == 'tracking-persistent' else 'Independent channel prior at each segment; legacy reset reference.'),
                        pruning='Discarded path likelihood is not renormalized; ambiguity can lose true paths.',
                        local_map_consumed=mapped_capture, segment_seconds=segment_seconds,
                        arbitrary_dynamics_qualified=False, low_cn0_coherent_sensitivity_qualified=False)
                    result['identities'] += [file_identity(ROOT/'tools'/f) for f in
                        ('triad_timing_forward.py','triad_tracking_receiver.py','triad_audio_mapping.py','triad_tracking_basis.py')]
                else:
                    receiver = IncrementalReceiver(**common, basis=source_basis(source, coordinates, taps, offset),
                        candidate_count=len(coordinates))
                result.update(bank=bank, bank_sha256=hashlib.sha256(a.bank.read_bytes()).hexdigest(),
                    admission_policy=operational_threshold(alpha_per_day=a.alpha_per_day),
                    helper_null_scope='Fixed DATA projection retains finite-window Helper leakage; physical/Helper null unqualified.')
            requested = total if a.limit_seconds is None else min(total, math.ceil(a.limit_seconds*fs))
            if a.mode in ('transmit', 'receive'):
                args = [str(a.audio_native), '--mode', 'play' if a.mode == 'transmit' else 'capture',
                    '--sample-rate', str(fs), '--frames', str(requested), '--device', a.device, *audio_arguments]
                audio = subprocess.Popen(args, stdin=subprocess.PIPE if a.mode == 'transmit' else subprocess.DEVNULL,
                    stdout=subprocess.PIPE if a.mode == 'receive' else subprocess.DEVNULL, stderr=log)
                result['audio_command'] = args
                if mapped_capture:
                    from triad_audio_mapping import MappedCaptureReader
                    capture_reader = MappedCaptureReader(audio.stdout)
            result['preparation_wall_seconds'] = time.perf_counter()-started
            while first < requested:
                n = min(a.chunk_samples, requested-first)
                if clock_control is not None:
                    clock_control.poll(source)
                if a.mode == 'receive':
                    if mapped_capture:
                        from triad_audio_mapping import mapped_phase, rescale_coordinates
                        pcm, native_origin, native_offsets, native_rate = capture_reader.read(n)
                        phase = mapped_phase(native_origin, native_offsets, float(d['data_if_hz']), native_rate)
                        physical_origin, physical_offsets = rescale_coordinates(native_origin, native_offsets, native_rate, fs)
                    else:
                        pcm = np.frombuffer(read_exact(audio.stdout, n*4), dtype='<f4')
                        phase = carrier_phase(first, n, float(d['data_if_hz']), fs)
                    values = pcm * (math.sqrt(2)/a.fixed_gain) * np.exp(-1j*phase)
                    valid = np.ones(n, np.uint8)
                else:
                    values, valid = source.next(n)
                    if len(values) != n: raise EOFError('native source ended before the public calendar')
                if a.mode == 'transmit':
                    phase = carrier_phase(first, n, float(d['data_if_hz']), fs)
                    pcm = (math.sqrt(2)*a.fixed_gain*np.real(values*np.exp(1j*phase))).astype('<f4')
                    if np.max(np.abs(pcm)) >= 1: raise ValueError('fixed playback gain clips; choose a lower gain')
                    audio.stdin.write(pcm.tobytes())
                else:
                    if mapped_capture:
                        receiver.push(first, values, valid, physical_origin=physical_origin, physical_offsets=physical_offsets)
                    else:
                        receiver.push(first, values, valid)
                first += n
            if audio is not None:
                if audio.stdin: audio.stdin.close()
                if audio.wait(timeout=30): raise RuntimeError('native audio stream failed; see stderr log')
            result.update(processed_samples=first, processed_seconds=first/fs,
                          complete=first == total)
            if receiver is not None:
                r = receiver.finish()
                result['receiver'] = r
                if tracking:
                    result['tracking_templates'] = basis.cache_report()
                if result['complete'] and r['complete_observation']:
                    scores = np.asarray(r['bit_scores'], dtype=float).reshape(2)
                    result.update(endpoint_decision(scores, complete=True,
                        simulated=a.mode == 'simulate' and d.get('conditional_gaussian_null_supported', False),
                        helper_enabled=d['helper_enabled'],
                        log_threshold=result['admission_policy']['log_e_threshold']))
            result['status'] = 'complete' if result['complete'] else 'diagnostic_prefix_incomplete'
            if a.mode == 'receive' and (a.follow_system_clock == 'continuous' or tracking):
                result['admitted'] = False
                result['status'] = ('completed_tracking_physical_null_unqualified' if tracking
                    else 'completed_clock_tracking_unqualified') if result['complete'] else 'diagnostic_prefix_incomplete'
        except BaseException as error:
            result.update(status='failed', error=type(error).__name__+': '+str(error))
            raise
        finally:
            if clock_control is not None:
                result['system_clock_follow'] = dict(clock_control.report,
                    association=clock_control.clock.report(),
                    scope='Bounded slow DATA source coordinate; fixed epoch, physical audio NCO and nominal receiver basis. No remote timing inference.')
            if audio is not None and audio.poll() is None:
                audio.terminate()
                try: audio.wait(timeout=3)
                except subprocess.TimeoutExpired: audio.kill(); audio.wait()
            if source is not None: result['source_completion'] = source.close()
            usage = resource.getrusage(resource.RUSAGE_CHILDREN)
            result.update(wall_seconds=time.perf_counter()-started,
                python_cpu_seconds=time.process_time()-cpu,
                child_cpu_seconds=usage.ru_utime+usage.ru_stime-child_before.ru_utime-child_before.ru_stime,
                peak_python_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                peak_child_rss_kib=usage.ru_maxrss)
            seconds = result.get('processed_seconds', 0)
            if seconds: result['all_process_cpu_seconds_per_input_second'] = (result['python_cpu_seconds']+result['child_cpu_seconds'])/seconds
            a.report.write_text(json.dumps(result, indent=2, allow_nan=False, default=lambda v: v.tolist() if isinstance(v,np.ndarray) else str(v))+'\n')
    return result


def main():
    try:
        r = execute()
        print(json.dumps({k:r.get(k) for k in ('status','complete','admitted','candidate_bit','processed_seconds','wall_seconds','all_process_cpu_seconds_per_input_second')}))
        return 0
    except (ValueError, OSError, RuntimeError, EOFError) as error:
        print('triad_continuous: '+str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())

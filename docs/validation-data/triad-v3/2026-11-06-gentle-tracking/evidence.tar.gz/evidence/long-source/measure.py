#!/usr/bin/env python3
"""Complete 512-day coupled-GPS sources, with separate phase/clock comparisons."""
from pathlib import Path
import hashlib,json,math,resource,subprocess,time
import numpy as np
root=Path(__file__).resolve().parent
binary=Path('build/dev-cli/triad_tracking_export').resolve()
records=[]
for name,drift,seed,key,phase in [('gps-plus20-512d',20,43651,72011,0),('gps-minus20-phase-512d',-20,55109,82117,.001)]:
    output=root/name
    command=[str(binary),'--output',str(output),'--rate','.001','--added','1','--sample-rate','1',
             '--sample-rate-denominator','64','--days','512','--data-if','half-rate','--template-ppm','0',
             '--clock-profile','gps-disciplined','--clock-drift-ppm',str(drift),'--seed',str(seed),
             '--key-seed',str(key),'--phase-diffusion',str(phase),'--max-output-bytes',str(256*1024*1024)]
    if phase:command+=['--raw-sources']
    source_sha=hashlib.sha256(Path('tools/triad-tracking-export.cpp').read_bytes()).hexdigest()
    before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.perf_counter()
    run=subprocess.run(command,text=True,capture_output=True,timeout=300)
    generation_wall=time.perf_counter()-started;after=resource.getrusage(resource.RUSAGE_CHILDREN)
    if run.returncode:raise RuntimeError((command,run.stderr))
    manifest=json.loads((output/'manifest.json').read_text())
    if manifest['compiled_driver_sha256']!=source_sha:raise RuntimeError('compiled native driver differs from frozen source')
    metrics=[]
    def compare(signal,nominal):
        s=np.memmap(signal,dtype='<c8',mode='r');t=np.memmap(nominal,dtype='<c8',mode='r')
        if s.shape!=t.shape:raise RuntimeError('paired calendars differ')
        es=et=0.;dot=0j
        for i in range(0,len(s),65536):
            a=np.asarray(s[i:i+65536],dtype=np.complex128);b=np.asarray(t[i:i+65536],dtype=np.complex128)
            es+=np.vdot(a,a).real;et+=np.vdot(b,b).real;dot+=np.vdot(b,a)
        rho=abs(dot)**2/(es*et)
        return dict(signal_energy_seconds=float(es/manifest['sample_rate_hz']),nominal_energy_seconds=float(et/manifest['sample_rate_hz']),
            energy_change_db=10*math.log10(es/et),retained_energy_after_one_complex_gain=float(rho),mismatch_loss_db=-10*math.log10(min(1.,rho)))
    for bit in (0,1):
        item=dict(bit=bit,full_channel_vs_nominal=compare(output/f'signal_bit{bit}.c64',output/f'basis_bit{bit}_ppm0.c64'))
        if phase:item['clock_only_vs_nominal']=compare(output/f'source_warped_bit{bit}.c64',output/f'source_unwarped_bit{bit}.c64')
        metrics.append(item)
    source_after=hashlib.sha256(Path('tools/triad-tracking-export.cpp').read_bytes()).hexdigest()
    if source_sha!=source_after:raise RuntimeError('native source changed during source generation')
    record=dict(name=name,command=command,manifest=manifest,complete_rows=manifest['samples'],
        capture_days=manifest['samples']/manifest['sample_rate_hz']/86400,native_generation_wall_seconds=generation_wall,
        native_generation_child_cpu_seconds=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,metrics=metrics,
        files_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in output.glob('*.c64')})
    records.append(record)
    (root/'results.json').write_text(json.dumps(dict(scope='Complete native encrypted 512-day request with coupled system UTC/monotonic GPS discipline and shared full-waveform None/Off channel; second arm adds declared common phase diffusion. Constant-complex-gain comparison is a waveform mismatch diagnostic, not receiver sensitivity/admission.',records=records),indent=2)+'\n')
    print(name,'capture_days',record['capture_days'],'CPU',record['native_generation_child_cpu_seconds'],
          'mismatchdB',[v['full_channel_vs_nominal']['mismatch_loss_db'] for v in metrics],flush=True)

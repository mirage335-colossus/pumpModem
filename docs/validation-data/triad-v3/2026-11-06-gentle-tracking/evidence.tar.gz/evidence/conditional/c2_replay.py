#!/usr/bin/env python3
"""Focused current-C2 source cohort, using the already qualified MC replayer."""
import json, time
from pathlib import Path
import replay
import torch
torch.set_num_threads(1)
torch.backends.cuda.matmul.allow_tf32=False
torch.set_float32_matmul_precision('highest')
root=replay.ROOT
source=[Path(__file__),Path(replay.__file__),*(root/'tools'/p for p in
    ('triad_multiday_likelihood.py','triad_gaussian_state.py','triad_operational_admission.py'))]
before={str(p):replay.sha(p) for p in source}
out=Path(__file__).with_name('c2-rate001-added1-holdover.json')
if out.exists():raise FileExistsError(out)
r=replay.case(root/'local-evidence/triad-gentle-clock/c2-source/rate001-added1-holdover',
              -41.,821001,out)
after={str(p):replay.sha(p) for p in source}
out.with_name('c2-execution.json').write_text(json.dumps(dict(source_hashes=before,
    source_unchanged=before==after,qualification_valid=r['qualification_valid']),indent=2)+'\n')

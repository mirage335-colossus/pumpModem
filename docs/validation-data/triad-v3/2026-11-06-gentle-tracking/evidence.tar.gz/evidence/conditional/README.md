# Conditional static-lane evidence on complete GPS-disciplined captures

This is an occasional qualification artifact, not a new routine test campaign.
No maintained implementation was changed here. `replay.py` reuses the maintained
`StreamingBankStatistics`, `GaussianStateFilter` and classification functions.
Source and input identities are retained in `execution.json` and each result.
All guards passed. The seven complete waveform passes, paired sampled controls
and conditional Monte Carlo used **7.292 CPU seconds / 7.312 wall seconds** on
one local CPU thread, excluding Python imports.

The receiver's default operational threshold is 21.4933786883. These tests use
that threshold plus ln(6) = **23.2851381575** for a static component which receives
one half of the practical nominal/adaptive mixture and one third of the global
coherence mixture. Thus its evidence contribution is a pointwise lower bound
on the complete practical mixture's evidence. **Its correct-bit rate is not a
guaranteed correct-bit rate of the complete mixture**: another branch can change
the final bit ranking. Root-owned full streaming checks test that separate issue.

Each conditional trial set has 4096 draws per bit and 32768 null draws. The
joint complex Gaussian Gram preserves dependence between both candidate patterns
and all channel/no-clock references. Corrected and nominal cases use exactly the
same projected noise within each fixture. The no-clock reference is the public
zero-rate template, with its unchanged energy and original padding. Results for
different fixtures are not asserted to have identical noise despite reused seeds.
Eight additional actual-sample noise streams per bit/condition/null were processed
through every row; direct FP64 correlations agree with the bulk-FP32 path within
**6.37e-6 log-likelihood units**. These small sampled controls validate numerical
consistency, not rare-event probabilities.

| Complete source | C/N0 dB-Hz | Corrected bit0/bit1 admissions | No-clock bit0/bit1 admissions |
|---|---:|---:|---:|
| Rate .01, +20 ppm GPS | −41 | 3477 / 3449 | 3478 / 3448 |
| Rate .1, +20 ppm GPS | −41 | 3111 / 3146 | 3222 / 3232 |
| Rate .1, −20 ppm, independent key/seed | −41 | 3125 / 3171 | 3225 / 3278 |
| Rate .1, Added ×10, ordinary fixes | −41 | 3261 / 3289 | 3278 / 3297 |
| Rate .1, Added ×10, 24-hour GPS holdover | −41 | 2015 / 2054 | 3283 / 3305 |
| Rate .001, +20 ppm, 514.973-day capture | −60 | 3977 / 3992 | 3977 / 3992 |
| Rate .001, −20 ppm + .001 rad/√s random phase, 514.973 days | −60 | 23 / 25 | 3983 / 3973 |

Every row has zero wrong admissions and zero of 32768 null admissions. Each
result retains misses, raw bit errors and exact two-sided 95% binomial intervals.
The long flat-channel corrected intervals are **96.53–97.59%** and
**96.93–97.92%**. The zero-null empirical upper bound is about 1.13e-4 per tested
endpoint (two-sided 95% interval); it is not a physical or repeated-operation
bound. The conditional normalized likelihood and explicit operational attempt
budget supply the theoretical false-admission accounting under their Gaussian
null assumptions. These results do not qualify colored ADC/ASRC noise.

The last row deliberately changes common channel phase, so its no-clock
comparison also removes that random phase. It does **not** attribute the large
failure to GPS corrections. The clock-only waveform mismatch is separately
recorded by the source owner. Existing finite-channel inference improves this
case but does not close the gap: with predeclared OU coherence 2e6 seconds,
4096-sample blocks (262144 seconds), the fixed OU/static nominal mixture passes
**73/512 and 89/512**, versus static-only **3/512 and 9/512**. All have zero wrong
or null admissions. This customized coherence pair is not the current default
(.5, 2, infinity), and these block results do not model adaptive timing. Its
block-Gaussian statistics processing used **0.497 CPU seconds**.

`phase-ou-comparison.json` retains the original slightly conservative gate
22.186724. `phase-ou-exact-threshold.json` reclassifies its unchanged saved scores
at the exact default gate + ln(2) = 22.1865258688, allowing the one-half nominal
lane weight. Counts did not change; no receiver rerun was needed.

`known-channel-reference.json` uses the same retained Gram with the complete
private channel/clock trajectory as a clearly labeled upper reference. At
−60 dB-Hz both long captures carry E/N0 about **44.293 (16.46 dB)**. With the
ordinary operational gate and no extra practical mixture penalty, the known
channel receiver passes 4061/4096 and 4044/4096 for the flat path; 4059/4096 and
4061/4096 for the varying-phase path. The exact known-channel binary error
probability *without the absent-signal admission gate* is about 1.3e-11–1.8e-11.
These are different metrics. The observed misses mostly reflect the stringent
signal-presence gate; the phase-model gap remains substantial. Computing these
upper references from retained statistics used 0.152 CPU seconds.

Reproduce only when the relevant source, waveform or probability contract changes:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /tmp/triad-weak-env/bin/python local-evidence/triad-gentle-clock/conditional/replay.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /tmp/triad-weak-env/bin/python tools/triad_multiday_block_mc.py \
  --samples local-evidence/triad-gentle-clock/long-source/gps-minus20-phase-512d \
  --output local-evidence/triad-gentle-clock/conditional/phase-ou-comparison.json \
  --cn0 -60 --block-samples 4096 --coherences 2000000,inf --trials 512 \
  --batch-trials 512 --seed 913301 --log-threshold 22.186724 --threads 1
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /tmp/triad-weak-env/bin/python local-evidence/triad-gentle-clock/conditional/oracle_reference.py
```

Use a fresh evidence directory; the main replayer and block tool refuse existing
case outputs. A first wrapper launch had an incorrect repository parent-path
calculation and failed before loading source (`run.log`); the corrected launch
and all seven results are retained in `run-corrected-path.log`. No failed receiver
case was removed. No cloud resources or background processes remain.

## Completion-review followups

`phase128-pilot.json` and `phase128-validation.json` additionally test the existing
128-state circular unit-amplitude phase likelihood. The full source, sample
blocks, C/N0, phase-diffusion parameter and 512-trial noise seed match the OU
comparison. The experimental public mixture now contains **OU 2e6 seconds,
static, and phase128 with equal weights**. It retains the default operational
gate plus ln(2) for the nominal lane. This is an explicit experimental alternative,
not the current default coherence bank or an unbudgeted best-of-models rule.

The 64-trial cost pilot took 1.193 CPU seconds; the 512-trial comparison took
**4.517 CPU seconds**. The phase component alone passed **132/512 and 131/512**;
the fixed three-model mixture passed **110/512 and 116/512**, compared with
OU-only 88/512 and 102/512 and static-only 3/512 and 9/512 on identical block
noise. All wrong-admission and null-admission counts were zero. The mixture's
95% intervals are **18.00–25.30%** and **19.10–26.53%**. The phase algorithm helps,
but does not reach the known-channel reference. This is not proof of the
unknown-channel fundamental limit. Source/input identity guards passed.

Reproduction uses the OU command above with output `phase128-validation.json`,
`--phase-states 128 --phase-diffusion .001`, and the exact
`--log-threshold 22.18652586882134`. The 64-trial pilot uses the same declared
algorithm and a smaller batch; the final run is paired to the existing OU
comparison, not advertised as an independent held-out channel realization.

`c2_replay.py` applies the same static evidence test to the current C2-shaped
native Rate .01, Added ×1, 24-hour holdover fixture. At −41 dB-Hz, corrected
bit0/bit1 results are **3444/4096 and 3497/4096**, against paired no-clock
**3449/4096 and 3498/4096**. The corrected intervals are **82.93–85.19%** and
**84.26–86.44%**; zero wrong admissions and zero of32768 null admissions occurred.
It processes every source row and eight actual-noise streams per condition;
FP32 versus independent FP64 score difference is at most5.18e-6. Source and
input guards pass. Complete processing costs **0.388 CPU seconds**. Thus this
deliberately marginal setting can naturally miss some full streaming trials.

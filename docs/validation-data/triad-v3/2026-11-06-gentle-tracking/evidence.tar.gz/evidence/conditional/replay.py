#!/usr/bin/env python3
"""Paired whole-sample static-lane evidence, not whole adaptive RX qualification."""
import hashlib, json, math, os, sys, time
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
from triad_multiday_likelihood import StreamingBankStatistics, classify_scores
from triad_operational_admission import operational_threshold

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def case(path,cn0,seed,out):
    begin,cpu=time.perf_counter(),time.process_time()
    m=json.loads((path/'manifest.json').read_text());n=m['samples'];fs=m['sample_rate_hz'];v=fs/10**(cn0/10)
    idx=m['template_ppm'].index(0)
    files=[path/f'basis_bit{b}_ppm{idx}.c64' for b in (0,1)]+[path/f'signal_bit{b}.c64' for b in (0,1)]
    ids={str(p):sha(p) for p in [path/'manifest.json',*files]}
    x=[np.memmap(p,mode='r',dtype='<c8',shape=(n,)) for p in files]
    labels=[0]*8+[1]*8+[2]*8+[3]*8+[None]*8
    a=StreamingBankStatistics(sample_rate=fs,samples=n,candidates=1,noise_variance=v,
        signal_count=4,observed_streams=len(labels),precision='fp32',maximum_chunk_samples=4096,
        reduction_samples=1024,memory_limit_bytes=128*1024**2)
    rng=np.random.default_rng(seed);ref=np.zeros((len(labels),2),np.complex128)
    for lo in range(0,n,4096):
        hi=min(n,lo+4096);b=np.stack([p[lo:hi] for p in x[:2]])
        signals=np.stack([p[lo:hi] for p in x[2:]]+[p[lo:hi] for p in x[:2]])
        # Same actual noise for each corrected/nominal pair, independent bits/null.
        z=(rng.standard_normal((24,hi-lo))+1j*rng.standard_normal((24,hi-lo)))*math.sqrt(v/2)
        y=np.concatenate((z[:8],z[8:16],z[:8],z[8:16],z[16:24]))
        for j,label in enumerate(labels):
            if label is not None:y[j]+=signals[label]
        a.push(lo,b[:,None,:],signals,y)
        ref+=y@b.astype(np.complex128).conj().T/v
    s=a.finish();threshold=operational_threshold()['log_e_threshold']+math.log(6)
    sampled=s.observed_scores();fp64=s.static_scores(ref.reshape(-1,2,1))
    results={};raw={}
    for label in (0,1,2,3,None):
        name='null' if label is None else ('corrected' if label<2 else 'nominal')+f'-bit{label%2}'
        trials=32768 if label is None else 4096
        draw=s.draw_correlations(trials=trials,seed=seed+100000+(0 if label is None else label%2),signal_index=label)
        score=s.static_scores(draw['bank_correlations']);raw[name]=score
        start=32 if label is None else label*8
        results[name]=dict(conditional=classify_scores(score,threshold,true_bit=None if label is None else label%2),
            actual_sampled=classify_scores(sampled[start:start+8],threshold,true_bit=None if label is None else label%2))
    paired={}
    for b in (0,1):
        c=raw[f'corrected-bit{b}'];r=raw[f'nominal-bit{b}']
        from scipy.special import logsumexp
        ce=logsumexp(c,axis=-1)-math.log(2);re=logsumexp(r,axis=-1)-math.log(2)
        cp=ce>=threshold;rp=re>=threshold
        paired[str(b)]=dict(corrected_only=int((cp&~rp).sum()),nominal_only=int((rp&~cp).sum()),
            both_pass=int((cp&rp).sum()),both_miss=int((~cp&~rp).sum()),
            log_e_change_quantiles=np.quantile(ce-re,[.01,.5,.99]).tolist())
    after={str(p):sha(p) for p in [path/'manifest.json',*files]}
    report=dict(input=str(path),manifest=m,cn0_db_hz=cn0,seed=seed,results=results,paired=paired,
        default_policy=operational_threshold(),static_component_weight=1/6,
        threshold_static=threshold,statistics=s.metadata,
        actual_sampled_fp32_vs_fp64_max_score_difference=float(abs(sampled-fp64).max()),
        qualification_valid=ids==after,input_hashes=ids,wall_seconds=time.perf_counter()-begin,
        cpu_seconds=time.process_time()-cpu,
        scope='Full-sample static-channel sufficient statistics, both public bit patterns; same-noise corrected/nominal pairs. Static evidence/6 is a pointwise lower bound on equal nominal/adaptive +3-coherence mixture evidence. This is not a whole-mixture correct-bit guarantee, adaptive receiver trial or channel-population reliability. Fixed Gaussian null only; no physical ASRC qualification.')
    out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    np.savez_compressed(out.with_suffix('.npz'),gram=s.gram,observed_correlations=s.observed_correlations,
        fp64_reference_correlations=ref,**raw)
    print(json.dumps(dict(case=path.name,cn0=cn0,cpu=report['cpu_seconds'],
        results={k:v['conditional']['counts'] for k,v in results.items()})),flush=True)
    return report

if __name__=='__main__':
    torch.set_num_threads(1);torch.backends.cuda.matmul.allow_tf32=False;torch.set_float32_matmul_precision('highest')
    base=ROOT/'local-evidence/triad-gentle-clock';out=base/'conditional'
    sources=[Path(__file__),*(ROOT/'tools'/p for p in ('triad_multiday_likelihood.py','triad_gaussian_state.py','triad_operational_admission.py'))]
    before={str(p):sha(p) for p in sources};start=time.perf_counter();cpu=time.process_time()
    cases=[('source-tolerance/rate001-plus20',-41.,811001),('source-tolerance/rate01-plus20',-41.,811101),
        ('source-tolerance/rate01-minus20-validation',-41.,911101),('source-tolerance/rate01-added10-plus20',-41.,811201),
        ('source-tolerance/rate01-added10-no-holdover',-41.,811201),('long-source/gps-plus20-512d',-60.,811301),
        ('long-source/gps-minus20-phase-512d',-60.,911301)]
    for path,cn0,seed in cases:
        target=out/(Path(path).name+'.json')
        if target.exists():raise FileExistsError(target)
        case(base/path,cn0,seed,target)
        if time.process_time()-cpu>120:raise RuntimeError('initial CPU budget reached; completed evidence retained')
    after={str(p):sha(p) for p in sources}
    (out/'execution.json').write_text(json.dumps(dict(source_hashes=before,source_unchanged=before==after,
        cases=cases,cpu_seconds=time.process_time()-cpu,wall_seconds=time.perf_counter()-start),indent=2)+'\n')

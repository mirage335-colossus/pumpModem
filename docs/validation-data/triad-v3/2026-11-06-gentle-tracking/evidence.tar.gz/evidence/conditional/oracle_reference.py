#!/usr/bin/env python3
"""Known channel/phase upper reference from retained exact sampled Grams."""
import json, math, sys, time
from pathlib import Path
import numpy as np
from scipy.special import ndtr
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from triad_multiday_likelihood import BankStatistics, classify_scores
from triad_operational_admission import operational_threshold
started=time.process_time();reports={}
for path in sorted(HERE.glob('*.json')):
    m=json.loads(path.read_text())
    if 'statistics' not in m or 'paired' not in m:continue
    z=np.load(path.with_suffix('.npz'));g=z['gram']
    s=BankStatistics(g,1,4,np.ones(1),z['observed_correlations'],m['statistics'])
    energy=g.diagonal().real[2:4];distance=float(energy.sum()-2*g[2,3].real)
    result={}
    for bit in (0,1,None):
        draw=s.draw_correlations(trials=32768 if bit is None else 4096,
            seed=m['seed']+200000+(2 if bit is None else bit),signal_index=bit)
        scores=2*draw['oracle_correlations'][:,:2].real-energy[None,:]
        result['null' if bit is None else f'bit{bit}']=classify_scores(scores,
            operational_threshold()['log_e_threshold'],true_bit=bit)
    reports[path.stem]=dict(received_energy_over_n0=energy.tolist(),
        squared_codeword_distance_over_n0=distance,
        exact_equal_prior_known_channel_binary_error_probability=float(ndtr(-math.sqrt(max(0,distance)/2))),
        conditional_known_channel_scores=result,
        scope='Known complete channel and phase including private clock trajectory; not an implementable unknown-channel receiver. Same operational gate, no practical-lane penalty. Binary error formula has no absent-signal admission gate.')
(HERE/'known-channel-reference.json').write_text(json.dumps(dict(reports=reports,
    cpu_seconds=time.process_time()-started),indent=2,allow_nan=False)+'\n')

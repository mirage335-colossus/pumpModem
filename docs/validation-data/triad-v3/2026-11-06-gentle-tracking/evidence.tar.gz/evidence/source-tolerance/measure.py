#!/usr/bin/env python3
"""Full native coupled-GPS source versus exact paired no-clock basis.
No generated noise or receiver admission; unchanged shared None/Off channel.
"""
from pathlib import Path
import hashlib,json,math,resource,subprocess,time
import numpy as np
root=Path(__file__).resolve().parent
binary=Path('build/dev-cli/triad_tracking_export').resolve()
records=[]
configs=[('rate001-plus20','.01',1,1,4,20,43651),
         ('rate01-plus20','.1',1,1,4,20,43651),
         ('rate01-minus20-validation','.1',1,1,4,-20,55109),
         ('rate01-added10-plus20','.1',10,4,1,20,43651)]
initial=resource.getrusage(resource.RUSAGE_CHILDREN)
for name,rate,added,num,den,drift,seed in configs:
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    if before.ru_utime+before.ru_stime-initial.ru_utime-initial.ru_stime>80:
        raise RuntimeError('Earlier native cases exhausted bounded campaign CPU before next case')
    output=root/name
    command=[str(binary),'--output',str(output),'--rate',rate,'--added',str(added),'--sample-rate',str(num),
             '--sample-rate-denominator',str(den),'--days','5','--data-if','half-rate','--template-ppm','0',
             '--clock-profile','gps-disciplined','--clock-drift-ppm',str(drift),'--seed',str(seed),
             '--key-seed','72011','--max-output-bytes',str(256*1024*1024)]
    started=time.perf_counter();run=subprocess.run(command,capture_output=True,text=True,timeout=120)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    if run.returncode:
        raise RuntimeError((command,run.stderr))
    manifest=json.loads((output/'manifest.json').read_text());results=[]
    for bit in (0,1):
        signal=np.memmap(output/f'signal_bit{bit}.c64',dtype='<c8',mode='r')
        nominal=np.memmap(output/f'basis_bit{bit}_ppm0.c64',dtype='<c8',mode='r')
        if signal.shape!=nominal.shape:raise RuntimeError('paired calendars differ')
        dot=0j;es=et=0.
        for start in range(0,len(signal),65536):
            s=np.asarray(signal[start:start+65536],dtype=np.complex128)
            t=np.asarray(nominal[start:start+65536],dtype=np.complex128)
            dot+=np.vdot(t,s);es+=np.vdot(s,s).real;et+=np.vdot(t,t).real
        correlation=abs(dot)**2/(es*et)
        results.append(dict(bit=bit,signal_energy_seconds=float(es/manifest['sample_rate_hz']),
            nominal_energy_seconds=float(et/manifest['sample_rate_hz']),
            signal_to_nominal_energy_db=10*math.log10(es/et),
            retained_energy_after_one_complex_gain=float(correlation),
            mismatch_loss_db=-10*math.log10(min(1.,correlation))))
    record=dict(name=name,command=command,manifest=manifest,complete_rows=manifest['samples'],
                capture_days=manifest['samples']/manifest['sample_rate_hz']/86400,
                generation_wall_seconds=time.perf_counter()-started,
                generation_child_cpu_seconds=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
                metrics=results,files_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in output.glob('*.c64')})
    records.append(record)
    (root/'results.json').write_text(json.dumps(dict(scope='Complete native emitted clock-warped signal through shared None/Off channel versus public unwarped exact source, one fitted constant complex gain; no IF-phase omission, no noise/admission assertion. No-clock equivalence reused from native protocol.',records=records),indent=2)+'\n')
    print(name,'days',record['capture_days'],'CPU',record['generation_child_cpu_seconds'],
          'mismatchdB',[x['mismatch_loss_db'] for x in results],flush=True)

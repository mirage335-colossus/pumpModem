#!/usr/bin/env python3
"""Explicit C2 pulse, all other native geometry retained, coupled GPS correction."""
from pathlib import Path
import hashlib,json,math,resource,subprocess,time
import numpy as np
root=Path(__file__).resolve().parent;binary=Path('build/dev-cli/triad_tracking_export').resolve();records=[]
for name,rate,added,num,den,hold in [('rate001-added1-holdover','.01',1,1,4,86400),('rate01-added10-normal','.1',10,4,1,0),('rate01-added10-holdover','.1',10,4,1,86400)]:
 output=root/name;command=[str(binary),'--output',str(output),'--rate',rate,'--added',str(added),'--sample-rate',str(num),'--sample-rate-denominator',str(den),'--days','5','--data-if','half-rate','--template-ppm','0','--pulse-shape','c2','--clock-profile','gps-disciplined','--clock-drift-ppm','20','--gps-holdover-seconds',str(hold),'--seed','43651','--key-seed','72011','--max-output-bytes',str(256*1024*1024)]
 source_sha=hashlib.sha256(Path('tools/triad-tracking-export.cpp').read_bytes()).hexdigest();before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter();run=subprocess.run(command,text=True,capture_output=True,timeout=120);wall=time.perf_counter()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN);assert run.returncode==0,run.stderr
 m=json.loads((output/'manifest.json').read_text());assert m['pulse_shape']=='rrc-025-span8-c2-tail2';assert m['compiled_driver_sha256']==source_sha;metrics=[]
 for bit in (0,1):
  s=np.memmap(output/f'signal_bit{bit}.c64',dtype='<c8',mode='r');t=np.memmap(output/f'basis_bit{bit}_ppm0.c64',dtype='<c8',mode='r');es=et=0.;dot=0j
  for i in range(0,len(s),65536):
   a=np.asarray(s[i:i+65536],dtype=np.complex128);b=np.asarray(t[i:i+65536],dtype=np.complex128);es+=np.vdot(a,a).real;et+=np.vdot(b,b).real;dot+=np.vdot(b,a)
  rho=abs(dot)**2/(es*et);metrics.append(dict(bit=bit,signal_energy_seconds=float(es/m['sample_rate_hz']),nominal_energy_seconds=float(et/m['sample_rate_hz']),energy_change_db=10*math.log10(es/et),retained_energy_after_one_complex_gain=float(rho),mismatch_loss_db=-10*math.log10(min(1.,rho))))
 assert source_sha==hashlib.sha256(Path('tools/triad-tracking-export.cpp').read_bytes()).hexdigest()
 record=dict(name=name,command=command,manifest=m,complete_rows=m['samples'],capture_days=m['samples']/m['sample_rate_hz']/86400,native_generation_wall_seconds=wall,native_generation_child_cpu_seconds=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,metrics=metrics,files_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in output.glob('*.c64')});records.append(record)
 (root/'results.json').write_text(json.dumps(dict(scope='Explicit C2 pulse used by productionauto shape; other geometryunchanged, complete GPSwarped source throughsharedNoneOff channel vsnominalsource; retainsfullIFphase, no noise/admissionclaim',records=records),indent=2)+'\n');print(name,'capture_days',record['capture_days'],'CPU',record['native_generation_child_cpu_seconds'],'mismatchdB',[v['mismatch_loss_db'] for v in metrics],flush=True)

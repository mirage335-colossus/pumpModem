#!/usr/bin/env python3
"""One prospective named-case savings experiment; no maintained API changes.

Freeze on the measurement host, then run the sealed plan once. Each protocol
arm receives a fresh Python process and the same native target and decision
policy. Three blocked pairs provide actual costs, not a whole-suite forecast.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time
import traceback

SCHEMA = "triad-native-matched-savings-v1"
SOURCE_NAMES = ("triad_perf_native.py", "triad_perf_adaptive.py",
                "triad_perf_conditional.py", "triad_perf_hardware.py",
                "triad-performance-native-cases.json")
ORDERS = (("abbreviated", "direct"), ("direct", "abbreviated"),
          ("abbreviated", "direct"))
THREAD_ENV = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".writing")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def imports(root):
    sys.path.insert(0, str(Path(root).resolve() / "tools"))
    import triad_perf_native as native
    import triad_perf_adaptive as adaptive
    return native, adaptive


def seal(value):
    value = {k: v for k, v in value.items() if k != "plan_sha256"}
    return {**value, "plan_sha256": digest(value)}


def verify(plan):
    if plan != seal(plan) or plan.get("schema") != SCHEMA:
        raise ValueError("invalid frozen plan")
    if plan["orders"] != [list(v) for v in ORDERS]:
        raise ValueError("changed predeclared block order")
    if sha(__file__) != plan["script_sha256"]:
        raise ValueError("experiment source changed")
    if sys.version != plan["python_version"] or {n: os.environ.get(n) for n in THREAD_ENV} != plan["thread_environment"]:
        raise ValueError("Python or numerical thread environment changed")
    root = Path(plan["source_root"])
    for name, expected in plan["helper_sha256"].items():
        if sha(root / "tools" / name) != expected:
            raise ValueError("measurement dependency changed: " + name)
    for name in ("reference", "candidate"):
        if sha(plan["binaries"][name]) != plan["binary_sha256"][name]:
            raise ValueError("native binary changed: " + name)
    if sha(plan["anchor_path"]) != plan["anchor_file_sha256"]:
        raise ValueError("historical anchor changed")
    native, adaptive = imports(root)
    if native.environment_identity(plan["threads"]) != plan["environment"]:
        raise ValueError("measurement host/allocation changed")
    current_case = next(c for c in native.scenarios() if c["id"] == "native-vlf-low-cn0")
    if current_case != plan["abbreviated_case"]:
        raise ValueError("native target case changed")
    direct = dict(current_case)
    direct.pop("training_seconds")
    if direct != plan["direct_case"]:
        raise ValueError("direct representation changed more than training metadata")
    for source in ("reference", "candidate"):
        a = native._argv(plan["binaries"][source], current_case, current_case["target_seconds"], 71231, plan["threads"])
        b = native._argv(plan["binaries"][source], direct, direct["target_seconds"], 71231, plan["threads"])
        if a != b or a != plan["full_target_argv"][source]:
            raise ValueError("physical full target argv differs")
    policy = adaptive.AdaptivePolicy(stopping_rule="decision", **adaptive.regression_profile(plan["profile"]))
    if asdict(policy) != {**plan["policy"], "looks": tuple(plan["policy"]["looks"])}:
        raise ValueError("regression decision policy changed")
    anchor = json.loads(Path(plan["anchor_path"]).read_text())
    identities = {n: native.identity(b, current_case, plan["threads"]) for n, b in plan["binaries"].items()}
    if not native.anchor_compatible(anchor, identities, current_case):
        raise ValueError("abbreviated history is incompatible; experiment must not qualify it")
    return native, policy, anchor


def freeze(args):
    started = time.monotonic()
    if not math.isfinite(args.budget_seconds) or not 0 < args.budget_seconds <= 1800 or args.threads != 1:
        raise ValueError("experiment requires one native thread and a budget in (0,1800]")
    root = args.source_root.resolve()
    native, adaptive = imports(root)
    case = next(c for c in native.scenarios() if c["id"] == "native-vlf-low-cn0")
    direct = dict(case)
    direct.pop("training_seconds")
    binaries = {"reference": str(args.reference_binary.resolve()), "candidate": str(args.binary.resolve())}
    policy = adaptive.AdaptivePolicy(stopping_rule="decision", **adaptive.regression_profile(args.profile))
    plan = seal({
        "schema": SCHEMA, "source_root": str(root), "script_sha256": sha(__file__),
        "helper_sha256": {n: sha(root / "tools" / n) for n in SOURCE_NAMES},
        "binaries": binaries, "binary_sha256": {n: sha(v) for n, v in binaries.items()},
        "anchor_path": str(args.anchor.resolve()), "anchor_file_sha256": sha(args.anchor),
        "environment": native.environment_identity(args.threads), "threads": args.threads,
        "python_version": sys.version, "thread_environment": {n: os.environ.get(n) for n in THREAD_ENV},
        "profile": args.profile, "policy": {**asdict(policy), "looks": list(policy.looks)},
        "abbreviated_case": case, "direct_case": direct,
        "full_target_argv": {n: native._argv(v, case, case["target_seconds"], 71231, args.threads)
                             for n, v in binaries.items()},
        "orders": [list(v) for v in ORDERS], "budget_seconds": args.budget_seconds,
        "cache_policy": "fresh Python arm and fresh native process for every CLI call; ordinary OS page cache retained; no flush",
        "timing_boundary": "parent Popen before fresh arm interpreter through exit/reap after result serialization; includes imports, configuration probes, native startup/generation/channel/receiver/output, pilots, calibration and required endpoints",
        "shared_cost": "freeze function timing is in a separate plan-bound receipt; run timing includes initial verification and controller orchestration, reported separately from arm costs; no qualification or hardware stress probes rerun inside arms",
        "comparability": "same full target argv template for an equal seed, binaries, allocation and declared per-test decision profile; each arm stops using its own allowed sample count; abbreviated support remains conditional on its exact qualified historical model and endpoint",
        "input_matching": "Each unchanged adapter retains its own frozen seed schedule. Native generation does not match every noise realization across protocols. Full-target geometry, actual work counters and duration-independent execution regimes are checked across arms; native candidate/reference numerical agreement is required within every arm.",
        "stopping": "three fixed blocked protocol pairs, no interim cost-savings decisions, halt on any nonpassing or invalid arm; never retry",
        "interpretation": "named-case observed cost comparison only; no whole-suite savings, architecture transfer, universal future bound or unconditional model-error confidence claim",
        "cost_interval": "fixed-three paired arithmetic cost differences and log cost ratios, pointwise95% Student-t intervals conditional on stationary independent block effects and approximate normality; not a sequential decision",
    })
    verify(plan)
    if args.output.exists():
        raise ValueError("refusing to overwrite frozen plan")
    save(args.output, plan)
    elapsed = time.monotonic() - started
    save(args.output.with_name(args.output.name + ".freeze-receipt.json"), {
        "schema": SCHEMA, "plan_sha256": plan["plan_sha256"], "plan_file_sha256": sha(args.output),
        "freeze_function_seconds": elapsed,
        "scope": "freeze function entry before validation/imports through completed plan write; excludes interpreter startup/argument parsing, this timing-receipt serialization and final console output",
    })
    print(json.dumps({"plan_sha256": plan["plan_sha256"], "target": case["id"], "blocks": len(ORDERS)}))


def arm(args):
    plan = json.loads(args.plan.read_text())
    output = args.output
    evidence = {"schema": SCHEMA, "arm": args.arm, "plan_sha256": plan["plan_sha256"], "status": "running"}
    started = time.monotonic()
    save(output, evidence)
    try:
        native, policy, anchor = verify(plan)
        case = plan["abbreviated_case"] if args.arm == "abbreviated" else plan["direct_case"]
        result = native.measure_native_case(plan["binaries"]["reference"], plan["binaries"]["candidate"],
            case, policy, threads=plan["threads"], deadline=time.monotonic() + args.budget_seconds,
            validation_mode="routine", anchor=anchor if args.arm == "abbreviated" else None,
            freeze_callback=lambda value: save(output.with_name(output.stem + ".forecast.json"), value))
        evidence["result"] = result
        native2, _, _ = verify(plan)
        if native2 is not native:
            raise ValueError("native helper identity changed")
        evidence["status"] = ("passed" if result["prediction_valid"] and result["comparison"]["gate"] == "pass"
                              else "incomparable")
    except BaseException as exc:
        evidence.update(status="error", error=str(exc), traceback=traceback.format_exc())
    evidence["inner_arm_seconds"] = time.monotonic() - started
    save(output, evidence)
    return 0 if evidence["status"] == "passed" else 2


def run(args):
    started = time.monotonic()
    plan = json.loads(args.plan.read_text())
    verify(plan)
    output = args.output
    output.mkdir(parents=True, exist_ok=False)
    deadline = started + plan["budget_seconds"]
    initial_setup_seconds = time.monotonic() - started
    freeze_path = args.plan.with_name(args.plan.name + ".freeze-receipt.json")
    freeze_receipt = json.loads(freeze_path.read_text()) if freeze_path.exists() else None
    if freeze_receipt is not None and (freeze_receipt["plan_sha256"] != plan["plan_sha256"] or
                                      freeze_receipt["plan_file_sha256"] != sha(args.plan)):
        raise ValueError("freeze timing receipt belongs to another plan")
    report = {"schema": SCHEMA, "plan_sha256": plan["plan_sha256"], "status": "running", "blocks": [],
              "initial_setup_seconds": initial_setup_seconds, "freeze_timing_receipt": freeze_receipt,
              "outer_timing_scope": "run function entry before plan load/verification through completed inference and result construction; excludes interpreter startup/argument parsing, final summary serialization and console output; complete arm subprocess startup/finalization is inside each arm wall",
              "shared_cost_policy": "freeze and comparison-controller costs are experimental shared overhead, retained separately; all fresh arm setup/verification is included in each measured protocol arm"}
    save(output / "summary.json", report)
    for index, order in enumerate(ORDERS):
        block = {"index": index, "order": list(order), "arms": {}}
        report["blocks"].append(block)
        for name in order:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("experiment budget exhausted")
            path = output / f"block-{index+1:02d}-{name}.json"
            argv = [sys.executable, str(Path(__file__).resolve()), "_arm", "--plan", str(args.plan.resolve()),
                    "--arm", name, "--output", str(path.resolve()), "--budget-seconds", str(remaining)]
            start = time.perf_counter()
            with path.with_suffix(".stdout.log").open("wb") as stdout, path.with_suffix(".stderr.log").open("wb") as stderr:
                process = subprocess.Popen(argv, stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    code = process.wait(timeout=remaining)
                except BaseException:
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        pass
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=3)
                    raise
            elapsed = time.perf_counter() - start
            row = json.loads(path.read_text()) if path.exists() else None
            block["arms"][name] = {"wall_seconds": elapsed, "returncode": code,
                                    "record": str(path), "record_sha256": sha(path) if path.exists() else None,
                                    "status": row.get("status") if row else "absent"}
            report["wall_seconds"] = time.monotonic() - started
            save(output / "summary.json", report)
            if code or not row or row["status"] != "passed":
                report.update(status="incomparable", reason="an arm did not establish its configured full-target pass")
                save(output / "summary.json", report)
                return 2
        a = json.loads(Path(block["arms"]["abbreviated"]["record"]).read_text())["result"]
        b = json.loads(Path(block["arms"]["direct"]["record"]).read_text())["result"]
        full = {n: next(h["actual"] for h in a["current_validation"]["holds"] if h["source"] == n)
                for n in ("reference", "candidate")}
        keys = ("regime", "counter_summary", "samples_per_trial", "total_rows", "batch_trials")
        for n in ("reference", "candidate"):
            for row in b["raw"][n]:
                if any(full[n][k] != row[k] for k in keys):
                    raise ValueError("direct/abbreviated full-target work differs: " + n)
        block["matching_full_target_work"] = True
        verify(plan)
    from scipy.stats import t
    differences = [b["arms"]["direct"]["wall_seconds"] - b["arms"]["abbreviated"]["wall_seconds"] for b in report["blocks"]]
    logs = [math.log(b["arms"]["abbreviated"]["wall_seconds"] / b["arms"]["direct"]["wall_seconds"]) for b in report["blocks"]]
    def interval(values):
        point = statistics.fmean(values)
        half = float(t.ppf(.975, len(values)-1)) * statistics.stdev(values) / math.sqrt(len(values))
        return point, [point-half, point+half]
    diff, diff_ci = interval(differences)
    log_ratio, log_ci = interval(logs)
    observed = {n: math.fsum(b["arms"][n]["wall_seconds"] for b in report["blocks"]) for n in ("direct", "abbreviated")}
    report.update(status="measured_comparable_named_case", wall_seconds=time.monotonic()-started,
        observed_protocol_wall_seconds=observed,
        observed_saved_seconds=observed["direct"]-observed["abbreviated"],
        observed_saved_fraction=1-observed["abbreviated"]/observed["direct"],
        paired_mean_saved_seconds=diff, paired_mean_saved_seconds_95_interval=diff_ci,
        geometric_abbreviated_over_direct_cost_ratio=math.exp(log_ratio),
        geometric_cost_ratio_95_interval=[math.exp(v) for v in log_ci],
        assurance_scope=plan["comparability"], limitations=plan["interpretation"],
        qualification_cost="previously incurred; excluded from routine costs and not amortized by this experiment",
        controller_overhead_seconds=time.monotonic()-started-math.fsum(observed.values()))
    report["controller_after_initial_setup_seconds"] = report["controller_overhead_seconds"] - initial_setup_seconds
    report["measured_experiment_seconds_including_recorded_freeze"] = (
        report["wall_seconds"] + freeze_receipt["freeze_function_seconds"] if freeze_receipt is not None else None)
    save(output / "summary.json", report)
    print(json.dumps({k: report[k] for k in ("status", "wall_seconds", "observed_saved_seconds", "observed_saved_fraction", "paired_mean_saved_seconds_95_interval")}))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    prepare = sub.add_parser("freeze")
    prepare.add_argument("--source-root", type=Path, required=True)
    prepare.add_argument("--binary", type=Path, required=True)
    prepare.add_argument("--reference-binary", type=Path, required=True)
    prepare.add_argument("--anchor", type=Path, required=True)
    prepare.add_argument("--threads", type=int, default=1)
    prepare.add_argument("--profile", choices=("normal", "ci", "strict"), default="normal")
    prepare.add_argument("--budget-seconds", type=float, default=900.)
    prepare.add_argument("--output", type=Path, required=True)
    execute = sub.add_parser("run")
    execute.add_argument("--plan", type=Path, required=True)
    execute.add_argument("--output", type=Path, required=True)
    child = sub.add_parser("_arm")
    child.add_argument("--plan", type=Path, required=True)
    child.add_argument("--arm", choices=("direct", "abbreviated"), required=True)
    child.add_argument("--output", type=Path, required=True)
    child.add_argument("--budget-seconds", type=float, required=True)
    args = parser.parse_args()
    try:
        if args.mode == "freeze":
            freeze(args)
            return 0
        return run(args) if args.mode == "run" else arm(args)
    except BaseException as exc:
        if args.mode == "run" and (args.output / "summary.json").exists():
            path = args.output / "summary.json"
            report = json.loads(path.read_text())
            report.update(status="error", error=str(exc), traceback=traceback.format_exc())
            save(path, report)
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

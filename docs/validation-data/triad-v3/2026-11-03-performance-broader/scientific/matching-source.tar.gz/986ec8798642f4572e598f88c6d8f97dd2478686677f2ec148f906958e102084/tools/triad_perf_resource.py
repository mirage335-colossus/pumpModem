#!/usr/bin/env python3
"""Qualify one actual native memory transition; directly time its routine targets.

The target is a complete native grouped-statistics export, from process creation
through exit after output finalization. Validation hashes and scratch removal
are harness overhead, retained separately. No disk-cache flush or durable fsync
is requested. Paired/sequential channels are separate cost regimes: a fitted
duration law is never carried through their memory boundary.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = Path(__file__).with_name("triad-performance-resource.json")
SCHEMA = "triad-performance-resource-v1"
ANCHOR_SCHEMA = "triad-performance-resource-anchor-v1"
CONTRACT = "complete-grouped-export-separate-memory-regimes-v1"
REGIMES = ("paired", "sequential")
MIB = 1024 * 1024
FILES = ("group_gram.c128", "group_mean.c128", "intervals.u64", "valid_rows.u64",
         "signal_energy.f64", "group_observation.c128", "received_energy.f64")


class ResourcePerformanceError(RuntimeError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(MIB), b""):
            h.update(part)
    return h.hexdigest()


def sealed(value, field="record_sha256"):
    result = {k: v for k, v in value.items() if k != field}
    return {**result, field: digest(result)}


def verify_seal(value, field="record_sha256"):
    return isinstance(value, dict) and value.get(field) == digest({k: v for k, v in value.items() if k != field})


def load_config(path=CONFIG_PATH):
    value = json.loads(Path(path).read_text())
    if (value.get("schema") != "triad-performance-resource-config-v1" or
            value.get("training_seconds") != [32, 48] or value.get("target_seconds") != 64 or
            value.get("training_replicates") != 5 or value.get("qualification_looks") != [3, 5, 9, 17] or
            value.get("qualification_alpha") != .05 or value.get("model_relative_error_limit") != .10):
        raise ResourcePerformanceError("unknown resource qualification contract")
    return value


def implementation_identity():
    return {"measurement_contract": CONTRACT, "adapter_sha256": file_sha(__file__),
            "adaptive_sha256": file_sha(Path(__file__).with_name("triad_perf_adaptive.py")),
            "native_environment_helper_sha256": file_sha(Path(__file__).with_name("triad_perf_native.py")),
            "hardware_environment_helper_sha256": file_sha(Path(__file__).with_name("triad_perf_hardware.py")),
            "config_sha256": file_sha(CONFIG_PATH)}


def binary_identity(binary, source_root, threads=1):
    from triad_perf_native import environment_identity
    if threads != 1:
        raise ResourcePerformanceError("native grouped exporter is currently serial; use --threads 1")
    root = Path(source_root).resolve()
    paths = [root / "tools/triad-long.cpp"]
    paths += sorted((root / "src").glob("triad*.cpp"))
    paths += sorted((root / "include/datapump").glob("triad*.hpp"))
    return {"binary_sha256": file_sha(binary), "environment": environment_identity(threads),
            "declared_source_sha256": {str(p.relative_to(root)): file_sha(p) for p in paths if p.is_file()},
            "source_binding_scope": "Exact executable bytes; declared checkout hashes are provenance, not a reconstructed compiler dependency closure.",
            "arithmetic": "native complex128/float64", "backend": "cpu"}


def argv_for(binary, config, seconds, seed, memory_mib, output, threads=1):
    if (seconds not in (*config["training_seconds"], config["target_seconds"]) or
            isinstance(seed, bool) or not isinstance(seed, int) or seed < 0 or
            isinstance(memory_mib, bool) or not isinstance(memory_mib, int) or memory_mib < 1 or threads != 1):
        raise ResourcePerformanceError("invalid native resource workload")
    return [str(Path(binary).resolve()), *config["args"], "--seconds", str(seconds),
            "--seed", str(seed), "--threads", str(threads), "--memory-mib", str(memory_mib),
            "--output", str(output)]


def work_record(manifest, config, memory_mib, mode):
    ex = manifest["grouped_export_execution"]
    rows = manifest["sample_count"]
    block = manifest["block_samples"]
    if (manifest.get("format") != "triad-group-block-stats-v1" or not manifest.get("stats_noisy") or
            mode not in REGIMES or ex["channel_pass_mode"] != mode or
            ex["basis_synthesis_passes"] != (1 if mode == "paired" else 2) or
            ex["worker_threads_used"] != 1 or ex["bounded_workspace_bytes"] > memory_mib * MIB or
            rows < config["chunk_samples"] or manifest["channel_samples"] != rows or
            manifest["group_count"] != config["group_count"] or manifest["dimension"] != config["dimension"] or
            manifest["block_count"] != (rows + block - 1) // block):
        raise ResourcePerformanceError("native export did not execute the declared complete memory regime")
    regime = {"mode": mode, "basis_synthesis_passes": ex["basis_synthesis_passes"],
              "memory_mib": memory_mib, "bounded_workspace_bytes": ex["bounded_workspace_bytes"],
              "chunk_samples": config["chunk_samples"], "block_samples": block,
              "group_count": manifest["group_count"], "dimension": manifest["dimension"],
              "candidate_count": manifest["candidate_count"], "sample_rate": manifest["sample_rate"],
              "channel_tail_samples": manifest["channel_tail_samples"], "worker_threads_used": 1,
              "candidates": manifest["candidates"], "groups": manifest["groups"],
              "arithmetic": "complex128", "stats_noisy": True}
    # Derived work counters are distinguished from the native branch counters.
    work = {"sample_count": rows, "source_samples": manifest["source_samples"],
            "block_count": manifest["block_count"], "chunks_per_channel": math.ceil(rows / config["chunk_samples"]),
            "channel_passes": 2, "channel_rows": 2 * rows,
            "basis_values": rows * manifest["group_count"] * manifest["dimension"] * ex["basis_synthesis_passes"],
            "gram_terms": rows * manifest["group_count"] * manifest["dimension"] ** 2,
            "projection_terms": 2 * rows * manifest["group_count"] * manifest["dimension"],
            "file_bytes": sum(manifest["file_sizes"].values()),
            "derivation": "Counts follow emitted complete rows, group dimensions and native basis-pass counter; not CPU instruction counts."}
    return regime, work


def run_export(binary, config, seconds, seed, memory_mib, mode, directory, *, deadline=None, threads=1):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix="export-", dir=directory)) / "output"
    argv = argv_for(binary, config, seconds, seed, memory_mib, output, threads)
    timeout = 120. if deadline is None else min(120., deadline - time.monotonic())
    if timeout <= 0:
        shutil.rmtree(output.parent)
        raise TimeoutError("resource workload deadline exhausted")
    outer = time.perf_counter()
    try:
        start = time.perf_counter()
        result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        elapsed = time.perf_counter() - start
        if result.returncode:
            raise ResourcePerformanceError(f"native resource export exited {result.returncode}: {result.stderr[-1600:]}")
        manifest = json.loads((output / "manifest.json").read_text())
        regime, work = work_record(manifest, config, memory_mib, mode)
        hashes = {}
        if set(manifest["file_sizes"]) != set(FILES):
            raise ResourcePerformanceError("unknown grouped statistics file set")
        for name in FILES:
            path = output / name
            if path.stat().st_size != manifest["file_sizes"][name]:
                raise ResourcePerformanceError("grouped statistics size differs from native manifest")
            hashes[name] = file_sha(path)
        record = {"requested_seconds": seconds, "seed": seed, "argv": argv,
                  "argv_sha256": digest(argv), "full_test_wall_seconds": elapsed,
                  "timing_boundary": "Popen/run to complete process exit; includes native generation, two channel passes, grouped preparation, writes and native finalization; excludes validation hashes and scratch cleanup",
                  "regime": regime, "work": work, "file_sha256": hashes,
                  "file_sizes": manifest["file_sizes"], "manifest_sha256": file_sha(output / "manifest.json"),
                  "native_execution": manifest["grouped_export_execution"],
                  "output_semantics": "all emitted sufficient-statistic binary files retained by digest; no receiver scoring or GPU execution"}
    finally:
        cleanup_start = time.perf_counter()
        shutil.rmtree(output.parent)
        cleanup = time.perf_counter() - cleanup_start
    record["harness_cleanup_seconds"] = cleanup
    record["harness_wall_seconds"] = time.perf_counter() - outer
    return sealed(record)


def compare_outputs(a, b, *, across_regimes=False):
    if a["seed"] != b["seed"] or a["requested_seconds"] != b["requested_seconds"]:
        raise ResourcePerformanceError("output comparison requires matched physical seeds and duration")
    if a["file_sizes"] != b["file_sizes"] or a["file_sha256"] != b["file_sha256"]:
        raise ResourcePerformanceError("paired exports differ in actual sufficient-statistic bytes")
    ignore = {"mode", "basis_synthesis_passes", "memory_mib", "bounded_workspace_bytes"} if across_regimes else set()
    if ({k: v for k, v in a["regime"].items() if k not in ignore} !=
            {k: v for k, v in b["regime"].items() if k not in ignore}):
        raise ResourcePerformanceError("paired exports changed computational geometry")
    return {"byte_identical": True, "files": list(FILES), "across_memory_regimes": across_regimes}


def bracket(pilot):
    if pilot["regime"]["mode"] != "paired":
        raise ResourcePerformanceError("memory bracket needs a paired pilot")
    threshold = pilot["native_execution"]["bounded_workspace_bytes"]
    result = {"paired": math.ceil(threshold / MIB), "sequential": (threshold - 1) // MIB}
    if result["sequential"] < 1 or result["paired"] == result["sequential"]:
        raise ResourcePerformanceError("no integer-MiB memory bracket")
    return result


def forecast(training, target_rows, config):
    a, b = sorted(training, key=lambda r: r["work"]["sample_count"])
    if (a["regime"] != b["regime"] or a["requested_seconds"] != config["training_seconds"][0] or
            b["requested_seconds"] != config["training_seconds"][1]):
        raise ResourcePerformanceError("duration fit crossed a resource/algorithm regime")
    x0, x1 = a["work"]["sample_count"], b["work"]["sample_count"]
    if not 0 < x0 < x1 < target_rows or target_rows / x1 > config["maximum_extrapolation"]:
        raise ResourcePerformanceError("duration fit exceeds qualified row geometry")
    slope = (b["full_test_wall_seconds"] - a["full_test_wall_seconds"]) / (x1 - x0)
    estimate = b["full_test_wall_seconds"] + slope * (target_rows - x1)
    if slope < 0 or estimate <= 0 or not math.isfinite(estimate):
        raise ResourcePerformanceError("duration forecast is nonphysical or unresolved")
    return {"full_test_wall_seconds": estimate, "seconds_per_row": slope,
            "intercept_seconds": a["full_test_wall_seconds"] - slope * x0,
            "target_rows": target_rows, "regime_sha256": digest(a["regime"]),
            "training_record_sha256": [a["record_sha256"], b["record_sha256"]]}


def arithmetic_interval(values, alpha):
    from scipy.stats import t
    if len(values) < 3 or any(not math.isfinite(x) or x <= 0 for x in values):
        raise ResourcePerformanceError("arithmetic interval requires three finite positive outer observations")
    point = statistics.mean(values)
    half = float(t.ppf(1 - alpha / 2, len(values) - 1)) * statistics.stdev(values) / math.sqrt(len(values))
    return {"point_seconds": point, "interval_seconds": [point - half, point + half],
            "sample_count": len(values), "alpha": alpha, "estimand": "arithmetic mean complete export wall time"}


def qualification(predictions, actual, config):
    """Rectangular component CIs retain training and holdout mean uncertainty."""
    if len(actual) not in config["qualification_looks"]:
        raise ResourcePerformanceError("qualification inspected outside its fixed look schedule")
    # Two regimes, each with one frozen training interval and four possible
    # holdout intervals. Count the shared training uncertainty once.
    training_alpha = config["qualification_alpha"] / (2 * 2)
    holdout_alpha = training_alpha / len(config["qualification_looks"])
    predicted = arithmetic_interval(predictions, training_alpha)
    observed = arithmetic_interval(actual, holdout_alpha)
    p0, p1 = predicted["interval_seconds"]
    a0, a1 = observed["interval_seconds"]
    bounds = [a0 / p1, a1 / p0] if p0 > 0 and a0 > 0 else [0., None]
    allowance = config["model_relative_error_limit"]
    if bounds[1] is None:
        status = "inconclusive"
    elif bounds[0] >= 1 - allowance and bounds[1] <= 1 + allowance:
        status = "validated"
    elif bounds[1] < 1 - allowance or bounds[0] > 1 + allowance:
        status = "invalid"
    else:
        status = "inconclusive"
    return {"status": status, "forecast_mean": predicted, "actual_mean": observed,
            "actual_over_frozen_forecast_mean_interval": bounds,
            "allowed_ratio_interval": [1 - allowance, 1 + allowance],
            "family_error_budget": config["qualification_alpha"],
            "conditional_assumptions": "Independent stationary outer arithmetic runtimes with approximately normal mean inference; separate uncertainty in frozen training and independent full holds. Not a future-run bound.",
            "ledger": {"regimes": 2, "frozen_training_alpha_per_regime": training_alpha,
                       "holdout_alpha_per_regime_look": holdout_alpha,
                       "holdout_looks": config["qualification_looks"],
                       "total_alpha": 2 * (training_alpha + len(config["qualification_looks"]) * holdout_alpha)}}


def _save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def _target_rows(small, large, config):
    # Same fixed sample rate, tail, source tile geometry and padding. This is
    # tested prospectively against every holdout's emitted row count.
    ratio = ((config["target_seconds"] - config["training_seconds"][1]) /
             (config["training_seconds"][1] - config["training_seconds"][0]))
    rows = large["work"]["sample_count"] + ratio * (large["work"]["sample_count"] - small["work"]["sample_count"])
    if rows != int(rows):
        raise ResourcePerformanceError("noninteger full-target row prediction")
    return int(rows)


def qualify(binary, source_root, output, *, deadline=None, threads=1, config=None):
    config = load_config() if config is None else config
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    identity = binary_identity(binary, source_root, threads)
    pilot = run_export(binary, config, 32, config["seed"], config["pilot_memory_mib"], "paired", out,
                       deadline=deadline, threads=threads)
    budgets = bracket(pilot)
    training = {r: [] for r in REGIMES}
    comparisons = []
    for i in range(config["training_replicates"]):
        pair = {r: [] for r in REGIMES}
        for seconds in config["training_seconds"]:
            current = {}
            for mode in (REGIMES if i % 2 == 0 else REGIMES[::-1]):
                current[mode] = run_export(binary, config, seconds, config["seed"] + 1000 + i * 10 + seconds,
                                           budgets[mode], mode, out, deadline=deadline, threads=threads)
                pair[mode].append(current[mode])
            comparisons.append(compare_outputs(current["paired"], current["sequential"], across_regimes=True))
        for mode in REGIMES:
            training[mode].append(pair[mode])
    targets = {mode: _target_rows(*training[mode][0], config) for mode in REGIMES}
    predictions = {mode: [forecast(pair, targets[mode], config) for pair in training[mode]] for mode in REGIMES}
    frozen = sealed({"schema": SCHEMA, "contract": CONTRACT, "implementation": implementation_identity(),
                     "identity": identity, "config": config, "budgets_mib": budgets,
                     "training": training, "predictions": predictions,
                     "timing_boundary": pilot["timing_boundary"],
                     "held_seed_base": config["seed"] + 100000,
                     "frozen_before_independent_full_work": True})
    _save(out / "frozen.json", frozen)
    holds = {mode: [] for mode in REGIMES}
    looks = []
    for i in range(config["qualification_looks"][-1]):
        current = {}
        for mode in (REGIMES if i % 2 == 0 else REGIMES[::-1]):
            row = run_export(binary, config, config["target_seconds"], config["seed"] + 100000 + i,
                             budgets[mode], mode, out, deadline=deadline, threads=threads)
            if (row["work"]["sample_count"] != targets[mode] or
                    digest(row["regime"]) != predictions[mode][0]["regime_sha256"]):
                raise ResourcePerformanceError("full holdout changed the frozen row geometry or memory regime")
            holds[mode].append(row); current[mode] = row
        comparisons.append(compare_outputs(current["paired"], current["sequential"], across_regimes=True))
        if i + 1 in config["qualification_looks"]:
            checks = {mode: qualification([p["full_test_wall_seconds"] for p in predictions[mode]],
                                         [r["full_test_wall_seconds"] for r in holds[mode]], config) for mode in REGIMES}
            looks.append({"count": i + 1, "regimes": checks})
            _save(out / "progress.json", {"frozen_sha256": frozen["record_sha256"], "holds": holds, "looks": looks})
            if all(c["status"] == "validated" for c in checks.values()) or any(c["status"] == "invalid" for c in checks.values()):
                break
    states = {r["status"] for r in looks[-1]["regimes"].values()}
    status = "validated" if states == {"validated"} else "invalid" if "invalid" in states else "inconclusive"
    anchor = sealed({"schema": ANCHOR_SCHEMA, "status": status, "frozen": frozen,
                     "pilot": pilot, "full_holdouts": holds, "confirmation_looks": looks,
                     "output_comparisons": comparisons, "elapsed_seconds": time.monotonic() - start,
                     "scope": config["scope"], "current_regression_claim": False})
    _save(out / "anchor.json", anchor)
    return anchor


def historical_proof(anchor, config=None):
    """Recompute source-bound frozen predictions and independent confirmations."""
    config = load_config() if config is None else config
    try:
        frozen = anchor["frozen"]
        if (not verify_seal(anchor) or not verify_seal(frozen) or anchor["schema"] != ANCHOR_SCHEMA or
                anchor["status"] != "validated" or frozen["contract"] != CONTRACT or frozen["config"] != config or
                frozen["implementation"] != implementation_identity() or
                frozen["budgets_mib"] != bracket(anchor["pilot"]) or not frozen["frozen_before_independent_full_work"]):
            return False
        n = len(anchor["full_holdouts"]["paired"])
        if n not in config["qualification_looks"] or len(anchor["full_holdouts"]["sequential"]) != n:
            return False
        for mode in REGIMES:
            train = frozen["training"][mode]
            target = _target_rows(*train[0], config)
            expected = [forecast(pair, target, config) for pair in train]
            if len(train) != config["training_replicates"] or expected != frozen["predictions"][mode]:
                return False
            for pair in train:
                if not all(verify_seal(row) for row in pair):
                    return False
            for i, row in enumerate(anchor["full_holdouts"][mode]):
                if (not verify_seal(row) or row["seed"] != config["seed"] + 100000 + i or
                        row["requested_seconds"] != config["target_seconds"] or row["work"]["sample_count"] != target or
                        digest(row["regime"]) != expected[0]["regime_sha256"]):
                    return False
        expected_looks = []
        for count in config["qualification_looks"]:
            if count > n:
                break
            checks = {mode: qualification([p["full_test_wall_seconds"] for p in frozen["predictions"][mode]],
                        [r["full_test_wall_seconds"] for r in anchor["full_holdouts"][mode][:count]], config) for mode in REGIMES}
            expected_looks.append({"count": count, "regimes": checks})
        if expected_looks != anchor["confirmation_looks"] or any(c["status"] != "validated" for c in expected_looks[-1]["regimes"].values()):
            return False
        for i in range(config["training_replicates"]):
            for j in range(2):
                compare_outputs(frozen["training"]["paired"][i][j], frozen["training"]["sequential"][i][j], across_regimes=True)
        for a, b in zip(anchor["full_holdouts"]["paired"], anchor["full_holdouts"]["sequential"], strict=True):
            compare_outputs(a, b, across_regimes=True)
        return True
    except (KeyError, ValueError, TypeError, IndexError, ResourcePerformanceError, OverflowError):
        return False


def routine(binary, reference_binary, source_root, reference_root, anchor, output, *, deadline=None,
            threads=1, profile="normal", config=None):
    from triad_perf_adaptive import AdaptivePolicy, regression_profile, summarize
    config = load_config() if config is None else config
    if not historical_proof(anchor, config):
        raise ResourcePerformanceError("resource anchor historical proof is absent, changed or unqualified")
    start = time.monotonic(); out = Path(output); out.mkdir(parents=True, exist_ok=True)
    policy = AdaptivePolicy(stopping_rule="decision", **regression_profile(profile))
    identities = {name: binary_identity(path, root, threads) for name, path, root in
                  (("reference", reference_binary, reference_root), ("candidate", binary, source_root))}
    # Fresh pilots locate each binary's real branch. Historical brackets never
    # silently force a new executable into the wrong resource regime.
    pilots = {name: run_export(path, config, 32, config["seed"] + 200000, config["pilot_memory_mib"], "paired", out,
                               deadline=deadline, threads=threads)
              for name, path in (("reference", reference_binary), ("candidate", binary))}
    budgets = {name: bracket(row) for name, row in pilots.items()}
    cases = []; cross_checks = []
    for mode in REGIMES:
        pairs = []; looks = []
        for i in range(policy.looks[-1]):
            pair = {}
            for name in (("reference", "candidate") if i % 2 == 0 else ("candidate", "reference")):
                path = binary if name == "candidate" else reference_binary
                pair[name] = run_export(path, config, config["target_seconds"], config["seed"] + 300000 + i,
                                        budgets[name][mode], mode, out, deadline=deadline, threads=threads)
            compare_outputs(pair["reference"], pair["candidate"])
            pairs.append(pair)
            if i + 1 in policy.looks:
                summary = summarize([r["reference"]["full_test_wall_seconds"] for r in pairs],
                                    [r["candidate"]["full_test_wall_seconds"] for r in pairs], policy,
                                    model_validation="direct_full")
                looks.append(summary)
                if summary["stop_reason"] != "continue":
                    break
        cases.append({"id": f"native-grouped-memory-{mode}", "regime": mode,
                      "prediction_method": "direct_full_target", "raw_pairs": pairs, "looks": looks,
                      "summary": looks[-1], "current_model_extrapolation": False,
                      "computed_saved_seconds_against_direct": 0.})
        _save(out / "progress.json", {"cases": cases, "identities": identities})
    for i in range(min(len(c["raw_pairs"]) for c in cases)):
        for name in ("reference", "candidate"):
            cross_checks.append(compare_outputs(cases[0]["raw_pairs"][i][name], cases[1]["raw_pairs"][i][name], across_regimes=True))
    gates = {case["summary"]["performance_gate"] for case in cases}
    status = "pass" if gates == {"pass"} else "regression" if "performance_regression" in gates else "inconclusive"
    return sealed({"schema": SCHEMA, "mode": "routine", "status": status,
                   "complete_scope": status == "pass", "finite_gap_ids": [config["gap_id"]],
                   "scope": config["scope"], "device": "cpu", "threads": threads,
                   "profile": profile, "policy": asdict(policy), "identities": identities,
                   "implementation": implementation_identity(), "config": config,
                   "historical_anchor_sha256": anchor["record_sha256"],
                   "historical_binary_sha256": anchor["frozen"]["identity"]["binary_sha256"],
                   "historical_prediction_validated": True,
                   "historical_model_applied_to_current_binary": False,
                   "pilots": pilots, "budgets_mib": budgets, "cases": cases,
                   "cross_regime_output_checks": cross_checks,
                   "outcomes": {"functional": "pass", "work_regime": "pass", "historical_prediction": "validated",
                                "performance_regression": status},
                   "routine_method_reason": config["routine_reason"],
                   "elapsed_seconds": time.monotonic() - start, "errors": [],
                   "limitations": ["No GPU memory, allocator fragmentation, paging, spill or OOM throughput claim.",
                                   "Direct routine measurements require no transfer of old duration models across source or hardware changes.",
                                   "Historical ±10% arithmetic mean equivalence is conditional and is not a future-error guarantee."]})


def validate_report(report, *, anchor_path, binary, reference_binary, source_root=ROOT,
                    reference_root=ROOT, threads=1, profile="normal", device="cpu"):
    """Wrapper receipt guard: replay proof, raw decisions and current identities."""
    from triad_perf_adaptive import AdaptivePolicy, regression_profile, summarize
    issues = []
    try:
        config = load_config(); anchor = json.loads(Path(anchor_path).read_text())
        if not historical_proof(anchor, config):
            issues.append("historical resource proof invalid")
        if not verify_seal(report) or report.get("schema") != SCHEMA or report.get("mode") != "routine":
            issues.append("resource report integrity/schema mismatch")
        policy = AdaptivePolicy(stopping_rule="decision", **regression_profile(profile))
        identities = {name: binary_identity(path, root, threads) for name, path, root in
                      (("reference", reference_binary, reference_root), ("candidate", binary, source_root))}
        if (report["implementation"] != implementation_identity() or report["config"] != config or
                report["identities"] != identities or digest(report["policy"]) != digest(asdict(policy)) or
                report["profile"] != profile or report["device"] != "cpu" or device != "cpu" or
                report["threads"] != threads or report["historical_anchor_sha256"] != anchor["record_sha256"]):
            issues.append("resource current source/build/input/environment/profile identity mismatch")
        if [c["regime"] for c in report["cases"]] != list(REGIMES):
            issues.append("resource regime inventory mismatch")
        for case in report["cases"]:
            pairs = case["raw_pairs"]
            for pair in pairs:
                if not all(verify_seal(row) for row in pair.values()):
                    issues.append("resource raw record integrity mismatch")
                compare_outputs(pair["reference"], pair["candidate"])
                if any(r["requested_seconds"] != config["target_seconds"] or
                       r["regime"]["mode"] != case["regime"] for r in pair.values()):
                    issues.append("resource routine did not directly execute the full target")
            expected = []
            for count in policy.looks:
                if count > len(pairs):
                    break
                expected.append(summarize([r["reference"]["full_test_wall_seconds"] for r in pairs[:count]],
                                          [r["candidate"]["full_test_wall_seconds"] for r in pairs[:count]],
                                          policy, model_validation="direct_full"))
            if expected != case["looks"] or expected[-1] != case["summary"]:
                issues.append("resource adaptive proof mismatch")
        gates = {c["summary"]["performance_gate"] for c in report["cases"]}
        status = "pass" if gates == {"pass"} else "regression" if "performance_regression" in gates else "inconclusive"
        expected_outcomes = {"functional": "pass", "work_regime": "pass", "historical_prediction": "validated",
                             "performance_regression": status}
        if (report["status"] != status or report["complete_scope"] != (status == "pass") or
                report["outcomes"] != expected_outcomes or report["finite_gap_ids"] != [config["gap_id"]]):
            issues.append("resource decision or complete-scope receipt inconsistent with measured evidence")
    except (OSError, ValueError, TypeError, KeyError, IndexError, ResourcePerformanceError) as exc:
        issues.append(f"resource receipt invalid: {exc}")
    return {"valid": not issues, "issues": issues,
            "finite_gap_ids": ["resource.memory-thresholds"] if not issues and report.get("status") == "pass" else [],
            "scope": "one real native simulation/preparation memory transition; CPU only"}


def validate_routine_report(report, context):
    """Shared complete-suite extension receipt interface.

    This extension executes native CPU exports even in an outer GPU campaign;
    its finite-gap receipt never claims a GPU allocator transition.
    """
    checked = validate_report(report, anchor_path=context["anchor"], binary=context["binary"],
                              reference_binary=context["reference_binary"],
                              source_root=context["candidate_root"], reference_root=context["reference_root"],
                              threads=context["native_threads"], profile=context["regression_profile"], device="cpu")
    status = ({"pass": "passed", "regression": "failed", "inconclusive": "inconclusive"}.get(report.get("status"), "unqualified")
              if checked["valid"] else "unqualified")
    return {"valid": checked["valid"], "status": status, "errors": checked["issues"],
            "gap_ids": checked["finite_gap_ids"], "outcomes": report.get("outcomes", {}),
            "execution_backend": "cpu", "scope": checked["scope"]}


def cli(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("qualify", "routine"), required=True)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--reference-binary")
    parser.add_argument("--source-root", default=str(ROOT))
    parser.add_argument("--reference-root", default=str(ROOT))
    parser.add_argument("--anchor")
    parser.add_argument("--output", required=True)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--budget-seconds", type=float, default=300.)
    parser.add_argument("--regression-profile", choices=("normal", "ci", "strict"), default="normal")
    args = parser.parse_args(argv)
    if args.threads != 1 or not math.isfinite(args.budget_seconds) or args.budget_seconds <= 0:
        parser.error("resource target requires one native thread and a finite positive budget")
    if args.mode == "routine" and (not args.reference_binary or not args.anchor):
        parser.error("routine requires --reference-binary and a qualified --anchor")
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    start = time.monotonic(); deadline = start + args.budget_seconds
    try:
        if args.mode == "qualify":
            result = qualify(args.binary, args.source_root, out, deadline=deadline, threads=args.threads)
            code = 0 if result["status"] == "validated" else 2
        else:
            anchor = json.loads(Path(args.anchor).read_text())
            result = routine(args.binary, args.reference_binary, args.source_root, args.reference_root,
                             anchor, out, deadline=deadline, threads=args.threads, profile=args.regression_profile)
            code = 0 if result["status"] == "pass" else 1 if result["status"] == "regression" else 2
    except (OSError, ValueError, ResourcePerformanceError, TimeoutError, subprocess.TimeoutExpired) as exc:
        result = sealed({"schema": SCHEMA, "mode": args.mode, "status": "error", "complete_scope": False,
                         "errors": [str(exc)], "elapsed_seconds": time.monotonic() - start})
        code = 2
    _save(out / "report.json", result)
    _save(out / "summary.json", result)
    print(json.dumps({"status": result["status"], "elapsed_seconds": result["elapsed_seconds"],
                      "report": str(out / "report.json")}, sort_keys=True))
    return code


if __name__ == "__main__":
    sys.exit(cli())

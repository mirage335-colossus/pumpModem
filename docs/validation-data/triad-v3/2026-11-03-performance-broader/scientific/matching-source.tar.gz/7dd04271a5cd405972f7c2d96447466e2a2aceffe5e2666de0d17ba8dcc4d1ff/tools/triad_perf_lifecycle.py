#!/usr/bin/env python3
"""Source-bound cold-process and fixed mixed-family simulation timing.

The controller is already running; the target starts before creating its
receiver process and ends after close/wait and sampled-file cleanup. OS page
cache is retained. Mixed campaigns share native captures by exact profile and
capture count, then create a complete independent receiver state on every call.
"""
from __future__ import annotations

import argparse
import ast
from contextlib import contextmanager
from dataclasses import replace
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import sys
import tempfile
import time

import numpy as np
from scipy.stats import t as student_t

import triad_perf_families as sample
from triad_perf_adaptive import AdaptivePolicy, model_confirmation_policy, regression_profile
from triad_perf_family_regression import numerical_agreement

ROOT = Path(__file__).resolve().parents[1]
WORKER = Path(__file__).resolve()
MANIFEST = WORKER.with_name("triad-performance-lifecycle.json")
SCHEMA = "triad-performance-lifecycle-v1"
SOURCES = ("reference", "candidate")
LOOKS = (3, 5, 9, 17)
MEASUREMENT_SCOPE = (
    "fresh receiver process creation, numerical imports, native shared full sampled exports, "
    "family setup/device initialization, first complete calls, declared warm cycles, "
    "receiver finish/result IPC, close/wait and scratch cleanup; controller initialization, "
    "fixture hashing and evidence serialization excluded; ordinary OS page cache retained"
)


def sha(path):
    return sample.file_sha(path)


def digest(value):
    return sample.digest(value)


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    sample.write_json(path, value)


def load_manifest():
    value = json.loads(MANIFEST.read_text())
    if value.get("schema") != SCHEMA or len({c["id"] for c in value["cases"]}) != len(value["cases"]):
        raise ValueError("invalid lifecycle manifest")
    families = sample.manifest()
    known = {c["id"]: c for c in families["cases"]}
    for case in value["cases"]:
        if case["kind"] not in ("cold", "mixed") or not case["members"] or len(set(case["members"])) != len(case["members"]):
            raise ValueError("invalid lifecycle case")
        if any(name not in known or case["device"] not in known[name]["devices"] for name in case["members"]):
            raise ValueError("lifecycle member unavailable on its declared backend")
        if case["kind"] == "mixed" and set(case["members"]) != {c["id"] for c in known.values() if case["device"] in c["devices"]}:
            raise ValueError("mixed campaign omits an applicable maintained family")
    return value, families, known


def _api():
    return sample.load_source(ROOT, "triad-performance.py")


def _body_hashes(path, names):
    tree = ast.parse(Path(path).read_text())
    found = {node.name: hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
             for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names}
    if set(found) != set(names):
        raise ValueError("measurement body missing")
    return found


def static_binding(roots, binaries, case, families, known, *, device, precision, threads, native_threads):
    # Gate/profile/rendering changes do not change a timed loop. Full module
    # hashes remain in each report; applicability binds reviewed measurement
    # bodies and exact DSP/adapter/native inputs instead.
    selected = [known[name] for name in case["members"]]
    return {
        "schema": SCHEMA, "case": case, "profiles": {c["fixture"]: families["fixtures"][c["fixture"]] for c in selected},
        "members": selected, "binary_sha256": {n: sha(binaries[n]) for n in SOURCES},
        "stage_sources": {n: {c["id"]: sample.stage_sources(roots[n], c) for c in selected} for n in SOURCES},
        "measurement_bodies": {
            "lifecycle": _body_hashes(WORKER, ("observe", "group_plan", "cache_environment")),
            "transport": _body_hashes(WORKER.with_name("triad-performance.py"), ("ReceiverWorker", "child_environment", "stop_group")),
            "sampled": _body_hashes(WORKER.with_name("triad_perf_families.py"),
                ("serve", "native_arguments", "export_fixtures", "receive", "case_worker_setup", "complete_work_signature")),
        },
        "device": device, "precision": precision, "threads": threads, "native_threads": native_threads,
        "timing_scope": MEASUREMENT_SCOPE,
        "cache_contract": {"policy": case["cache"], "os_page_cache": "retained",
                           "controller_already_running": True, "global_device_or_disk_cold_claim": False},
    }


def group_plan(members, known):
    # A three-capture CFO batch can share its first physical capture with a
    # one-capture receiver of the identical native profile.
    result = {}
    for name in members:
        case = known[name]
        result[case["fixture"]] = max(result.get(case["fixture"], 0), case["captures"])
    return result


@contextmanager
def cache_environment(cache, directory):
    previous = os.environ.get("TRITON_CACHE_DIR")
    if cache != "process-cold":
        Path(directory).mkdir(parents=True, exist_ok=True)
        os.environ["TRITON_CACHE_DIR"] = str(directory)
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop("TRITON_CACHE_DIR", None)
        else:
            os.environ["TRITON_CACHE_DIR"] = previous


def _environment(value, cache):
    value = json.loads(json.dumps(value))
    policy = value.get("triton_jit_policy")
    if policy:
        policy["explicit_cache_directory_sha256"] = "owned-directory-path-is-not-a-compute-regime"
        policy["disk_cache"] = cache
    return value


def observe(root, binary, case, families, known, *, cycles, seed, threads, native_threads,
            device, precision, deadline, directory, cache_directory, delay=None):
    """One complete physical session; every member runs at full public work."""
    api = _api()
    directory = Path(directory)
    delay = {} if delay is None else delay
    def pause(stage):
        seconds = delay.get(stage, 0.)
        if seconds:
            time.sleep(seconds)
    receipts, setup, generation, signatures, fixture = [], {}, {}, {}, []
    worker = None
    start = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="lifecycle-", dir=directory) as temp:
        scratch = Path(temp)
        cache_dir = scratch/"private-triton-cache" if case["cache"] == "private-empty-compiled" else cache_directory
        with cache_environment(case["cache"], cache_dir):
            try:
                pause("startup")
                before = time.perf_counter()
                worker = api.ReceiverWorker(root, threads=threads, deadline=deadline,
                    log_directory=directory, name=f"worker-{seed}", adapter=sample.WORKER)
                startup = time.perf_counter()-before
                for name in case["members"]:
                    setup[name] = sample.case_worker_setup(worker, known[name], device)
                paths = {}
                pause("simulation")
                for index, (profile, captures) in enumerate(group_plan(case["members"], known).items()):
                    paths[profile], generation[profile] = sample.export_fixtures(binary, families["fixtures"][profile],
                        seed+1000*index, native_threads, scratch/profile, captures, deadline)
                pause("preparation")
                first_start = time.perf_counter()
                first = []
                for name in case["members"]:
                    member = known[name]
                    call = sample.receive(worker, paths[member["fixture"]][:member["captures"]], member, device, precision)
                    signature = sample.complete_work_signature({"receiver_runs": [call]})
                    signatures[name] = signature
                    first.append({"id": name, "call": call})
                first_seconds = time.perf_counter()-first_start
                warm_start = time.perf_counter()
                cycle_seconds = []
                for cycle in range(cycles):
                    cycle_start = time.perf_counter()
                    row = []
                    for name in case["members"]:
                        member = known[name]
                        call = sample.receive(worker, paths[member["fixture"]][:member["captures"]], member, device, precision)
                        if sample.complete_work_signature({"receiver_runs": [call]}) != signatures[name]:
                            raise ValueError("mixed campaign changed a full receiver work regime")
                        row.append({"id": name, "call": call})
                    cycle_seconds.append(time.perf_counter()-cycle_start)
                    receipts.append(row)
                warm_seconds = time.perf_counter()-warm_start
                for name in case["members"]:
                    checked = worker.request({"action": "family-verify", "case": known[name], "verify_environment": True})
                    if checked.get("environment_matches_setup") is not True:
                        raise ValueError("receiver environment changed during lifecycle observation")
                pause("finalization")
            finally:
                before = time.perf_counter()
                if worker is not None:
                    worker.close()
                close_seconds = time.perf_counter()-before
        # Native output cleanup belongs to the complete target. Hashing is
        # instrument overhead, deliberately outside the monotonic target.
    elapsed = time.perf_counter()-start
    environment = {name: _environment(row["environment"], case["cache"]) for name, row in setup.items()}
    return {
        "seed": seed, "cycles": cycles, "complete_seconds": elapsed,
        "fixed_seconds": elapsed-warm_seconds, "warm_seconds": warm_seconds,
        "cycle_seconds": cycle_seconds, "startup_seconds": startup, "close_seconds": close_seconds,
        "first_seconds": first_seconds, "generation": generation, "setup": setup,
        "first": first, "warm": receipts, "work_signature": signatures, "environment": environment,
        "cache": case["cache"], "timing_scope": MEASUREMENT_SCOPE,
        "hashing_and_evidence_outside_target": True, "injected_delay_seconds": delay,
    }


def mean_interval(values, confidence):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or len(values) < 3 or not np.isfinite(values).all():
        raise ValueError("at least three finite independent outer observations required")
    point = float(np.mean(values))
    half = float(student_t.ppf((1+confidence)/2, len(values)-1)*np.std(values, ddof=1)/math.sqrt(len(values)))
    return {"mean": point, "interval": [point-half, point+half], "n": len(values)}


def ratio_interval(reference, candidate, tail_alpha):
    """Fieller interval with each endpoint spending the stated one-sided tail."""
    a, b = (np.asarray(v, dtype=np.float64) for v in (reference, candidate))
    if len(a) != len(b) or len(a) < 3 or np.any(a <= 0) or np.any(b <= 0) or not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError("three paired finite positive outer runtimes required")
    n = len(a)
    x, y = float(np.mean(a)), float(np.mean(b))
    scale = float(student_t.ppf(1-tail_alpha, n-1)**2/n)
    aa = x*x-scale*float(np.var(a, ddof=1))
    ratio = y/x
    residual = b-ratio*a
    # Same centered Fieller construction as the existing staged validator:
    # avoid cancellation of O(mean**4) terms for nearly identical timings.
    shifted_b = float(scale*np.cov(a, residual, ddof=1)[0, 1])
    shifted_c = -float(scale*np.var(residual, ddof=1))
    disc = shifted_b*shifted_b-aa*shifted_c
    if aa <= 0 or disc < 0 or not math.isfinite(disc):
        return None
    center = ratio-shifted_b/aa
    return [center-math.sqrt(disc)/aa, center+math.sqrt(disc)/aa]


def comparison(reference, candidate, policy, *, allowance=0.):
    n = len(reference)
    if n not in policy.looks:
        raise ValueError("comparison must be at a predeclared look")
    upper = ratio_interval(reference, candidate, policy.pass_error_budget/len(policy.looks))
    lower = ratio_interval(reference, candidate, policy.failure_error_budget/len(policy.looks))
    lo = None if lower is None else max(0., lower[0])/(1+allowance)
    hi = None if upper is None else upper[1]*(1+allowance)
    gate = ("performance_regression" if lo is not None and lo > policy.slowdown_threshold else
            "pass" if hi is not None and hi <= policy.slowdown_threshold else "inconclusive")
    return {"gate": gate, "sample_count": n, "timing_only_lower_bound": None if lower is None else lower[0],
            "timing_only_upper_bound": None if upper is None else upper[1],
            "model_adjusted_ratio_interval": [lo, hi], "engineering_model_relative_allowance": allowance,
            "pass_error_budget": policy.pass_error_budget, "failure_error_budget": policy.failure_error_budget,
            "threshold": policy.slowdown_threshold, "looks": list(policy.looks),
            "estimand": "ratio of arithmetic mean complete-target runtimes",
            "confidence_includes_unverified_model_error": False, "future_model_coverage_qualified": False}


def forecast(rows, cycles):
    values = {name: [r[name]["fixed_seconds"]+cycles*r[name]["warm_seconds"] for r in rows] for name in SOURCES}
    return {"cycles": cycles, "point_seconds": {n: statistics.fmean(v) for n, v in values.items()},
            "outer_predictions": values,
            "joint_components": "F + C*W per outer session; covariance retained and shared setup counted once",
            "timing_scope": MEASUREMENT_SCOPE}


def model_validation(rows, frozen, allowance):
    confidence = model_confirmation_policy().confidence
    times = {n: [r[n]["complete_seconds"] for r in rows] for n in SOURCES}
    checks = {}
    for name in SOURCES:
        ratio = mean_interval([v/frozen["point_seconds"][name] for v in times[name]], confidence)
        checks[name] = ratio["interval"]
    band = ratio_interval(times["reference"], times["candidate"], (1-confidence)/2)
    predicted_ratio = frozen["point_seconds"]["candidate"]/frozen["point_seconds"]["reference"]
    checks["paired"] = None if band is None else [v/predicted_ratio for v in band]
    valid = all(v is not None and 1-allowance <= v[0] <= v[1] <= 1+allowance for v in checks.values())
    invalid = any(v is not None and (v[1] < 1-allowance or v[0] > 1+allowance) for v in checks.values())
    return {"status": "validated" if valid else "invalid" if invalid else "inconclusive",
            "arithmetic_actual_over_frozen_prediction_intervals": checks,
            "allowed_relative_error": allowance, "confidence_per_confirmation_look": confidence,
            "confirmation_policy": model_confirmation_policy().to_dict(), "n": len(rows),
            "future_prediction_coverage_claim": False}


def _pair_check(row, precision):
    for section in ("first", "warm"):
        left, right = (row[n][section] for n in SOURCES)
        if section == "first":
            left, right = [left], [right]
        if len(left) != len(right):
            raise ValueError("paired cycle counts differ")
        for a, b in zip(left, right, strict=True):
            if [v["id"] for v in a] != [v["id"] for v in b]:
                raise ValueError("paired member ordering differs")
            for aa, bb in zip(a, b, strict=True):
                numerical_agreement({"reference": {"receiver_runs": [aa["call"]]},
                                     "candidate": {"receiver_runs": [bb["call"]]}}, precision)


def _validate_anchor(value):
    if not isinstance(value, dict) or value.get("schema") != SCHEMA or value.get("status") != "validated":
        return False
    try:
        if value["record_sha256"] != digest({k: v for k, v in value.items() if k != "record_sha256"}):
            return False
        frozen = value["forecast"]
        rebuilt = forecast(value["training"], frozen["cycles"])
        if any(frozen[key] != content for key, content in rebuilt.items()):
            return False
        all_rows = [*value["training"], *value["full_pairs"]]
        if (set(value["training_pair_ids"]) & {r["pair_id"] for r in value["full_pairs"]} or
                value["training_pair_ids"] != [r["pair_id"] for r in value["training"]] or
                any({n: r[n]["work_signature"] for n in SOURCES} != frozen["work_signature"] or
                    _environment_signature(r) != frozen["environment"] for r in all_rows)):
            return False
        if any(r[n]["cycles"] != frozen["cycles"] for r in value["full_pairs"] for n in SOURCES):
            return False
        checks = [model_validation(value["full_pairs"][:n], frozen, value["model_relative_error"])
                  for n in model_confirmation_policy().looks if n <= len(value["full_pairs"])]
        return (checks == value["confirmation"] and checks[-1]["status"] == "validated" and
                all(c["status"] == "inconclusive" for c in checks[:-1]))
    except (KeyError, ValueError, TypeError, IndexError):
        return False


def _anchor_path(directory, identifier):
    return Path(directory)/(identifier+".lifecycle-anchor.json")


def _sentinel(anchor, current, full):
    """Fixed historical observation envelope plus current mean uncertainty."""
    confidence = 1-.05/(3*len(LOOKS))
    result = {}
    for name, bounds, historical in _sentinel_components(anchor, current, confidence):
        actual = (full[name]["complete_seconds"] if name in SOURCES else
                  full["candidate"]["complete_seconds"]/full["reference"]["complete_seconds"])
        envelope = max(math.log1p(anchor["model_relative_error"]), *(abs(v) for v in historical))
        interval = [math.log(actual/bounds[1]), math.log(actual/bounds[0])] if bounds is not None and bounds[0] > 0 else None
        result[name] = {"actual_over_timing_log_interval": interval, "historical_log_envelope": envelope,
                        "eligible": interval is not None and -envelope <= interval[0] <= interval[1] <= envelope}
    return {"eligible": all(v["eligible"] for v in result.values()), "sources": result,
            "scope": "one independent complete fixed campaign; historical engineering envelope, no future-tail guarantee"}


def _sentinel_components(anchor, current, confidence):
    rows = []
    for name in SOURCES:
        interval = mean_interval(current["outer_predictions"][name], confidence)["interval"]
        errors = [math.log(r[name]["complete_seconds"]/anchor["forecast"]["point_seconds"][name])
                  for r in anchor["full_pairs"]]
        rows.append((name, interval, errors))
    ratio = ratio_interval(current["outer_predictions"]["reference"], current["outer_predictions"]["candidate"], (1-confidence)/2)
    expected = anchor["forecast"]["point_seconds"]["candidate"]/anchor["forecast"]["point_seconds"]["reference"]
    errors = [math.log((r["candidate"]["complete_seconds"]/r["reference"]["complete_seconds"])/expected)
              for r in anchor["full_pairs"]]
    return [*rows, ("paired", ratio, errors)]


def sentinel_readiness(anchor, current):
    blockers = []
    confidence = 1-.05/(3*len(LOOKS))
    for name, interval, errors in _sentinel_components(anchor, current, confidence):
        envelope = max(math.log1p(anchor["model_relative_error"]), *(abs(v) for v in errors))
        if interval is None or interval[0] <= 0:
            blockers.append(name)
            continue
        half = math.log(interval[1]/interval[0])/2
        if half > envelope or half+math.log1p(anchor["model_relative_error"]) > math.log1p(.20):
            blockers.append(name)
    return {"feasible": not blockers, "timing_blockers": blockers,
            "scope": "necessary pre-endpoint uncertainty check; not acceptance or future coverage"}


def _validate_cold_anchor(value):
    try:
        if value.get("schema") != SCHEMA or value.get("status") != "direct_full" or value.get("kind") != "cold":
            return False
        if value["record_sha256"] != digest({k: v for k, v in value.items() if k != "record_sha256"}):
            return False
        rows = value["full_pairs"]
        return (len(rows) in LOOKS and all(r[n]["cycles"] == 0 and
                    r[n]["work_signature"] == value["expected_work"][n] and
                    r[n]["environment"] == value["environment"][n] for r in rows for n in SOURCES))
    except (KeyError, ValueError, TypeError):
        return False


def _environment_signature(row):
    return {n: row[n]["environment"] for n in SOURCES}


def run_case(case, families, known, roots, binaries, output, args, deadline):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    static = static_binding(roots, binaries, case, families, known, device=args.device, precision=args.precision,
                            threads=args.threads, native_threads=args.native_threads)
    report = {"schema": SCHEMA, "id": case["id"], "kind": case["kind"], "case": case,
              "static_binding": static, "static_binding_sha256": digest(static), "status": "unqualified",
              "prediction_valid": False, "comparison": {"gate": "inconclusive"}, "training": [],
              "full_pairs": [], "confirmation": [], "mode": args.mode, "timing_scope": MEASUREMENT_SCOPE}
    anchor_path = _anchor_path(args.anchor_directory, case["id"])
    anchor = json.loads(anchor_path.read_text()) if args.mode == "reuse" and anchor_path.is_file() else None
    if case["kind"] == "mixed" and args.mode == "reuse" and (not _validate_anchor(anchor) or anchor["static_binding"] != static):
        report["reason"] = "missing applicable independently validated fixed-campaign anchor"
        save(output/"result.json", report)
        return report
    policy = AdaptivePolicy(stopping_rule="decision", looks=LOOKS, **regression_profile(args.regression_profile))
    cache_base = Path(args.anchor_directory)/"compiled-cache"/digest(static)[:20]
    base_seed = int(digest(case)[:10], 16) + (0 if args.mode == "qualify" else 200000000)
    expected_work = None
    environment = None
    def pair(cycles, index, phase):
        nonlocal expected_work, environment
        row = {}
        seed = base_seed+index*1000000+(100000000 if phase == "validation" else 0)
        for name in SOURCES if index % 2 == 0 else SOURCES[::-1]:
            row[name] = observe(roots[name], binaries[name], case, families, known, cycles=cycles, seed=seed,
                threads=args.threads, native_threads=args.native_threads, device=args.device, precision=args.precision,
                deadline=deadline, directory=output, cache_directory=cache_base/name)
        _pair_check(row, args.precision)
        work = {n: row[n]["work_signature"] for n in SOURCES}
        env = _environment_signature(row)
        if expected_work is None:
            expected_work, environment = work, env
        if work != expected_work or env != environment:
            raise ValueError("lifecycle work or environment changed across physical observations")
        row["pair_id"] = digest({"case": case["id"], "seed": seed, "phase": phase})
        save(output/f"{phase}-{index:03d}.json", row)
        return row
    if case["cache"] == "persistent-compiled":
        report["cache_precondition"] = pair(0, 0, "cache-precondition")
    if case["kind"] == "cold":
        values = {n: [] for n in SOURCES}
        for i in range(LOOKS[-1]):
            row = pair(0, i+1, "cold-direct")
            report["full_pairs"].append(row)
            for n in SOURCES:
                values[n].append(row[n]["complete_seconds"])
            if i+1 in LOOKS:
                report["comparison"] = comparison(values["reference"], values["candidate"], policy)
                if report["comparison"]["gate"] != "inconclusive":
                    break
        report.update(status="direct_full", prediction_valid=True)
        if args.mode == "qualify":
            record = {"schema": SCHEMA, "id": case["id"], "kind": "cold", "status": "direct_full",
                      "static_binding": static, "environment": environment, "expected_work": expected_work,
                      "full_pairs": report["full_pairs"], "comparison": report["comparison"]}
            record["record_sha256"] = digest(record)
            if anchor_path.exists():
                raise ValueError("refusing to overwrite a historical cold qualification")
            save(anchor_path, record)
    else:
        if args.mode == "qualify":
            pilot = pair(1, 0, "discarded-pilot")
            cost = max(pilot[n]["warm_seconds"] for n in SOURCES)
            fixed = max(pilot[n]["fixed_seconds"] for n in SOURCES)
            cycles = max(2, math.ceil(max(0., args.minimum_campaign_seconds-fixed)/cost))
            if cycles > 256:
                raise ValueError("campaign requires more than its declared cycle limit")
            report["discarded_pilot"] = pilot
        else:
            cycles = anchor["forecast"]["cycles"]
        for i in range(LOOKS[-1]):
            report["training"].append(pair(1, i+1, "training"))
            if i+1 not in LOOKS:
                continue
            frozen = forecast(report["training"], cycles)
            gate = comparison(frozen["outer_predictions"]["reference"], frozen["outer_predictions"]["candidate"],
                              policy, allowance=anchor["model_relative_error"] if anchor else 0.)
            ready = sentinel_readiness(anchor, frozen) if anchor else {"feasible": True}
            if args.mode == "qualify" or (gate["gate"] != "inconclusive" and ready["feasible"]) or i+1 == LOOKS[-1]:
                break
        report["forecast"] = {**frozen, "work_signature": expected_work, "environment": environment}
        save(output/"forecast.json", report["forecast"])
        if anchor and (anchor["forecast"]["work_signature"] != expected_work or anchor["forecast"]["environment"] != environment):
            report["reason"] = "current full work/environment differs from historical mixed model"
        elif anchor and (gate["gate"] == "inconclusive" or not ready["feasible"]):
            report["reason"] = "frozen routine decision or sentinel timing remains inconclusive"
            report["sentinel_readiness"] = ready
        else:
            maximum = 1 if anchor else args.maximum_holds
            for i in range(maximum):
                row = pair(cycles, i+1, "validation")
                report["full_pairs"].append(row)
                if anchor:
                    report["sentinel"] = _sentinel(anchor, frozen, row)
                    if report["sentinel"]["eligible"]:
                        report.update(status="historically_supported_conditional", prediction_valid=True,
                                      comparison=gate, historical_anchor_sha256=anchor["record_sha256"])
                    break
                if i+1 in model_confirmation_policy().looks:
                    check = model_validation(report["full_pairs"], frozen, args.model_relative_error)
                    report["confirmation"].append(check)
                    if check["status"] != "inconclusive":
                        report["status"] = check["status"]
                        report["prediction_valid"] = check["status"] == "validated"
                        break
            if report["status"] == "validated":
                report["comparison"] = gate
                record = {"schema": SCHEMA, "id": case["id"], "status": "validated", "static_binding": static,
                          "forecast": report["forecast"], "full_pairs": report["full_pairs"],
                          "training": report["training"], "training_pair_ids": [r["pair_id"] for r in report["training"]],
                          "confirmation": report["confirmation"], "model_relative_error": args.model_relative_error}
                record["record_sha256"] = digest(record)
                if anchor_path.exists():
                    raise ValueError("refusing to overwrite a historical lifecycle anchor")
                save(anchor_path, record)
    report["environment"] = environment
    report["expected_work"] = expected_work
    report["independent_validation"] = {
        "full_target_pairs": len(report["full_pairs"]), "forecast_frozen_before_validation": case["kind"] == "mixed",
        "physical_seed_sets_disjoint": True, "work_regime_checked": True,
        "ordinary_page_cache_retained": True, "controller_startup_included": False,
        "complete_processing_target_includes_receiver_startup": True,
    }
    report["source_binding_sha256"] = digest({"static": static, "environment": environment, "work": expected_work})
    if static_binding(roots, binaries, case, families, known, device=args.device, precision=args.precision,
                      threads=args.threads, native_threads=args.native_threads) != static:
        raise ValueError("source, native binary or measurement body changed during lifecycle run")
    save(output/"result.json", report)
    return report


def validate_routine_report(report, context):
    """Lightweight wrapper guard; no worker, simulation or numerical kernel."""
    errors = []
    try:
        config, families, known = load_manifest()
        device = context["device"]
        required = [c for c in config["cases"] if c["device"] == device and c["routine"]]
        actual = {r["id"]: r for r in report["cases"]}
        if set(actual) != {c["id"] for c in required} or len(actual) != len(report["cases"]):
            errors.append("lifecycle case set is incomplete or duplicated")
        roots = {"candidate": Path(context["candidate_root"]), "reference": Path(context["reference_root"])}
        binaries = {"candidate": Path(context["binary"]), "reference": Path(context["reference_binary"])}
        for case in required:
            row = actual[case["id"]]
            binding = static_binding(roots, binaries, case, families, known, device=device, precision=context["precision"],
                                     threads=context["threads"], native_threads=context["native_threads"])
            if row["static_binding"] != binding or row["static_binding_sha256"] != digest(binding):
                errors.append(case["id"]+": current source/build/workload binding mismatch")
            if not row["prediction_valid"] or row["comparison"]["gate"] != "pass":
                errors.append(case["id"]+": unsupported runtime decision")
            if case["kind"] == "mixed":
                anchor_path = _anchor_path(context["anchor_directory"], case["id"])
                anchor = json.loads(anchor_path.read_text())
                if not _validate_anchor(anchor) or anchor["record_sha256"] != row.get("historical_anchor_sha256") or anchor["static_binding"] != binding:
                    errors.append(case["id"]+": historical prediction proof missing or changed")
                if not row.get("sentinel", {}).get("eligible") or len(row["full_pairs"]) != 1:
                    errors.append(case["id"]+": independent complete campaign sentinel missing")
            if not row["independent_validation"]["work_regime_checked"] or not row["full_pairs"]:
                errors.append(case["id"]+": completed work evidence missing")
    except (KeyError, TypeError, ValueError, OSError) as error:
        errors.append(type(error).__name__+": "+str(error))
    return {"valid": not errors, "status": "passed" if not errors else "unqualified", "errors": errors,
            "gap_ids": [] if errors else ["scheduler.concurrency-and-batches"],
            "cold_latency_qualified": not errors,
            "outcomes": {"cold": "qualified" if not errors else "unqualified",
                         "fixed_mixed_campaign": "qualified" if not errors else "unqualified"}}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, default=ROOT)
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--reference-binary", type=Path, required=True)
    parser.add_argument("--anchor-directory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--precision", choices=("fp32", "fp64"), default="fp32")
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--native-threads", type=int, default=1)
    parser.add_argument("--mode", choices=("qualify", "reuse"), default="reuse")
    parser.add_argument("--regression-profile", choices=("normal", "ci", "strict"), default="normal")
    parser.add_argument("--budget-seconds", type=float, default=1500.)
    parser.add_argument("--minimum-campaign-seconds", type=float, default=60.)
    parser.add_argument("--maximum-holds", type=int, choices=(3, 5, 9, 17), default=9)
    parser.add_argument("--model-relative-error", type=float, default=.10)
    parser.add_argument("--case", action="append")
    args = parser.parse_args(argv)
    if not 0 < args.budget_seconds <= 28800 or not 0 < args.minimum_campaign_seconds <= 3600 or not 0 < args.model_relative_error < 1:
        parser.error("invalid declared timing or model limits")
    config, families, known = load_manifest()
    available = [c for c in config["cases"] if c["device"] == args.device and (args.mode == "qualify" or c["routine"])]
    if args.case and set(args.case)-{c["id"] for c in available}:
        parser.error("unknown or unavailable lifecycle case")
    selected = [c for c in available if not args.case or c["id"] in args.case]
    args.output.mkdir(parents=True, exist_ok=False)
    args.anchor_directory.mkdir(parents=True, exist_ok=True)
    roots = {"reference": args.reference_root.resolve(), "candidate": args.candidate_root.resolve()}
    binaries = {"reference": args.reference_binary.resolve(), "candidate": args.binary.resolve()}
    report = {"schema": SCHEMA, "mode": args.mode, "device": args.device,
              "regression_profile": args.regression_profile, "regression_policy": regression_profile(args.regression_profile),
              "selected_case_ids": [c["id"] for c in selected], "cases": [], "errors": [],
              "protocol_sha256": sha(WORKER), "manifest_sha256": sha(MANIFEST), "status": "running"}
    start = time.perf_counter()
    deadline = time.monotonic()+args.budget_seconds
    try:
        for case in selected:
            report["cases"].append(run_case(case, families, known, roots, binaries, args.output/case["id"], args, deadline))
    except Exception as error:
        report["errors"].append(type(error).__name__+": "+str(error))
    if report["protocol_sha256"] != sha(WORKER) or report["manifest_sha256"] != sha(MANIFEST):
        report["errors"].append("lifecycle protocol changed during measurement")
    report["wall_seconds"] = time.perf_counter()-start
    report["status"] = "passed" if not report["errors"] and all(r["prediction_valid"] and r["comparison"]["gate"] == "pass" for r in report["cases"]) else "incomplete"
    report["cold_latency_qualification"] = "qualified" if report["status"] == "passed" else "unqualified"
    save(args.output/"summary.json", report)
    print(f"Triad lifecycle: {report['status']}; {report['wall_seconds']:.3f}s; {args.output/'summary.json'}")
    return 0 if report["status"] == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())

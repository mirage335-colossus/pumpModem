#!/usr/bin/env python3
"""Direct full-target regression for the isolated native planners and bounds.

Each statistical observation is a fresh complete native process with a fixed
bundle. Cheap full work is measured directly: there is no abbreviated model to
qualify or historical calibration to repeat. Retained pairs are source-bound
full-run anchors, not predictions for an unmeasured duration or hardware.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = Path(__file__).with_name("triad-performance-planner.json")
DRIVER = "tools/triad-planner-perf.cpp"
SCHEMA = "triad-performance-planner-v1"
GAP = "regime.v3-native-planner-statistics"
DEPENDENCIES = (
    "src/triad_statistics.cpp", "src/triad_modem_v3.cpp",
    "include/datapump/triad_statistics.hpp", "include/datapump/triad_modem_v3.hpp",
    "include/datapump/triad_modem.hpp", "include/datapump/triad_simulation.hpp",
    "include/datapump/crypto.hpp", "include/datapump/pattern_pulse.hpp",
)


def file_sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def manifest():
    value = json.loads(MANIFEST.read_text())
    cases = value.get("cases", [])
    if value.get("schema") != "triad-performance-planner-cases-v1" or len(cases) != 6:
        raise ValueError("invalid planner manifest")
    if len({row["id"] for row in cases}) != len(cases):
        raise ValueError("duplicate planner case")
    for row in cases:
        if type(row["repetitions"]) is not int or not 1 <= row["repetitions"] <= 1000000:
            raise ValueError("invalid planner repetitions")
        if row["calls_per_repetition"] != len(row["outputs"]):
            raise ValueError("invalid planner call count")
    return value


def source_identity(root, binary):
    root = Path(root).resolve(strict=True)
    files = {name: file_sha(root/name) for name in DEPENDENCIES}
    # This exact ordered byte format is also computed by CMake.
    production = hashlib.sha256("".join(f"{name}:{files[name]}\n" for name in DEPENDENCIES).encode()).hexdigest()
    return {"binary_sha256": file_sha(binary), "driver_sha256": file_sha(root/DRIVER),
            "production_sha256": production, "declared_production_dependencies": files,
            "dependency_scope": "listed source/header bytes; standard library, compiler and runtime are separately identified by build/environment evidence"}


def environment_identity():
    from triad_perf_native import environment_identity as native_environment
    return native_environment(1)


def identities(candidate_root, reference_root, candidate_binary, reference_binary):
    sources = {name: source_identity(root, binary) for name, root, binary in (
        ("candidate", candidate_root, candidate_binary), ("reference", reference_root, reference_binary))}
    if sources["candidate"]["driver_sha256"] != sources["reference"]["driver_sha256"]:
        raise ValueError("reference and candidate must use the identical planner driver")
    if sources["candidate"]["driver_sha256"] != file_sha(ROOT/DRIVER):
        raise ValueError("planner driver differs from this harness's workload definition")
    return {"sources": sources, "environment": environment_identity(),
            "harness": {name: file_sha(Path(__file__).with_name(name)) for name in
                        ("triad_perf_planner.py", "triad_perf_adaptive.py", "triad_perf_native.py",
                         "triad_perf_hardware.py", MANIFEST.name)},
            "manifest_sha256": file_sha(MANIFEST)}


def validate_native(row, case, identity):
    if row.get("schema") != "triad-planner-perf-native-v1" or row.get("complete") is not True:
        raise ValueError("incomplete native planner target")
    for key in ("driver_sha256", "production_sha256"):
        if row.get(key) != identity[key]:
            raise ValueError(f"native planner embedded {key} does not match selected source")
    if row.get("case") != case["id"] or row.get("repetitions") != case["repetitions"]:
        raise ValueError("native planner workload changed")
    if row.get("calls") != case["repetitions"]*case["calls_per_repetition"]:
        raise ValueError("native planner call count changed")
    if row.get("arithmetic") != "fp64_and_native_long_double_bounds":
        raise ValueError("native planner arithmetic changed")
    if [value.get("name") for value in row.get("outputs", [])] != case["outputs"]:
        raise ValueError("native planner branch output inventory changed")
    for value in [row.get("checksum"), row.get("operation_seconds"),
                  *(item.get("value") for item in row["outputs"])]:
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
            raise ValueError("native planner returned a non-finite result")
    if row["operation_seconds"] <= 0:
        raise ValueError("native planner operation timer is not positive")
    return True


def numerical_agreement(reference, candidate):
    for key in ("case", "repetitions", "calls", "arithmetic", "internal_iterations_instrumented"):
        if reference[key] != candidate[key]:
            raise ValueError(f"planner work regime differs: {key}")
    if len(reference["outputs"]) != len(candidate["outputs"]):
        raise ValueError("planner output count differs")
    for left, right in zip(reference["outputs"], candidate["outputs"]):
        if any(left[key] != right[key] for key in ("name", "status", "coordinate")):
            raise ValueError("planner status or coordinate differs")
        if not math.isclose(left["value"], right["value"], rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError("planner numerical output differs")
    if not math.isclose(reference["checksum"], candidate["checksum"], rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError("planner checksum differs")


def invoke(binary, case, identity, deadline):
    remaining = deadline-time.monotonic()
    if remaining <= 0:
        raise TimeoutError("planner suite deadline exhausted")
    argv = [str(Path(binary).resolve()), "--case", case["id"], "--repetitions", str(case["repetitions"])]
    started = time.perf_counter()
    process = subprocess.run(argv, capture_output=True, text=True, timeout=remaining, check=False)
    wall = time.perf_counter()-started
    if process.returncode:
        raise ValueError(f"planner target exited {process.returncode}: {process.stderr[-1200:]}")
    row = json.loads(process.stdout)
    validate_native(row, case, identity)
    if row["operation_seconds"] > wall + .001:
        raise ValueError("planner native timer exceeds external process duration")
    return {"argv": argv, "wall_seconds": wall, "native": row}


def measure_case(case, binaries, identity, policy, deadline, output):
    from triad_perf_adaptive import summarize
    pairs = []; looks = []; case_dir = Path(output)/case["id"]
    case_dir.mkdir()
    for count in range(1, policy.looks[-1]+1):
        order = ("reference", "candidate") if count % 2 else ("candidate", "reference")
        pair = {"index": count, "order": list(order)}
        for name in order:
            pair[name] = invoke(binaries[name], case, identity["sources"][name], deadline)
        numerical_agreement(pair["reference"]["native"], pair["candidate"]["native"])
        pair["numerical_agreement"] = True
        write_json(case_dir/f"pair-{count:03d}.json", pair)
        pairs.append(pair)
        if count not in policy.looks:
            continue
        summary = summarize([row["reference"]["wall_seconds"] for row in pairs],
                            [row["candidate"]["wall_seconds"] for row in pairs],
                            policy, model_validation="direct_full")
        looks.append(summary)
        if summary["stop_reason"] != "continue":
            break
    result = {"id": case["id"], "workload": case, "status": "direct_full",
              "prediction_valid": True, "complete": True, "source_identity_verified": True,
              "functional_valid": True, "timing_boundary": manifest()["timing_boundary"],
              "full_target_observations_per_source": len(pairs), "pairs": pairs, "looks": looks,
              "adaptive": summary, "comparison": {"gate": summary["performance_gate"]},
              "runtime_estimand": "geometric mean complete process runtime; paired log-runtime ratio",
              "abbreviation_model": None,
              "unmeasured_work_scaling_claim": False}
    write_json(case_dir/"result.json", result)
    return result


def validate_routine_report(report, context):
    """Fail closed on changed sources, missing raw work, or non-passing cases."""
    from triad_perf_adaptive import AdaptivePolicy, regression_profile, summarize
    errors = []
    try:
        if report.get("schema") != SCHEMA:
            raise ValueError("unknown planner report schema")
        expected = identities(context["candidate_root"], context["reference_root"],
                              context["candidate_binary"], context["reference_binary"])
        if report.get("identity") != expected:
            raise ValueError("planner source, binary, harness, or environment identity changed")
        profile = context["regression_profile"]
        policy = AdaptivePolicy(stopping_rule="decision", **regression_profile(profile))
        if report.get("policy") != json.loads(json.dumps(asdict(policy))):
            raise ValueError("planner decision policy changed")
        case_rows = manifest()["cases"]
        if [row.get("id") for row in report.get("cases", [])] != [row["id"] for row in case_rows]:
            raise ValueError("planner full inventory is incomplete")
        if not all(report.get(key) is True for key in
                   ("completed", "source_identity_verified", "functional_valid", "prediction_valid")):
            raise ValueError("planner run is incomplete or invalid")
        path = Path(context["report_path"])
        plan = json.loads((path.parent/"plan.json").read_text())
        if plan != report.get("plan") or plan["identity"] != expected:
            raise ValueError("planner frozen plan differs")
        if plan["cases"] != case_rows or plan["policy"] != report["policy"]:
            raise ValueError("planner plan workload or policy differs")
        for result, case in zip(report["cases"], case_rows):
            pairs = result["pairs"]
            if result["workload"] != case or len(pairs) not in policy.looks:
                raise ValueError("planner work or observation count differs")
            for index, pair in enumerate(pairs, 1):
                if pair != json.loads((path.parent/case["id"]/f"pair-{index:03d}.json").read_text()):
                    raise ValueError("planner raw pair differs")
                order = ["reference", "candidate"] if index % 2 else ["candidate", "reference"]
                if pair["index"] != index or pair["order"] != order:
                    raise ValueError("planner pair ordering changed")
                for side in ("reference", "candidate"):
                    validate_native(pair[side]["native"], case, expected["sources"][side])
                    wall = pair[side]["wall_seconds"]
                    if not math.isfinite(wall) or wall <= 0 or pair[side]["native"]["operation_seconds"] > wall + .001:
                        raise ValueError("planner external timer is invalid")
                numerical_agreement(pair["reference"]["native"], pair["candidate"]["native"])
                if index in policy.looks:
                    replay = summarize([row["reference"]["wall_seconds"] for row in pairs[:index]],
                                       [row["candidate"]["wall_seconds"] for row in pairs[:index]],
                                       policy, model_validation="direct_full")
                    if replay["stop_reason"] != "continue" and index != len(pairs):
                        raise ValueError("planner collected observations after its stopping decision")
            if replay != result["adaptive"] or replay["performance_gate"] != "pass":
                raise ValueError("planner replay does not support a pass")
        return {"valid": True, "status": "passed", "errors": [], "gap_ids": [GAP],
                "outcomes": {"functional": "pass", "timing": "direct_full", "regression": "pass",
                             "scope": "six fixed native planner/statistics bundles; no GPU or Gaussian-design-bound claim"}}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append(str(exc))
    return {"valid": False, "status": "unqualified", "errors": errors, "gap_ids": [],
            "outcomes": {"regression": "unqualified"}}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, default=ROOT)
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--candidate-binary", type=Path, required=True)
    parser.add_argument("--reference-binary", type=Path, required=True)
    parser.add_argument("--regression-profile", choices=("normal", "ci", "strict"), default="normal")
    parser.add_argument("--budget-seconds", type=float, default=120.)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", default=[])
    args = parser.parse_args(argv)
    started = time.monotonic()
    from triad_perf_adaptive import AdaptivePolicy, regression_profile
    policy = AdaptivePolicy(stopping_rule="decision", **regression_profile(args.regression_profile))
    args.output.mkdir(parents=True, exist_ok=False)
    report = {"schema": SCHEMA, "regression_profile": args.regression_profile,
              "policy": json.loads(json.dumps(asdict(policy))), "cases": [], "errors": [],
              "completed": False, "source_identity_verified": False,
              "functional_valid": False, "prediction_valid": False, "coverage_gap_ids": []}
    try:
        if not math.isfinite(args.budget_seconds) or args.budget_seconds <= 0:
            raise ValueError("planner budget must be finite and positive")
        rows = manifest()["cases"]
        if set(args.case)-{row["id"] for row in rows}:
            raise ValueError("unknown planner case selection")
        selected = [row for row in rows if not args.case or row["id"] in args.case]
        identity = identities(args.candidate_root, args.reference_root, args.candidate_binary, args.reference_binary)
        report["identity"] = identity
        plan = {"schema": SCHEMA, "identity": identity, "cases": selected,
                "policy": report["policy"], "timing_boundary": manifest()["timing_boundary"],
                "all_observations_are_direct_full_targets": True,
                "deadline_seconds": args.budget_seconds}
        report["plan"] = plan
        write_json(args.output/"plan.json", plan)
        binaries = {"candidate": args.candidate_binary, "reference": args.reference_binary}
        for case in selected:
            report["cases"].append(measure_case(case, binaries, identity, policy,
                                               started+args.budget_seconds, args.output))
        if identity != identities(args.candidate_root, args.reference_root, args.candidate_binary, args.reference_binary):
            raise ValueError("planner identities changed during measurement")
        report.update(completed=True, source_identity_verified=True, functional_valid=True, prediction_valid=True)
        report["full_inventory"] = len(selected) == len(rows)
        if report["full_inventory"] and all(row["comparison"]["gate"] == "pass" for row in report["cases"]):
            report["coverage_gap_ids"] = [GAP]
    except (OSError, ValueError, TimeoutError, subprocess.TimeoutExpired) as exc:
        report["errors"].append(str(exc))
    report["wall_seconds"] = time.monotonic()-started
    write_json(args.output/"summary.json", report)
    print(json.dumps({"summary": str(args.output/"summary.json"), "wall_seconds": report["wall_seconds"],
                      "complete": report["completed"], "errors": report["errors"]}))
    return 0 if report["completed"] and all(row["comparison"]["gate"] == "pass" for row in report["cases"]) else 2


if __name__ == "__main__":
    raise SystemExit(main())

"""Small resource-contract controls; native qualification is an explicit command."""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import triad_perf_resource as resource


def manifest(seconds=32, mode="paired", *, memory_mib=7, seed=1):
    rows = seconds * 512 + 512
    return {"format": "triad-group-block-stats-v1", "stats_noisy": True,
            "sample_count": rows, "block_samples": 2048, "block_count": math.ceil(rows / 2048),
            "channel_samples": rows, "channel_tail_samples": 512, "source_samples": rows - 512,
            "group_count": 3, "dimension": 4, "candidate_count": 6, "sample_rate": 512,
            "candidates": [0, 1], "groups": [0, 1, 2],
            "grouped_export_execution": {"channel_pass_mode": mode, "basis_synthesis_passes": 1 if mode == "paired" else 2,
                 "worker_threads_used": 1, "bounded_workspace_bytes": int((6.5 if mode == "paired" else 4.5) * resource.MIB)},
            "file_sizes": {name: 8 for name in resource.FILES}}


def fake_record(binary, config, seconds, seed, memory_mib, mode, directory, **kwargs):
    meta = manifest(seconds, mode, memory_mib=memory_mib, seed=seed)
    regime, work = resource.work_record(meta, config, memory_mib, mode)
    elapsed = .025 + work["sample_count"] * (.000002 if mode == "paired" else .000003)
    return resource.sealed({"requested_seconds": seconds, "seed": seed,
                            "full_test_wall_seconds": elapsed, "regime": regime, "work": work,
                            "file_sizes": meta["file_sizes"],
                            "file_sha256": {name: resource.digest([name, seed, seconds]) for name in resource.FILES},
                            "native_execution": meta["grouped_export_execution"],
                            "timing_boundary": "synthetic complete target", "harness_wall_seconds": elapsed})


def fake_identity(binary, root, threads=1):
    return {"binary_sha256": resource.digest(str(binary)), "source": str(root), "threads": threads}


class ResourceTests(unittest.TestCase):
    def setUp(self):
        self.config = resource.load_config()

    def test_real_branch_counters_and_complete_work_required(self):
        paired, work = resource.work_record(manifest(), self.config, 7, "paired")
        seq, seq_work = resource.work_record(manifest(mode="sequential"), self.config, 6, "sequential")
        self.assertEqual(seq_work["basis_values"], 2 * work["basis_values"])
        self.assertEqual(seq_work["gram_terms"], work["gram_terms"])
        self.assertEqual(seq_work["channel_rows"], work["channel_rows"])
        self.assertEqual(resource.bracket({"regime": paired, "native_execution": manifest()["grouped_export_execution"]}),
                         {"paired": 7, "sequential": 6})
        for field, value in (("basis_synthesis_passes", 2), ("worker_threads_used", 2)):
            bad = manifest(); bad["grouped_export_execution"][field] = value
            with self.assertRaises(resource.ResourcePerformanceError):
                resource.work_record(bad, self.config, 7, "paired")
        bad = manifest(); bad["channel_samples"] -= 1
        with self.assertRaises(resource.ResourcePerformanceError):
            resource.work_record(bad, self.config, 7, "paired")
        with self.assertRaises(resource.ResourcePerformanceError):
            resource.work_record(manifest(), self.config, 6, "paired")

    def test_independent_affine_regimes_and_scope(self):
        a, b = [fake_record("b", self.config, n, 1, 7, "paired", ".") for n in (32, 48)]
        target = 64 * 512 + 512
        result = resource.forecast([a, b], target, self.config)
        self.assertAlmostEqual(result["full_test_wall_seconds"], .025 + target * .000002)
        bad = fake_record("b", self.config, 48, 1, 6, "sequential", ".")
        with self.assertRaisesRegex(resource.ResourcePerformanceError, "crossed"):
            resource.forecast([a, bad], target, self.config)
        with self.assertRaises(resource.ResourcePerformanceError):
            resource.forecast([a, b], target * 2, self.config)

    def test_byte_parity_is_not_nominal_metadata_parity(self):
        a = fake_record("b", self.config, 64, 7, 7, "paired", ".")
        b = fake_record("b", self.config, 64, 7, 6, "sequential", ".")
        self.assertTrue(resource.compare_outputs(a, b, across_regimes=True)["byte_identical"])
        b["file_sha256"][resource.FILES[0]] = "different"
        with self.assertRaisesRegex(resource.ResourcePerformanceError, "actual sufficient-statistic bytes"):
            resource.compare_outputs(a, b, across_regimes=True)

    def test_arithmetic_forecast_and_holdout_uncertainty_both_count(self):
        good = resource.qualification([1.] * 5, [1.] * 3, self.config)
        self.assertEqual(good["status"], "validated")
        self.assertEqual(good["actual_over_frozen_forecast_mean_interval"], [1., 1.])
        self.assertEqual(resource.qualification([1.] * 5, [1.3] * 3, self.config)["status"], "invalid")
        self.assertEqual(resource.qualification([.5, .7, 1, 1.3, 1.5], [1.] * 3, self.config)["status"], "inconclusive")
        with self.assertRaisesRegex(resource.ResourcePerformanceError, "fixed look"):
            resource.qualification([1.] * 5, [1.] * 4, self.config)

    def _anchor(self, directory):
        full_calls = []
        def run(*args, **kwargs):
            if args[2] == 64:
                self.assertTrue((Path(directory) / "frozen.json").is_file())
                full_calls.append(args[3])
            return fake_record(*args, **kwargs)
        geometry = {"performance_geometry": {"capture_samples": 64 * 512 + 512}}
        with (patch.object(resource, "run_export", side_effect=run),
              patch.object(resource, "binary_identity", side_effect=fake_identity),
              patch.object(resource, "target_geometry", return_value=geometry)):
            anchor = resource.qualify("candidate", ROOT, directory, config=self.config)
        self.assertEqual(full_calls, [self.config["seed"] + 100000 + i for i in range(3) for _ in range(2)])
        return anchor

    def test_target_counter_comes_from_geometry_not_requested_seconds(self):
        # Actual observed private-tile rounding from the first native attempt.
        a, b = [fake_record("b", self.config, n, 1, 7, "paired", ".") for n in (32, 48)]
        for row, rows in ((a, 18000), (b, 29879)):
            row["work"]["sample_count"] = rows
            row["full_test_wall_seconds"] = .025 + .000002 * rows
        geometry = {"performance_geometry": {"capture_samples": 35818}}
        target = resource._target_rows(geometry)
        self.assertNotEqual(target, 2 * b["work"]["sample_count"] - a["work"]["sample_count"])
        predicted = resource.forecast([a, b], target, self.config)
        self.assertAlmostEqual(predicted["full_test_wall_seconds"], .025 + .000002 * 35818)

    def test_forecast_is_frozen_before_full_validation_and_proof_replays(self):
        with tempfile.TemporaryDirectory() as tmp:
            anchor = self._anchor(tmp)
            self.assertEqual(anchor["status"], "validated")
            self.assertTrue(resource.historical_proof(json.loads(json.dumps(anchor))))
            bad = copy.deepcopy(anchor)
            bad["full_holdouts"]["paired"][0]["full_test_wall_seconds"] *= 1.4
            bad["full_holdouts"]["paired"][0] = resource.sealed(bad["full_holdouts"]["paired"][0])
            bad = resource.sealed(bad)
            self.assertFalse(resource.historical_proof(bad))
            bad = copy.deepcopy(anchor)
            bad["frozen"]["identity"]["binary_sha256"] = "changed"
            self.assertFalse(resource.historical_proof(bad))

    def test_direct_routine_profiles_complete_target_and_wrapper_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            anchor = self._anchor(tmp)
            anchor_path = Path(tmp) / "anchor.json"
            with patch.object(resource, "run_export", side_effect=fake_record), patch.object(resource, "binary_identity", side_effect=fake_identity):
                for profile in ("normal", "ci"):
                    result = resource.routine("candidate", "reference", ROOT, ROOT, anchor, tmp,
                                              profile=profile, config=self.config)
                    result = json.loads(json.dumps(result))
                    checked = resource.validate_routine_report(result, {"anchor": anchor_path,
                        "binary": "candidate", "reference_binary": "reference", "candidate_root": ROOT,
                        "reference_root": ROOT, "device": "cuda", "native_threads": 1,
                        "regression_profile": profile})
                    self.assertTrue(checked["valid"], checked)
                    self.assertEqual(checked["status"], "passed")
                    self.assertEqual(checked["execution_backend"], "cpu")
                    self.assertEqual(result["policy"]["pass_alpha"], .15 if profile == "normal" else .30)
                    self.assertEqual(result["policy"]["failure_alpha"], .05)
                    self.assertTrue(all(len(c["raw_pairs"]) == 5 for c in result["cases"]))
                    self.assertTrue(all(r["requested_seconds"] == 64 for c in result["cases"] for p in c["raw_pairs"] for r in p.values()))
                    bad = copy.deepcopy(result); bad["identities"]["candidate"]["binary_sha256"] = "bad"
                    bad = resource.sealed(bad)
                    self.assertFalse(resource.validate_report(bad, anchor_path=anchor_path,
                        binary="candidate", reference_binary="reference", source_root=ROOT, reference_root=ROOT,
                        profile=profile)["valid"])

    def test_full_only_and_outside_receiver_slowdown_are_measured(self):
        with tempfile.TemporaryDirectory() as tmp:
            anchor = self._anchor(tmp)
            def changed(*args, **kwargs):
                row = fake_record(*args, **kwargs)
                if args[0] == "candidate" and args[2] == 64:
                    row["full_test_wall_seconds"] *= 1.4
                return resource.sealed(row)
            with patch.object(resource, "run_export", side_effect=changed), patch.object(resource, "binary_identity", side_effect=fake_identity):
                normal = resource.routine("candidate", "reference", ROOT, ROOT, anchor, tmp,
                                          profile="normal", config=self.config)
                ci = resource.routine("candidate", "reference", ROOT, ROOT, anchor, tmp,
                                      profile="ci", config=self.config)
            self.assertEqual(normal["status"], "regression")
            self.assertEqual(ci["status"], "pass")
            self.assertFalse(normal["complete_scope"])

    def test_process_boundary_includes_native_work_and_excludes_hashes(self):
        def fake_run(argv, **kwargs):
            target = Path(argv[argv.index("--output") + 1]); target.mkdir()
            for name in resource.FILES:
                (target / name).write_bytes(b"12345678")
            (target / "manifest.json").write_text(json.dumps(manifest()))
            time.sleep(.003)
            return subprocess.CompletedProcess(argv, 0, "", "")
        with tempfile.TemporaryDirectory() as tmp, patch.object(resource.subprocess, "run", side_effect=fake_run):
            result = resource.run_export("binary", self.config, 32, 3, 7, "paired", tmp)
            self.assertGreaterEqual(result["full_test_wall_seconds"], .003)
            self.assertGreaterEqual(result["harness_wall_seconds"], result["full_test_wall_seconds"])
            self.assertEqual(list(Path(tmp).iterdir()), [])
            self.assertTrue(resource.verify_seal(result))


if __name__ == "__main__":
    unittest.main()

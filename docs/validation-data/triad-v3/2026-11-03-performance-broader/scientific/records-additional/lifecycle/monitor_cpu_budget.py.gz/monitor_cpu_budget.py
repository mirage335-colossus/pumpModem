"""Bounded external scheduler stop; does not change the frozen lifecycle protocol."""
import json,math,os,signal,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import triad_perf_lifecycle as life
base=Path('local-evidence/triad-performance-broader/lifecycle/cpu-qual-001')
mixed=base/'mixed-cpu';anchor=base.parent/'cpu-anchors/mixed-cpu.lifecycle-anchor.json'
receipt=base.parent/'cpu-qual-001-external-stop.json'
assert life.sha(life.WORKER)=='35e543ac8a84ad879dedb1aa39628e995ad1584e5e4e921d207dda581fe3b40a'

def controller():
 found=[]
 for path in Path('/proc').iterdir():
  if not path.name.isdecimal():continue
  try:argv=(path/'cmdline').read_bytes().split(b'\0');argv=[a.decode(errors='replace') for a in argv if a]
  except OSError:continue
  if len(argv)>2 and argv[1].endswith('tools/triad_perf_lifecycle.py') and '--output' in argv:
   output=Path(argv[argv.index('--output')+1])
   if output.resolve()==base.resolve():found.append(int(path.name))
 if len(found)>1:raise RuntimeError('ambiguous owned lifecycle controller')
 return found[0] if found else None

def processes():
 records={}
 for path in Path('/proc').iterdir():
  if not path.name.isdecimal():continue
  try:
   value=(path/'stat').read_text();fields=value[value.rfind(')')+2:].split()
   records[int(path.name)]=(int(fields[1]),fields[19])
  except (OSError,ValueError,IndexError):continue
 return records

def same_process(pid,token):
 return processes().get(pid,(None,None))[1]==token

while True:
 pid=controller()
 if pid is None or (mixed/'result.json').exists() or anchor.exists():
  print('Controller completed or produced final case/anchor; no scheduling stop')
  break
 files=sorted(mixed.glob('validation-*.json'))
 if len(files)<5:
  time.sleep(.25);continue
 try:
  rows=[json.loads(p.read_text()) for p in files[:5]]
  frozen=json.loads((mixed/'forecast.json').read_text())
 except (json.JSONDecodeError,OSError):
  time.sleep(.1);continue
 check=life.model_validation(rows,frozen,.1)
 if check['status']!='inconclusive':
  print('Fifth look resolved; permit frozen controller to finalize')
  break
 # Sum disjoint completed target timers as a LOWER bound on elapsed run wall.
 # Estimated future cost remains an engineering schedule estimate.
 recorded=[]
 cold=json.loads((base/'cold-cpu-phase/result.json').read_text())
 recorded.extend(cold['full_pairs'])
 for pattern in ['discarded-pilot-*.json','training-*.json','validation-*.json']:
  recorded.extend(json.loads(p.read_text()) for p in sorted(mixed.glob(pattern)))
 elapsed_lower=sum(r[n]['complete_seconds'] for r in recorded for n in life.SOURCES)
 pair_costs=[sum(r[n]['complete_seconds'] for n in life.SOURCES) for r in rows]
 next_cost=4*sum(pair_costs)/len(pair_costs)
 remaining_upper=max(0.,1800-elapsed_lower)
 if next_cost<=remaining_upper:
  print('Next look may fit; no external scheduling stop')
  break
 # Pause the controller before enumerating its descendants so it cannot start
 # another exporter during collection. Only this exact output owner is stopped.
 os.kill(pid,signal.SIGSTOP)
 snapshot=processes();owned={pid};changed=True
 while changed:
  changed=False
  for child,(parent,token) in snapshot.items():
   if parent in owned and child not in owned:owned.add(child);changed=True
 for child in owned-{pid}:
  try:os.kill(child,signal.SIGTERM)
  except ProcessLookupError:pass
 os.kill(pid,signal.SIGINT);os.kill(pid,signal.SIGCONT)
 until=time.monotonic()+5
 while time.monotonic()<until and any(same_process(p,snapshot[p][1]) for p in owned):time.sleep(.1)
 for child in owned:
  if same_process(child,snapshot[child][1]):
   try:os.kill(child,signal.SIGKILL)
   except ProcessLookupError:pass
 value={'status':'externally_stopped_inconclusive','completed_validation_pairs':5,
  'reason':'Predeclared next9 look cannot be scheduled in remaining1800s using observed pair costs',
  'model_look5':check,'completed_target_timer_elapsed_lower_seconds':elapsed_lower,
  'remaining_budget_upper_seconds':remaining_upper,'estimated_next9_additional_seconds':next_cost,
  'frozen_protocol_sha256':life.sha(life.WORKER),'source_modified':False,
  'partial_later_pair_excluded':True,'owned_controller_and_descendants_stopped':True,
  'interpretation':'Scheduling interruption is not a validated forecast or confirmed receiver regression'}
 receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));break

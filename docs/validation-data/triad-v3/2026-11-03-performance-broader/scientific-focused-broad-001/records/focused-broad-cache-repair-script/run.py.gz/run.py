#!/usr/bin/env python3
"""One existing broad-HF FFT prediction chain, preserving qualified fixture bytes."""
from __future__ import annotations
import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def load(path):
    spec = importlib.util.spec_from_file_location('_focused_fft_controller', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class ObservedWorker:
    """Delegate unchanged API requests, retaining completed work outside its timer."""
    def __init__(self, worker, case, path):
        self.worker, self.case, self.path = worker, case, path
        self.identity = worker.identity
        self.full_calls = 0
        self.requests = 0

    def request(self, request):
        result = self.worker.request(request)
        self.requests += 1
        # Checkpoint before assertions so failed geometry remains inspectable.
        with self.path.open('a') as stream:
            stream.write(json.dumps({'request_id': self.requests, 'request': request,
                'result': result}, allow_nan=False)+'\n')
        if request['action'] == 'prepare':
            if result['input_hashes'] != self.case['fixture_hashes']:
                raise ValueError('prepared fixture bytes differ from frozen case')
            if result['geometry']['lags'] != self.case['configuration']['lag_group_count']:
                raise ValueError('prepared timing lattice differs from full target')
        elif request['action'] == 'score':
            count = len(request['frequency_offsets_hz'])
            expected = count*self.case['configuration']['lag_group_count']
            ranks = result['rank_histogram']
            if (not isinstance(ranks, list) or
                    any(type(x) is not int or x < 0 for x in ranks) or
                    sum(ranks) != expected or result['measured_group_count'] != expected or
                    result['geometry']['group_count'] != expected):
                raise ValueError('completed rank/work counters differ from requested full lattice')
            if count == len(self.case['frequency_offsets_hz']):
                if request['frequency_offsets_hz'] != self.case['frequency_offsets_hz']:
                    raise ValueError('full score grid changed')
                self.full_calls += 1
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ('source-root', 'reference-root', 'binary', 'fixture-cache',
                   'anchor-directory', 'prior-health-report', 'output'):
        parser.add_argument('--'+option, type=Path, required=True)
    parser.add_argument('--device', choices=('cpu', 'cuda'), required=True)
    parser.add_argument('--budget-seconds', type=float, default=300.)
    args = parser.parse_args()
    if not 0 < args.budget_seconds <= 300:
        parser.error('budget must be positive and no greater than 300 seconds')
    started = time.monotonic(); deadline = started+args.budget_seconds
    source, reference = args.source_root.resolve(), args.reference_root.resolve()
    out = args.output.resolve(); out.mkdir(parents=True, exist_ok=False)
    expected_path = Path(__file__).with_name('expected-sources.json')
    expected = json.loads(expected_path.read_text())
    observed = {name: sha(source/name) for name in expected}
    if observed != expected:
        write(out/'source-mismatch.json', {'expected': expected, 'observed': observed})
        raise ValueError('reviewed source snapshot does not match')
    sys.path.insert(0, str(source/'tools'))
    import triad_perf_fft_trace as trace
    from triad_perf_adaptive import AdaptivePolicy, regression_profile
    from triad_perf_cases import prepare_cases, PUBLIC_FILES
    from triad_perf_hardware import discover_hardware
    api = load(source/'tools/triad-performance.py')
    policy = AdaptivePolicy(looks=(5, 9, 17, 33), family_count=14,
                            stopping_rule='decision', **regression_profile('normal'))
    anchor_dir = args.anchor_directory.resolve(strict=True)
    before_anchors = {str(p): sha(p) for p in anchor_dir.glob('*.anchor.json')}
    if not before_anchors:
        raise ValueError('no original full-work anchors available')
    plan = {'schema': 'triad-focused-broad-fft-reuse-v1', 'argv': sys.argv,
        'wrapper_sha256': sha(__file__), 'expected_source_manifest_sha256': sha(expected_path),
        'source_sha256': observed, 'source_root': str(source), 'reference_root': str(reference),
        'native_binary_sha256': sha(args.binary), 'fixture_cache': str(args.fixture_cache.resolve()),
        'anchor_directory': str(anchor_dir), 'original_anchor_sha256': before_anchors,
        'prior_health_report': str(args.prior_health_report.resolve()),
        'prior_health_report_sha256': sha(args.prior_health_report),
        'case': 'broad-hf-timing', 'device': args.device, 'threads': 2,
        'profile': 'normal', 'adaptive_policy': asdict(policy), 'maximum_seconds': args.budget_seconds,
        'target_boundary': 'resident full sampled FFT preparation plus complete wrapped score; fixture generation, native configure, interpreter startup and finalization are separately charged in component wall',
        'procedure': 'existing cached fixture; existing eligible historical precision; unchanged measure_fft reuse with independently measured full endpoint',
        'hardware_stress': 'not repeated; prior report retained separately and descriptor compared exactly',
        'retry_policy': 'none; preserve invalid, inconclusive and budget outcomes',
        'scope': 'one focused component; no complete CI, hardware-health or release claim'}
    write(out/'plan.json', plan)
    summary = {'schema': plan['schema'], 'status': 'running', 'complete_suite_claim': False,
               'plan_sha256': sha(out/'plan.json')}
    actual_workers, workers = {}, {}
    try:
        prior = json.loads(args.prior_health_report.read_text())
        hardware = discover_hardware(args.device, threads=2)
        write(out/'environment.json', {'current': hardware, 'prior': prior['hardware_profile']['hardware'],
              'retained_prior_health': prior.get('hardware_health'), 'fresh_stress_performed': False})
        if hardware != prior['hardware_profile']['hardware']:
            raise ValueError('current hardware/dependency descriptor differs from retained health report')
        begin = time.monotonic()
        cases = prepare_cases(args.binary.resolve(), args.fixture_cache.resolve(), profile='ci',
            deadline=deadline, source_root=source, case_ids=['broad-hf-timing'])
        summary['fixture_setup_seconds'] = time.monotonic()-begin
        if len(cases) != 1 or cases[0]['id'] != 'broad-hf-timing':
            raise ValueError('unexpected target selection')
        case = cases[0]; case['performance_environment'] = hardware
        write(out/'case.json', case)
        if not case['source_bound_metadata']['cache_hit']:
            raise ValueError('qualified immutable fixture was not reused')
        for name, root in (('reference', reference), ('candidate', source)):
            worker = api.ReceiverWorker(root, threads=2, deadline=deadline,
                                       log_directory=out, name=name)
            actual_workers[name] = worker
            workers[name] = ObservedWorker(worker, case, out/(name+'-responses.jsonl'))
        write(out/'workers.json', {n: {'identity': w.identity,
            'external_startup_seconds': w.external_startup_seconds} for n,w in actual_workers.items()})
        numeric = api.qualify_fft(case, workers, args.device, historical_anchor_directory=anchor_dir)
        write(out/'precision-qualification.json', numeric)
        if numeric['selection_method'] != 'eligible_exact_historical_precision':
            raise ValueError('no numerically eligible exact historical precision')
        precision = numeric['selected']
        prepared = {n: w.request(api.prepare_request(case, precision, args.device)) for n,w in workers.items()}
        geometries = [{k: prepared[n]['geometry'][k] for k in trace.GEOMETRY} for n in workers]
        if geometries[0] != geometries[1]:
            raise ValueError('preflight paired geometry differs')
        identity = trace._identity(case, workers, precision, args.device, geometries[0])
        anchor, reason = trace._find_anchor(anchor_dir, identity)
        write(out/'preflight.json', {'identity': identity, 'anchor': anchor, 'reason': reason})
        if not anchor or anchor['path'] != numeric['historical_precision_lookups'][precision]['anchor_path']:
            raise ValueError('historical lookup changed after arithmetic selection')
        measured = trace.measure_fft(case, workers, precision, args.device, policy=policy,
            deadline=deadline, api=api, anchor_directory=anchor_dir, validation_mode='reuse')
        write(out/'measurement.json', measured)
        guard = api.endpoint_calibration_guard(measured)
        write(out/'endpoint-guard.json', guard)
        summary.update(precision=precision, selection_method=numeric['selection_method'],
            prediction_valid=measured['prediction_valid'], comparison=measured['comparison'],
            endpoint_guard=guard, measured_helper_seconds=measured['elapsed_seconds'],
            actual_full_score_calls={n: w.full_calls for n,w in workers.items()},
            original_selected_anchor_sha256=sha(anchor['path']))
        if (not measured['prediction_valid'] or not measured['full_target_measured'] or
                measured['full_target_measurement_count_per_source'] < 1 or
                any(w.full_calls < 1 for w in workers.values()) or
                measured['comparison']['gate'] != 'pass' or
                not measured['comparison']['performance_pass_eligible'] or guard['blocking']):
            raise ValueError('focused model/full-endpoint/performance gate is not qualified to pass')
        summary['status'] = 'passed_component'
    except BaseException as error:
        summary.update(status='incomplete_component', error=f'{type(error).__name__}: {error}',
                       traceback=traceback.format_exc())
    finally:
        for worker in actual_workers.values():
            worker.close()
        final_hashes = {name: sha(source/name) for name in expected}
        original_anchor_unchanged = all(Path(p).is_file() and sha(p) == h for p,h in before_anchors.items())
        fixture_unchanged = 'case' not in locals() or all(
            sha(Path(case['input_directory'])/name) == case['fixture_hashes'][name] for name in PUBLIC_FILES)
        summary.update(source_unchanged=final_hashes == expected,
            original_anchors_unchanged=original_anchor_unchanged, fixture_unchanged=fixture_unchanged,
            descendants_stopped=all(w.process.poll() is not None for w in actual_workers.values()),
            component_wall_seconds=time.monotonic()-started)
        if not all(summary[k] for k in ('source_unchanged','original_anchors_unchanged',
                                       'fixture_unchanged','descendants_stopped')):
            summary['status'] = 'incomplete_component'
        write(out/'summary.json', summary)
    print(json.dumps(summary, allow_nan=False))
    return 0 if summary['status'] == 'passed_component' else 2


if __name__ == '__main__':
    raise SystemExit(main())

"""Reverse recorded post-campaign edits and require the campaign's exact hash."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
POST_SHA = "0316dcb5f19a34541ad551e20be9bf80c9cd2c7595a237e155c31a86172a7dc7"
PRE_SHA = "114f5d87d43f6fcf66d1c4144aa1ca24292f35ffaf896d46018f1088d01f7862"
post_path = HERE/"postchange-triad_perf_staged.py"
post_bytes = post_path.read_bytes()
assert hashlib.sha256(post_bytes).hexdigest() == POST_SHA
post = post_bytes.decode()
edits = [
    ('LEGACY_NATIVE_DIRECT_DRIVER_SHA256 = "114f5d87d43f6fcf66d1c4144aa1ca24292f35ffaf896d46018f1088d01f7862"\n', ""),
    ('        "afd3592550ce6dd57f21ae8b351399baa2459d9e8b3c19511281446bf6bdd5cd"),',
     '        "f59f02a9eca8c2893c7f695d5a5fcafb79cce47c5e36ba7084573840d7052705"),'),
    ('REVIEWED_NATIVE_DIRECT_DEPENDENCIES = {\n'
     '    "triad-performance.py": "f59f02a9eca8c2893c7f695d5a5fcafb79cce47c5e36ba7084573840d7052705",\n'
     '}\n', ""),
    ('        origins = {versions[0], REVIEWED_DECISION_DEPENDENCIES[key], REVIEWED_PROFILE_DEPENDENCIES.get(key),\n'
     '                   REVIEWED_NATIVE_DIRECT_DEPENDENCIES.get(key)}',
     '        origins = {versions[0], REVIEWED_DECISION_DEPENDENCIES[key], REVIEWED_PROFILE_DEPENDENCIES.get(key)}'),
    ('               LEGACY_PROFILE_DRIVER_SHA256: "40e_explicit_native_route_only",\n'
     '               LEGACY_NATIVE_DIRECT_DRIVER_SHA256: "114_fixture_cache_and_arithmetic_policy_only"}',
     '               LEGACY_PROFILE_DRIVER_SHA256: "40e_explicit_native_route_only"}'),
]
pre = post
for old, new in edits:
    assert pre.count(old) == 1, old
    pre = pre.replace(old, new, 1)
pre_bytes = pre.encode()
observed = hashlib.sha256(pre_bytes).hexdigest()
assert observed == PRE_SHA, observed
target = HERE/"reconstructed-triad_perf_staged.py"
target.write_bytes(pre_bytes)
patch = "".join(difflib.unified_diff(pre.splitlines(True), post.splitlines(True),
    fromfile="staged-114-prechange.py", tofile="staged-0316-postchange.py"))
patch_path = HERE/"recorded-forward-edits.patch"
patch_path.write_text(patch)
receipt = {
    "classification": "reconstructed exact source bytes",
    "contemporaneous_original_snapshot": False,
    "method": "reverse the five recorded source edits applied after CPUcomplete001; require its independently recorded prechange SHA256",
    "input_postchange_path": str(post_path), "input_postchange_sha256": POST_SHA,
    "reconstruction_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "recorded_forward_patch_sha256": hashlib.sha256(patch_path.read_bytes()).hexdigest(),
    "expected_campaign_source_sha256": PRE_SHA,
    "reconstructed_path": str(target), "reconstructed_sha256": observed,
    "exact_expected_hash_match": True,
    "scope": "Source preservation only. The live source and historical campaign results are unchanged; no runtime measurements were repeated.",
}
(HERE/"reconstruction.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(target, observed)

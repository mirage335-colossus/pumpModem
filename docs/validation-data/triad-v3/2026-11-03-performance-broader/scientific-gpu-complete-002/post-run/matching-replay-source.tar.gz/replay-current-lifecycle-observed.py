import pathlib,tarfile,sys,json,importlib.util,hashlib,time
base=pathlib.Path('/tmp/triad-current-validation');base.mkdir(exist_ok=False)
with tarfile.open('/tmp/current-validation-tools.tar.gz') as t:t.extractall(base,filter='data')
for f in pathlib.Path('/workspace/triad/tools').iterdir():
 p=base/'tools'/f.name
 if f.is_file() and not p.exists():p.symlink_to(f)
sys.path.insert(0,'/workspace/triad/tools')
spec=importlib.util.spec_from_file_location('current_lifecycle_validation',base/'tools/triad_perf_lifecycle.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=pathlib.Path('/workspace/triad')
outer=json.loads(pathlib.Path('/workspace/evidence/complete-routine-002/summary.json').read_text());ctx=outer['extensions']['lifecycle']['context'];ctx['mixed_method']='modeled';ctx['direct_cycles']='6'
report=json.loads(pathlib.Path(ctx['report_path']).read_text());start=time.perf_counter();v=m.validate_routine_report(report,ctx);v['validation_wall_seconds']=time.perf_counter()-start
v['current_source_sha256']={n:hashlib.sha256((base/'tools'/n).read_bytes()).hexdigest() for n in ('triad_perf_lifecycle.py','triad-performance-lifecycle.json','triad-performance.py','triad_perf_complete.py')}
p=pathlib.Path('/workspace/evidence/current-lifecycle-replay.json');p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2));raise SystemExit(0 if v['valid'] and v['status']=='passed' else 2)


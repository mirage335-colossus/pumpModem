import pathlib,sys,json,importlib.util,hashlib,time
base=pathlib.Path('/tmp/triad-current-validation')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(base/'tools/triad_perf_lifecycle.py')=='93de7a47b360bcb7531e72de5381cdb4b6feb0d10c0c44150697bc62704d7b80'
assert sha(base/'tools/triad-performance.py')=='afd3592550ce6dd57f21ae8b351399baa2459d9e8b3c19511281446bf6bdd5cd'
sys.path.insert(0,'/workspace/triad/tools')
spec=importlib.util.spec_from_file_location('current_lifecycle_validation_93',base/'tools/triad_perf_lifecycle.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=pathlib.Path('/workspace/triad')
outerpath=pathlib.Path('/workspace/evidence/complete-routine-002/summary.json');ctx=dict(json.loads(outerpath.read_text())['extensions']['lifecycle']['context'])
rawpath=pathlib.Path(ctx['report_path']);before=sha(rawpath);report=json.loads(rawpath.read_text());start=time.perf_counter();v=m.validate_routine_report(report,ctx);v['validation_wall_seconds']=time.perf_counter()-start
assert sha(rawpath)==before
v['original_report_sha256']=before;v['original_context']=ctx;v['current_source_sha256']={n:sha(base/'tools'/n) for n in ('triad_perf_lifecycle.py','triad-performance-lifecycle.json','triad-performance.py')}
p=pathlib.Path('/workspace/evidence/current-lifecycle-replay-93de7a47-afd35925.json')
with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps(v,indent=2));raise SystemExit(0 if v['valid'] and v['status']=='passed' else 2)

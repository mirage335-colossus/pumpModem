#!/bin/sh
# A small, offline entry point; CMake remains the build system.
# Compatible with Dash and traditional SVR4 Bourne shell; modern build tools are required.
# shellcheck disable=SC2006,SC2015
set -eu

usage() {
    cat <<'HELP'
Usage: ./build.sh [configure|build|test GROUP|sanitize [GROUP]|package] [OPTIONS] [-- CMAKE_ARGS...]

  configure            Configure the selected profile without building targets.
  build                Build pump and the FLTK GUI (default).
  test GROUP           Build then run contract, regular, fast, legacy, gui,
                       frontends, web, native, packaging, build, amplitude_probability, amplitude_arrival,
                       triad, or all tests.
  sanitize [GROUP]     Run instrumented headless tests (default: contract).
  package              Build and verify portable TGZ and ZIP bundles.

  --tui                Also build datapump-tui (ncurses; combine with --cli for no GUI).
  --fb                 Also build datapump-fb (software renderer with SDL2 host).
  --web-worker         Also build the socket-free inherited-pipe datapump-worker.
  --cli                Omit the native GUI (shared GUI tests remain available).
  --backend fltk|rev   Select a GUI backend; Rev needs its own suitable toolchain.
  --jobs N, -j N       Explicit parallel build/test limit (tests default to 2).
  --build-jobs N       Override compilation concurrency; keep --jobs for tests.
                       Default: available CPUs minus one, capped by available RAM.
  --stop-on-failure   Stop a test run after its first failed test (CI feedback).
  --build-dir PATH     Separate output tree, e.g. for another compiler/toolchain.
  --sdk PATH           Use a prepared source SDK; keep host dependencies separate.
  --wasm-sdk PATH      Build browser C++ using a separately prepared Wasm SDK.
  --help, -h           Show this help.

Environment: DATAPUMP_JOBS (or CMAKE_BUILD_PARALLEL_LEVEL), CC, CXX,
CMAKE_GENERATOR, DATAPUMP_MAX_GLIBC (optional explicit package ABI ceiling).
Ninja is preferred for new trees; Unix Makefiles is the fallback. No downloads.
Examples:
  ./build.sh test contract --jobs 4
  ./build.sh --cli -- -DDATAPUMP_COMPILER_CACHE=OFF
  ./build.sh --build-dir build/custom -- -DCMAKE_TOOLCHAIN_FILE=/path/toolchain.cmake
HELP
}

die() { printf '%s\n' "build.sh: $*" >&2; exit 2; }
need_value() { [ "$#" -ge 2 ] || die "$1 needs a value"; }

# `type` exists in traditional Bourne; the later `command` builtin does not.
has_executable() { type "$1" >/dev/null 2>&1; }

# Return an executable path without parsing shell-specific `type` output or
# evaluating compiler arguments. Normalize empty PATH entries to the current
# directory before splitting, and disable pathname expansion during that split.
find_executable() {
    case "$1" in
        */*) [ -f "$1" ] && [ -x "$1" ] && printf '%s\n' "$1"; return ;;
    esac
    executable_name=$1
    search_path=`printf '%s' "$PATH" | sed 's/^:/.:/; :empty; s/::/:.:/g; t empty; s/:$/:./; s/^$/./'`
    saved_ifs=$IFS
    saved_flags=$-
    IFS=:
    set -f
    # Intentional PATH field splitting; globbing is disabled above.
    # shellcheck disable=SC2086
    set -- $search_path
    IFS=$saved_ifs
    case "$saved_flags" in *f*) ;; *) set +f ;; esac
    for executable_directory do
        if [ -f "$executable_directory/$executable_name" ] &&
           [ -x "$executable_directory/$executable_name" ]; then
            printf '%s\n' "$executable_directory/$executable_name"
            return 0
        fi
    done
    return 1
}

command_name=build
command_seen=no
group=
backend=fltk
backend_explicit=no
cli=no
tui=OFF
framebuffer=OFF
web_worker=OFF
jobs=${DATAPUMP_JOBS:-${CMAKE_BUILD_PARALLEL_LEVEL:-}}
jobs_explicit=no
[ -z "$jobs" ] || jobs_explicit=yes
jobs=${jobs:-2}
build_jobs=
build_jobs_explicit=no
build_dir=
sdk_root=
wasm_sdk_root=
stop_on_failure=no
while [ "$#" -gt 0 ]; do
    case "$1" in
        --help|-h) usage; exit 0 ;;
        --cli) cli=yes; shift ;;
        --tui) tui=ON; shift ;;
        --fb) framebuffer=ON; shift ;;
        --web-worker) web_worker=ON; shift ;;
        --stop-on-failure) stop_on_failure=yes; shift ;;
        --backend) need_value ${1+"$@"}; backend=$2; backend_explicit=yes; shift 2 ;;
        --jobs|-j) need_value ${1+"$@"}; jobs=$2; jobs_explicit=yes; shift 2 ;;
        --build-jobs) need_value ${1+"$@"}; build_jobs=$2; build_jobs_explicit=yes; shift 2 ;;
        --build-dir) need_value ${1+"$@"}; build_dir=$2; shift 2 ;;
        --wasm-sdk) need_value ${1+"$@"}; [ -n "$2" ] || die "--wasm-sdk needs a nonempty path"; wasm_sdk_root=$2; shift 2 ;;
        --sdk) need_value ${1+"$@"}; [ -n "$2" ] || die "--sdk needs a nonempty path"; sdk_root=$2; shift 2 ;;
        --) shift; break ;;
        configure|build|test|sanitize|package)
            if [ "$command_seen" = no ]; then
                command_name=$1; command_seen=yes
            elif [ "$1" = build ] && [ -z "$group" ] &&
                 { [ "$command_name" = test ] || [ "$command_name" = sanitize ]; }; then
                group=$1
            else die "unexpected command: $1"; fi
            shift ;;
        -*) die "unknown option: $1 (pass CMake options after --)" ;;
        *)
            [ -z "$group" ] || die "unexpected argument: $1"
            case "$command_name" in test|sanitize) group=$1 ;; *) die "unexpected argument: $1" ;; esac
            shift ;;
    esac
done
case "$backend" in fltk|rev) ;; *) die "backend must be fltk or rev" ;; esac
case "$jobs" in ''|*[!0-9]*|0) die "jobs must be a positive integer" ;; esac
[ "$jobs" -gt 0 ] || die "jobs must be a positive integer"
if [ "$build_jobs_explicit" = no ]; then
    if [ "$jobs_explicit" = yes ]; then
        build_jobs=$jobs
    else
        script_directory=`dirname -- "$0"`
        case "$script_directory" in /*) ;; *) script_directory=./$script_directory ;; esac
        source_dir=`CDPATH=; export CDPATH; cd "$script_directory" && pwd -P`
        capacity_available=no
        if has_executable python3; then
            # Heirloom applies errexit to a failed substitution even when the
            # assignment is an if condition. A marker makes the failure explicit
            # while keeping the substitution itself successful.
            build_jobs=`python3 -B "$source_dir/tools/build_capacity.py" || printf '%s' unavailable`
            case "$build_jobs" in ''|*[!0-9]*|0) ;; *) capacity_available=yes ;; esac
        fi
        if [ "$capacity_available" = no ]; then
            # Resource discovery is optional, including on CMake-only hosts.
            build_jobs=1
            printf '%s\n' 'build.sh: resource detection unavailable; compiling with one job (override with --build-jobs).' >&2
        fi
        case "$build_jobs" in ''|*[!0-9]*|0) build_jobs=1 ;; esac
    fi
fi
case "$build_jobs" in ''|*[!0-9]*|0) die "build jobs must be a positive integer" ;; esac
[ "$build_jobs" -gt 0 ] || die "build jobs must be a positive integer"
if [ -n "${DATAPUMP_MAX_GLIBC:-}" ]; then
    case "$DATAPUMP_MAX_GLIBC" in *[!0-9.]*|.*|*..*|*.) die "DATAPUMP_MAX_GLIBC must be a dotted version, e.g. 2.35" ;; esac
    case "$DATAPUMP_MAX_GLIBC" in *.*) ;; *) die "DATAPUMP_MAX_GLIBC must be a dotted version, e.g. 2.35" ;; esac
fi
case "$command_name" in
    test) [ -n "$group" ] || die "test requires a group; see --help" ;;
    sanitize) group=${group:-contract} ;;
esac
if [ -n "$group" ]; then
    case "$group" in contract|regular|fast|legacy|gui|frontends|web|native|packaging|build|amplitude_probability|amplitude_arrival|triad|all) ;;
        *) die "unknown test group: $group" ;;
    esac
fi
[ "$group" != web ] || [ -n "$wasm_sdk_root" ] || web_worker=ON
[ "$stop_on_failure" = no ] || [ -n "$group" ] || die "--stop-on-failure requires test or sanitize"
[ "$group" != native ] || [ "$cli" != yes ] || die "native tests require the GUI; omit --cli"

# Resolve paths before changing directory so invocation from elsewhere works.
script_directory=`dirname -- "$0"`
case "$script_directory" in /*) ;; *) script_directory=./$script_directory ;; esac
source_dir=`CDPATH=; export CDPATH; cd "$script_directory" && pwd -P`
if [ -n "$build_dir" ]; then
    invocation_directory=`pwd`
    case "$build_dir" in /*) ;; *) build_dir=$invocation_directory/$build_dir ;; esac
fi
if [ -n "$sdk_root" ]; then
    [ -d "$sdk_root" ] || die "SDK directory is missing: $sdk_root"
    case "$sdk_root" in /*) ;; *) sdk_root=./$sdk_root ;; esac
    sdk_root=`CDPATH=; export CDPATH; cd "$sdk_root" && pwd -P`
    [ -f "$sdk_root/share/datapump-sdk/manifest.json" ] ||
        die "SDK manifest is missing; prepare the SDK explicitly before building"
    relocated_root=
    if [ -f "$sdk_root/share/datapump-sdk/relocated-root.txt" ]; then
        relocated_root=`sed -n '1p' "$sdk_root/share/datapump-sdk/relocated-root.txt"`
    fi
    [ "$relocated_root" = "$sdk_root" ] ||
        die "SDK needs explicit installation/relocation; use tools/build-sdk.py install before building"
    [ -z "${CC:-}${CXX:-}${CMAKE_TOOLCHAIN_FILE:-}" ] ||
        die "--sdk selects its own compiler and toolchain; unset CC, CXX and CMAKE_TOOLCHAIN_FILE"
    # GCC can search these outside --sysroot, making the result host-dependent.
    [ -z "${CPATH:-}${C_INCLUDE_PATH:-}${CPLUS_INCLUDE_PATH:-}${OBJC_INCLUDE_PATH:-}${LIBRARY_PATH:-}${GCC_EXEC_PREFIX:-}${COMPILER_PATH:-}" ] ||
        die "--sdk requires compiler search-path environment overrides to be unset"
    PATH=$sdk_root/bin:$PATH
    export PATH
fi
if [ -n "$wasm_sdk_root" ]; then
    [ -z "$sdk_root" ] && [ "$web_worker" = OFF ] && [ "$tui" = OFF ] && [ "$framebuffer" = OFF ] && [ "$backend_explicit" = no ] ||
        die "--wasm-sdk selects a separate browser target; remove native backend/SDK options"
    { [ -z "$group" ] || [ "$group" = web ]; } && [ "$command_name" != sanitize ] || die "Only test web is available in the Wasm profile; native groups use a native tree"
    [ -z "${CC:-}${CXX:-}${CMAKE_TOOLCHAIN_FILE:-}${EM_CONFIG:-}${EM_CACHE:-}${EMCC_CFLAGS:-}${EMMAKEN_CFLAGS:-}" ] ||
        die "--wasm-sdk owns compiler and Emscripten configuration; unset competing overrides"
    [ -z "${CPATH:-}${C_INCLUDE_PATH:-}${CPLUS_INCLUDE_PATH:-}${OBJC_INCLUDE_PATH:-}${LIBRARY_PATH:-}" ] ||
        die "--wasm-sdk requires compiler search-path environment overrides to be unset"
    [ -d "$wasm_sdk_root" ] || die "Wasm SDK directory is missing"
    case "$wasm_sdk_root" in /*) ;; *) wasm_sdk_root=./$wasm_sdk_root ;; esac
    wasm_sdk_root=`CDPATH=; export CDPATH; cd "$wasm_sdk_root" && pwd -P`
    [ -f "$wasm_sdk_root/share/datapump-wasm-sdk/manifest.json" ] || die "Prepare the Wasm SDK explicitly with tools/build-wasm-sdk.py"
    relocated_root=
    if [ -f "$wasm_sdk_root/share/datapump-wasm-sdk/relocated-root.txt" ]; then
        relocated_root=`sed -n '1p' "$wasm_sdk_root/share/datapump-wasm-sdk/relocated-root.txt"`
    fi
    [ "$relocated_root" = "$wasm_sdk_root" ] || die "Wasm SDK moved or preparation is incomplete"
    EM_CONFIG=$wasm_sdk_root/.emscripten
    EM_CACHE=$wasm_sdk_root/cache
    EM_FROZEN_CACHE=1
    export EM_CONFIG EM_CACHE EM_FROZEN_CACHE
fi
cd "$source_dir"
preset=dev
build_config=Release
gui=ON
portable=OFF
native=OFF
case "$command_name" in
    package) preset=release; portable=ON ;;
    sanitize) preset=sanitize; build_config=Debug; gui=OFF ;;
esac
if [ "$backend" = rev ]; then
    [ "$preset" != dev ] || preset=rev
    gui=ON
fi
if [ "$backend_explicit" = yes ] || [ "$group" = native ]; then gui=ON; fi
if [ "$cli" = yes ]; then gui=OFF; fi
if [ "$group" = native ]; then native=ON; fi
if [ "$group" = packaging ]; then portable=ON; fi
if [ -n "$wasm_sdk_root" ]; then preset=wasm; gui=OFF; portable=OFF; fi
if [ -z "$build_dir" ]; then
    build_dir=$source_dir/build/$preset
    if [ "$group" = packaging ]; then
        build_dir=$source_dir/build/package-tests
        if [ "$preset" = sanitize ]; then build_dir=$source_dir/build/sanitize-package-tests; fi
        if [ "$backend" = rev ]; then build_dir=$build_dir-rev; fi
    fi
    if [ "$backend" = rev ] && [ "$preset" != rev ] && [ "$group" != packaging ]; then
        build_dir=$build_dir-rev
    fi
    # Keep CLI variants apart from normal GUI output and native sanitizer builds.
    if [ "$cli" = yes ] && [ "$preset" != sanitize ]; then build_dir=$build_dir-cli; fi
    if [ "$preset" = sanitize ] && [ "$gui" = ON ] && [ "$backend" = fltk ]; then
        build_dir=$build_dir-gui
    fi
    if [ "$tui" = ON ]; then build_dir=$build_dir-tui; fi
    if [ "$framebuffer" = ON ]; then build_dir=$build_dir-fb; fi
    if [ "$web_worker" = ON ]; then build_dir=$build_dir-web; fi
    if [ -n "$sdk_root" ]; then build_dir=$build_dir-sdk; fi
fi

# Never reuse cached native paths with an SDK, or vice versa. CMake also checks
# the SDK manifest fingerprint so upgrading it in place needs a fresh tree.
if [ -f "$build_dir/CMakeCache.txt" ]; then
    cached_sdk=`sed -n 's/^DATAPUMP_CONFIGURED_SDK_ROOT:[^=]*=//p' "$build_dir/CMakeCache.txt"`
    cached_wasm_sdk=`sed -n 's/^DATAPUMP_CONFIGURED_WASM_SDK_ROOT:[^=]*=//p' "$build_dir/CMakeCache.txt"`
    [ "$cached_wasm_sdk" = "$wasm_sdk_root" ] || die "Wasm SDK differs from the configured tree; use a new --build-dir"
    [ "$cached_sdk" = "$sdk_root" ] ||
        die "SDK differs from the configured tree; use --build-dir with a new directory"
fi

has_executable cmake || die "CMake 3.21 or newer is required"
case "$command_name" in test|sanitize)
    has_executable ctest || die "CTest is required" ;;
esac

# Honor a cached generator; selecting Ninja again would reject an existing Make tree.
generator=${CMAKE_GENERATOR:-}
cmake_define_next=no
for arg do
    option=$arg
    if [ "$cmake_define_next" = yes ]; then option=-D$arg; cmake_define_next=no; fi
    if [ "$arg" = -D ]; then cmake_define_next=yes; fi
    case "$arg" in
        -G|-G?*) generator=explicit ;;
        -B|-B?*|-S|-S?*|--preset|--preset=*)
            die "use --build-dir for output paths; source and preset are selected by this script" ;;
    esac
    if [ -n "$sdk_root$wasm_sdk_root" ]; then
        case "$option" in
            --toolchain|--toolchain=*|-DCMAKE_TOOLCHAIN_FILE=*|-DCMAKE_TOOLCHAIN_FILE:*=*|\
            -DCMAKE_C_COMPILER=*|-DCMAKE_C_COMPILER:*=*|-DCMAKE_CXX_COMPILER=*|-DCMAKE_CXX_COMPILER:*=*|\
            -DCMAKE_SYSROOT=*|-DCMAKE_SYSROOT:*=*|-DDATAPUMP_SDK_ROOT=*|-DDATAPUMP_SDK_ROOT:*=*|\
            -DDATAPUMP_WASM_SDK_ROOT=*|-DDATAPUMP_WASM_SDK_ROOT:*=*|\
            -DDATAPUMP_DEPENDENCY_PREFIX=*|-DDATAPUMP_DEPENDENCY_PREFIX:*=*)
                die "--sdk selects the compiler, toolchain and dependency root; remove the competing CMake option: $option" ;;
        esac
    fi
done
if [ -z "$generator" ] && [ ! -f "$build_dir/CMakeCache.txt" ]; then
    if has_executable ninja; then generator=Ninja; else generator='Unix Makefiles'; fi
fi
if [ -n "$generator" ] && [ "$generator" != explicit ]; then set -- -G "$generator" ${1+"$@"}; fi
if [ -n "$sdk_root" ]; then
    set -- "-DCMAKE_TOOLCHAIN_FILE=$source_dir/cmake/toolchains/source-sdk.cmake" \
        "-DDATAPUMP_SDK_ROOT=$sdk_root" ${1+"$@"}
fi

if [ -n "$wasm_sdk_root" ]; then
    if [ "$group" = web ]; then set -- -DBUILD_TESTING=ON ${1+"$@"}; fi
    set -- "-DCMAKE_TOOLCHAIN_FILE=$source_dir/cmake/toolchains/wasm-sdk.cmake" \
        "-DDATAPUMP_WASM_SDK_ROOT=$wasm_sdk_root" ${1+"$@"}
fi

# Match CMake's simple compiler-name + raw PROGRAM_ARGS form without evaluating
# shell text. Compiler arguments can contain quotes; they are compared verbatim.
compiler_environment() {
    requested_compiler=`printf '%s' "$1" | sed 's/^[[:space:]]*//'`
    requested_arguments=
    case "$requested_compiler" in
        \"*|\'*)
            quote=`printf '%s' "$requested_compiler" | cut -c 1`
            remainder=`printf '%s' "$requested_compiler" | cut -c 2-`
            case "$remainder" in
                *"$quote"*)
                    requested_compiler=`printf '%s' "$remainder" | sed "s/$quote.*//"`
                    requested_arguments=`printf '%s' "$remainder" | sed "s/^[^$quote]*$quote//"` ;;
                *) die "unclosed compiler-name quote in CC/CXX" ;;
            esac ;;
        *)
            # An existing executable path may itself contain unquoted spaces.
            resolved=`find_executable "$requested_compiler" || :`
            if [ -z "$resolved" ]; then
                remainder=$requested_compiler
                requested_compiler=`printf '%s' "$remainder" | sed 's/[[:space:]].*//'`
                requested_arguments=`printf '%s' "$remainder" | sed 's/^[^[:space:]]*//'`
            fi ;;
    esac
    case "$requested_compiler" in
        ''|*\"*|*\'*|*\\*) die "unsupported compiler-name quoting in CC/CXX; use a plain executable path or quote the whole path" ;;
    esac
    # Keep the full CMake whitespace class; character classes in shell case
    # patterns are not available in traditional Bourne.
    if [ -n "$requested_arguments" ]; then
        if expr "x$requested_arguments" : 'x[[:space:]]' >/dev/null; then
            :
        else
            die "unsupported compiler-name quoting in CC/CXX; put whitespace between the executable and arguments"
        fi
    fi
}

# CMake otherwise silently ignores a changed CC/CXX environment in a cached tree.
check_compiler() {
    requested_compiler=$1
    language=$2
    kind=$3
    [ -n "$requested_compiler" ] || return 0
    if [ "$kind" = environment ]; then compiler_environment "$requested_compiler"; fi
    [ -f "$build_dir/CMakeCache.txt" ] || return 0
    cached=`sed -n "s/^CMAKE_${language}_COMPILER:[^=]*=//p" "$build_dir/CMakeCache.txt"`
    [ -n "$cached" ] || return 0
    resolved=`find_executable "$requested_compiler" || :`
    [ "$requested_compiler" = "$cached" ] || [ "$resolved" = "$cached" ] ||
        die "${language} compiler differs from $cached; use --build-dir with a new directory when changing CC/CXX"
    if [ "$kind" = environment ]; then
        cached_arguments=`sed -n "s/^CMAKE_${language}_COMPILER_ARG1:[^=]*=//p" "$build_dir/CMakeCache.txt"`
        [ "$requested_arguments" = "$cached_arguments" ] ||
            die "${language} compiler arguments differ from the configured tree; use --build-dir with a new directory when changing CC/CXX"
    fi
}
check_compiler "${CC:-}" C environment
check_compiler "${CXX:-}" CXX environment
for arg do
    case "$arg" in
        -DCMAKE_C_COMPILER=*|-DCMAKE_C_COMPILER:*=*) compiler_option=`printf '%s' "$arg" | sed 's/^[^=]*=//'`; check_compiler "$compiler_option" C path ;;
        -DCMAKE_CXX_COMPILER=*|-DCMAKE_CXX_COMPILER:*=*) compiler_option=`printf '%s' "$arg" | sed 's/^[^=]*=//'`; check_compiler "$compiler_option" CXX path ;;
    esac
done

printf 'Configuring %s in %s\n' "$preset" "$build_dir"
if cmake --preset "$preset" -S "$source_dir" -B "$build_dir" \
    "-DDATAPUMP_BUILD_GUI=$gui" "-DDATAPUMP_GUI_BACKEND=$backend" \
    "-DDATAPUMP_BUILD_TUI=$tui" "-DDATAPUMP_BUILD_FB=$framebuffer" \
    "-DDATAPUMP_BUILD_WEB_WORKER=$web_worker" \
    "-DDATAPUMP_PORTABLE=$portable" "-DOPENSSL_USE_STATIC_LIBS=$portable" \
    "-DDATAPUMP_TEST_NATIVE_GUI=$native" ${1+"$@"}; then
    :
else
    die "configuration failed; check dependencies and use a new --build-dir for a different compiler/generator"
fi

# CI can configure one fresh SDK tree and then build only the test targets
# selected by the generated CTest plan. All normal SDK/toolchain validation
# above still applies to this path.
if [ "$command_name" = configure ]; then
    printf 'Configured %s in %s\n' "$preset" "$build_dir"
    exit 0
fi

target=datapump-apps
if [ -n "$group" ]; then target=datapump-tests-$group; fi
if [ "$group" = all ]; then target=datapump-tests; fi
if [ "$command_name" = package ]; then target=package; fi
printf 'Building %s with %s compile jobs\n' "$target" "$build_jobs"
cmake --build "$build_dir" --config "$build_config" --target "$target" --parallel "$build_jobs"

if [ -n "$group" ]; then
    # A bare set -- does not clear arguments in traditional Bourne.
    set -- clear
    shift
    if [ "$stop_on_failure" = yes ]; then set -- --stop-on-failure; fi
    label=$group
    if [ "$group" = native ]; then label=native_gui; fi
    if [ "$group" = all ]; then
        ctest ${1+"$@"} --test-dir "$build_dir" -C "$build_config" --output-on-failure \
            --no-tests=error --parallel "$jobs" -LE native_gui
    elif [ "$group" = native ]; then
        ctest ${1+"$@"} --test-dir "$build_dir" -C "$build_config" --output-on-failure \
            --no-tests=error --parallel "$jobs" -L "^$label$"
    else
        ctest ${1+"$@"} --test-dir "$build_dir" -C "$build_config" --output-on-failure \
            --no-tests=error --parallel "$jobs" -L "^$label$" -LE native_gui
    fi
elif [ "$command_name" = package ]; then
    if [ -n "$wasm_sdk_root" ]; then
        python3 "$source_dir/tools/package-wasm.py" --verify-archives "$build_dir/releases"
        printf 'Verified browser archives: %s/releases\n' "$build_dir"
        exit 0
    fi
    set -- "-DARCHIVE_DIR=$build_dir/releases" "-DBUILD_DIR=$build_dir" -DGUI_SMOKE=OFF -DREQUIRE_MANUALS=ON
    if [ -n "${DATAPUMP_MAX_GLIBC:-}" ]; then
        set -- ${1+"$@"} "-DMAX_GLIBC=$DATAPUMP_MAX_GLIBC"
    elif [ -n "$sdk_root" ]; then
        [ -f "$build_dir/CMakeCache.txt" ] || die "SDK configuration cache is missing"
        sdk_glibc=`sed -n 's/^DATAPUMP_SDK_GLIBC_MAX:[^=]*=//p' "$build_dir/CMakeCache.txt"`
        [ -n "$sdk_glibc" ] || die "SDK configuration did not provide its glibc baseline"
        set -- ${1+"$@"} "-DMAX_GLIBC=$sdk_glibc"
    fi
    # These are newly generated local archives, not downloaded release artifacts.
    rm -f "$build_dir/releases/SHA256SUMS.txt"
    cmake ${1+"$@"} -P "$source_dir/tools/verify-native-archives.cmake"
    printf 'Verified portable archives: %s/releases\n' "$build_dir"
else
    executable_dir=$build_dir
    if [ -f "$build_dir/CMakeCache.txt" ]; then
        configurations=`sed -n 's/^CMAKE_CONFIGURATION_TYPES:[^=]*=//p' "$build_dir/CMakeCache.txt"`
        if [ -n "$configurations" ]; then executable_dir=$build_dir/$build_config; fi
    fi
    if [ -n "$wasm_sdk_root" ]; then
        printf 'Browser application: %s/web/datapump-wasm.html\n' "$build_dir"
    else
        printf 'Application: %s/pump\n' "$executable_dir"
    fi
    if [ "$tui" = ON ]; then printf 'TUI: %s/datapump-tui\n' "$executable_dir"; fi
    if [ "$framebuffer" = ON ]; then printf 'Framebuffer: %s/datapump-fb\n' "$executable_dir"; fi
    if [ "$web_worker" = ON ]; then printf 'Pipe worker: %s/datapump-worker\n' "$executable_dir"; fi
    if [ "$gui" = ON ]; then printf 'GUI: %s/datapump-gui\n' "$executable_dir"; fi
fi

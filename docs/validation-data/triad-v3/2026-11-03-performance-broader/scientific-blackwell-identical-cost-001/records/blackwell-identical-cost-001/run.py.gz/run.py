#!/usr/bin/env python3
"""Prospective Blackwell full-vs-abbreviated FFT cost experiment; no source edits."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--fixture-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--budget-seconds", type=float, default=300.)
    args = parser.parse_args()
    if not 0 < args.budget_seconds <= 300:
        parser.error("maximum experiment budget is 300 seconds")
    source, reference = args.source_root.resolve(), args.reference_root.resolve()
    output = args.output.resolve(); output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(source/"tools"))
    import triad_perf_fft_trace as trace
    from triad_perf_adaptive import AdaptivePolicy, regression_profile
    from triad_perf_cases import prepare_cases
    study = load(source/"tools/triad_perf_identical_fft.py", "cost_identical_study")
    api = study.load_harness("triad-performance.py", "_triad_cost_controller")
    started = time.monotonic(); deadline = started+args.budget_seconds
    order = random.Random(20261103).sample(["direct", "abbreviated"], 2)
    policy_qualify = AdaptivePolicy(looks=(5, 9, 17, 33), family_count=14, stopping_rule="precision")
    policy_routine = AdaptivePolicy(looks=(5, 9, 17, 33), family_count=14,
                                   stopping_rule="decision", **regression_profile("normal"))
    plan = {"schema": "triad-blackwell-identical-cost-experiment-v1", "wrapper_sha256": sha(__file__),
        "source_root": str(source), "reference_root": str(reference), "native_binary_sha256": sha(args.binary),
        "measurement_files": {name: sha(source/"tools"/name) for name in study.MEASUREMENT_FILES},
        "measurement_core": study.measurement_core_hashes(), "case": "free-crystal", "device": "cuda",
        "precision": "fp32", "threads": 2, "maximum_seconds": args.budget_seconds,
        "qualification_maximum_full_holds": 5, "qualification_looks": [5, 9, 17, 33],
        "routine_looks": [5, 9, 17, 33], "routine_profile": "normal",
        "routine_directional_parameters": regression_profile("normal"), "random_order_seed": 20261103,
        "prospective_arm_order": order, "retry_policy": "no retries; retain qualification, model, timing or budget failure",
        "direct_override": "first measurement_plan call only; restore original before any historical proof replay; direct full result is never promoted to a reusable anchor",
        "cost_boundary": "separate arm total wall including fresh workers, arithmetic eligibility probes, identity audit, pilot, adaptive measurements, finalization and close; fixture setup and new qualification reported separately",
        "runtime_target": "unchanged full resident ReceiverService preparation plus wrapped score",
        "claim_limits": ["one order-randomized arm pair, not a confidence-qualified campaign-cost ratio", "no cross-hardware transfer", "qualification overhead not hidden in routine savings"]}
    write(output/"plan.json", plan)
    summary = {"schema": plan["schema"], "status": "running", "plan_sha256": sha(output/"plan.json"),
               "qualification": None, "arms": {}, "complete_suite_claim": False}
    try:
        before = time.monotonic()
        cases = prepare_cases(args.binary.resolve(), args.fixture_cache.resolve(), profile="ci",
            deadline=deadline, source_root=source, case_ids=["free-crystal"])
        if len(cases) != 1 or cases[0]["id"] != "free-crystal":
            raise ValueError("required full target not resolved")
        case = cases[0]
        write(output/"case.json", case)
        summary["fixture_setup_seconds"] = time.monotonic()-before

        def execute(label, *, historical=None, direct=False):
            before = time.monotonic(); directory = output/label; directory.mkdir()
            workers = {}; original_plan = trace.measurement_plan; forced_calls = []
            def first_direct_plan(target, minimum_repeats=5):
                trace.measurement_plan = original_plan
                forced_calls.append({"target": target, "minimum_repeats": minimum_repeats})
                if target != len(case["frequency_offsets_hz"]):
                    raise ValueError("direct comparator target changed")
                return {**original_plan(target, minimum_repeats), "direct": True,
                        "direct_reason": "prospective_same_policy_direct_comparator"}
            try:
                for name, root in (("reference", reference), ("candidate", source)):
                    workers[name] = api.ReceiverWorker(root, threads=2, deadline=deadline,
                        log_directory=directory, name=name, adapter=source/"tools/triad_perf_identical_fft.py")
                numeric = api.qualify_fft(case, workers, "cuda")
                write(directory/"precision-qualification.json", numeric)
                if not numeric["alternatives"]["fp32"]["eligible"]:
                    raise ValueError("fixed FP32 comparator failed numerical eligibility")
                if direct:
                    if not study.anchor_valid(historical):
                        raise ValueError("original same-hardware anchor proof invalid before direct comparator")
                    trace.measurement_plan = first_direct_plan
                record = study.measure_identical_fft(case, workers, "fp32", "cuda",
                    policy=policy_qualify if historical is None else policy_routine,
                    api=api, deadline=deadline, output=directory/"measurement",
                    mode="qualify" if historical is None else "reuse", historical=historical,
                    maximum_holds=5)
                if direct:
                    if len(forced_calls) != 1 or trace.measurement_plan is not original_plan:
                        raise ValueError("direct one-shot plan override escaped its declared scope")
                    if not study.anchor_valid(historical):
                        raise ValueError("original historical proof changed during direct comparator")
                    target = len(case["frequency_offsets_hz"])
                    if any([score["count"] for score in row["scores"]] != [target] for row in record["training"]):
                        raise ValueError("direct observations did not complete full target")
            finally:
                trace.measurement_plan = original_plan
                for worker in workers.values():
                    worker.close()
            elapsed = time.monotonic()-before
            pilot = record["discarded_pilot"]
            pilot_seconds = pilot["preparation_seconds"]+sum(row["seconds"] for row in pilot["scores"])
            receipt = {"status": record["status"], "prediction_valid": record["prediction_valid"],
                "gate": record["comparison"]["gate"], "own_training_count": len(record["training"]),
                "full_observation_count": len(record["full_runs"]), "total_arm_wall_seconds": elapsed,
                "recorded_measurement_wall_seconds": record["wall_seconds"], "discarded_pilot_processing_seconds": pilot_seconds,
                "total_wall_minus_discarded_pilot_seconds": elapsed-pilot_seconds,
                "record_sha256": record["record_sha256"], "identity_sha256": record["identity_sha256"],
                "source_override_calls": forced_calls, "qualification_attempt": False if direct else historical is None,
                "comparison": record["comparison"]}
            write(directory/"cost-receipt.json", receipt)
            return record, receipt

        historical, receipt = execute("qualification")
        summary["qualification"] = receipt
        if not study.anchor_valid(historical):
            summary["status"] = "qualification_failed_or_inconclusive"
            return 2
        write(output/"same-hardware-anchor.json", historical)
        for arm in order:
            _, receipt = execute(arm, historical=historical, direct=arm == "direct")
            summary["arms"][arm] = receipt
        direct, short = summary["arms"]["direct"], summary["arms"]["abbreviated"]
        eligible = all(row["prediction_valid"] and row["gate"] == "pass" for row in (direct, short))
        saving = direct["total_arm_wall_seconds"]-short["total_arm_wall_seconds"]
        summary["status"] = "comparison_measured_both_pass" if eligible else "comparison_measured_not_both_pass"
        summary["savings"] = {"same_policy_supported": eligible,
            "observed_routine_seconds_saved": saving,
            "observed_routine_fraction_saved": saving/direct["total_arm_wall_seconds"],
            "direct_seconds_without_discarded_pilot": direct["total_wall_minus_discarded_pilot_seconds"],
            "new_qualification_wall_seconds": summary["qualification"]["total_arm_wall_seconds"],
            "first_use_seconds_saved_after_new_qualification": saving-summary["qualification"]["total_arm_wall_seconds"],
            "qualification_amortization_run_count": math.ceil(summary["qualification"]["total_arm_wall_seconds"]/saving) if saving > 0 else None,
            "campaign_cost_ratio_confidence_qualified": False}
        return 0 if eligible else 2
    except Exception as error:
        summary["status"] = "experiment_failed"
        summary["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        summary["total_wall_seconds"] = time.monotonic()-started
        write(output/"summary.json", summary)


if __name__ == "__main__":
    raise SystemExit(main())

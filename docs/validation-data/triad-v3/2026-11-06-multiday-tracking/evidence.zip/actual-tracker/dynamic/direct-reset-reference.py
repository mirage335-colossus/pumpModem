import json,math
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
root=Path(__file__).resolve().parent
reports=[]
for cn0 in (-50,-30):
 ref=json.loads((root/f'beam8-cn0{cn0}-bit0.json').read_text());a=ref['configuration'];m=ref['manifest'];p=Path(a['input']);n=ref['samples'];idx=m['template_ppm'].index(0);v=ref['noise_variance'];b=np.stack([np.fromfile(p/f'basis_bit{k}_ppm{idx}.c64',dtype='<c8') for k in (0,1)]).astype(complex);s=np.fromfile(p/'signal_bit0.c64',dtype='<c8');rng=np.random.default_rng(a['seed']);total=np.zeros(2);size=round(a['segment_seconds']*m['sample_rate_hz'])
 assert a['chunk']%size==0
 for lo in range(0,n,a['chunk']):
  hi=min(n,lo+a['chunk']);y=(rng.normal(size=hi-lo)+1j*rng.normal(size=hi-lo))*math.sqrt(v/2)+s[lo:hi]
  for local in range(0,hi-lo,size):
   stop=min(hi-lo,local+size);bb=b[:,lo+local:lo+stop];g=np.sum(abs(bb)**2,axis=-1)/v;c=bb.conj()@y[local:stop]/v;total+=abs(c)**2/(1+g)-np.log1p(g)
 reports.append(dict(cn0=cn0,bit_scores=total.tolist(),log_e=float(logsumexp(total)-math.log(2)),segment_seconds=size/m['sample_rate_hz'],scope='Independent scalar reference with fresh Gaussian gain each segment and no timing search; exact same sampled y and nominal templates as actual HMM comparisons.'))
(root/'direct-reset-reference.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports))

import sys,subprocess,json,math
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'tools'))
from triad_multiday_tracker_check import PublicTimingBasis
from triad_timing_forward import TimingState
root=Path('/tmp/triad-interp-review');exe=str(Path('build/dev-cli/triad_tracking_export').resolve());common=[exe,'--rate','.001','--sample-rate','1','--sample-rate-denominator','64','--days','38','--data-if','half-rate','--clock-profile','off','--seed','12017','--key-seed','13219']
for name,extra in [('complete',[]),('late',['--source-window','3000000','4096'])]:
 target=root/name
 if not target.exists(): subprocess.run(common+['--template-ppm','0' if name=='complete' else '-200','--output',str(target)]+extra,check=True,stdout=subprocess.DEVNULL)
m=json.loads((root/'complete/manifest.json').read_text());w=json.loads((root/'late/manifest.json').read_text());b=[np.fromfile(root/'complete'/f'basis_bit{i}_ppm0.c64',dtype='<c8') for i in(0,1)];f=w['first_sample'];n=w['samples'];p=PublicTimingBasis(b,1/64,.0005);value=p([TimingState(0,-60,-2)],3e6,f,f+n,f,np.arange(n))[1,0,0];exact=np.fromfile(root/'late/basis_bit0_ppm0.c64',dtype='<c8');err=abs(value-exact);points=(np.arange(n)+f)*.9998;times=(np.arange(n)+f)*64*.9998;results=[]
for i in np.argsort(err)[-10:][::-1]:results.append(dict(i=int(i),t=float(times[i]),coordinate=float(points[i]),error=float(err[i]),amplitude=float(abs(exact[i])),chip=float(times[i]*(.001/6)-8)))
print(json.dumps(dict(rms=float(np.linalg.norm(value-exact)/np.linalg.norm(exact)),top=results,manifest=m),indent=2))
np.savez(root/'failure.npz',value=value,exact=exact,points=points)

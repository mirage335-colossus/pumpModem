# Maintained streaming receivers on complete multi-day samples

These are complete native DATA observations, not restarted windows or virtual
clock tests. The isolated exporter includes encryption, the canonical public
source calendar, continuous 200-ppm UTC following, and the explicitly selected
None/Off shared channel. Receiver templates use only the public zero-ppm basis.
The private source clock coordinates are never input to either receiver.

The native 38-day request becomes a 3,456,002.4-second bit after complete-tile
rounding. Its complete capture has 55,529 samples at 1/64 Hz, or 3,553,856 seconds
(41.13 days), including source/filter padding. The transmitter accumulates
115.964 seconds of clock correction while preserving a 200-ppm rate cap.
The two-day request has 45,625 samples at 1/4 Hz, or 182,500 seconds (2.11 days).

| Request, C/N0 | Input | Persistent log-e | Reset-tracker log-e | Result |
|---|---|---:|---:|---|
| 38 days, -50 dB-Hz | bit 0 | 25.4893 | -0.4939 | Persistent correct admission; reset miss |
| 38 days, -50 dB-Hz | bit 1 | 16.8735 | -1.4125 | Persistent correct admission; reset miss |
| 38 days, -60 dB-Hz | bit 0 | -0.3077 | -0.0314 | Both miss |
| 38 days, -50 dB-Hz noise variance | noise only | -2.6079 | -0.4543 | Both reject |
| 2 days, -35 dB-Hz | bit 0 | 39.7557 | 1.5840 | Persistent correct admission; reset miss |

The fixed endpoint threshold is `ln(10000) = 9.21034`, using equal bit priors.
There is one sampled noise realization for each table row. This establishes a
causal implementation comparison, not 99% reliability or a rare empirical
false-admission rate. Full conditional noise Monte Carlo is a separate study.

Both receivers are the maintained classes: `IncrementalReceiver` with infinite
channel coherence, and `TrackingReceiver` with one fixed public timing state.
The latter renews its channel prior every **4096 seconds** in the 38-day cases,
and every **64 seconds** in the two-day case. These deliberately longer segments
make a cheap, favorable reset reference; they are **not** the current four-second
default, and the one-state model does not qualify dynamic unknown-clock search.
No beam pruning occurs; the retained initial path probability is exactly one.

The persistent maintained filter agrees with an independently accumulated
whole-window scalar Gaussian formula within `1.85e-13` log-score units. Maximum
declared receiver workspace is about 1.28 MB for persistence and 119 kB for the
38-day reset case, independent of observation duration. Five complete comparisons
used about 9.59 CPU seconds inside the experiment's main routine; imports and
native generation are outside that timer. The input files are small and retained
here for review. `summary.json` and individual reports retain input/build/source
hashes, full row counts, timings, outcomes and timing-state diagnostics.

## Reproduction

Use the project-configured `build/dev-cli/triad_tracking_export` and a Python
environment containing NumPy, SciPy and PyTorch. Set BLAS/OpenMP threads to one.

```sh
build/dev-cli/triad_tracking_export --rate .001 --sample-rate 1 \
  --sample-rate-denominator 64 --days 38 --data-if half-rate \
  --clock-profile periodic --template-ppm 0 --seed 12017 --key-seed 13219 \
  --output /tmp/triad-actual38
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python tools/triad_multiday_tracker_check.py \
  --input /tmp/triad-actual38 --output /tmp/triad-actual38-result.json \
  --cn0 -50 --true-bit 0 --seed 527031 --segment-seconds 4096
```

Other 38-day rows use `(cn0, true-bit, seed)` of `(-60, 0, 527033)`,
`(-50, 1, 527039)`, and `(-50, null, 527041)`. For the two-day row, export
rate `.01`, denominator `4`, days `2`, seed `13007`, key seed `14221`; receive
at `-35`, bit `0`, seed `527047`, segment `64` seconds.

This is occasional qualification. Do not add these runs to routine regressions
when the tiny maintained receiver tests exercise the same changed code paths.
The experiment does not qualify physical ASRC noise, Helper tones, FHSS,
randomly evolving channels or unpredictable high-IF multi-day timing trajectories.

## Paired changing-phase extension

The later `--coherence-seconds` option retains the maintained Gaussian state
between blocks while allowing a finite correlation time. Native TX and RX Wiener
phase contributions have combined diffusion `sigma = 0.001 rad/sqrt(second)`.
For that phase process, the complex phasor autocorrelation is
`exp(-sigma^2 * abs(dt) / 2)`. The public Gaussian OU prior therefore uses
`tau = 2 / sigma^2 = 2,000,000 seconds`. Matching autocorrelation does not make
the Gaussian-amplitude prior the exact constant-envelope Brownian-phase law.

These additional paired runs use the same recorded sampled noise in each arm,
256-sample persistent blocks and 65,536-second reset segments. The 512-day request
produces **694,656 samples / 44,457,984 seconds (514.56 days)** including padding.
No private phase history or transmitter timing trajectory enters either receiver.

| Request, C/N0 | Input | Infinite coherence log-e | Finite OU log-e | Reset log-e |
|---|---|---:|---:|---:|
| 38 days, -50 dB-Hz | bit 0 | 6.7396, miss | 30.6446, correct | 10.8013, correct |
| 512 days, -60 dB-Hz | bit 0 | -2.2527, miss | 10.3012, correct | 1.7073, miss |
| 512 days, -60 dB-Hz | bit 1 | -3.6880, miss | 4.6584, miss | 0.3974, miss |
| 512 days, -60 dB-Hz noise variance | noise only | -2.4402, reject | -6.4001, reject | 0.3005, reject |

Finite coherence improves these changing-phase observations, but the 512-day
result is only **one correct admission and one miss in two signal trials**.
It does not establish high reliability. A separate blockwise conditional Monte
Carlo experiment is required to quantify this sensitivity boundary. The reset
scores are exactly identical across paired arms, as expected. The independent
whole-window formula remains an equality check only for infinite coherence.

All six 512-day runs used 28.045 CPU seconds inside the experiment, or 39.978 CPU
seconds / 40.056 wall seconds including subprocess imports. The two 38-day phase
runs add 1.191 CPU seconds inside the experiment. `phase-summary.json` retains
scores and workspaces; the two `phase512*-execution.json` files retain exact
commands and complete process timings. Source capture paths, hashes and public
settings are in each result. Reproduce by adding `--chunk 256
--segment-seconds 65536 --coherence-seconds 2000000` to the wrapper command.
The paired infinite arm uses `--coherence-seconds inf`. The 512-day bit/noise seeds
are 527031 (bit 0), 527043 (bit 1), and 527032 (noise only).

## Shared random channel with Each65 modulation

The finite-state comparison also processes the complete shared sampled channel
with Sub9-best rays, random Doppler width 0.001 Hz, moving delay excursion
0.005 ms at 3600-second knots, RF 8270 Hz and Each65 frequency-selective
modulation. The same low-rate encrypted pattern is sampled at 1/8 Hz. Each
capture contains 444,509 rows / 3,556,072 seconds (41.16 days), including complete
shared-channel tails. The public Gaussian OU coherence is fixed at 300 seconds;
persistent blocks contain 16 samples (128 seconds). The reset reference retains
its 65,536-second segments. This statistical alternative is not claimed to be
the exact stochastic physical-channel law.

| Case, nominal -35 dB-Hz | Finite OU log-e | Static whole-window log-e | Reset log-e |
|---|---:|---:|---:|
| Design seed9109/key99109, periodic clock, bit0 | 98.7825, correct | -6.4549, miss | -98.5278, miss |
| Independent seed10111/key100111, wandering clock, bit1 | 109.0822, correct | -5.9603, miss | -95.4925, miss |
| Independent noise-only control | -57.1888, reject | -6.1734, reject | -111.1186, reject |

The static column is the independently accumulated scalar Gaussian formula on
the same observations, already verified against the maintained infinite-coherence
receiver above. No additional static run was needed. All arms use unchanged
thresholds and identical received energy. In the design capture, Each65 raises
the shared-channel signal energy by 1.142 dB; realized capture-average C/N0 is
approximately -34.03 dB-Hz. That energy change does not explain the difference
between receivers on the same sampled input.

The design export and reception used 31.417 CPU seconds including imports;
independent export, bit1 reception and null used 50.546 CPU seconds. The maintained
finite receiver declares 6952 bytes of working state for this block configuration.
These three observations establish a useful model improvement, not population
reliability or empirical rare false-admission bounds. Exact commands, provenance,
model settings and timings are in `random/`, `random-validation/`, and
`random-summary.json`.

## Unqualified dynamic-provider attempt

The optional coarse dynamic timing provider is **not yet accepted**. Its first
Catmull-Rom interpolation attempt failed a native-window comparison at 1.227e-5
relative complex RMS against a 1e-5 gate. Reusing the maintained four-point
Lagrange weights passed that midpoint but failed a late window at 2.390e-4.
Both failures are preserved in `dynamic/`; no full-span dynamic HMM run has
started. Independent diagnosis is pending. Passing fixed-state receiver runs
above do not qualify this new provider or unknown-trajectory tracking.

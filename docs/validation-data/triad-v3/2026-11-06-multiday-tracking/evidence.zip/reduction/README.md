# Independent source-window reduction validation

Reproduce with:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /tmp/triad-weak-env/bin/python \
  tests/test_triad_tracking_reduction.py build/dev-cli/triad_tracking_export \
  --report local-evidence/triad-multiday-tracking/reduction/results.json
```

This checks local windows before corrections, during correction, and at 38 days.
It is not complete multi-day reception, a receiver test, channel qualification,
production-ASRC qualification, or physical hardware evidence. None/Off channel
is explicit. The parent campaign supplies full-span reception evidence.

The reference independently generates an unwarped native source at 6 kHz
(high-IF cases) or 64 Hz (complex low-IF hardware case), checks that the
**declared canonical physical source origins** agree, and uses SciPy cubic interpolation at exported
source coordinates. Full IF phase is applied analytically. The 1725-Hz cases
then form real 6-kHz audio, downconvert and use a Kaiser anti-alias polyphase
filter to recover the 8-Hz envelope. Four seconds at each window edge are
excluded for anti-alias transients. This removes the image rather than naively
decimating real downmixed samples. The 0.0005-Hz IF case represents complex I/Q
hardware; it is not an acoustic-codec claim.

The private source coordinates are used only by this numerical reference, never
by a practical receiver. Tests assert that omitting IF-phase warp causes more
than 10 dB mismatch in the changing high-IF cases. Full-rate samples/windows are
temporary; exact recipes and source/binary hashes are retained in the JSON.

Initial setup failures, retained in `initial-setup-failure.json`, were SciPy's
unsupported complex256 input and a Python recomputation of a native ceiling
that differed by one sample. The repair casts the polyphase input to complex128
and uses actual manifest integer calendar origins. It does not relax waveform
comparison tolerances. Source-origin alignment mattered in the original
exporter because native finite pulse padding contains two samples and thus
depends on sample rate. The corrected exporter now uses a canonical physical
eight-chip origin at every Fs. `legacy-native-origin-results.json` retains the
old exporter result; `results.json` is the canonical rerun with exactly zero
origin adjustment. All four checks pass in 4.58 wall / 5.19 CPU seconds.

Float64 exported source times can make finite-difference rate diagnostics exceed
200 ppm by a few thousandths of a ppm at day 38. The native controller's own
maximum remains 200 ppm. This quantization is included in the measured waveform
comparison and is not treated as a controller-rate violation.

## Occasional full-span shared-channel refinement

This is a qualification command, not a routine window-test prerequisite:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /tmp/triad-weak-env/bin/python \
  tests/test_triad_tracking_reduction.py build/dev-cli/triad_tracking_export \
  --channel-refinement \
  --report local-evidence/triad-multiday-tracking/reduction/channel-refinement.json \
  SharedChannelRefinement.test_complete_38_day_random_channel
```

The complete paired shared-channel streams use rate 0.001 Hz, periodic clock
corrections, RF 8270 Hz, Sub9 best, random Doppler width 0.001 Hz, delay excursion
0.005 ms with 3600-second knots, and Each65 random additional modulation. The
38-day request rounds to 40.00003 active days; all source and channel tails are
generated. At 0.125/0.25 sample/s there are 444,509/888,998 rows. Both runs use
the same physical-time random fields and seed 9109. Noise, sample-wise oscillator
processes and physical ASRC are disabled; those do not inherit this evidence.

After proper anti-alias decimation and removing only the resampling filter's
128-second boundary pads at each end, 3,555,736 seconds are compared. Energy-
normalized waveform RMS difference is 7.4355e-5, energy difference 2.398e-6 dB,
and coherent mismatch 2.401e-8 dB. Peak complex error is 0.00716. The refinement
costs 15.92 wall / 16.59 CPU seconds. This is one measured refinement, not proof
of continuous-time convergence or a receiver sensitivity/noise-admission result.
No arbitrary waveform-error tolerance is turned into a qualification guarantee.

The result JSON retains both full manifests, exact commands, source/binary
identities, channel-tail counts and coupling limits. Numeric results are retained
unchanged; the original generic `scope`/`channel` keys were renamed
`window_scope`/`window_channel` after the run to clarify that None/Off applies
only to the four local source-window checks, not the separate shared-channel
refinement.

#!/usr/bin/env python3
"""Measure full HF receiver with the complete declared public workspace resident."""
import argparse,json,sys,time
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from triad_helper_study import HelperComparison
p=argparse.ArgumentParser();p.add_argument('--fixture',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
if a.output.exists():raise ValueError('fresh output required')
torch.set_num_threads(4);torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False
m=json.loads((a.fixture/'manifest.json').read_text());c=m['channel'];margin=c['spread_margin']
cb=margin*c['sample_clock_pair_ppm'];rb=margin*c['endpoint_uniform_half_bound_ppm']/(1-c['endpoint_uniform_half_bound_ppm']*1e-6)
clocks=np.linspace(-cb,cb,7);rates=1+np.linspace(-rb,rb,3)*1e-6
study=HelperComparison(a.fixture,device='cuda',precision='fp32',fft_backend='batched',frontend_profile='wide',
 clock_ppm_values=clocks,doppler_scale_values=rates,frequency_batch_size=32,max_cached_hypotheses=273,
 memory_limit_bytes=32*1024**3,aligned_fft_grid=True)
mark=time.perf_counter()
for ei in range(13):
 for clock in clocks:
  for rate in rates:study.receiver._batched_child(ei,float(clock),float(rate))
 print(json.dumps({'prepared_epochs':ei+1,'seconds':time.perf_counter()-mark}),flush=True)
torch.cuda.synchronize();prewarm=time.perf_counter()-mark
torch.cuda.reset_peak_memory_stats();mark=time.perf_counter()
result=study.score(a.fixture);torch.cuda.synchronize();elapsed=time.perf_counter()-mark
result['resident_measurement']={'public_cache_prewarm_seconds':prewarm,'synchronized_score_seconds':elapsed,
 'max_cached_hypotheses':273,'memory_limit_bytes':32*1024**3,
 'cuda_peak_allocated_bytes':torch.cuda.max_memory_allocated(),'cuda_peak_reserved_bytes':torch.cuda.max_memory_reserved(),
 'scope':'One measured full comparison after all public epoch/clock/rate workspaces were explicitly prepared; prewarm included separately, not free.'}
a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'timing':result['timing'],'resident_measurement':result['resident_measurement']}),flush=True)

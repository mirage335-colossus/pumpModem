#!/usr/bin/env python3
"""Source-bound workload diagnostic; not a decoded-capture or admission result."""
import argparse, json, os, sys, time, hashlib
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from triad_helper_study import HelperComparison, digest

p = argparse.ArgumentParser()
p.add_argument('--fixture', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--devices', default='cpu,cuda')
p.add_argument('--counts', default='64,256,1024')
p.add_argument('--batches', default='8,32,128')
a = p.parse_args()
if a.output.exists(): raise ValueError('fresh output required')
torch.set_num_threads(4)
torch.set_float32_matmul_precision('highest')
torch.backends.cuda.matmul.allow_tf32 = False
m = json.loads((a.fixture/'manifest.json').read_text())
ch = m['channel']; margin = ch['spread_margin']
cb = margin*ch['sample_clock_pair_ppm']
rb = margin*ch['endpoint_uniform_half_bound_ppm']/(1-ch['endpoint_uniform_half_bound_ppm']*1e-6)
clocks = np.linspace(-cb,cb,7); scales = 1+np.linspace(-rb,rb,3)*1e-6
records=[]
report=dict(schema='triad-helper-fft-work-ladder-v1', fixture_sha256=digest(a.fixture/'observation.c128'),
            source_sha256={f.name:digest(f) for f in Path('tools').glob('triad_helper*.py')},
            clock_grid=clocks.tolist(), doppler_scale_grid=scales.tolist(), records=records,
            limits=['One fixed public epoch/clock/rate workload; not complete capture decoding.',
                    'Full-bank forecast must be frozen before a separate actual full-bank validation.',
                    'CPU=4 threads on the same host; FP32 bulk, cached FP64 preparation/reductions.'])
for batch in map(int,a.batches.split(',')):
  for device in a.devices.split(','):
    t=time.perf_counter()
    study=HelperComparison(a.fixture, device=device, precision='fp32', fft_backend='batched',
       frontend_profile='wide',clock_ppm_values=clocks,doppler_scale_values=scales,
       frequency_batch_size=batch,memory_limit_bytes=8*1024**3,aligned_fft_grid=True)
    raw=np.memmap(a.fixture/'observation.c128',dtype='<c16',mode='r')
    prepared=study.receiver.prepare_observation(raw)
    (child,_),prep=study.receiver._batched_child(6,0.,1.)
    setup=time.perf_counter()-t
    def sync():
      if device=='cuda':torch.cuda.synchronize()
    frequencies=np.asarray(study.frequencies)
    for count in map(int,a.counts.split(',')):
      ids=np.unique(np.linspace(1,len(frequencies)-2,count).astype(int))
      bank=frequencies[ids]
      for repeat in range(2):
        sync(); started=time.perf_counter()
        result=child.score(prepared.samples, bank, family_groups=study.receiver.effective_group_count)
        sync(); elapsed=time.perf_counter()-started
        records.append(dict(device=device,batch=batch,count=len(bank),repeat=repeat,
          wall_seconds=elapsed,setup_seconds=setup,child_preparation_seconds=prep,
          full_cfo_count=len(frequencies),full_hypothesis_count=13*len(clocks)*len(scales),
          lag_count=len(study.receiver.lags),nfft=child.workspace.nfft,
          timings=result['timing'], resources=result['resources'],scores=result['bit_log_likelihoods']))
        a.output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({k:records[-1][k] for k in ('device','batch','count','repeat','wall_seconds')}),flush=True)
    del child,study,prepared,raw
    if device=='cuda':torch.cuda.empty_cache()

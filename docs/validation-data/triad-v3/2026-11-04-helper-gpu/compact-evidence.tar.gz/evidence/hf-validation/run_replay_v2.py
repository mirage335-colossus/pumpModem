import os,pathlib,json,subprocess,sys,time,hashlib,platform
root=pathlib.Path.cwd();folder=root/'local-evidence/triad-helper-gpu/hf-validation';allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,set(allowed[:2]));start=time.perf_counter();results=[]
sourcehash=hashlib.sha256((root/'tools/triad_helper_assistance.py').read_bytes()).hexdigest()
for seed in range(94102,94112):
    weakened=94106<=seed<=94109 or seed==94111;name=f'hf-{seed}'+('-cn0-8' if weakened else '-physical');capture=folder/name;output=folder/(name+'-assistance-v2.json')
    if output.exists():raise RuntimeError('outputalreadyexists:'+str(output))
    if hashlib.sha256((root/'tools/triad_helper_assistance.py').read_bytes()).hexdigest()!=sourcehash:raise RuntimeError('sourcechanged')
    exportseconds=0
    if not capture.exists():
        command=[str(root/'build/dev-cli/triad_helper_export'),'--case','hf','--output',str(capture),'--seed',str(seed),'--bit',str(seed%2),'--seconds','16','--receiver-tail-seconds','.25','--base-oscillator','crystal','--shift-oscillator','ic-7100']
        if weakened:command+=['--cn0','8']
        exportstart=time.perf_counter()
        with (folder/(name+'-export.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=45)
        exportseconds=time.perf_counter()-exportstart
    with (folder/(name+'-assistance-v2.log')).open('w') as log:subprocess.run([sys.executable,str(folder/'run_assistance.py'),str(capture),str(output)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=65)
    r=json.loads(output.read_text());ev=r['evaluator'];fitc=r['peaks_hz'].get('joint');fitq=r.get('clock_estimate_ppm')
    row=dict(seed=seed,injected_cn0_db_hz=8 if weakened else json.loads((capture/'manifest.json').read_text())['power']['physical_data_cn0_db_hz'],bit=seed%2,status=r['status'],reason=r['reason'],bank_before=r['original_count'],bank_after=r['selected_count'],clock_status=r.get('clock_status'),cfo_error_hz=None if fitc is None else fitc-ev['cfo_hz'],clock_error_ppm=None if fitq is None else fitq-ev['clock_ppm'],cfo_covered=ev['cfo_covered'],clock_covered=ev['clock_covered'],assistance_wall_seconds=r['wall_seconds'],export_wall_seconds=exportseconds,identity=r['identity'],result_file=output.name)
    oldpath=folder/(name+'-assistance.json')
    if oldpath.exists():
        old=json.loads(oldpath.read_text());row['paired_previous']=dict(status=old['status'],reason=old['reason'],bank_after=old['selected_count'],clock_change_ppm=fitq-old['clock_estimate_ppm'],cfo_change_hz=fitc-old['peaks_hz']['joint'],score_change=r['presence_score']-old['presence_score'],old_wall_seconds=old['wall_seconds'],same_input_hash=old['identity']['observation.c128']==r['identity']['observation.c128'],same_frequency_bank=r['selected_frequencies']==old['selected_frequencies'])
    results.append(row);print(json.dumps(row),flush=True)
    (folder/'paired-validation-v2-summary.json').write_text(json.dumps(dict(schema='triad-helper-joint-clock-validation-v2',source_sha256=sourcehash,cpu_affinity=allowed[:2],cpu_threads=2,python=platform.python_version(),results=results,complete=False,wall_seconds=time.perf_counter()-start),indent=2)+'\n')
(folder/'paired-validation-v2-summary.json').write_text(json.dumps(dict(schema='triad-helper-joint-clock-validation-v2',source_sha256=sourcehash,cpu_affinity=allowed[:2],cpu_threads=2,python=platform.python_version(),results=results,complete=True,wall_seconds=time.perf_counter()-start),indent=2)+'\n')

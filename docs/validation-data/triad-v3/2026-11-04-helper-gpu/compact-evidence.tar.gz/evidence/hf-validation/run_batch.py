import os,pathlib,json,subprocess,sys,time,hashlib
root=pathlib.Path.cwd();folder=root/'local-evidence/triad-helper-gpu/hf-validation';allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,set(allowed[:2]));start=time.perf_counter();results=[]
sourcehash=hashlib.sha256((root/'tools/triad_helper_assistance.py').read_bytes()).hexdigest()
for seed in range(94102,94110):
    weakened=seed>=94106;name=f'hf-{seed}'+('-cn0-8' if weakened else '-physical');capture=folder/name;output=folder/(name+'-assistance.json')
    command=[str(root/'build/dev-cli/triad_helper_export'),'--case','hf','--output',str(capture),'--seed',str(seed),'--bit',str(seed%2),'--seconds','16','--receiver-tail-seconds','.25','--base-oscillator','crystal','--shift-oscillator','ic-7100']
    if weakened:command+=['--cn0','8']
    if capture.exists() or output.exists():raise RuntimeError('outputalreadyexists:'+name)
    exportstart=time.perf_counter()
    with (folder/(name+'-export.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=45)
    exportseconds=time.perf_counter()-exportstart
    with (folder/(name+'-assistance.log')).open('w') as log:subprocess.run([sys.executable,str(folder/'run_assistance.py'),str(capture),str(output)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=65)
    r=json.loads(output.read_text());ev=r['evaluator'];fitc=r['peaks_hz'].get('joint');fitq=r.get('clock_estimate_ppm')
    row=dict(seed=seed,injected_cn0_db_hz=8 if weakened else json.loads((capture/'manifest.json').read_text())['power']['physical_data_cn0_db_hz'],bit=seed%2,status=r['status'],reason=r['reason'],bank_before=r['original_count'],bank_after=r['selected_count'],clock_status=r.get('clock_status'),cfo_error_hz=None if fitc is None else fitc-ev['cfo_hz'],clock_error_ppm=None if fitq is None else fitq-ev['clock_ppm'],cfo_covered=ev['cfo_covered'],clock_covered=ev['clock_covered'],assistance_wall_seconds=r['wall_seconds'],export_wall_seconds=exportseconds,identity=r['identity'],result_file=output.name)
    results.append(row);print(json.dumps(row),flush=True)
    (folder/'independent-validation-summary.json').write_text(json.dumps(dict(schema='triad-helper-joint-clock-validation-v1',source_sha256=sourcehash,cpu_affinity=allowed[:2],cpu_threads=2,results=results,complete=False,wall_seconds=time.perf_counter()-start),indent=2)+'\n')
(folder/'independent-validation-summary.json').write_text(json.dumps(dict(schema='triad-helper-joint-clock-validation-v1',source_sha256=sourcehash,cpu_affinity=allowed[:2],cpu_threads=2,results=results,complete=True,wall_seconds=time.perf_counter()-start),indent=2)+'\n')

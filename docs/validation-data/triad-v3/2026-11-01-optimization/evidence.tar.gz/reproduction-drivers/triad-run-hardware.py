import json,pathlib,subprocess,time,sys,hashlib,os
root=pathlib.Path('/workspace/triad-opt');py='/workspace/triad-env/bin/python';out=root/'results';label=sys.argv[1];jobs=[];runs=[]
for rep in range(3):
 for b in (1,8,32):
  jobs.append((f'{label}-cached-hour-graph-b{b}-r{rep}',[py,'tools/triad-optimization-study.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch',str(b),'--memory-gib','12','--warmup-blocks','4','--cn0','-18','--seed','170051','--backend','graph','--observation-preparation','cached','--output-scores']))
jobs.append((f'{label}-resident-graph-b8',[py,'tools/triad-resident-campaign.py','inputs/hour','--device','cuda:0','--backend','graph','--batch','8','--batches','8','--seed','170111','--cn0','-18','--memory-gib','12']))
jobs.append((f'{label}-precision',[py,'tools/triad_tensor_probe.py','inputs/flat','--device','cuda:0','--trials','128','--cn0-grid=-4,-2,0,1,2','--repeats','5','--memory-gib','4']))
jobs.append((f'{label}-acquisition',[py,'tools/triad-acquisition-compare.py','inputs/flat','--device','cuda:0','--trials','64','--batch','16','--repeats','5','--reference-trials','4','--cn0-grid=-4,-2,0,1,2,4','--split','holdout']))
paths=sorted((root/'inputs/holdout').glob('path-*'));assert len(paths)==20
jobs.append((f'{label}-holdout20',[py,'tools/triad-path-study.py',*[str(p.relative_to(root)) for p in paths],'--cn0','-18','--seed','170091','--split','holdout','--device','cuda:0','--precision','fp32','--methods','phase-frequency','--phase-implementation','graph','--actual-observation','--memory-limit-mib','16384']))
for name,cmd in jobs:
 cmd+=['--output',str(out/(name+'.json'))];t=time.perf_counter()
 with (out/(name+'.stdout')).open('x') as log,(out/(name+'.stderr')).open('x') as err:p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=300)
 runs.append({'name':name,'command':cmd,'wall_seconds':time.perf_counter()-t,'returncode':p.returncode})
 (out/(label+'-driver.json')).write_text(json.dumps({'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()},'cpu_count':os.cpu_count(),'cpu_affinity_count':len(os.sched_getaffinity(0)),'runs':runs},indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print('complete',label)

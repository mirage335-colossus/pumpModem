import pathlib,subprocess,time,json,sys,hashlib,os
root=pathlib.Path('/workspace/triad-opt');out=root/'results';py='/workspace/triad-env/bin/python';label=sys.argv[1];runs=[]
def command(name,backend,batch,batches=8,device=0,seed=170121,compare=None):
 c=[py,'tools/triad-resident-campaign.py','inputs/hour','--output',str(out/(name+'.json')),'--backend',backend,'--batch',str(batch),'--batches',str(batches),'--device',f'cuda:{device}','--seed',str(seed),'--split','holdout','--cn0','-18','--memory-gib','12']
 if compare:c+=['--compare-report',str(out/(compare+'.json'))]
 return c
def one(name,cmd):
 if (out/(name+'.json')).exists():
  runs.append({'name':name,'status':'reused_completed_v1_job'});save();return
 for ext in ('.stdout','.stderr'):
  old=out/(name+ext)
  if old.exists():old.rename(out/(name+'.failed-cap8'+ext))
 t=time.perf_counter()
 with (out/(name+'.stdout')).open('x') as log,(out/(name+'.stderr')).open('x') as err:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=300)
 runs.append({'name':name,'command':cmd,'wall_seconds':time.perf_counter()-t,'returncode':p.returncode});save()
 if p.returncode:raise SystemExit(p.returncode)
def save():
 (out/(label+'-finish-driver-v2.json')).write_text(json.dumps({'driver_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'cpu_count':os.cpu_count(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'runs':runs},indent=2))
if label=='5090':
 for rep in range(3):
  ref=f'{label}-equal192-reference-b4-r{rep}';opt=f'{label}-equal192-graph-fp64-b4-r{rep}';best=f'{label}-equal192-graph-fp64-b12-r{rep}'
  one(ref,command(ref,'reference',4,24,seed=170121+rep))
  one(opt,command(opt,'graph-fp64',4,24,seed=170121+rep,compare=ref))
  one(best,command(best,'graph-fp64',12,8,seed=170121+rep))
else:
 for b in ([1,2,4,8] if label=='mig24' else [4,8,12,16]):
  name=f'{label}-screen-graph-fp64-b{b}';one(name,command(name,'graph-fp64',b))
 if label=='pro6000':
  for rep in range(3):
   cmds=[]
   for dev in (0,1):
    name=f'pro6000-scale-single-g{dev}-r{rep}';one(name,command(name,'graph-fp64',8,16,dev,170131+dev+rep*2))
    name=f'pro6000-scale-dual-g{dev}-r{rep}';cmds.append((name,command(name,'graph-fp64',8,16,dev,170131+dev+rep*2)))
   opened=[];ps=[];t=time.perf_counter()
   try:
    for name,c in cmds:
     log=(out/(name+'.stdout')).open('x');err=(out/(name+'.stderr')).open('x');opened.extend([log,err]);ps.append(subprocess.Popen(c,cwd=root,stdout=log,stderr=err))
    codes=[p.wait(timeout=300) for p in ps]
   finally:
    for p in ps:
     if p.poll() is None:p.kill();p.wait()
    for f in opened:f.close()
   runs.append({'name':f'pro6000-scale-dual-parent-r{rep}','commands':[c for _,c in cmds],'wall_seconds':time.perf_counter()-t,'returncodes':codes});save()
   if any(codes):raise SystemExit(1)
print('finished',label)

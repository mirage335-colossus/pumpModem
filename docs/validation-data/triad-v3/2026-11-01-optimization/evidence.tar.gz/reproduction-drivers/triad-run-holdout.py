import hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/workspace/triad-opt');paths=sorted((root/'inputs/holdout').glob('path-*'));assert len(paths)==300
python='/workspace/triad-env/bin/python';out=root/'results';runs=[]
source_hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()}
for offset in range(0,300,20):
 dest=out/f'5090-holdout-hour-{offset:03d}.json'
 cmd=[python,'tools/triad-path-study.py',*[str(p.relative_to(root)) for p in paths[offset:offset+20]],'--output',str(dest),'--cn0','-18','--seed','170091','--split','holdout','--device','cuda:0','--precision','fp32','--methods','phase-frequency','--phase-implementation','graph','--actual-observation','--memory-limit-mib','16384']
 start=time.perf_counter()
 with dest.with_suffix('.stdout').open('x') as log,dest.with_suffix('.stderr').open('x') as err:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=180)
 runs.append({'offset':offset,'command':cmd,'wall_seconds':time.perf_counter()-start,'returncode':p.returncode})
 (out/'5090-holdout-driver.json').write_text(json.dumps({'source_sha256':source_hashes,'runs':runs},indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print('completed300 independent physical paths')

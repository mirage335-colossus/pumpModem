import hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/workspace/triad-opt');py='/workspace/triad-env/bin/python';out=root/'results';jobs=[];runs=[]
modes='strict-fp64-reference,complex64-strict,fp16-template-storage,bf16-template-storage,fp16-observation-storage,bf16-observation-storage,fp16-products-fp32-output-attempt,bf16-products-fp32-output-attempt,bf16-real-products,tf32-requested'
for target,grid,opts in [('default','-1,0,.25,.5,.75,1,1.25,1.5,2',[]),('relaxed','-4,-3,-2,-1,0,.5,1',['--false-probability','.01','--horizon-seconds','43200'])]:
 jobs.append((f'5090-precision-holdout-{target}',[py,'tools/triad_precision_probe.py','inputs/flat','--device','cuda:0','--trials','1024','--seed','194999','--split','holdout','--cn0-grid='+grid,'--modes',modes,'--memory-gib','12',*opts]))
jobs.append(('5090-acquisition',[py,'tools/triad-acquisition-compare.py','inputs/flat','--device','cuda:0','--trials','64','--batch','16','--repeats','5','--reference-trials','4','--cn0-grid=-4,-2,0,1,2,4','--split','holdout']))
for path in sorted((root/'inputs/physical').glob('hour-*'))+sorted((root/'inputs/physical').glob('two-day-*')):
 if not path.is_dir():continue
 jobs.append(('5090-actual-'+path.name,[py,'tools/triad-optimization-study.py',str(path.relative_to(root)),'--device','cuda:0','--backend','graph','--precision','fp32','--batch','1','--cn0','-18','--actual-observation','--memory-gib','12','--output-scores']))
for name,cmd in jobs:
 cmd+=['--output',str(out/(name+'.json'))];t=time.perf_counter()
 with (out/(name+'.stdout')).open('x') as log,(out/(name+'.stderr')).open('x') as err:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=600)
 runs.append({'name':name,'command':cmd,'wall_seconds':time.perf_counter()-t,'returncode':p.returncode})
 (out/'5090-boundary-driver.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()},'runs':runs},indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print('complete')

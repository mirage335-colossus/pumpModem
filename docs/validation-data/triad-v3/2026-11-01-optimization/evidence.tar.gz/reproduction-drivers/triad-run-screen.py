import hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/workspace/triad-opt');py='/workspace/triad-env/bin/python';out=root/'results';runs=[];jobs=[]
for rep in range(3):
 for b in (1,8,32):
  jobs.append((f'5090-cached-hour-graph-b{b}-r{rep}',[py,'tools/triad-optimization-study.py','inputs/hour','--device','cuda:0','--precision','fp32','--batch',str(b),'--memory-gib','12','--warmup-blocks','4','--cn0','-18','--seed','170051','--backend','graph','--observation-preparation','cached','--output-scores']))
for precision in ('fp32','fp64'):
 for mode in ('reference','graph'):
  jobs.append((f'5090-numeric-hour-{mode}-{precision}-b1',[py,'tools/triad-optimization-study.py','inputs/hour','--device','cuda:0','--precision',precision,'--batch','1','--memory-gib','12','--warmup-blocks','4','--cn0','-18','--seed','170071','--backend',mode,'--observation-preparation','cached','--output-scores']))
for precision in ('fp32','fp64'):
 jobs.append((f'5090-gaussian-{precision}',[py,'tools/triad_gaussian_prepared.py','--device','cuda:0','--precision',precision,'--batch','32','--blocks','929','--warmup','2','--repeats','5']))
jobs.append(('5090-profile-graph',[py,'tools/triad-profile.py','inputs/hour','--device','cuda:0','--backend','graph','--batch','8','--blocks','32']))
for name,cmd in jobs:
 dest=out/(name if 'profile' in name else name+'.json');cmd+=['--output',str(dest)]
 start=time.perf_counter()
 with (out/(name+'.stdout')).open('x') as log,(out/(name+'.stderr')).open('x') as err:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=300)
 runs.append({'name':name,'command':cmd,'wall_seconds':time.perf_counter()-start,'returncode':p.returncode})
 (out/'5090-screen-driver.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()},'runs':runs},indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print('complete')

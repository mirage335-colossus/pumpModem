import hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/workspace/triad-opt');py='/workspace/triad-env/bin/python';out=root/'results';paths=sorted((root/'inputs/holdout').glob('path-*'));jobs=[];runs=[]
for phase in (128,256,512):
 for shard in (0,16):
  jobs.append((f'5090-phase-grid-p{phase}-s{shard}',[py,'tools/triad-path-study.py',*[str(p.relative_to(root)) for p in paths[shard:shard+16]],'--cn0','-20','-18','-16','-14','--seed','170101','--split','development','--device','cuda:0','--precision','fp32','--methods','phase-frequency','--phase-implementation','graph','--phase-states',str(phase),'--memory-limit-mib','16384']))
jobs.append(('5090-holdout-reference20',[py,'tools/triad-path-study.py',*[str(p.relative_to(root)) for p in paths[:20]],'--cn0','-18','--seed','170091','--split','holdout','--device','cuda:0','--precision','fp32','--methods','phase-frequency','--phase-implementation','reference','--actual-observation','--memory-limit-mib','16384']))
for name,cmd in jobs:
 cmd+=['--output',str(out/(name+'.json'))];t=time.perf_counter()
 with (out/(name+'.stdout')).open('x') as log,(out/(name+'.stderr')).open('x') as err:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=err,timeout=300)
 runs.append({'name':name,'command':cmd,'wall_seconds':time.perf_counter()-t,'returncode':p.returncode})
 (out/'5090-grid-driver.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tools').glob('triad*') if p.is_file()},'runs':runs},indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print('complete')

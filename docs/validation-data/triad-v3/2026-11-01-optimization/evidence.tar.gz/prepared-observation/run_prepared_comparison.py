#!/usr/bin/env python3
"""Reproduce an exact paired H0/H1 cache benchmark on the archived HF hour."""
from __future__ import annotations

import hashlib
import json
import platform
import statistics
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "tools"))
from triad_prepared_observation import PreparedGaussianObservation
from triad_state_workspace import BlockWorkspace


INPUT = ROOT / "local-evidence/triad-v3-weak/dev-hour-0"
BATCH = 4
CN0_DB_HZ = -18.0
SEEDS = [8419, 8420, 8421, 8422, 8423]
MEMORY_LIMIT = 64 * 1024 * 1024


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def reference(workspace, seed):
    h0 = list(workspace.iter_simulator(seed=seed, batch=BATCH,
        cn0_db_hz=CN0_DB_HZ, signal=False))
    h1 = list(workspace.iter_simulator(seed=seed, batch=BATCH,
        cn0_db_hz=CN0_DB_HZ, signal=True))
    return h0, h1


def cached(prepared, seed):
    return list(prepared.iter_paired(seed=seed))


def main() -> None:
    workspace = BlockWorkspace(INPUT, max_tile_blocks=16)
    # Warm the NumPy and iterator code paths outside the timed independent
    # seeds. The fixed warmup output is discarded and never enters score data.
    warmup_reference_start = time.perf_counter()
    reference(workspace, 8418)
    warmup_reference_seconds = time.perf_counter()-warmup_reference_start

    prep_start = time.perf_counter()
    prepared = PreparedGaussianObservation(workspace, seed=SEEDS[0], batch=BATCH,
        cn0_db_hz=CN0_DB_HZ, memory_limit_bytes=MEMORY_LIMIT)
    preparation_seconds = time.perf_counter()-prep_start
    warmup_cached_start = time.perf_counter()
    cached(prepared, 8418)
    warmup_cached_seconds = time.perf_counter()-warmup_cached_start

    reference_seconds, prepared_seconds = [], []
    max_absolute_difference = 0.0
    bit_identical_blocks = 0
    for index, seed in enumerate(SEEDS):
        outputs = {}
        for name in (("reference", "prepared") if index % 2 == 0 else
                     ("prepared", "reference")):
            started = time.perf_counter()
            outputs[name] = (reference(workspace, seed) if name == "reference"
                             else cached(prepared, seed))
            elapsed = time.perf_counter()-started
            (reference_seconds if name == "reference" else prepared_seconds).append(elapsed)
        h0, h1 = outputs["reference"]
        pairs = outputs["prepared"]
        if len(h0) != len(h1) or len(h0) != len(pairs):
            raise RuntimeError("reference and prepared outputs have different block counts")
        for pair, null, signal in zip(pairs, h0, h1):
            if pair.null.index != null.index or pair.signal.index != signal.index:
                raise RuntimeError("block indices differ")
            null_error = float(np.max(np.abs(pair.null.r-null.r)))
            signal_error = float(np.max(np.abs(pair.signal.r-signal.r)))
            gram_error = max(float(np.max(np.abs(pair.null.gram-null.gram))),
                             float(np.max(np.abs(pair.signal.gram-signal.gram))))
            max_absolute_difference = max(max_absolute_difference, null_error,
                                           signal_error, gram_error)
            if (not np.array_equal(pair.null.r, null.r) or
                    not np.array_equal(pair.signal.r, signal.r) or
                    not np.array_equal(pair.null.gram, null.gram) or
                    not np.array_equal(pair.signal.gram, signal.gram)):
                raise RuntimeError("prepared paired result differs from reference")
            bit_identical_blocks += 1

    ref_median = statistics.median(reference_seconds)
    prep_median = statistics.median(prepared_seconds)
    amortized = (preparation_seconds+sum(prepared_seconds))/len(prepared_seconds)
    source_files = [Path(__file__), ROOT/"tools/triad_state_workspace.py",
                    ROOT/"tools/triad_prepared_observation.py"]
    input_files = [workspace.manifest_path] + [INPUT/name for name in
                    sorted(workspace.manifest["file_sizes"])]
    record = {
        "schema": "triad-prepared-observation-paired-hour-v1",
        "scope": "CPU FP64 Gaussian sufficient-statistic simulation; public channel design; not waveform/acquisition or reception qualification",
        "command": [sys.executable, str(Path(__file__).resolve())],
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "device": "CPU", "processor": platform.processor()},
        "configuration": {"input": str(INPUT.relative_to(ROOT)),
            "manifest_sha256": sha256(workspace.manifest_path),
            "block_count": workspace.block_count, "sample_count": workspace.sample_count,
            "sample_rate": workspace.sample_rate, "dimension": workspace.dimension,
            "batch": BATCH, "cn0_db_hz": CN0_DB_HZ, "independent_noise_seeds": SEEDS,
            "max_tile_blocks": workspace.max_tile_blocks,
            "memory_limit_bytes": MEMORY_LIMIT},
        "source_sha256": {str(path.relative_to(ROOT)): sha256(path)
                          for path in source_files},
        "input_sha256": {path.name: sha256(path) for path in input_files},
        "timing_seconds": {"warmup_reference_excluded": warmup_reference_seconds,
            "public_design_preparation": preparation_seconds,
            "warmup_cached_excluded": warmup_cached_seconds,
            "reference_h0_and_h1_by_seed": reference_seconds,
            "cached_paired_h0_and_h1_by_seed": prepared_seconds,
            "reference_median_per_pair": ref_median,
            "cached_median_per_pair_excluding_preparation": prep_median,
            "cached_median_speedup_excluding_preparation": ref_median/prep_median,
            "cached_mean_cost_per_pair_including_one_preparation": amortized,
            "amortized_speedup_using_reference_median": ref_median/amortized},
        "verification": {"paired_h0_h1_and_gram_bit_identical": True,
            "independent_noise_seed_count": len(SEEDS),
            "blocks_checked": bit_identical_blocks,
            "max_absolute_difference": max_absolute_difference},
        "prepared_diagnostics": prepared.diagnostics(),
    }
    destination = Path(__file__).with_name("prepared-observation-hour.json")
    destination.write_text(json.dumps(record, indent=2, allow_nan=False)+"\n")
    print(json.dumps(record, sort_keys=True))


if __name__ == "__main__":
    main()

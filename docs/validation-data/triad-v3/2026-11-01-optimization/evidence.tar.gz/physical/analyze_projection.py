#!/usr/bin/env python3
"""Paired observation diagnostic, not sensitivity or admission calibration."""
import hashlib,json
from pathlib import Path
import numpy as np

OUT=Path(__file__).resolve().parent
root=json.loads((OUT/'screen-manifest.json').read_text())
rows=[]
for record in root['results']:
    if record['status']!='completed':continue
    base=OUT/('hour-baseline' if record['case'].startswith('hour-') else 'two-day-baseline')
    b=json.loads((base/'manifest.json').read_text())
    d=b['dimension'];n=b['block_count'];variance=b['noise_variance']
    g=np.memmap(base/'gram.c128',mode='r',dtype='<c16',shape=(n,d,d))
    y=np.memmap(base/'observation.c128',mode='r',dtype='<c16',shape=(n,d))
    iv=np.memmap(base/'intervals.u64',mode='r',dtype='<u8',shape=(n,2))
    directory=OUT/record['case'];m=json.loads((directory/'manifest.json').read_text())
    if m['control']=='null':continue
    count=min(n,m['block_count'])
    other_i=np.memmap(directory/'intervals.u64',mode='r',dtype='<u8',shape=(m['block_count'],2))
    same=(iv[:count]==other_i[:count]).all(axis=1)
    index=np.nonzero(same)[0]
    other_g=np.memmap(directory/'gram.c128',mode='r',dtype='<c16',shape=(m['block_count'],d,d))
    other_y=np.memmap(directory/'observation.c128',mode='r',dtype='<c16',shape=(m['block_count'],d))
    if not np.array_equal(g[index],other_g[index]):raise ValueError('public Gram changed on equal sample intervals')
    difference=other_y[index]-y[index]
    values,vectors=np.linalg.eigh(g[index])
    keep=values>np.maximum(values[:,-1,None],1)*1e-10
    transformed=np.einsum('nji,nj->ni',vectors.conj(),difference)
    energy=float(np.sum(np.abs(transformed)**2/np.where(keep,values,np.inf)))
    ranks=int(keep.sum())
    rows.append({'case':record['case'],'reference_case':base.name,'paired_equal_interval_blocks':len(index),
      'source_pattern_elapsed_seconds':m['actual_elapsed_seconds'],
      'capture_elapsed_seconds':m['sample_count']/m['sample_rate'],
      'excluded_different_interval_blocks':count-len(index),'public_gram_bitwise_equal':True,
      'projection_relative_rms_difference':float(np.linalg.norm(difference)/np.linalg.norm(y[index])),
      'whitened_projection_difference_energy_over_thermal_expected':energy/(variance*ranks),
      'public_retained_rank_sum':ranks,'frontend_report':record['frontend_report'],
      'generation_wall_seconds':record['wall_seconds']})
result={'schema':'triad-physical-projection-screen-v1','scope':'one fixed development HF hour path and a separate fixed two-day path; paired actual sampled observations within each group; difference energy is NOT added-noise variance, sensitivity loss or calibrated admission',
  'source_manifest_sha256':hashlib.sha256((OUT/'screen-manifest.json').read_bytes()).hexdigest(),
  'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
(OUT/'projection-screen.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for r in rows:print(r['case'],r['projection_relative_rms_difference'],r['whitened_projection_difference_energy_over_thermal_expected'],r['frontend_report']['adc_clipped_components'])

#!/usr/bin/env python3
"""Bounded, reproducible actual-sampled frontend screen; no reception claims."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BINARY = ROOT/'build/dev/triad_long'
EXPECTED_BINARY = '88ee2b6b90f6233bd6ec46ac299d77b30b742bba361ac3cc12af0124a46fec0a'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def source_hashes():
    paths=[]
    for directory in ('src','include','cmake'):
        paths.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and p.suffix in ('.cpp','.hpp','.h','.c','.cmake'))
    paths.extend((ROOT/'tools').glob('*.cpp'))
    paths.extend([ROOT/'build.sh',ROOT/'CMakeLists.txt'])
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}

def write(name, value):
    target=OUT/name
    temp=target.with_suffix(target.suffix+'.partial')
    temp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    temp.replace(target)

def run_case(name,extra,seconds=3600,key=771001,channel=991001):
    directory=OUT/name
    if directory.exists():raise FileExistsError(directory)
    command=[str(BINARY),'--mode','export-stats','--seconds',str(seconds),
        '--rate','3.6','--sample-rate','64','--added','10','--rf-hz','30000000',
        '--basis','two-ray','--cn0','-18','--block-seconds','4','--chunk','4096',
        '--threads','1','--signal-bit','0','--epoch','1800042000',
        '--seed','511001','--key-seed',str(key),'--channel-seed',str(channel),
        '--channel','hf','--phase-diffusion','0.00872665','--white-fm','0.002',
        '--random-walk-fm','0.000001','--flicker-fm','0.002','--white-pm','0.01',
        '--stats-noisy','--output',str(directory),*extra]
    start=time.monotonic(); timed_out=False; terminated=False
    with (OUT/(name+'.log')).open('x') as log:
        log.write(json.dumps(command)+'\n');log.flush()
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=process.wait(timeout=300)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);code=process.wait()
            terminated=True
    row={'case':name,'command':command,'wall_seconds':time.monotonic()-start,
         'returncode':code,'timed_out_300s':timed_out,'owned_process_group_reaped':True,
         'termination_required':terminated,'binary_sha256':sha(BINARY),
         'scope':'one fixed development physical path; actual sampled projections, no calibrated admission',
         'key_seed':key,'channel_seed':channel,'source_bit':0,'requested_seconds':seconds}
    if code==0 and (directory/'manifest.json').exists():
        row['status']='completed'
        row['files_sha256']={p.name:sha(p) for p in sorted(directory.iterdir()) if p.is_file()}
        m=json.loads((directory/'manifest.json').read_text())
        row['sample_count']=m['sample_count'];row['actual_elapsed_seconds']=m['actual_elapsed_seconds']
        row['block_count']=m['block_count'];row['dimension']=m['dimension']
        row['frontend_report']=m['frontend_report'];row['gaussian_projection_supported']=m['gaussian_projection_supported']
        row['export_manifest_sha256']=sha(directory/'manifest.json')
    else:row['status']='incomplete_timeout' if timed_out else 'failed'
    print(json.dumps({k:row[k] for k in ('case','status','wall_seconds','returncode')}),flush=True)
    return row

def main():
    if sha(BINARY)!=EXPECTED_BINARY:raise RuntimeError('release binary hash changed')
    sources=source_hashes()
    plan=[
      ('hour-baseline',[]),
      ('hour-adc16-fs512',['--adc-bits','16','--adc-full-scale','512']),
      ('hour-adc16-fs65536-enob12',['--adc-bits','16','--adc-full-scale','65536','--adc-enob','12']),
      ('hour-adc16-fs65536-enob8',['--adc-bits','16','--adc-full-scale','65536','--adc-enob','8']),
      ('hour-adc16-fs32-overload',['--adc-bits','16','--adc-full-scale','32']),
      ('hour-adc16-interference',['--adc-bits','16','--adc-full-scale','512','--interference-tone','1000','15','--tone-every-dwells','3','--rx-lowpass-hz','20','--overload-recovery-seconds','.5']),
      ('hour-dac16-enob12-adc16',['--dac-bits','16','--dac-full-scale','2','--dac-enob','12','--adc-bits','16','--adc-full-scale','512']),
      ('hour-null-interference',['--control','null','--adc-bits','16','--adc-full-scale','512','--interference-tone','1000','15','--tone-every-dwells','3','--rx-lowpass-hz','20','--overload-recovery-seconds','.5']),
    ]
    metadata={'schema':'triad-physical-screen-v1','source_base_revision':'75f3af291100d513a8bc20bff9f26d259b51ed71',
      'source_files_sha256':sources,'binary_sha256':EXPECTED_BINARY,'driver_sha256':sha(Path(__file__)),
      'python':sys.version,'platform':platform.platform(),'split':'development','source_path_count':1,
      'paired_cases_reuse_physical_realization':True,'independent_holdout':False,
      'noise_seed_policy':'thermal std::mt19937_64 seed = channel_seed XOR 0x3254494154415747; independent salted TX/RX oscillator, spectrum, propagation, converter and interference RNGs; no separate CLI thermal root seed',
      'gains':'all DAC and ADC gain1; vary full-scale to isolate converter level, with shared nuisance assumptions unchanged except intentional frontend processing',
      'calibration':'unsupported for active frontend; known-variance white Gaussian analytic allocation is not inherited',
      'two_day_limit_seconds':300,'hour_case_plan':plan,'results':[]}
    if (OUT/'screen-manifest.json').exists():raise FileExistsError('screen manifest exists')
    write('screen-manifest.json',metadata)
    for name,extra in plan:
        if sha(BINARY)!=EXPECTED_BINARY or source_hashes()!=sources:raise RuntimeError('source/binary changed during screen')
        metadata['results'].append(run_case(name,extra));write('screen-manifest.json',metadata)
    for name,extra in [('two-day-baseline',[]),('two-day-adc16-fs1024',['--adc-bits','16','--adc-full-scale','1024'])]:
        if sha(BINARY)!=EXPECTED_BINARY or source_hashes()!=sources:raise RuntimeError('source/binary changed during screen')
        metadata['results'].append(run_case(name,extra,172800,771002,991002));write('screen-manifest.json',metadata)
    metadata['source_hashes_unchanged_at_end']=source_hashes()==sources
    metadata['all_processes_reaped']=True
    write('screen-manifest.json',metadata)

if __name__=='__main__':main()

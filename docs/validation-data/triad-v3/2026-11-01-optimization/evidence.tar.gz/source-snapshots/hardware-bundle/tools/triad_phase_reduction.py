"""Optional FP64 posterior reduction without a full-sized FP64 input copy.

The CUDA reducer loads FP32 or FP64 values, converts each loaded value to FP64,
performs both reduction levels in FP64 and writes small FP64 partials/output.
It changes reduction order, not accumulation precision. The graph subclass
retains every state, the existing log-domain update and FP64 log evidence.
CUDA support is required; the separately named CPU reference is not a fallback.
"""
from __future__ import annotations

from functools import lru_cache
import math

import torch

from triad_phase_optimized import GraphPhaseFrequencyLikelihood

triton = None
tl = None


@lru_cache(maxsize=1)
def _kernels():
    global triton, tl
    try:
        import triton as compiler
        import triton.language as language
    except ImportError as error:
        raise RuntimeError("FP64 fused reduction requires Triton; no fallback executed") from error
    triton, tl = compiler, language

    @triton.jit
    def partial_sum(source, partials, LENGTH: tl.constexpr, PARTS: tl.constexpr,
                    BLOCK: tl.constexpr):
        row, part = tl.program_id(0), tl.program_id(1)
        index = part*BLOCK+tl.arange(0, BLOCK)
        # Conversion remains in registers; no LENGTH-sized FP64 tensor is
        # written. Both the tree values and the partial result are FP64.
        values = tl.load(source+row*LENGTH+index, index < LENGTH, other=0).to(tl.float64)
        total = tl.sum(values, axis=0)
        tl.store(partials+row*PARTS+part, total)

    @triton.jit
    def final_sum(partials, output, PARTS: tl.constexpr, BLOCK: tl.constexpr):
        row = tl.program_id(0)
        index = tl.arange(0, BLOCK)
        values = tl.load(partials+row*PARTS+index, index < PARTS, other=0).to(tl.float64)
        tl.store(output+row, tl.sum(values, axis=0))

    return partial_sum, final_sum


def reduction_layout(shape, *, block_size=1024):
    """Shape and logical scratch accounting, independent of device allocation."""
    shape = tuple(shape)
    if len(shape) < 3 or any(isinstance(x, bool) or not isinstance(x, int) or x < 1 for x in shape):
        raise ValueError("positive integer shape with at least three dimensions required")
    if block_size not in (256, 512, 1024, 2048):
        raise ValueError("block_size must be256,512,1024 or2048")
    rows, length = math.prod(shape[:-3]), math.prod(shape[-3:])
    parts = (length+block_size-1)//block_size
    if parts > 32768:
        raise ValueError("bounded FP64 final reduction supports at most32768 partials per row")
    return {"rows": rows, "values_per_row": length, "parts_per_row": parts,
            "block_size": block_size, "scratch_fp64_bytes": rows*parts*8,
            "output_fp64_bytes": rows*8,
            "avoided_full_fp64_intermediate_bytes": rows*length*8,
            "logical_intermediate_write_and_read_bytes_avoided": rows*length*16,
            "final_shape": shape[:-3]+(1, 1, 1)}


def chunked_cpu_reference(values, *, block_size=1024):
    """FP64 two-level mathematical reference for tests; never selected by CUDA."""
    if values.device.type != "cpu" or values.dtype not in (torch.float32, torch.float64):
        raise ValueError("CPU FP32/FP64 reference input required")
    layout = reduction_layout(values.shape, block_size=block_size)
    flat = values.reshape(layout["rows"], layout["values_per_row"])
    partials = [flat[:, first:first+block_size].sum(-1, dtype=torch.float64)
                for first in range(0, layout["values_per_row"], block_size)]
    return torch.stack(partials, -1).sum(-1, dtype=torch.float64).reshape(layout["final_shape"])


def sum_last_three_fp64(values, *, block_size=1024):
    """Native CUDA FP64 accumulation with no implicit layout/device fallback."""
    if values.device.type != "cuda":
        raise RuntimeError("native FP64 reduction requires CUDA; CPU fallback is prohibited")
    if values.dtype not in (torch.float32, torch.float64) or not values.is_contiguous():
        raise ValueError("contiguous FP32/FP64 CUDA input required")
    layout = reduction_layout(values.shape, block_size=block_size)
    first, last = _kernels()
    partials = torch.empty((layout["rows"], layout["parts_per_row"]),
                           dtype=torch.float64, device=values.device)
    output = torch.empty(layout["final_shape"], dtype=torch.float64, device=values.device)
    first[(layout["rows"], layout["parts_per_row"])](
        values, partials, LENGTH=layout["values_per_row"], PARTS=layout["parts_per_row"],
        BLOCK=block_size, num_warps=4, enable_fp_fusion=False)
    last[(layout["rows"],)](partials, output, PARTS=layout["parts_per_row"],
        BLOCK=triton.next_power_of_2(layout["parts_per_row"]),
        num_warps=4, enable_fp_fusion=False)
    return output


class Fp64ReductionGraphLikelihood(GraphPhaseFrequencyLikelihood):
    """Experimental graph variant retaining FP64 posterior accumulation."""

    def __init__(self, *args, reduction_block_size=1024, **kwargs):
        self.reduction_block_size = reduction_block_size
        super().__init__(*args, **kwargs)
        self._reduction_layout = reduction_layout(self.weights.shape,
                                                  block_size=reduction_block_size)
        _kernels()

    def _graph_body(self, dt):
        # Deliberately mirror the existing graph update: only the total's
        # implementation changes. Reference and original graph remain intact.
        r, gram = self._graph_r, self._graph_g
        predicted = self._predict(self.weights, dt)
        correlation = torch.einsum("qk,nbk->nbq", self.gain_vectors.conj(), r)
        energy = torch.einsum("qk,nbkl,ql->nbq", self.gain_vectors.conj(), gram,
                              self.gain_vectors).real
        emission = 2*(correlation.real[..., None]*self.phase_cosine+
                      correlation.imag[..., None]*self.phase_sine)-energy[..., None]
        logits = predicted.log()+emission[..., None, :]
        maximum = logits.amax(dim=(-3, -2, -1), keepdim=True)
        unnormalized = (logits-maximum).exp()
        total = sum_last_three_fp64(unnormalized, block_size=self.reduction_block_size)
        increment = maximum[..., 0, 0, 0].to(torch.float64)+total[..., 0, 0, 0].log()
        posterior = unnormalized/total.to(self.dtype)
        empty = (gram.abs().amax(dim=(-2, -1)) == 0) & (r.abs().amax(dim=-1) == 0)
        self.weights.copy_(torch.where(empty[..., None, None, None], predicted, posterior))
        self._scores.add_(torch.where(empty, torch.zeros_like(increment), increment))

    def diagnostics(self):
        result = super().diagnostics()
        result.update({"implementation": "experimental_graph_fp64_register_reduction_v1",
            "posterior_normalizer_input_dtype": str(self.dtype),
            "posterior_normalizer_accumulation_dtype": "float64 at both levels",
            "posterior_normalizer_partial_storage_dtype": "float64",
            "posterior_normalizer_full_input_fp64_copy": False,
            "posterior_normalizer_reduction_order": "chunked pairwise tree then FP64 partial tree; differs from torch.sum",
            "posterior_normalizer_layout": self._reduction_layout,
            "normalizer_hardware_counter_or_isa_verification": False})
        return result

import pathlib,json,subprocess,sys,time,concurrent.futures
out=pathlib.Path(/workspace/sub9-holdout-analysis/wrong-key38-corrected);out.mkdir()
prior=json.load(open(/workspace/sub9-holdout-analysis/wrong-key38/runs.json))
def run(row):
 cmd=[v.replace(/workspace/triad/tools/,/workspace/triad-controls-fixed/tools/).replace(/workspace/sub9-holdout-analysis/wrong-key38/,/workspace/sub9-holdout-analysis/wrong-key38-corrected/) for v in row[command]]
 name=pathlib.Path(cmd[cmd.index(--output)+1]).stem;t=time.monotonic()
 with (out/(name+.log)).open(x) as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(row,command=cmd,returncode=r.returncode,seconds=time.monotonic()-t)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:rows=list(p.map(run,prior))
(out/runs.json).write_text(json.dumps(rows,indent=2));raise SystemExit(any(r[returncode] for r in rows))

# Independent 8-dB-Hz sampled-waveform qualification

Protocol `4565cdee4f328f91c6452192c0f5ff26ff3e521a24111667b89146b021f720b7`
was written before all 39 native captures and receiver scores. Runtime sources,
reused native binary, public geometry and templates are hash-bound in
`protocol.json`. Each `receiver-result.json` was written exclusively before its
evaluator truth file was opened. The receiver retained the original public
epoch, all 13 epoch alternatives, broad ±7.035-second timing prior, clock/CFO
envelopes and Helper-enabled hypothesis on signal and null controls alike.

All cases use encrypted rate 36 / Added ×10/interleave, DATA IF 1725 Hz, RF 30 MHz,
free base crystal/IC-7100 shift clock, HF-worst margin 3, two ray centers 0/90 Hz,
21 ms excess delay and random Each 65% additional modulation at 9/90 Hz. Injected
DATA C/N₀ is 8 dB-Hz; Helper is 18 dB-Hz. This is 12.02 dB weaker than the earlier
4 W / 180 dB / −164 dBm/Hz physical link. DATA lasts 23.2 seconds; Helper lead remains 38 s.
Whole native captures are 84.678 s. No audio conversion or hardware is included.

| Channel law | Correct conditional admissions | Wrong admissions | Misses | Raw bit errors | Helper-only false admissions | Pure-noise false admissions |
|---|---:|---:|---:|---:|---:|---:|
| Persistent ray centers; random selective modulation |6/6|0|0|0|0/6|0/1|
| Random ray width B=0.5 Hz |6/6|0|0|0|0/6|0/1|
| B=0.5 Hz plus 0.2 µs moving-delay excursion, 20 s knots |4/6|0|2|0|0/6|0/1|

All 18 raw bit choices were correct. The two moving-delay misses were fully
scored: `moving-signal-04` had logE 20.1083 and `moving-signal-05` 17.0855, against
the frozen threshold 21.4934. Their correct-versus-wrong bit margins were 40.12
and 40.23 nats. They are retained misses, not discarded seeds or setup failures.
All 18 Helper-only controls were scored and rejected. Three pure-noise controls
returned explicit Helper-acquisition unresolved outcomes. There were no setup
or execution errors.

Counts do not demonstrate 99% correct reception or a physical 10⁻⁴/day false
admission rate. With six Helper-only controls per law, each law's one-sided 95%
binomial upper false-admission probability remains 39.3%. Balanced fixed-bit
confidence intervals are reported separately in `summary.json`; pooled
fractions are descriptive. The finite randomized arrival/epoch mixture is not
all operating conditions. The Gaussian fixed-bank admission theorem remains
conditional on its stated noise/covariance/residual assumptions.

| Law | Original→retained Helper frequency candidates | RX construction+score CPU seconds | RX construction+score wall seconds |
|---|---|---:|---:|
| Persistent |365→3–4|27.17–30.02|22.50–25.02|
| Renewing |365→10–11|38.98–52.38|32.93–45.76|
| Moving delay |365→14–15|45.82–60.03|38.69–51.39|

These timings include receiver construction and scoring from existing public
templates, with two concurrent trial processes and two numerical threads each.
They are campaign measurements, not isolated single-capture latency. The later
moving-delay portion also overlapped the owner's separate continuous live audio
test; no exclusive CPU allocation is claimed. Native generation, loading,
hashing and finalization remain separately recorded. Total campaign wall time
was 731.792 s; worker CPU 1546.653 s plus 120.740 native-generation child CPU seconds.
The measured maximum 60.03 receiver CPU seconds per 84.678 captured seconds is
0.709 core equivalents, or0.975 per 61.6 seconds of transmission. Audio frontend
and regeneration of public keyed templates are excluded from that ratio.

The cheap maintained check is:

```sh
python3 tools/triad_weak_qualify.py --check-contracts
```

The occasional campaign used the following, in sequence; do not repeat it as a
routine regression prerequisite. The tool refuses existing evidence and source
changes after freezing. A deliberate new qualification needs a new output path.

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  /tmp/triad-weak-env/bin/python tools/triad_weak_qualify.py --prepare-protocol
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  /tmp/triad-weak-env/bin/python tools/triad_weak_qualify.py --run --workers 2
```

Individual exact generator
argument arrays and timing boundaries are in each `receipt.json`.

`compact.json` is a reporting-only extraction from the original receipts and
summary. Raw captures remain under `trials/*/capture/`; no templates were
regenerated per trial. The later 34.8-second follow-up is a separate frozen study,
with selected paired failures kept separate from new independent validation.

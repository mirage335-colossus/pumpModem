import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import copy,hashlib,json,sys,time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'local-evidence/triad-weak-stream/helper';sys.path.insert(0,str(ROOT/'tools'))
import numpy as np
from triad_weak_helper import estimate_weak_helper
BASE=ROOT/'local-evidence/triad-cpu-ceiling/capture'
base=json.loads((BASE/'manifest.json').read_text());ch=base['channel'];bound=ch['deterministic_cfo_bound_hz']*ch['spread_margin'];bank=np.linspace(-bound,bound,365)
rows=[]
for name in ['stress8-00','stress8-01','stress8-02','stress8-03','ray05-00','ray05-01']:
 d=ROOT/'local-evidence/triad-realtime/captures'/name;actual=json.loads((d/'manifest.json').read_text());m=copy.deepcopy(base)
 for field in ['complex_noise_variance','data_cn0_db_hz','effective_helper_cn0_db_hz']:m['power'][field]=actual['power'][field]
 for field in ['random_doppler_width_hz','random_ray_total_bandwidth_allowance_hz']:m['channel'][field]=actual['channel'][field]
 raw=np.memmap(d/'observation.c128',dtype='<c16',mode='r');valid=np.memmap(d/'validity.u8',dtype='u1',mode='r')
 r=estimate_weak_helper(raw,m,bank,valid=valid)
 path=OUT/(name+'.json');path.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
 print(name,r['status'],r['reason'],r['timing'],r.get('onset',{}).get('padded_arrival_hull_seconds'),flush=True)
 # Receiver output frozen before evaluator truth.
 truth=json.loads((d/'evaluator-truth.json').read_text())
 rows.append(dict(name=name,status=r['status'],reason=r['reason'],timing=r['timing'],onset=r.get('onset',{}).get('padded_arrival_hull_seconds'),truth_arrival=truth['arrival_seconds'],onset_covers=any(a<=truth['arrival_seconds']<=b for a,b in r['onset_intervals_seconds']),selected_count=r['selected_count'],frequency_intervals=r['expanded_intervals_hz'],result_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')

# Operational admission contract for the weak streaming study

Read-only source baseline: `c401265714d2769ac660483c96fa69994664c25b`.
No runtime source edits or numerical receiver campaigns were performed for this
note. `benchmarks.py` is a small ideal-model calculation, not waveform validation.

## Current source and the important distinction

`triad_gaussian_state.py` and `triad_gaussian_prepared.py` return a normalized
Gaussian marginal likelihood relative to independent proper complex white
zero-mean noise, for each fixed public candidate/design/model. The covariance
recursion is observation-independent. The block DFT selector is orthonormal and
disjoint across blocks, so ideal white sampled noise stays white in retained
modes. This is a useful mathematical starting point.

`ProjectedJointReceiver.score_correlations()` and `ScanJointReceiver` return
mixtures over the instantiated candidates. In the realtime path,
`pilot_use='none'` makes every H0 source basis identically zero. Its H0 evidence
is therefore zero; each fixed H1 atom's raw log evidence is a log likelihood
ratio against the same white-noise law. Renormalizing a *selected* candidate
mixture is not an operational e-value after adaptive screening.

For `pilot_use='both'`, the H0 is a Gaussian mixture of imperfect Helper models,
not a uniform guarantee for every unknown Helper realization. Dividing by a
fitted or truncated H0 likelihood does not repair this automatically.

## Minimal fixed-lattice construction

Predeclare a countable/fixed finite public atom bank. An atom includes epoch,
arrival, CFO, clock, bit, channel-coherence model, duration and any alternative
projection/algorithm chosen from observed data. The first implementation can use
1-ms arrival, 10-mHz CFO, 75-ppm clock and the existing public epoch/model bank.
The original full prior fixes the weights. Refined coordinates must snap to this
lattice, deduplicate, and pass membership checks; arbitrary continuously fitted
points have no finite-bank guarantee.

For atom i let `ell_i=log(q_i(y)/p0(y))` and predeclare `w_i>=0` with sum at most
one. If each `exp(ell_i)` has null expectation at most one, then

`E_selected = sum_{i in S(y)} w_i exp(ell_i)`

also has expectation at most one, for an arbitrary adaptive subset S. This follows
pointwise from its nonnegativity and domination by the full mixture. Missing
atoms contribute zero. Selection must not increase their weights, duplicate
them or choose a different unaccounted model. One can avoid evaluating the full
bank entirely. Shared preparation and adaptively choosing which atoms to execute
do not weaken this argument if each atom remains the predetermined function of
the original samples/projection.

For uniform weights `1/N`, either compute `logsumexp(selected ell)-log(N)`, or
use the still-more-conservative `max(selected ell)-log(N)`. Comparing this with
`log(1/alpha_attempt)` bounds each attempt's false admission by alpha_attempt.
The sum-of-selected statistic dominates the max version and requires negligible
extra arithmetic.

If only current pilot-none bit mixtures are exposed, with selected candidate
count n, fixed total candidate count Nc and fixed equally weighted channel
models, the equivalent selected-mixture result is:

`logE = logsumexp(bit_scores)-log(2)+log(n)-log(Nc)`.

This formula relies on zero H0 evidence and consistent fixed model/projection
weights. Returning raw `[model,batch,H,candidate]` evidence is clearer and supports
per-atom residual corrections. Do not treat `hypothesis_log_evidence` as raw atom
evidence: the current field already averages over candidates.

## Repeated acquisition and duration alternatives

At a fixed 400-ms attempt grid there are 216,000 attempts per day. For a
10^-4/day budget, alpha_attempt is 4.62963e-10 and its negative log is 21.493.
Allocate budget across durations/models within fixed atom weights, rather than
trying durations freely. A union bound over attempts needs no independence and
also covers overlapping observation windows. Report the bounded operational
horizon. New midnight budget resets guarantee aligned calendar days; arbitrary
rolling 24-hour intervals can cross two budgets unless that extra factor is
included. With attempts on a deterministic global lattice and a fixed per-attempt
budget, use the maximum count in any rolling-day interval, including endpoints.

For the current broad prior, a conservative bank has 14,071 arrivals, 18,107 CFO
points (outward rounding across original ±90.522-Hz envelope), 11 clock points
(nine 75-ppm lattice points plus the two public margin endpoints), 13 epochs,
two bits and two coherence models. This is N=145,736,217,484 atoms. The resulting
raw per-atom logLR threshold is 47.1984 before residual/numerical allowances.
Helper-selected CFO intervals do not reduce this original-bank penalty unless
a valid conditional argument proves that narrowing is independent of all DATA
testing noise. Simply selecting the interval from the same capture is inadequate.
Changing the attempt stride/duration bank changes the declared threshold.

Repeated partial updates within an attempt require either another union-bound
allocation or a proved likelihood-ratio/e-process. A sequence of separately
fitted or changing-projection maximum scores is not automatically a martingale.
The fixed full-duration attempt policy is simpler to implement first.

## Colored Gaussian noise and Helper residual allowance

Let z be retained observations whitened by a *public upper* covariance Sigma*,
and K be a fixed additive Gaussian signal covariance in those coordinates.
Its normalized marginal logLR is

`ell = z^H B z - logdet(I+K)`,  `B=K(I+K)^(-1)`.

For zero-mean proper complex Gaussian null noise with covariance R'<=I,

`E0[exp(ell)] = 1 / (det(I+K) det(I-R'^(1/2) B R'^(1/2))) <= 1`.

Thus a known conservative covariance envelope protects against smaller colored
Gaussian noise without needing equality or ideal exact whitening. It does not
protect arbitrary non-Gaussian interference from covariance alone.

If null data are `z=mu+n`, conditional on a fixed Helper residual mu, then

`E0[exp(ell)] <= exp(mu^H K mu)`.

Consequently a predeclared bound `d_i >= sup mu^H K_i mu` yields an e-value
`exp(ell_i-d_i)`. A simpler sufficient bound is
`d_i=lambda_max(K_i)*D` when `||mu||^2<=D`. A covariance-free bound on residual
mean energy is genuinely required here. For a random residual with probability
at least 1-delta of satisfying this bound, the final false-admission guarantee
is alpha+delta, after allocating delta over the full operational horizon.
An observed calibration maximum is not such a probability bound.

Each65 Gaussian-erf coefficients and products with random fading are not jointly
Gaussian. Inflating by an estimated Helper residual covariance therefore does
not, by itself, prove the Gaussian e-value theorem. Conditional bounded-residual
analysis can cover such a mean, but the needed bound may be conservative. A
worst-case bound using the entire strong Helper energy will usually destroy
useful sensitivity; spectral/projection-specific bounds are the productive next
step. Finite block DFT windows leak pilot/auxiliary energy even with nominally
separated bands.

For simulation, fixed injected white variance is public. For real audio, variance
or a covariance envelope estimated from an independent quiet interval needs its
own confidence failure budget and a justified noise law. A runtime whiteness or
clipping check is a model diagnostic, not a mathematical coverage proof.

Recommended first interface returns separately:

- the selected fixed-bank log e-statistic and its daily/attempt budget;
- public atom counts, deduplication/lattice checks and projection identity;
- declared noise envelope, Helper residual penalty and provenance;
- `assurance='conditional_on_declared_null'` when those inputs are modeling
  assumptions, or unresolved/unqualified if missing;
- diagnostic empirical acceptance, distinct from an operational bounded claim.

Do not relabel a model-conditioned calculation as a field-wide daily guarantee.
A strict deployment mode can require a qualified null-profile object before
issuing operational admissions; a study mode can still report scores and the
conditional bound while collecting evidence.

## Ideal sensitivity benchmark and limitations

At DATA C/N0=8 dB-Hz, 23.2 seconds contains nominal E/N0=146.382=21.655 dB.
For a known deterministic received complex waveform, matched-filter Gaussian
Neyman-Pearson detection has required energy

`E = (Q^-1(alpha_atom)+Q^-1(1-Pd))^2/2`.

Using alpha_atom=10^-4/(216000*N) and Pd=.99 gives E=68.566=18.361 dB,
or 10.867 seconds at 8 dB-Hz. This known-channel benchmark includes none of the
cost of channel, timing, clock or waveform mismatch. It is a favorable reference,
not an achieved modem duration or universal lower bound with fading outages.

For unknown proper complex Gaussian channel, whitened signal covariance
eigenvalues lambda_i yield exactly under that model:

`logLR|H1 = sum lambda_i Exp_i(1) - sum log(1+lambda_i)`;
`E1[logLR] = sum(lambda_i-log(1+lambda_i))`;
`Var1(logLR) = sum lambda_i^2`.

Under H0 replace lambda_i in the random quadratic by
`lambda_i/(1+lambda_i)`. At low per-mode SNR the mean evidence is approximately
one half sum lambda_i^2, so increasing independent channel-mode count at fixed
total energy can impose quadratic low-C/N0 duration scaling. This describes
channel inference loss, which cannot be repaired by a faster implementation.

`benchmarks.json` uses ideal orthogonal, equal-power two-ray observations and
unit-power source; a 0.1-second temporal discretization represents covariance
`R(t)=exp(-pi^2*B^2*t^2/2)` for Gaussian Doppler width B=2sigma. At B=.5 Hz,
23.2 seconds gives mean logLR79.15, SD22.65, versus threshold47.20. At46.4 seconds,
mean158.86, SD32.16; the Chernoff upper bound on miss probability at that threshold
is0.000181 under this ideal model. OU coherence .5 seconds is harsher: at23.2s
mean50.53/SD15.22; at46.4s mean101.30/SD21.58, with miss upper bound0.0214.
B=2Hz at23.2s has mean39.91 below threshold. Means alone are not Pd guarantees.

The static-Gaussian row has random unknown Gaussian ray gains, including deep
outages. It is not the native B=0 fixed-unit-gain ray law. Additional selective
AM, actual keyed source/Gram geometry, finite-window projection, Helper residue,
clock error and adaptive candidate retention are absent from every ideal row.
Use measured full-waveform Grams/likelihood designs for the next practical
prediction and retain these rows only as explicit-assumption references.

## Primary sources

- [Grünwald, de Heide and Koolen, Safe Testing](https://arxiv.org/abs/1906.07801):
  e-values, safe optional continuation and composite-null caveats.
- [Howard et al., Time-uniform nonparametric nonasymptotic confidence sequences](https://arxiv.org/abs/1810.08240):
  nonnegative-martingale concentration and time-uniform construction.
- [Wasserman, Ramdas and Balakrishnan, Universal Inference](https://arxiv.org/abs/1912.11436):
  valid split/profile-likelihood alternatives for composite nulls. This may be
  useful if a tractable Helper-null likelihood envelope becomes available; a
  generic fitted numerator/denominator does not inherit the theorem.

The covariance-domination and mean-penalty formulas above are direct Gaussian
integration derivations for this proposed receiver guard, not claims that these
papers qualify the radio channel or the existing implementation.

## Conditional Gaussian Helper model: useful route and current obstacle

Reading `src/triad_simulation_stream.cpp`, `src/triad_random_process.hpp` and
`src/channel_perturbation.hpp` confirms a useful distinction. For nonzero fixed
Gaussian random-ray width, condition on the source/Helper waveform, oscillator
realizations, moving delay, bounded selective coefficient paths and knot origins.
The two ray innovations then enter linearly. The resulting Helper observation is
zero-mean Gaussian conditional on those quantities. Unconditionally it is a
Gaussian covariance mixture, rather than one Gaussian having its average
covariance. This permits the earlier expectation proof if a covariance envelope
holds uniformly over the conditioned quantities, or with an explicitly budgeted
failure probability.

Use an augmented real covariance for a rigorous implementation. The native
`FixedGaussianRay` real and imaginary fields have independent seeded knot
origins. Each queried marginal is exactly normalized, but their *conditional*
cross-time covariance matrices can differ slightly because of interpolation.
The unconditional covariance is symmetric between real and imaginary streams;
that does not justify assuming exact conditional proper-complex Gaussianity.
The same covariance-domination proof works in real coordinates, with the usual
one-half quadratic/log-determinant factors.

There is a simple source-derived selective-operator norm bound. Write its three
DFT delay branches as B_b. Because every sampled fractional-delay FIR is an L2
contraction, `sum_b B_b^H B_b <= I`. With |e_b(t)|<=d_slow+d_fast=d,

`||I+sum_b M[e_b]B_b|| <= 1+sqrt(3)*d`.

For Each65 this is amplitude3.2517, power10.573. It preserves actual finite
delays/sidebands and does not depend on carrier labels. It is much too broad to
be useful as the only receiver covariance envelope. For scale, an ideal B=.5-Hz
unit-power Gaussian ray sampled at6kHz has peak covariance spectrum about9575.
The current composite Helper source peak squared is about27, versus thermal
variance951 at DATA8dB-Hz. A global bound based on peak amplitude and the above
operator norm would suggest scalar variance inflation around2900, about34.6dB,
before further interpolation/envelope conservatism. This is an illustrative
unprojected calculation, not an exact bound on the DATA projection. It shows why
this generic route would destroy useful sensitivity and should not be added as
a default receiver correction.

The productive quantity is the Helper covariance in the *tested DATA subspace*,
not its full raw-band maximum. For fixed candidate signal covariance K, Gaussian
Helper covariance C in whitened observations yields the exact exponential-moment
inflation `det(I-C K)^(-1)` when the largest eigenvalue of
`K^(1/2) C K^(1/2)` is below one. Once it reaches one the uncorrected exponential
moment diverges, even though ordinary helper/noise scores can look benign.
Thus a typical or averaged residual covariance is not an adequate substitute
for a uniform or high-probability envelope. Rare allowed bounded-AM paths can
mix a Helper tone into the DATA band; the native Gaussian-erf modulation has
no compact spectral support. A proof must budget such path events or explicitly
bound their contribution.

A modest diagnostic can quantify whether a practical projected bound is worth
developing, without pretending that a few nulls establish it:

1. Generate matched DATA-off Helper-on and DATA-off Helper-off controls using the
   same fixture/noise seed and identical sample calendar. Verify noise roots,
   normalization, row counts and unchanged channel state policy before taking
   their difference. This cancels injected thermal noise and isolates complete
   realized Helper residue, retaining modulation and all tails.
2. Apply the original fixed DATA projection. Record normalized retained energy
   and the weighted quantity `q_i=mu^H K_i mu` for fixed diagnostic candidates,
   including the candidates selected from independent scored observations.
3. Reuse existing block correlations r rather than rebuilding sample designs.
   For each channel model, `q_i = sum_bb' r_b^H P_bb' r_b'`, where
   `P_bb'=diag(powers)*exp(-|t_b-t_b'|/coherence)`. Static coherence simplifies to
   `sum_t power_t*|sum_b r_bt|^2`. This directly measures the realized mean penalty
   relevant to the e-value, and is more informative than whole-band SNR.
4. Keep these as realized/model metrology. A calibration maximum or18zero-admission
   null captures cannot supply an operational10^-4/day tail bound. If the weighted
   penalties are negligible, a next bounded study can target a spectral/smoothness
   envelope with an explicit probability budget. If penalties are large, improve
   fixed nuisance rejection/whitening before collecting a large null campaign.

No extra channel implementation, Gaussianization of the nonlinear modulation,
heavy covariance tensor or importance-sampling campaign is warranted merely to
obtain a theoretical label. Until the projected envelope is established, retain
the conditional-null accounting and independent physical-null outcomes as separate
reported evidence.

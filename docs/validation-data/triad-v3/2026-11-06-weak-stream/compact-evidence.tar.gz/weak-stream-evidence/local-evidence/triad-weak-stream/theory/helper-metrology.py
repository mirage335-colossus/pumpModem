#!/usr/bin/env python3
"""Realized Helper residue on matched continuous native controls; no tail proof."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import hashlib,json,math,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
BASE=OUT.parent
sys.path.insert(0,str(ROOT/'tools'))
import numpy as np
import torch
from triad_stream_slots import load_slots
from triad_dynamic_variants import ScanJointReceiver,core_projection_bands

torch.set_num_threads(1);torch.set_num_interop_threads(1)
torch.set_float32_matmul_precision('highest')

def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()

def load(directory):
    m=json.loads((directory/'manifest.json').read_text())
    t=json.loads((directory/m['evaluator_truth_file']).read_text())
    rows=int(m['calendar']['capture_samples'])
    y=np.memmap(directory/m['observation']['file'],dtype='<c16',mode='r',shape=(rows,))
    return m,t,y

def covariance_quadratic(r,powers,centers,coherence):
    # r=[block,bit,candidate,tap], normalized as A^H mu / sigma^2.
    if math.isinf(coherence):
        return (np.abs(r.sum(axis=0))**2*np.asarray(powers)).sum(axis=-1)
    history=np.zeros_like(r[0]);value=np.zeros(r.shape[1:-1],float)
    last=None
    for center,block in zip(centers,r):
        if last is not None:history*=math.exp(-(center-last)/coherence)
        value+=((np.abs(block)**2+2*np.real(block.conj()*history))*np.asarray(powers)).sum(axis=-1)
        history+=block;last=center
    return value

def main():
    destination=OUT/'helper-metrology.json'
    if destination.exists():raise RuntimeError('refusing to replace frozen metrology')
    c,w=time.process_time(),time.perf_counter()
    source_names=('triad_stream_slots.py','triad_dynamic_joint.py','triad_dynamic_variants.py',
                  'triad_dynamic_scan.py','triad_gaussian_prepared.py','triad_gaussian_state.py')
    sources={name:sha(ROOT/'tools'/name)for name in source_names}
    native_sources={name:sha(ROOT/name)for name in ('src/triad_simulation_stream.cpp',
        'src/triad_random_process.hpp','src/channel_perturbation.hpp')}
    report=dict(schema='triad-realized-helper-residue-v1',
        scope='One continuous physical channel realization, three source slots; realized Helper mean/weighted-covariance metrology only. No operational null-tail, ensemble covariance, daily false-admission or physical-device qualification.',
        sources=sources,native_sources=native_sources,
        recipe_sha256=sha(pathlib.Path(__file__)),checks={},windows=[])
    try:
        full_m,slots=load_slots(BASE/'train')
        full_m,full_t,full=load(BASE/'train')
        hm,ht,helper_only=load(BASE/'train-helper-only')
        nm,nt,noise=load(BASE/'train-noise-long')
        old_m,old_t,old_noise=load(BASE/'train-noise')
        checks=report['checks']
        for name,m,t in [('helper-only',hm,ht),('noise-long',nm,nt),('noise-old',old_m,old_t)]:
            if t['random_seed_roots']['noise']!=full_t['random_seed_roots']['noise']:
                raise ValueError(name+' noise root differs')
            if m['power']['complex_noise_variance']!=full_m['power']['complex_noise_variance']:
                raise ValueError(name+' noise variance differs')
            if m['sample_rate_hz']!=full_m['sample_rate_hz'] or m['calendar']['capture_lead_seconds']!=full_m['calendar']['capture_lead_seconds']:
                raise ValueError(name+' absolute sample coordinates differ')
        if full.shape!=helper_only.shape or len(noise)<len(full):
            raise ValueError('matched Helper controls or extended noise shape differs')
        for name in ('format','channel','calendar','helper_plan','whole_bit_calendar'):
            if full_m[name]!=hm[name]:raise ValueError('full/Helper-only '+name+' differs')
        if full_m['power']['post_plan_composite_gain']!=hm['power']['post_plan_composite_gain']:
            raise ValueError('full/Helper-only fixed gain differs')
        if full_t['random_seed_roots']!=ht['random_seed_roots']:
            raise ValueError('full/Helper-only random roots differ')
        checks['noise_roots_equal']=True
        checks['noise_seed']=full_t['random_seed_roots']['noise']
        checks['variance']=full_m['power']['complex_noise_variance']
        checks['noise_long_matches_old_prefix_rows']=len(old_noise)
        checks['noise_long_matches_old_prefix_exact']=bool(np.array_equal(noise[:len(old_noise)],old_noise))
        if not checks['noise_long_matches_old_prefix_exact']:
            raise ValueError('long noise does not match retained old prefix exactly')
        # Ten seconds is inside the public guaranteed pre-Helper region: the
        # earliest selected Helper starts more than22 seconds into capture.
        quiet_rows=10*full_m['sample_rate_hz']
        checks['pre_helper_rows']=quiet_rows
        checks['pre_helper_full_helper_exact']=bool(np.array_equal(full[:quiet_rows],helper_only[:quiet_rows]))
        checks['pre_helper_full_noise_exact']=bool(np.array_equal(full[:quiet_rows],noise[:quiet_rows]))
        if not checks['pre_helper_full_helper_exact']or not checks['pre_helper_full_noise_exact']:
            raise ValueError('pre-Helper noise identity failed')
        checks['noise_prefix_sha256']=hashlib.sha256(np.ascontiguousarray(noise[:len(old_noise)]).view(np.uint8)).hexdigest()
        report['noise_identity_source_argument']='StreamingChannel::process_one adds exactly two thermal_rng.gaussian draws per raw row after propagation, from noise_seed; source calendar, ray/selective state and source controls do not change that RNG stream. Frontend nonlinear/noise controls are absent in these native arguments. Prefix equality independently checked.'
        report['input_sha256']={str(directory.relative_to(ROOT)):dict(manifest=sha(directory/'manifest.json'),observation=sha(directory/'observation.c128'))for directory in
            (BASE/'train',BASE/'train-helper-only',BASE/'train-noise-long',BASE/'train-noise')}
        for index,(m,templates,epochs)in enumerate(slots):
            saved_path=BASE/f'train-native-fixed-{index}.json'
            saved=json.loads(saved_path.read_text())
            coordinates=tuple(tuple(x)for x in saved['refinement']['candidates'])
            if saved['policy']['precision']!='fp32' or saved['policy']['noise_inflation']!=1.:
                raise ValueError('saved receiver precision/noise policy differs')
            for name in source_names:
                if name in saved['policy']['sources']and saved['policy']['sources'][name]!=sources[name]:
                    raise ValueError('saved receiver source differs: '+name)
            qbound=float(m['channel']['sample_clock_pair_ppm'])*float(m['channel']['spread_margin'])
            fbound=float(m['channel']['deterministic_cfo_bound_hz'])*float(m['channel']['spread_margin'])
            required,excluded=core_projection_bands(m,pilot_use='none',frequencies_hz=(-fbound,fbound),clock_ppm=(-qbound,qbound))
            a,b=(m['stream_window'][name]for name in ('absolute_start_sample','absolute_stop_sample'))
            mu=np.asarray(helper_only[a:b])-np.asarray(noise[a:b])
            data=np.asarray(full[a:b])-np.asarray(helper_only[a:b])
            validity=np.ones(len(mu),dtype=bool)
            receiver=ScanJointReceiver(m,templates,epochs,candidate_coordinates=coordinates,
                block_seconds=.25,coherence_seconds=(.5,2.,math.inf),pilot_use='none',
                required_bands_hz=required,auxiliary_exclusion_hz=excluded,valid=validity,
                device='cpu',precision='fp32',memory_limit_bytes=2*1024**3)
            correlations,_=receiver.correlations(mu)
            r=correlations[:,0,1:].detach().cpu().numpy().astype(np.complex128)
            centers=np.cumsum(np.asarray(receiver.elapsed))
            powers=receiver.designs[0].prior.stationary_power
            penalties=[]
            for coherence in receiver.coherences:
                q=covariance_quadratic(r,powers,centers,coherence)
                if np.min(q)<-1e-9*max(1.,float(np.max(abs(q)))):
                    raise ValueError('prior quadratic lost positive semidefiniteness')
                q=np.maximum(q,0.)
                penalties.append(dict(coherence_seconds=str(coherence),max_q=float(q.max()),
                    per_bit_max=q.max(axis=-1).tolist(),per_bit_candidate_q=q.tolist()))
            variance=m['power']['complex_noise_variance']
            total_d,active_d,data_projected=0.,0.,0.
            active_blocks=0
            for start,stop,projection,basis,_,erased in receiver.blocks:
                if erased:raise ValueError('unexpected erased block')
                piece=projection.numpy(mu[start:stop]);dp=projection.numpy(data[start:stop])
                energy=float(np.vdot(piece,piece).real/variance)
                total_d+=energy;data_projected+=float(np.vdot(dp,dp).real/variance)
                active=bool(torch.count_nonzero(basis[1:]))
                if active:active_d+=energy;active_blocks+=1
            report['windows'].append(dict(slot=index,public_window=m['stream_window'],
                saved_receiver_sha256=sha(saved_path),coordinates=coordinates,
                fixed_projection_required_hz=required,fixed_projection_excluded_hz=excluded,
                raw_helper_energy_n0=float(np.vdot(mu,mu).real/variance),
                retained_helper_energy_n0=total_d,retained_helper_active_blocks_energy_n0=active_d,
                active_blocks=active_blocks,total_blocks=len(receiver.blocks),
                raw_data_energy_n0=float(np.vdot(data,data).real/variance),
                retained_data_energy_n0=data_projected,
                q_definition='Realized mu^H K_model,bit,candidate mu from the exact public block-constant OU prior and selected-precision correlations; K is modeled DATA covariance in raw-noise-whitened retained coordinates.',
                penalties=penalties,work=receiver.work()))
            print(index,'Dactive',active_d,'qmax',[p['max_q']for p in penalties],flush=True)
            del receiver,correlations,r,mu,data
        if any(sha(ROOT/'tools'/n)!=h for n,h in sources.items()):
            raise ValueError('source changed during metrology')
        report['status']='measured'
    except Exception as error:
        report['status']='blocked';report['reason']=repr(error)
    report['cpu_seconds']=time.process_time()-c
    report['wall_seconds']=time.perf_counter()-w
    destination.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'],reason=report.get('reason'),cpu_seconds=report['cpu_seconds'],wall_seconds=report['wall_seconds'])))
    if report['status']!='measured':raise SystemExit(1)

if __name__=='__main__':main()

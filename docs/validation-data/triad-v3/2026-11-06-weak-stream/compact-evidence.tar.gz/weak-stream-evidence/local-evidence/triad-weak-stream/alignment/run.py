#!/usr/bin/env python3
"""Oracle-conditioned dynamic scoring for six retained failed acquisitions."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import copy,hashlib,json,math,pathlib,sys,time,resource
import numpy as np
import torch
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from triad_dynamic_joint import load_public
from triad_dynamic_variants import ScanJointReceiver,core_projection_bands
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.set_float32_matmul_precision('highest')
BASE=ROOT/'local-evidence/triad-cpu-ceiling/capture'
names=[f'stress8-{i:02d}'for i in range(4)]+[f'ray05-{i:02d}'for i in range(2)]
manifest,templates,epochs,_,_=load_public(BASE)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
 start_cpu,start_wall=time.process_time(),time.perf_counter();results=[]
 for name in names:
  directory=ROOT/'local-evidence/triad-realtime/captures'/name
  cm,_,_,raw,valid=load_public(directory,BASE)
  truth=json.loads((directory/cm['evaluator_truth_file']).read_text())
  # This deliberately conditions on externally recorded channel/acquisition
  # truth; it is an oracle-only sensitivity diagnostic, never a receiver mode.
  ep=int(cm['public_epoch_seconds'])-int(manifest['public_epoch_seconds'])
  arrival=float(truth['arrival_seconds'])
  tx,rx=truth['tx'],truth['rx']
  q=float(tx['audio_ppm']-rx['audio_ppm'])
  rf=float(cm['physics']['rf_hz']);iff=float(cm['physics']['data_if_hz'])
  f=(rf*(float(tx['rf_ppm'])-float(rx['rf_ppm']))+iff*(float(tx['audio_ppm'])-float(rx['audio_ppm'])))*1e-6
  m=copy.deepcopy(manifest);m['power']=copy.deepcopy(cm['power']);m['power']['reference_epoch_seconds']=manifest['public_epoch_seconds']
  m['channel']=copy.deepcopy(cm['channel'])
  coordinates=[(ep,arrival,f,q)]
  required,excluded=core_projection_bands(m,pilot_use='none',frequencies_hz=(-30.174,30.174),clock_ppm=(-300.015,300.015))
  receiver=ScanJointReceiver(m,templates,epochs,candidate_coordinates=coordinates,
      block_seconds=.25,coherence_seconds=(.5,math.inf),pilot_use='none',
      required_bands_hz=required,auxiliary_exclusion_hz=excluded,valid=valid,
      device='cpu',precision='fp32',memory_limit_bytes=2*1024**3)
  cpu,wall=time.process_time(),time.perf_counter();score=receiver.score(raw)
  elapsed=dict(cpu_seconds=time.process_time()-cpu,wall_seconds=time.perf_counter()-wall)
  bit_scores=score['bit_scores'].reshape(-1,2)[0].tolist()
  selected=int(np.argmax(bit_scores))
  margin=float(bit_scores[int(truth['source_bit'])]-bit_scores[1-int(truth['source_bit'])])
  row=dict(name=name,condition='known alignment/CFO/sample clock and epoch supplied from evaluator; dynamic channel remains unobserved',
    bit=int(truth['source_bit']),epoch_offset_seconds=ep,arrival_seconds=arrival,cfo_hz=f,sample_clock_pair_ppm=q,
    random_ray_width_hz=float(cm['channel']['random_doppler_width_hz']),data_cn0_db_hz=float(cm['power']['data_cn0_db_hz']),
    noise_variance=float(m['power']['complex_noise_variance']),receiver_selected_bit=selected,
    correctly_decoded=(selected==int(truth['source_bit'])),
    correct_minus_alternative_log_evidence=margin,
    bit_log_scores=bit_scores,timing=elapsed,work=receiver.work(),
    capture_sha256={x:sha(directory/x)for x in ('manifest.json','observation.c128','validity.u8')},
    likelihood_note='The exact candidate is both the simulated truth and a publicly absent operational input. Positive correct-minus-alternative log evidence favors the correct source bit; this does not measure acquisition, admission calibration, or unknown-channel fundamental sensitivity.')
  results.append(row);del receiver,score,raw,valid;print(name,round(margin,3),round(elapsed['cpu_seconds'],2),flush=True)
 report=dict(schema='triad-known-alignment-oracle-diagnostic-v1',scope='Retained weak acquisitions, truth-conditioned full dynamic likelihood; no acquisition/admission or performance claim',
  geometry={'block_seconds':.25,'coherences_seconds':[.5,'inf'],'projection':'fixed core; physical full channel/data remain in raw input','precision':'FP32bulk with existing FP64-sensitive reductions'},
  results=results,cpu_seconds=time.process_time()-start_cpu,wall_seconds=time.perf_counter()-start_wall,
  theoretical={'physical_data_cn0_db_hz':8.0,'pattern_calendar_seconds':23.2,'available_ebn0_db':8+10*math.log10(23.2),'assumption':'All nominal allocated DATA power and time contribute; no path, fading, model, acquisition, or false-alarm losses. An upper availability figure, not decoder sensitivity or a coding theorem bound.'})
 report['summary']={'correct':sum(x['correctly_decoded']for x in results),'wrong':sum(not x['correctly_decoded']for x in results),'correct_minus_alternative_log_evidence':[x['correct_minus_alternative_log_evidence']for x in results]}
 (OUT/'oracle-results-corrected.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'cpu_seconds':report['cpu_seconds'],'wall_seconds':report['wall_seconds'],'scores':[{'name':r['name'],'correct_margin':r['correct_minus_alternative_log_evidence']}for r in results]},indent=2))
if __name__=='__main__':main()

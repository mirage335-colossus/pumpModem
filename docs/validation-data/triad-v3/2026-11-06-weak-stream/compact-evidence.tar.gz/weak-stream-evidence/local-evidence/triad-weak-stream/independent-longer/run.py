#!/usr/bin/env python3
"""Frozen34.8-second follow-up; independent and selected paired strata separate."""
import argparse,copy,json,math,multiprocessing,os,resource,subprocess,sys,time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import triad_weak_qualify as q


def prepare():
    old_path=HERE.parent/'independent/protocol.json'
    old=json.loads(old_path.read_text());q.verify(old,full=True)
    if (HERE/'protocol.json').exists():raise ValueError('never overwrite frozen protocol')
    regime=next(x for x in old['regimes'] if x['name']=='moving')
    source=copy.deepcopy(old['base']['public_manifest'])
    source['format']['requested_bit_seconds']=24.
    argv=[old['exporter']['path'],*q.native_arguments(source,regime),
        '--seed','2026112199','--templates','--output',str(HERE/'public-base')]
    w=time.perf_counter();u=resource.getrusage(resource.RUSAGE_CHILDREN)
    with (HERE/'public-base-generation.log').open('x')as log:
        subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    base=json.loads((HERE/'public-base/manifest.json').read_text())
    if not math.isclose(base['format']['bit_seconds'],34.8):raise ValueError('unexpected duration')
    receipt=dict(argv=argv,wall_seconds=time.perf_counter()-w,
        child_cpu_seconds=q._cpu(resource.getrusage(resource.RUSAGE_CHILDREN))-q._cpu(u),
        scope='Public template/preparation fixture only; never used as a qualification observation.')
    q.write_json(HERE/'public-base-generation.json',receipt)
    plan_argv=[old['exporter']['path'],*q.native_arguments(base,regime),'--plan-only']
    plan=json.loads(subprocess.run(plan_argv,cwd=ROOT,capture_output=True,text=True,check=True).stdout)
    rows=[]
    for row in q.schedule(2026112200)[:9]:
        row=dict(row,regime='moving',evaluation_design='independent')
        row['id']='independent-'+row['id'].replace('persistent','moving')
        rows.append(row)
    for name in ('moving-signal-04','moving-signal-05'):
        row=dict(next(r for r in old['rows'] if r['id']==name),
            id='paired-'+name,evaluation_design='selected-paired-development',short_trial_id=name)
        rows.append(row)
    p=copy.deepcopy(old);p.pop('protocol_id')
    p.update(schema='triad-weak-longer-protocol-v1',created_unix_seconds=time.time(),
        source_hashes=q.sources(),additional_source_hashes={str(Path(__file__).resolve()):q.digest(__file__)},
        base=dict(directory=str(HERE/'public-base'),manifest_sha256=q.digest(HERE/'public-base/manifest.json'),
            template_sha256=q.digest(HERE/'public-base'/base['templates']['file']),public_manifest=base),
        public_plans={'moving':dict(argv=plan_argv,public_plan=plan)},regimes=[regime],rows=rows,trials=11,
        independent_trials=9,paired_development_trials=2,duration_alternatives=2,
        analysis_admission_rule='Frozen before heldouts: raw logE >= raw log_e_threshold + log(2). Preserve original raw receiver JSON and original outcome. Both23.2/34.8-second duration alternatives charged; no threshold lowered.',
        population='Six independent balanced-bit moving-channel signals and three independent Helper-only nulls, seeds2026112200..2208, same public arrival/epoch mixture. Two selected former misses at original seed/bit/arrival/epoch are development-paired comparisons, never pooled as independent validation.',
        baseline_protocol=dict(path=str(old_path),sha256=q.digest(old_path),protocol_id=old['protocol_id']),
        source_generation_receipt=receipt)
    p['protocol_id']=q.identity(p);q.write_json(HERE/'protocol.json',p)
    return p


def adjusted_outcome(p,row):
    directory=HERE/'trials'/row['id']
    o=json.loads((directory/'outcome.json').read_text())
    r=json.loads((directory/'receiver-result.json').read_text())
    admission=r.get('operational',{})
    threshold=admission.get('log_e_threshold')
    passed=bool(threshold is not None and admission['log_e_lower_bound']>=threshold+math.log(p['duration_alternatives']))
    o.update(evaluation_design=row['evaluation_design'],original_single_duration_admission=o['conditional_admission'],
        conditional_admission=passed,correct_admitted=bool(o['phase']=='signal'and passed and o['returned_bit']==o['source_bit']),
        wrong_admitted=bool(o['phase']=='signal'and passed and o['returned_bit']!=o['source_bit']),
        missed=bool(o['phase']=='signal'and not passed),null_admitted=bool(o['phase']!='signal'and passed),
        log_e_lower_bound=admission.get('log_e_lower_bound'),
        adjusted_log_e_threshold=None if threshold is None else threshold+math.log(p['duration_alternatives']),
        source_result_sha256=q.digest(directory/'receiver-result.json'))
    return o


def run():
    p=json.loads((HERE/'protocol.json').read_text());q.verify(p,full=True)
    if any(q.digest(path)!=sha for path,sha in p['additional_source_hashes'].items()):raise ValueError('driver changed after freeze')
    if (HERE/'trials').exists():raise ValueError('never automatically retry or overwrite trials')
    w=time.perf_counter()
    with ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn'))as pool:
        raw=list(pool.map(q.trial,[(p,r,str(HERE))for r in p['rows']]))
    elapsed=time.perf_counter()-w;q.verify(p,full=True)
    if any(q.digest(path)!=sha for path,sha in p['additional_source_hashes'].items()):raise ValueError('driver changed during run')
    outcomes=[]
    for row,result in zip(p['rows'],raw):
        if result.get('status')=='error':outcomes.append(dict(result,evaluation_design=row['evaluation_design']))
        else:outcomes.append(adjusted_outcome(p,row))
    independent=[o for o in outcomes if o['evaluation_design']=='independent']
    paired=[o for o in outcomes if o['evaluation_design']!='independent']
    summary=q.summarize(independent,p,elapsed,2,HERE)
    summary.update(expected=p['independent_trials'],scope='Only nine independent trials; campaign wall includes two additional paired development trials.',
        duration_alternatives=p['duration_alternatives'],analysis_admission_rule=p['analysis_admission_rule'])
    q.write_json(HERE/'independent-summary.json',summary)
    q.write_json(HERE/'paired-development.json',dict(protocol_id=p['protocol_id'],outcomes=paired,
        scope='Selected prior misses; paired diagnostic only, no independent success-probability interval.'))
    q.write_json(HERE/'run-summary.json',dict(protocol_id=p['protocol_id'],campaign_wall_seconds=elapsed,
        independent_count=len(independent),paired_count=len(paired),outcomes=outcomes))
    return dict(protocol_id=p['protocol_id'],campaign_wall_seconds=elapsed)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('prepare','run'));args=parser.parse_args()
    result=prepare()if args.action=='prepare'else run()
    print(json.dumps({k:result[k]for k in ('protocol_id',)}))

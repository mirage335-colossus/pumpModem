# Oracle-conditioned weak-capture alignment diagnostic

This is a six-capture sensitivity diagnostic, not blind acquisition or an
admission test. It supplies the receiver the evaluator's exact transmit epoch,
arrival, oscillator-derived CFO, and sample-clock ratio, then scores both keyed
bits with the existing dynamic likelihood. The native observations are unchanged:
Helper, DATA, oscillator phase noise, Doppler/delay spread, stochastic Each65
selectivity, complete tails and AWGN all remain present. The DATA core projection
and two-tap OU likelihood are the receiver's existing approximations.

The exact epoch candidate is
`capture_manifest.public_epoch_seconds - base_public_epoch_seconds + evaluator_truth.source_epoch_offset_seconds`.
The RF/IF CFO calculation is
`rf_hz*(tx_rf_ppm-rx_rf_ppm) + data_if_hz*(tx_audio_ppm-rx_audio_ppm)`, scaled by
1e-6. Clock ratio is `tx_audio_ppm-rx_audio_ppm`. Truth was deliberately opened
before scoring, so all results here are upper-side, conditioned diagnostics.
They cannot be used for runtime acquisition, sensitivity qualification or gate
calibration.

At injected 8 dB-Hz DATA C/N0 with the unchanged 23.2-second pattern, available
nominal DATA energy is 21.65 dB Eb/N0 if all allocated signal power and time are
usable. That favorable energy calculation ignores unknown-channel, waveform,
Helper leakage, receiver-model and false-alarm losses; it is not predicted
performance.

Using 338 blocks of 250 ms, coherences 0.5 s and infinity, and one exact
coordinate, the signed correct-bit log-likelihood ratios were:

| Capture | DATA C/N0 | Random ray width | Signed LLR |
| --- | ---: | ---: | ---: |
| stress8-00 | 8 dB-Hz | 0 Hz | −126.18 |
| stress8-01 | 8 dB-Hz | 0 Hz | −8.84 |
| stress8-02 | 8 dB-Hz | 0 Hz | −127.10 |
| stress8-03 | 8 dB-Hz | 0 Hz | −8.63 |
| ray05-00 | 20.02 dB-Hz | 0.5 Hz | −2875.06 |
| ray05-01 | 20.02 dB-Hz | 0.5 Hz | −11.57 |

Every negative value means the existing likelihood, even with exact alignment,
favored the wrong bit. This establishes that weak onset acquisition alone does
not explain the misses on these six samples. The renewing-ray results also show
substantial mismatch in this dynamic-likelihood/channel combination. It does
not establish a fundamental sensitivity boundary: sample size is tiny and the
likelihood still uses a small OU family with two physical taps.

As a mapping sanity check, two successful 20 dB-Hz holdouts were scored the same
way: signal-00 exact-truth scores `[2383.74, -3.44]` for bit 0, and signal-15
`[-5.36, 2314.74]` for bit 1. Their true epochs were +4 and +6 seconds relative
to the base manifest; coarse CFO candidates were within 0.005 Hz and midpoint-
preserving arrival residuals were under 0.2 ms. This validates the truth-to-
receiver coordinate conversion for those examples, not broad channel coverage.

The six weak-case scores used 3.43 process CPU seconds total on the local CPU.
One exact coordinate removes acquisition cost by design; no admission decision
was attempted. Full per-trial identities and the reproducible command are in
`oracle-results.json` and `run.py`.

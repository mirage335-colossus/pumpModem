# Oracle-conditioned weak-capture alignment diagnostic

This is a six-capture, truth-conditioned sensitivity diagnostic, not blind
acquisition or an admission test. It supplies the receiver the evaluator's exact
transmit epoch, arrival, oscillator-derived CFO and sample-clock ratio, then
scores both keyed bits with the existing dynamic likelihood. The native
observations are unchanged: Helper, DATA, oscillator phase noise, Doppler/delay
spread, stochastic Each65 selectivity, complete tails and AWGN remain present.
The DATA core projection and two-tap OU likelihood are the receiver's existing
approximations.

The exact epoch candidate is
`capture_manifest.public_epoch_seconds - base_public_epoch_seconds + evaluator_truth.source_epoch_offset_seconds`.
The RF/IF CFO calculation is
`rf_hz*(tx_rf_ppm-rx_rf_ppm) + data_if_hz*(tx_audio_ppm-rx_audio_ppm)`, scaled by
1e-6. Clock ratio is `tx_audio_ppm-rx_audio_ppm`. Truth was deliberately opened
before scoring, so these are conditioned results. They cannot be used for runtime
acquisition, sensitivity qualification or gate calibration.

At injected 8 dB-Hz DATA C/N0 with the unchanged 23.2-second pattern, available
nominal DATA energy is 21.65 dB Eb/N0 if all allocated signal power and time are
usable. That favorable energy calculation ignores unknown-channel, waveform,
Helper leakage, receiver-model and false-alarm losses; it is not predicted
performance.

The initial result interpretation had a reporting bug: it treated the first
bit's log evidence against H0 as a bit1-vs-bit0 LLR, and negated it for bit0.
The receiver actually returns `[evidence(bit0 vs H0), evidence(bit1 vs H0)]`.
The correct decision is `argmax(scores)`; the correct-minus-alternative margin
is `scores[true_bit]-scores[other_bit]`. The six score arrays were retained
unchanged, and corrected outcomes below were derived from those arrays without
rerunning the receiver.

| Capture | DATA C/N0 | Random ray width | Correct bit | Correct-minus-alternative evidence |
| --- | ---: | ---: | ---: | ---: |
| stress8-00 | 8 dB-Hz | 0 Hz | 0 | +133.76 |
| stress8-01 | 8 dB-Hz | 0 Hz | 1 | +128.18 |
| stress8-02 | 8 dB-Hz | 0 Hz | 0 | +135.96 |
| stress8-03 | 8 dB-Hz | 0 Hz | 1 | +153.32 |
| ray05-00 | 20.02 dB-Hz | 0.5 Hz | 0 | +2888.52 |
| ray05-01 | 20.02 dB-Hz | 0.5 Hz | 1 | +2705.79 |

Thus, with exact synchronization, all six retained weak or renewing-ray captures
select the transmitted bit. This shows that the earlier blind failures arose
before or during acquisition/selection on these cases, not in the final
truth-aligned likelihood score. It does not establish blind reception at 8 dB-Hz:
the exact candidate is hidden from a real receiver, the sample is small, and no
admission threshold was tested.

Two successful 20 dB-Hz holdouts provide a mapping check: signal-00 exact-truth
scores `[2383.74, -3.44]` for bit 0, and signal-15 `[-5.36, 2314.74]` for bit 1.
Their true epochs were +4 and +6 seconds relative to the base manifest; coarse
CFO candidates were within 0.005 Hz and midpoint-preserving arrival residuals
were under 0.2 ms. This validates the truth-to-receiver coordinate conversion
for those examples, not broad channel coverage.

The six weak-case scores used 3.43 process CPU seconds total on the local CPU.
One exact coordinate removes acquisition cost by design. See
`oracle-results-corrected.json` for recomputed outcomes and
`oracle-results-invalid-interpretation.json` plus
`README-invalid-interpretation.md` for the original derivative and its erroneous
interpretation. `run.py` is the corrected reproducer; it was not rerun as part of
this interpretation-only repair.

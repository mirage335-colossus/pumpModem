import os
os.environ.update(OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
import copy,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[3];OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import torch
from triad_dynamic_joint import load_public
from triad_weak_receiver import WeakReceiver
torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.set_float32_matmul_precision('highest')
base=ROOT/'local-evidence/triad-cpu-ceiling/capture'
m,t,e,_,_=load_public(base)
for name in sys.argv[1:]:
 path=ROOT/'local-evidence/triad-realtime/captures'/name
 cm,_,_,raw,v=load_public(path,base)
 public=copy.deepcopy(m);public['channel']=copy.deepcopy(cm['channel'])
 ratio=10**((m['power']['data_cn0_db_hz']-cm['power']['data_cn0_db_hz'])/10)
 public['power']['complex_noise_variance']*=ratio
 public['power']['data_cn0_db_hz']=cm['power']['data_cn0_db_hz']
 public['power']['effective_helper_cn0_db_hz']=cm['power']['effective_helper_cn0_db_hz']
 public['power']['cn0_override']=cm['power']['cn0_override']
 receiver=WeakReceiver(public,t,e)
 result=receiver.score(raw,v)
 (OUT/(name+'.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 truth=json.loads((path/cm['evaluator_truth_file']).read_text())
 print(name,result['status'],result['bit'],truth['source_bit'],result.get('score'),result['reason'],result['timing'],result.get('operational'),flush=True)

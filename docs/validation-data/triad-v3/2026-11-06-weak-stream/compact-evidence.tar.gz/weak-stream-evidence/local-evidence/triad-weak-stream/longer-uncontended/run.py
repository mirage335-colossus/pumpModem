import os
os.environ.update(OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
import json,pathlib,sys,time
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
cold_c,cold_w=time.process_time(),time.perf_counter()
import torch
from triad_dynamic_joint import load_public
from triad_weak_receiver import WeakReceiver
import triad_weak_qualify as q
torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.set_float32_matmul_precision('highest')
p=HERE.parent/'independent-longer';protocol=json.loads((p/'protocol.json').read_text());q.verify(protocol,full=True)
rows=[]
for row in protocol['rows']:
 if row['evaluation_design']=='independent' and row['phase']=='signal':
  receipt=json.loads((p/'trials'/row['id']/'receipt.json').read_text())
  result=json.loads((p/'trials'/row['id']/'receiver-result.json').read_text())
  wall=receipt['stages']['construction']['wall_seconds']+result['timing']['total']['wall_seconds']
  rows.append((wall,row))
previous,row=max(rows,key=lambda x:x[0]);directory=p/'trials'/row['id']/'capture'
cm,t,e,x,v=load_public(directory,protocol['base']['directory']);m=q.receiver_manifest(protocol['base']['public_manifest'],cm,protocol['regimes'][0])
a,b=time.process_time(),time.perf_counter();rx=WeakReceiver(m,t,e);prep=dict(cpu_seconds=time.process_time()-a,wall_seconds=time.perf_counter()-b)
r=rx.score(x,v);q.verify(protocol)
q.write_json(HERE/'receiver-result.json',r)
out=dict(schema='triad-longer-uncontended-runtime-v1',selected_trial=row['id'],selection='Largest prior independent construction+score wall; performance diagnostic only, not a new sensitivity trial.',previous_concurrent_wall_seconds=previous,preparation=prep,receiver_timing=r['timing'],cold_cpu_seconds=time.process_time()-cold_c,cold_wall_seconds=time.perf_counter()-cold_w,air_seconds=73.2,capture_seconds=len(x)/m['sample_rate_hz'],raw_templates_preexisting=True,scope='Fresh process, imports/loading/construction/score included from timer before numerical imports. Native raw-template generation and Python process startup before timer excluded.',source_sha256=q.sources(),source_script_sha256=q.digest(__file__),input_sha256=q.digest(directory/cm['observation']['file']))
q.write_json(HERE/'receipt.json',out);print(json.dumps(out),flush=True)

# Longer DATA duration under renewing rays and moving delay

Frozen protocol:
`e7b0dd51dd613be1547899fbe9a4b7ca25fa261a8db217769fa05f667728a82a`.
The protocol and local driver hash were fixed before the eleven new trial
captures. The native public template fixture was generated first and was never
used as a qualification observation. Runtime receiver sources and admission
model were unchanged from the preceding independent study.

The requested pattern duration changed from 16 to 24 seconds; the existing
planner resolves this to **34.8 seconds of DATA**, compared with 23.2 seconds.
The Helper lead remains 38 seconds. Total transmitted support is 73.2 seconds
and the native receiver capture is 96.279 seconds. DATA/Helper C/N₀ remain
8/18 dB-Hz. Every other physical setting remains the preceding moving-channel
case: B=0.5 Hz random ray width, 90 Hz center separation, 21 ms excess delay,
0.2 µs delay excursion with 20-second knots, random Each 65% modulation,
crystal base oscillator and IC-7100 shift clock at 30 MHz.

Before observing the new trials, the analysis charged **two duration
alternatives**: admission requires raw logE at least the original threshold
plus log(2), namely **22.1865259**. The original runtime result/outcome JSON is
unchanged; derived analysis fields identify the stricter threshold explicitly.
This is a conditional Gaussian construction, not a physical-null guarantee.

| Cohort | Correct admissions | Wrong admissions | Misses | False admissions |
|---|---:|---:|---:|---:|
| Six independent signals, balanced bits, seeds 2026112200–2205 | 6/6 | 0 | 0 | — |
| Three independent Helper-only controls, seeds 2026112206–2208 | — | — | — | 0/3 |
| Two selected paired former misses | 2/2 | 0 | 0 | — |

All six independent signal logE values were between 46.8853 and 79.3901.
Two Helper-only controls were scored and rejected, with logE −26.8585 and
−26.5527. The remaining control returned the explicit
`onset_aperture_work_limit` unresolved outcome. It was neither scored nor
counted as an execution error. No trial had a setup or execution error.

The selected paired cases retained their original channel/noise seed, bit,
arrival and epoch. `moving-signal-04` increased from logE 20.1083 to 107.3163;
`moving-signal-05` increased from 17.0855 to 49.4507. These are useful paired
development diagnostics, not independent validation: the original cases were
chosen because they missed. A longer pattern can change the keyed/interleaved
waveform, so this is not a claim that the first 23.2 seconds were unchanged.
The longer duration adds 50% nominal DATA energy, or 1.761 dB, without changing
power; realized fading energy and inference mismatch remain separate effects.

This small cohort does not qualify 99% correct reception. The conservative
balanced-bit 95% interval is [0.2321, 1] despite the six observed successes.
For three independent Helper-only controls, the one-sided 95% upper
false-admission probability is still 0.6316. No pure-noise trials were repeated
in this longer follow-up; the summary reports that stratum as untested.

The eleven-trial campaign took **377.468 seconds** on the local CPU, using two
trial processes with two numerical threads each, overlapping the owner's
separate live test. Independent-signal receiver construction plus scoring took
**73.03–101.30 CPU seconds** and **62.95–88.43 wall seconds**. These are concurrent
campaign measurements, not isolated latency bounds. Their maximum corresponds
to 1.052 CPU seconds per captured second and 1.384 per transmitted second.
The largest wall time fits the 96.279-second capture but exceeds the
73.2-second transmitted support. Do not infer a complete contiguous multi-bit
streaming capability from these one-bit workloads.

Public-base generation took 15.55 CPU / 15.72 wall seconds. That bundle includes
template generation, unused channel simulation and file output; it is not an
isolated measurement of unavoidable receiver preparation. Audio conversion and
physical device capture are outside this study.

The exact source-bound protocol, raw measurements, generation arguments,
per-trial input hashes and scores remain here. `independent-summary.json`
excludes both selected paired cases; `paired-development.json` contains only
those paired comparisons. `compact.json` is a reporting-only extraction.

This was an occasional focused qualification, not a routine test. The recorded
commands were:

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  /tmp/triad-weak-env/bin/python \
  local-evidence/triad-weak-stream/independent-longer/run.py prepare
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  /tmp/triad-weak-env/bin/python \
  local-evidence/triad-weak-stream/independent-longer/run.py run
```

The driver intentionally refuses overwriting or automatic retrying of existing
trial evidence. No additional duration campaign was run after these results.

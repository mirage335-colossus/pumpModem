#!/usr/bin/env python3
"""Read-only Nsight/cProfile extraction; writes only the requested summary."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import pstats
import sqlite3
import statistics


def union_ns(intervals):
    end = total = 0
    for first, last in sorted(intervals):
        total += max(0, last-max(first, end))
        end = max(end, last)
    return total


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyse(base):
    trace = base/'full-receiver-profile.sqlite'
    profile = base/'full-receiver.pstats'
    index_path = base/'profile-receiver/index.json'
    index = json.loads(index_path.read_text())
    references = [(case['label'], scan) for case in index['cases'] for scan in case['scans']]
    connection = sqlite3.connect('file:'+str(trace.resolve())+'?mode=ro', uri=True)
    ranges = connection.execute("SELECT start,end,text FROM NVTX_EVENTS WHERE text LIKE 'correlation=%' ORDER BY start").fetchall()
    if len(ranges) != len(references):
        raise ValueError('NVTX ranges do not match the ordered driver index')
    result = dict(schema='triad-full-receiver-profile-analysis-v1',
        input_hashes={str(path): sha(path) for path in (trace, profile, index_path)},
        gpu=connection.execute('SELECT name,smCount,memoryBandwidth,totalMemory FROM TARGET_INFO_GPU').fetchall(),
        limits=[
            'All timings come from simultaneous cProfile, Nsight Systems and per-block CUDA-event instrumentation; they are not normal throughput.',
            'Visible-kernel union omits graph-internal kernels. Combined coverage unions graph replay envelopes and visible kernels without summing overlapping spans.',
            'A graph envelope includes its internal gaps. Combined coverage is not an SM-busy or occupancy counter.',
            'Outside-reported-device-spans time is not a global GPU idle measurement or an exact Python-function attribution.',
            'Graph launch/envelope count mismatches invalidate complete device-coverage claims for the affected scans; their cause is unverified.',
            'CUDA event stage elapsed times include queue/host gaps between event records, not just kernel execution. They are separate from device interval unions.',
            'Conditional correlation-free speedups hold other instrumented stages fixed. They are scenario calculations, not demonstrated or operational performance bounds.',
            'No DRAM/cache/SM occupancy or stall counters were collected. cProfile is aggregated across imports, preparation, cold and warm scans; cumulative times cannot be summed.'
        ], scans=[])
    for (label, scan), (first, last, nvtx) in zip(references, ranges):
        if scan['timing_scan'] == 0:
            continue
        expected = f"correlation={scan['precision']};scan={scan['timing_scan']};copies={scan['timing_observation_copies']}"
        if nvtx != expected:
            raise ValueError(f'NVTX/index mismatch: {nvtx} != {expected}')
        kernels = connection.execute('SELECT k.start,k.end,s.value,k.streamId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName WHERE k.start>=? AND k.end<=? ORDER BY k.start', (first,last)).fetchall()
        graphs = connection.execute('SELECT start,end,graphId,streamId FROM CUPTI_ACTIVITY_KIND_GRAPH_TRACE WHERE start>=? AND end<=? ORDER BY start', (first,last)).fetchall()
        runtime = connection.execute('SELECT s.value,count(*),sum(r.end-r.start) FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId WHERE r.start>=? AND r.end<=? GROUP BY r.nameId ORDER BY 3 DESC', (first,last)).fetchall()
        launches = sum(count for name,count,_ in runtime if name.startswith('cudaGraphLaunch'))
        groups = defaultdict(lambda: [0,0])
        for start, end, name, stream in kernels:
            groups[name][0] += 1
            groups[name][1] += end-start
        kernel_union = union_ns([(k[0],k[1]) for k in kernels])
        graph_union = union_ns([(g[0],g[1]) for g in graphs])
        combined = union_ns([(k[0],k[1]) for k in kernels]+[(g[0],g[1]) for g in graphs])
        row = dict(label=label, timing_scan=scan['timing_scan'], nvtx=nvtx,
            wall_ms=(last-first)/1e6,
            visible_kernel_count=len(kernels), visible_kernel_union_ms=kernel_union/1e6,
            graph_envelope_count=len(graphs), graph_launch_api_count=launches,
            graph_envelope_union_ms=graph_union/1e6,
            combined_device_span_union_ms=combined/1e6,
            outside_reported_device_spans_ms=(last-first-combined)/1e6,
            graph_envelope_count_matches_launches=(len(graphs)==launches),
            streams=sorted({k[3] for k in kernels}|{g[3] for g in graphs}),
            top_visible_kernels=[dict(name=name,count=values[0],sum_ms=values[1]/1e6)
                                 for name,values in sorted(groups.items(),key=lambda item:-item[1][1])[:20]],
            runtime=[dict(name=name,count=count,sum_ms=ns/1e6) for name,count,ns in runtime],
            memcpy=[dict(copy_kind=kind,bytes_per_copy=size,count=count,sum_ms=ns/1e6)
                    for kind,size,count,ns in connection.execute('SELECT copyKind,bytes,count(*),sum(end-start) FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE start>=? AND end<=? GROUP BY copyKind,bytes ORDER BY count(*) DESC',(first,last))])
        corr = scan['correlation_seconds']*1000
        update = scan['inference_update_seconds']*1000
        finish = scan['inference_finish_seconds']*1000
        wall = scan['complete_resident_seconds']*1000
        row['instrumented_stages'] = dict(report_wall_ms=wall,correlation_event_elapsed_ms=corr,
            inference_update_event_elapsed_ms=update,inference_finish_event_elapsed_ms=finish,
            event_stage_elapsed_sum_ms=corr+update+finish,
            report_wall_outside_event_stages_ms=wall-corr-update-finish,
            conditional_correlation_free_wall_ms=wall-corr,
            conditional_correlation_free_speedup=wall/(wall-corr),
            assumptions='Same construction stream; sequential nonoverlapping event scopes in source runner; only correlation stage elapsed removed, remaining wall held fixed. Not an operational bound.')
        result['scans'].append(row)
    connection.close()
    result['warm_summary'] = []
    for label in dict.fromkeys(row['label'] for row in result['scans']):
        rows=[row for row in result['scans'] if row['label']==label]
        result['warm_summary'].append(dict(label=label,
            median_profiled_wall_ms=statistics.median(row['wall_ms'] for row in rows),
            median_visible_kernel_union_ms=statistics.median(row['visible_kernel_union_ms'] for row in rows),
            median_graph_envelope_union_ms=statistics.median(row['graph_envelope_union_ms'] for row in rows),
            median_combined_device_span_union_ms=statistics.median(row['combined_device_span_union_ms'] for row in rows),
            device_span_coverage_complete_by_graph_count=all(row['graph_envelope_count_matches_launches'] for row in rows),
            median_conditional_correlation_free_speedup=statistics.median(row['instrumented_stages']['conditional_correlation_free_speedup'] for row in rows)))
    stats = pstats.Stats(str(profile))
    result['cprofile'] = dict(total_seconds=stats.total_tt,total_calls=stats.total_calls,
        scope='Whole profiled process including imports, preparation, cold/warm cases; not warm-only attribution.',
        top_self=[dict(file=key[0],line=key[1],function=key[2],primitive_calls=value[0],calls=value[1],self_seconds=value[2],inclusive_seconds=value[3])
                  for key,value in sorted(stats.stats.items(),key=lambda item:-item[1][2])[:20]],
        fft=[dict(file=key[0],line=key[1],function=key[2],calls=value[1],self_seconds=value[2],inclusive_seconds=value[3])
             for key,value in stats.stats.items() if 'fft_irfft' in key[2]])
    result['fft_interpretation'] = 'No FFT-named kernels appear in primary warm eager scans. The selected receiver builds phase kernels with CPU torch.fft.irfft during cached transition preparation, then uses roll/add or the fused phase stencil plus frequency GEMM in updates. cProfile records 12 irfft calls totaling about 0.000744s across all cold/warm work. Graph-internal kernel detail is not exported, so do not assign graph time to FFT from these traces.'
    result['workload'] = dict(capture='boundary-cn-10-r0',blocks=85,candidates=4,
        external_cfo_states=3,lags=3,phase_states=512,residual_frequency_states=43,
        taps=1,static_gain_quadrature_states=3,hypotheses_per_capture=36,
        note='This one-tap example has Q=3, not the two-tap Q=24 workload.')
    return result


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parents[1]/'gpu-baseline/results')
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('full-receiver-summary.json'))
    args=parser.parse_args()
    output=analyse(args.input_dir)
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    for row in output['warm_summary']:
        print(row)

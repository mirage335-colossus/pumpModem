#!/usr/bin/env python3
"""Parse already-retained SASS and sweep JSON locally; no external execution.

Counts describe the compiled disassembly, not executed local-memory traffic,
cache misses, occupancy, bandwidth or utilization. No subprocess or GPU API
is used. Run with the directory containing this script as its first argument.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

CASES = (
    ("v1-bm128-bn128-bk128-w4", "sweep-v1.json", (128, 128, 128, 4, 2)),
    ("v1-bm128-bn256-bk128-w4", "sweep-v1.json", (128, 256, 128, 4, 2)),
    ("v1-bm128-bn128-bk256-w4", "sweep-v1.json", (128, 128, 256, 4, 2)),
    ("v2-bm128-bn256-bk128-w8", "sweep-v2.json", (128, 256, 128, 8, 2)),
)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def opcodes(sass):
    counts = {}
    for line in sass.splitlines():
        code = re.sub(r"/\*.*?\*/", "", line)
        match = re.match(r"\s*(?:@!?P\d+\s+)?([A-Z][A-Z0-9_.]*)\s", code)
        if match:
            op = match[1]
            counts[op] = counts.get(op, 0)+1
    return dict(sorted(counts.items()))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("retained_directory", type=Path)
    parser.add_argument("--output", default="-")
    args = parser.parse_args()
    root = args.retained_directory
    report = {
        "schema": "triad-fp4-static-kernel-analysis-v1",
        "method": "Local parsing of existing cuobjdump SASS and timing JSON; no subprocess or GPU API",
        "source_sha256": digest(Path(__file__).read_bytes()),
        "measured_dynamic_hardware_counters": None,
        "limits": "Static counts count instruction sites in disassembly, not executed counts or measured memory traffic; compiled resource fields are not measured occupancy.",
        "resource_register_spill_fields_retained": False,
        "resource_limit": "Sweep KernelMetadata retains shared bytes but not n_regs or n_spills. Raw cuobjdump resource stdout was not retained in these inputs.",
        "cases": [],
    }
    for name, filename, tile in CASES:
        timing_path = root/filename
        timing = json.loads(timing_path.read_text())
        found = [case for case in timing["cases"] if case.get("shape_mnk") == [8192, 8192, 4096]
                 and case.get("format") == "nvfp4" and tuple(case.get("tile", ())) == tile]
        if len(found) != 1:
            raise ValueError(f"expected one timing case for {name}, found {len(found)}")
        case = found[0]
        sass_path = root/f"{name}.sass"
        sass_bytes = sass_path.read_bytes()
        sass = sass_bytes.decode()
        expected_hash = case["kernel_artifacts"]["sass"]["sha256"]
        if digest(sass_bytes) != expected_hash:
            raise ValueError(f"SASS artifact SHA mismatch for {name}")
        counts = opcodes(sass)
        metadata = case["kernel_metadata"]
        shared = re.search(r"\bshared=(\d+)", metadata)
        stack_changes = [int(v, 16) for v in re.findall(
            r"\bIADD\s+R1,\s*R1,\s*-(0x[0-9a-fA-F]+)", sass)]
        report["cases"].append({
            "name": name, "shape_mnk": [8192, 8192, 4096],
            "tile_bm_bn_bk_warps_stages": tile,
            "timing_input": filename, "timing_input_sha256": digest(timing_path.read_bytes()),
            "sass_input": sass_path.name, "sass_sha256": digest(sass_bytes),
            "sass_hash_matches_sweep_record": True,
            "static_opcode_counts": counts,
            "static_local_load_instructions": sum(v for k, v in counts.items() if k == "LDL" or k.startswith("LDL.")),
            "static_local_store_instructions": sum(v for k, v in counts.items() if k == "STL" or k.startswith("STL.")),
            "static_stack_pointer_decrements_bytes": stack_changes,
            "compiled_shared_bytes_from_metadata": int(shared[1]) if shared else None,
            "native_product_host_paced_ms": case["host_paced"]["native_product"],
            "native_product_graph_ms": case["product_graph"]["native_fp4"],
            "pack_both_product_ms": case["host_paced"]["pack_both_product"],
            "instruction_evidence": case["instruction_evidence"],
        })
    denial = root/"ncu-good.log"
    log = denial.read_text()
    report["nsight_compute"] = {"log": denial.name, "sha256": digest(denial.read_bytes()),
                                 "status": "counter_permission_denied" if "ERR_NVGPUCTRPERM" in log else "inspect_log",
                                 "exact_log": log}
    baseline, bad, bk256, eight = report["cases"]
    report["same_shape_cross_run_timing_ratios"] = {
        "bad_bn256_w4_vs_baseline_product_graph": bad["native_product_graph_ms"]["cuda_ms_per_call"]/baseline["native_product_graph_ms"]["cuda_ms_per_call"],
        "bn256_w4_vs_w8_product_graph": bad["native_product_graph_ms"]["cuda_ms_per_call"]/eight["native_product_graph_ms"]["cuda_ms_per_call"],
        "bn256_w8_vs_baseline_product_graph": eight["native_product_graph_ms"]["cuda_ms_per_call"]/baseline["native_product_graph_ms"]["cuda_ms_per_call"],
    }
    report["cross_run_timing_limit"] = (
        "The v1/v2 timings use the same shape and GPU but separate sweep processes; "
        "their RNG draw histories and thermal/clock histories need not match. "
        "The small baseline-versus-eight-warp difference is not a repeated interleaved confidence interval.")
    report["conclusion"] = (
        "BN256 at four warps compiles many local-memory load/store sites and a large stack frame; "
        "the baseline has none, and the same BN256 tile at eight warps removes the local-memory sites. "
        "The same-shape timing change supports compiled register spilling as the severe regression mechanism. "
        "Dynamic spill traffic, cache behavior and achieved occupancy remain unmeasured because Nsight counters were denied.")
    encoded = json.dumps(report, indent=2)+"\n"
    if args.output == "-":
        print(encoded, end="")
    else:
        Path(args.output).write_text(encoded)

if __name__ == "__main__":
    main()

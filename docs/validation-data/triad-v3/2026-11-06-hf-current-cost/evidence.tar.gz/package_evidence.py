import hashlib,json,pathlib,tarfile,subprocess
p=pathlib.Path(__file__).resolve().parent
out=pathlib.Path('docs/validation-data/triad-v3/2026-11-06-hf-current-cost')
read=lambda f:json.loads(f.read_text())
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=read(p/'public-generation.json');b=read(p/'public-no-templates-generation.json')
key_cpu=a['cpu_seconds']-b['cpu_seconds'];key_wall=a['wall_seconds']-b['wall_seconds']
rows=[]
for name in ['physical0','physical1','target8']:
 d=read(p/name/'report.json');r=read(p/name/'receiver/slot-0-receiver.json')
 assert d['measurement_execution_pass'] and d['source_identity_unchanged']
 assert len(d['stream']['schedule']['records'])==1
 assert d['stream']['schedule']['records'][0]['status']=='scored'
 rx=d['reception'];work=d['receiver_preparation'];imp=d['imports'];load=d['public_loading']
 prep=key_cpu+work['cpu_seconds']+imp['cpu_seconds']+load['cpu_seconds']
 row=dict(name=name,source_revision=d['source_revision'],rx_cpu_seconds=rx['cpu_seconds'],rx_wall_seconds=rx['wall_seconds'],workspace=work,imports=imp,loading=load,
   fresh_preparation_estimate_cpu_seconds=prep,fresh_preparation_estimate_wall_seconds=key_wall+work['wall_seconds']+imp['wall_seconds']+load['wall_seconds'],
   cold_one_bit_total_cpu_seconds=rx['cpu_seconds']+prep,
   prepared_cpu_per_one_bit_air_second=rx['cpu_seconds']/84.8,cold_cpu_per_one_bit_air_second=(rx['cpu_seconds']+prep)/84.8,
   prepared_cpu_per_data_second=rx['cpu_seconds']/46.4,cold_cpu_per_data_second=(rx['cpu_seconds']+prep)/46.4,
   receiver_stage_timing=r['timing'],helper_original_cfo_count=r['helper']['original_count'],helper_selected_cfo_count=r['helper']['selected_count'],
   bit=r['bit'],expected_bit=1 if name=='physical1' else 0,
   conditional_model_pass=r['operational']['passes_conditional_bound'],log_e_lower_bound=r['operational']['log_e_lower_bound'],log_e_threshold=r['operational']['log_e_threshold'],
   fully_scored=True,physical_null_qualified=d['physical_null_qualified'],report_sha256=digest(p/name/'report.json'),receiver_result_sha256=digest(p/name/'receiver/slot-0-receiver.json'))
 assert row['bit']==row['expected_bit']
 if name!='target8':
  row['fox_cpu_estimate']=22*(rx['cpu_seconds']+work['cpu_seconds']+key_cpu)+imp['cpu_seconds']+load['cpu_seconds']
  row['fox_cpu_per_air_second_estimate']=row['fox_cpu_estimate']/1059.2
 else:row['quiet_noise_metrology']=d['metrology']['bands']
 rows.append(row)
summary=dict(schema='triad-hf-current-cost-summary-v1',measured_revision=rows[0]['source_revision'],native_exporter_sha256=digest(pathlib.Path('build/dev-cli/triad_helper_export')),
 raw_keyed_template_cpu_estimate=key_cpu,raw_keyed_template_wall_estimate=key_wall,raw_template_scope='Single paired exporter difference; not an isolated API timer or confidence interval.',
 active_data_seconds=46.4,one_bit_air_seconds=84.8,fox_bits=22,fox_air_seconds_estimate=1059.2,
 trials=rows,scope='Local 5650U two numerical threads; software48kPCM to6kDDC; not physicalADC/ASRC, not arbitrarymessage completion; estimates are not confidence bounds.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[f for f in p.iterdir() if f.suffix in ('.py','.json','.log') and f.is_file() and f.name not in ('archive-identities.json','package.log')]
for name in ['public','public-no-templates','signal0','signal1','signal0-scheduled','signal1-scheduled']:
 files+=list((p/name).glob('*.json'))
for name in ['physical0','physical1','target8']:
 files+=list((p/name).rglob('*.json'))
files=sorted(set(files))
identities={str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=digest(f)) for f in files}
(p/'archive-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','w:gz') as archive:
 for f in files+[p/'archive-identities.json']:
  archive.add(f,arcname=str(f.relative_to(p)),recursive=False)
archive_hash=digest(out/'evidence.tar.gz')
(out/'SHA256SUMS').write_text(f'{archive_hash}  evidence.tar.gz\n{digest(out/"summary.json")}  summary.json\n')
print(json.dumps(dict(files=len(files)+1,archive_bytes=(out/'evidence.tar.gz').stat().st_size,archive_sha256=archive_hash,rows=rows),indent=2))

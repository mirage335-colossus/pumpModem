import json,resource,subprocess,time
from pathlib import Path
p=Path(__file__).parent; protocol=json.load(open(p/'generation-protocol.json'));base=protocol['base']
rows=[('signal0-scheduled',202611064001,0,2.7),('signal1-scheduled',202611064002,1,-6.9)]
(p/'scheduled-generation-protocol.json').write_text(json.dumps(dict(base=base,rows=rows,epoch=1793850000,scope='Scheduled current whole-bit calendar, independent seeds/arrivals/bits; all13keyepochssearched. InitialdifferentexportepochschangedtheUTCcalendarandarenotusedinthistimingcomparison.'),indent=2))
for name,seed,bit,arrival in rows:
 cmd=base+['--epoch','1793850000','--seed',str(seed),'--bit',str(bit),'--arrival-seconds',str(arrival),'--output',str(p/name)]
 u=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter()
 with (p/(name+'-generation.log')).open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 v=resource.getrusage(resource.RUSAGE_CHILDREN);report=dict(command=cmd,returncode=r.returncode,wall_seconds=time.perf_counter()-w,cpu_seconds=v.ru_utime+v.ru_stime-u.ru_utime-u.ru_stime)
 (p/(name+'-generation.json')).write_text(json.dumps(report,indent=2));print(name,report['returncode'],report['cpu_seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)

import hashlib,json,resource,subprocess,time
from pathlib import Path
p=Path(__file__).parent
base=['build/dev-cli/triad_helper_export','--case','hf','--sample-rate','6000','--seconds','46.4','--rate','36','--added-symbols','10','--base-oscillator','crystal','--shift-oscillator','ic-7100','--rf-hz','30000000','--data-if','1725','--spread-preset','hf-worst','--margin','3','--selective-perturbation','each-65','--timing-policy','broad','--fhss','off','--helper','on','--data-power-w','4','--helper-power-w','40','--channel-evolution','stochastic','--random-doppler-width-hz','.5','--delay-excursion-ms','.0002','--delay-knot-seconds','20','--whole-bit-count','1','--key-seed','314159','--shaping','auto']
rows=[('public',1793850000,202611064000,0,0,True),('signal0',1793850002,202611064001,0,2.7,False),('signal1',1793849997,202611064002,1,-6.9,False),('public-no-templates',1793850000,202611064000,0,0,False)]
protocol=dict(base=base,rows=rows,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),native_sha256=hashlib.sha256(Path(base[0]).read_bytes()).hexdigest(),scope='Predeclared independent channel seeds and arrivals; RX uses only the separate public manifest/templates. Physical noise; target8 controls46.4sDATAplanning, no injectedcn0override.')
with (p/'generation-protocol.json').open('x') as f:json.dump(protocol,f,indent=2)
for name,epoch,seed,bit,arrival,templates in rows:
 cmd=base+['--epoch',str(epoch),'--seed',str(seed),'--bit',str(bit),'--arrival-seconds',str(arrival),'--output',str(p/name)]+(['--templates'] if templates else [])
 u=resource.getrusage(resource.RUSAGE_CHILDREN);w=time.perf_counter()
 with (p/(name+'-generation.log')).open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 v=resource.getrusage(resource.RUSAGE_CHILDREN)
 report=dict(command=cmd,returncode=r.returncode,wall_seconds=time.perf_counter()-w,cpu_seconds=v.ru_utime+v.ru_stime-u.ru_utime-u.ru_stime)
 (p/(name+'-generation.json')).write_text(json.dumps(report,indent=2)+'\n');print(name,report['returncode'],report['cpu_seconds'],report['wall_seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)

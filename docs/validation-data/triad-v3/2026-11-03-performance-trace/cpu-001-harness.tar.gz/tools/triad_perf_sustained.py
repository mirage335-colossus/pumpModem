#!/usr/bin/env python3
"""One-shot sustained consistency checks for qualified triad benchmarks.

These checks do not create new qualification anchors or confidence intervals.
They compare an already frozen forecast with one predeclared, longer execution
and report the actually observed timing span.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import secrets
import time


SCHEMA = "triad-performance-sustained-v1"
MAX_NATIVE_TRIALS = 10_000
MINIMUM_SECONDS = 60.0
SAFETY_FACTOR = 1.5


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def _positive(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{label} must be finite and positive")
    return float(value)


def _require_qualified(result):
    if not isinstance(result, dict) or result.get("prediction_valid") is not True:
        raise ValueError("sustained check requires a valid qualified prediction")


def _require_native_candidate(result, case):
    """Accept candidate mean equivalence despite an inconclusive paired gate."""
    if not isinstance(result, dict):
        raise ValueError("sustained check requires a native qualification report")
    from triad_perf_native import digest, validate_holdout

    anchors = result.get("anchors", {})
    qualification = anchors.get("qualification")
    frozen = anchors.get("frozen_prediction")
    holds = anchors.get("full_holdouts", [])
    if not isinstance(frozen, dict) or not isinstance(qualification, dict):
        raise ValueError("native sustained check requires a frozen prediction and independent holdout qualification")
    if (frozen.get("sha256") != digest({key: value for key, value in frozen.items() if key != "sha256"})
            or anchors.get("case_sha256") != digest(case)
            or frozen.get("case_sha256") != digest(case)
            or frozen.get("identities") != result.get("identities")
            or result.get("frozen_predictions", [])[-1:] != [frozen]):
        raise ValueError("native frozen prediction identity or linkage is invalid")
    count = frozen.get("predeclared_validation_repeats")
    if count not in (3, 5, 9, 17):
        raise ValueError("native qualification has no supported predeclared holdout count")
    if frozen.get("validation_duration_seconds") != case.get("target_seconds"):
        raise ValueError("native candidate qualification is not for the full target duration")
    candidate_prediction = frozen.get("validation_predictions", {}).get("candidate")
    if not isinstance(candidate_prediction, dict):
        raise ValueError("native frozen candidate validation prediction is missing")
    from triad_perf_adaptive import qualify_log_residuals
    candidate_holds = [row for row in holds if row.get("source") == "candidate"]
    if (len(candidate_holds) != count or
            {row.get("index") for row in candidate_holds} != set(range(count))):
        raise ValueError("native candidate holdouts do not match their frozen predeclared count")
    candidate_holds.sort(key=lambda row: row["index"])
    allowance_values = {row.get("validation", {}).get("allowed_relative_error") for row in candidate_holds}
    if len(allowance_values) != 1:
        raise ValueError("native candidate holdouts use inconsistent equivalence bounds")
    allowance = allowance_values.pop()
    logs = []
    for row in candidate_holds:
        if (row.get("kind") != "qualify" or row.get("frozen_prediction_sha256") != frozen["sha256"]
                or row.get("prediction") != candidate_prediction or not isinstance(row.get("actual"), dict)):
            raise ValueError("native candidate holdout is not linked to the frozen full-duration prediction")
        measured = validate_holdout(candidate_prediction, row["actual"], maximum_relative_error=allowance)
        if measured != row.get("validation") or measured.get("geometry_matched") is not True:
            raise ValueError("native candidate holdout no longer matches its recorded validation")
        logs.append(measured["log_error"])
    if qualification.get("log_errors", {}).get("candidate") != logs:
        raise ValueError("native candidate qualification residuals do not match the linked holdouts")
    candidate_interval = qualify_log_residuals(logs, maximum_relative_error=allowance)
    if qualification.get("intervals", {}).get("candidate") != candidate_interval:
        raise ValueError("native candidate mean-equivalence interval is not reproducible")
    if candidate_interval.get("status") == "validated":
        if result.get("prediction_valid") is True:
            return "joint_case_qualified"
        return "candidate_source_independently_qualified; paired/reference qualification inconclusive"
    raise ValueError("sustained native check requires a qualified candidate source prediction")


def _check_budget(expected_seconds, deadline):
    required = SAFETY_FACTOR * expected_seconds
    if deadline is not None:
        remaining = deadline - time.monotonic()
        if remaining < required:
            raise TimeoutError(f"sustained check needs at least {required:.3f}s budget; {max(0., remaining):.3f}s remains")
    return required


def native_sustained(binary, case, qualified_result, minimum_seconds=MINIMUM_SECONDS,
                     threads=1, deadline=None, freeze_callback=None):
    """Run one frozen full-duration native campaign sized from its forecast.

    The native pipeline is receiver plus generation/setup/other work. Process
    startup/output is paid once and is deliberately excluded from per-trial
    sizing. The case's target duration and all physical arguments are retained.
    """
    qualification_scope = _require_native_candidate(qualified_result, case)
    minimum_seconds = _positive(minimum_seconds, "minimum_seconds")
    if not isinstance(case, dict) or not isinstance(case.get("args"), list):
        raise ValueError("native sustained check requires a native case with args")
    frozen_rows = qualified_result.get("frozen_predictions")
    if not frozen_rows:
        raise ValueError("qualified native result has no frozen prediction")
    frozen = frozen_rows[-1]
    if not isinstance(frozen, dict) or not frozen.get("sha256"):
        raise ValueError("native frozen prediction is malformed")
    from triad_perf_native import digest, identity, run_native
    if frozen.get("case_sha256") != digest(case):
        raise ValueError("native frozen prediction case identity mismatch")
    if frozen["sha256"] != digest({key: value for key, value in frozen.items() if key != "sha256"}):
        raise ValueError("native frozen prediction checksum mismatch")
    current_identity = identity(binary, case, threads)
    qualified_identity = qualified_result.get("identities", {}).get("candidate")
    if qualified_identity != current_identity:
        raise ValueError("native qualified prediction source/environment identity mismatch")
    prediction = frozen.get("predictions", {}).get("candidate")
    if not isinstance(prediction, dict):
        raise ValueError("native frozen candidate prediction is missing")
    stages = prediction.get("stage_seconds", {})
    original_trials = case.get("batch_trials", 1)
    if isinstance(original_trials, bool) or not isinstance(original_trials, int) or original_trials < 1:
        raise ValueError("native original batch_trials must be a positive integer")
    pipeline_total = math.fsum(_positive(stages.get(name), f"native {name} prediction")
                               for name in ("receiver", "generation_setup_other"))
    per_trial_pipeline = pipeline_total / original_trials
    trials = max(1, math.ceil(minimum_seconds / per_trial_pipeline))
    if trials > MAX_NATIVE_TRIALS:
        raise ValueError(f"native sustained check requires {trials} trials, above cap {MAX_NATIVE_TRIALS}")
    # Startup/output is a single process cost. Reserve it once, while every
    # repeated trial contributes only pipeline work.
    startup = _positive(stages.get("process_startup_output"), "native startup prediction")
    expected_pipeline = per_trial_pipeline * trials
    expected_external = expected_pipeline + startup
    required_budget = _check_budget(expected_external, deadline)

    campaign_case = copy.deepcopy(case)
    campaign_case["batch_trials"] = trials
    seed = secrets.randbelow(2**31 - 1) + 1
    commitment = {"schema": SCHEMA, "kind": "native", "case_sha256": digest(case),
                 "campaign_case_sha256": digest(campaign_case), "frozen_prediction_sha256": frozen["sha256"],
                 "binary_identity": current_identity, "threads": threads,
                 "target_seconds": case.get("target_seconds"), "minimum_pipeline_seconds": minimum_seconds,
                 "original_batch_trials": original_trials, "sustained_batch_trials": trials,
                 "predicted_per_trial_pipeline_seconds": per_trial_pipeline,
                 "predicted_pipeline_seconds": expected_pipeline,
                 "predicted_process_startup_output_seconds": startup,
                 "predicted_external_seconds": expected_external,
                 "budget_required_with_safety_factor_seconds": required_budget,
                 "seed": seed, "frozen_before_run": True,
                 "source_qualification_scope": qualification_scope,
                 "interpretation": "single compositional consistency check; not a new qualification or independent confidence interval"}
    commitment["commitment_sha256"] = _digest(commitment)
    if freeze_callback:
        freeze_callback(commitment)

    observed = run_native(binary, campaign_case, case["target_seconds"], seed,
                          threads=threads, trace=False, deadline=deadline,
                          timeout=required_budget)
    actual_stages = observed["stage_seconds"]
    actual_pipeline = observed["native_pipeline_seconds"]
    receiver = actual_stages["receiver"]
    other = actual_stages["generation_setup_other"]
    external = observed["full_test_wall_seconds"]
    trial_rows = observed["native_results"]
    base, extra = divmod(trials, 4)
    quarter_sizes = [base + (1 if i < extra else 0) for i in range(4)]
    quarters, start = [], 0
    for size in quarter_sizes:
        quarters.append(trial_rows[start:start + size])
        start += size
    quarter_counts = [len(part) for part in quarters]
    quarter_means = [math.fsum(row["end_to_end_wall_seconds"] for row in part) / len(part)
                     if part else None for part in quarters]
    result = {"schema": SCHEMA, "kind": "native", "commitment": commitment,
              "observed_batch_trials": observed["batch_trials"],
              "observed_pipeline_seconds": actual_pipeline,
              "observed_receiver_seconds": receiver,
              "observed_generation_setup_other_seconds": other,
              "observed_process_startup_output_seconds": actual_stages["process_startup_output"],
              "observed_external_wall_seconds": external,
              "observed_pipeline_span_seconds": actual_pipeline,
              "minimum_seconds": minimum_seconds,
              "sustained_threshold_reached": actual_pipeline >= minimum_seconds,
              "predicted_vs_actual": {"pipeline_seconds": {"predicted": expected_pipeline, "actual": actual_pipeline},
                                      "receiver_seconds": {"predicted": stages["receiver"] / original_trials * trials,
                                                           "actual": receiver},
                                      "generation_setup_other_seconds": {
                                          "predicted": stages["generation_setup_other"] / original_trials * trials,
                                          "actual": other},
                                      "process_startup_output_seconds": {"predicted": startup,
                                                                          "actual": actual_stages["process_startup_output"]},
                                      "external_wall_seconds": {"predicted": expected_external, "actual": external}},
              "quarter_trial_counts": quarter_counts,
              "quarter_mean_pipeline_seconds_per_trial": quarter_means,
              "first_to_last_quarter_mean_ratio": (quarter_means[-1] / quarter_means[0]
                                                    if quarter_means[0] and quarter_means[-1] else None),
              "coverage": observed["coverage"], "counter_summary": observed["counter_summary"],
              "native_results": observed["native_results"],
              "qualification_claim": False,
              "interpretation": "the single observed span may be shorter than requested; no automatic rerun"}
    return result


def fft_sustained(case, worker, qualified_result, api, minimum_seconds=MINIMUM_SECONDS,
                  deadline=None, freeze_callback=None):
    """Repeat full resident FFT preparation and full-CFO scoring once planned."""
    _require_qualified(qualified_result)
    minimum_seconds = _positive(minimum_seconds, "minimum_seconds")
    if not isinstance(case, dict) or not case.get("frequency_offsets_hz"):
        raise ValueError("FFT sustained check requires its complete frequency bank")
    anchors = qualified_result.get("anchors", {})
    frozen = anchors.get("frozen_prediction")
    if anchors.get("status") != "validated" or not isinstance(frozen, dict):
        raise ValueError("qualified FFT result has no validated frozen prediction")
    candidate_prediction = qualified_result.get("prediction", {}).get("candidate", {})
    predicted_time = candidate_prediction.get("predicted_full_time", {})
    point_seconds = _positive(predicted_time.get("point_seconds") if isinstance(predicted_time, dict)
                               else predicted_time, "FFT full-point prediction")
    repetitions = max(1, math.ceil(minimum_seconds / point_seconds))
    expected_total = point_seconds * repetitions
    required_budget = _check_budget(expected_total, deadline)
    identity = anchors.get("identity", {})
    if identity.get("case") != case.get("id"):
        raise ValueError("FFT qualified prediction case identity mismatch")
    full_count = len(case["frequency_offsets_hz"])
    if identity.get("geometry") is None or identity.get("frequency_offsets_hz") != case["frequency_offsets_hz"]:
        raise ValueError("FFT qualified prediction bank identity mismatch")
    worker_identity = getattr(worker, "identity", {})
    expected_worker_identity = identity.get("worker_implementations", {}).get("candidate")
    if expected_worker_identity is not None and any(worker_identity.get(key) != value
                                                   for key, value in expected_worker_identity.items()):
        raise ValueError("FFT qualified prediction worker identity mismatch")
    precision = qualified_result.get("precision")
    device = identity.get("device")
    if not precision or not device:
        raise ValueError("FFT qualified prediction precision/device is missing")
    commitment = {"schema": SCHEMA, "kind": "fft", "case_id": case["id"],
                 "case_sha256": _digest({k: v for k, v in case.items() if k != "input_directory"}),
                 "fixture_hashes": qualified_result.get("fixture_hashes", case.get("fixture_hashes", {})),
                 "source_bound_metadata": qualified_result.get("source_bound_metadata", {}),
                 "qualified_source_identity": identity,
                 "frozen_prediction_sha256": _digest(frozen), "full_geometry": identity["geometry"],
                 "full_cfo_count": full_count, "precision": precision, "device": device,
                 "repetitions": repetitions, "minimum_seconds": minimum_seconds,
                 "predicted_full_point_seconds": point_seconds,
                 "predicted_work_seconds": expected_total,
                 "budget_required_with_safety_factor_seconds": required_budget,
                 "timing_boundary": "resident full FFT preparation plus full-CFO scoring; excludes interpreter and fixture generation",
                 "frozen_before_run": True,
                 "interpretation": "compositional consistency check; not a new qualification or independent confidence interval"}
    commitment["commitment_sha256"] = _digest(commitment)
    if freeze_callback:
        freeze_callback(commitment)

    prep_request = api.prepare_request(case, precision, device)
    score_request = api.score_request(case, full_count)
    expected_groups = full_count * case["configuration"]["lag_group_count"]
    repetitions_observed = []
    external_started = time.perf_counter()
    for index in range(repetitions):
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError("FFT sustained check deadline exhausted during its frozen single campaign")
        prepared = worker.request(prep_request)
        scored = worker.request(score_request)
        prep_seconds = _positive(prepared.get("wall_seconds"), "FFT preparation timing")
        score_seconds = _positive(scored.get("wall_seconds_including_finish"), "FFT score timing")
        if scored.get("measured_group_count") != expected_groups:
            raise ValueError("FFT sustained scoring did not execute the complete declared CFO/lag bank")
        geometry = {key: prepared.get("geometry", {}).get(key) for key in identity["geometry"]}
        if geometry != identity["geometry"]:
            raise ValueError("FFT sustained preparation geometry differs from its qualified anchor")
        repetitions_observed.append({"index": index, "preparation_seconds": prep_seconds,
                                     "score_including_finish_seconds": score_seconds,
                                     "full_point_seconds": prep_seconds + score_seconds,
                                     "measured_group_count": scored["measured_group_count"],
                                     "arithmetic": scored.get("arithmetic"), "resources": scored.get("resources")})
    total = math.fsum(row["full_point_seconds"] for row in repetitions_observed)
    external_elapsed = time.perf_counter() - external_started
    return {"schema": SCHEMA, "kind": "fft", "commitment": commitment,
            "full_cfo_count": full_count, "expected_group_count_per_repetition": expected_groups,
            "repetitions": repetitions_observed,
            "observed_receiver_seconds": total,
            "observed_external_elapsed_seconds": external_elapsed,
            "minimum_seconds": minimum_seconds,
            "sustained_threshold_reached": total >= minimum_seconds,
            "source_identity": identity, "fixture_hashes": commitment["fixture_hashes"],
            "numeric_comparison": {"available": False,
                                   "reason": "the qualified FFT report retains aggregate numerical-check metadata, not reusable per-bank score vectors"},
            "qualification_claim": False,
            "interpretation": "the single observed span may be shorter than requested; no automatic rerun"}

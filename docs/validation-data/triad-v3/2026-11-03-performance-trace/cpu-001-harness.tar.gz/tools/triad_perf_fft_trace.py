#!/usr/bin/env python3
"""Traceable adaptive timing of the complete, resident FFT acquisition bank.

Only the CFO count is abbreviated. Full sampled arrays, timing lattices,
template preparation and final score construction remain in every call. A
source/host-bound full-bank anchor and a current larger-bank check are required
before a saved duration model can support a regression decision.
"""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import statistics
import time

from triad_perf_adaptive import qualify_log_residuals, summarize


SCHEMA = "triad-performance-fft-trace-v2"
MODEL_ERROR_LIMIT = .05
QUALIFICATION_COUNTS = (3, 5, 9, 17)
MINIMUM_BLOCK_SECONDS = .10
MAXIMUM_BLOCK_INVOCATIONS = 16
GEOMETRY = ("sample_count", "sample_rate", "nfft", "lags", "lag_first_sample",
            "lag_last_sample", "lag_step_samples", "group_tile", "precision", "device")


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def _save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".writing")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _remaining(deadline):
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError("FFT performance measurement deadline exhausted")


def _positive(value, name):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value <= 0:
        raise ValueError(name + " must be finite positive seconds")
    return float(value)


def measurement_plan(target, minimum_repeats=5):
    """Freeze the bank sizes using work counts, never observed timing values."""
    if isinstance(target, bool) or not isinstance(target, int) or target < 1:
        raise ValueError("target CFO count must be a positive integer")
    large = max(2, math.ceil(target / 8))
    hold = max(large + 1, math.ceil(target / 4))
    routine_work = minimum_repeats * (1 + large) + 3 * hold
    direct_work = minimum_repeats * target
    direct = target <= 3 or hold >= target or routine_work >= .8 * direct_work
    return {"direct": direct, "training_counts": [] if direct else [1, large],
            "intermediate_count": None if direct else hold, "target_count": target,
            "maximum_extrapolation": 8., "minimum_repeats": minimum_repeats,
            "routine_cfo_work": direct_work if direct else routine_work,
            "direct_cfo_work": direct_work,
            "qualification_full_holdouts": 0 if direct else 3,
            "qualification_overhead_amortized_separately": True}


def _fit(prepare, counts, timings, target):
    """Two-point, nonnegative fixed-plus-CFO fit with explicit boundary fits."""
    if len(counts) != 2 or counts[0] >= counts[1] or target < counts[1]:
        raise ValueError("invalid FFT training geometry")
    prep = _positive(prepare, "preparation")
    y = [_positive(t, "score") for t in timings]
    slope = (y[1] - y[0]) / (counts[1] - counts[0])
    fixed = y[0] - slope * counts[0]
    options = [(sum(y) / 2., 0.),
               (0., sum(c*t for c, t in zip(counts, y)) / sum(c*c for c in counts))]
    if fixed >= 0 and slope >= 0:
        options.append((fixed, slope))
    fixed, slope = min(options, key=lambda p: sum((p[0] + p[1]*c-t)**2 for c, t in zip(counts, y)))
    full = prep + fixed + slope * target
    return {"preparation_seconds": prep, "fixed_score_seconds": fixed,
            "per_cfo_seconds": slope, "predicted_full_seconds": full}


def _mean_model(models, target):
    """Freeze the same geometric-mean estimand used by timing inference."""
    pooled = {k: statistics.fmean(m[k] for m in models) for k in models[0]}
    point = math.exp(statistics.fmean(math.log(_prediction(m, target)) for m in models))
    scale = point / _prediction(pooled, target)
    return {**{k: pooled[k] * scale for k in ("preparation_seconds", "fixed_score_seconds", "per_cfo_seconds")},
            "predicted_full_seconds": point}


def _prediction(model, count):
    return model["preparation_seconds"] + model["fixed_score_seconds"] + model["per_cfo_seconds"] * count


def _qualification(rows):
    errors = {n: [row["log_errors"][n] for row in rows] for n in ("reference", "candidate")}
    errors["paired"] = [row["paired_log_error"] for row in rows]
    intervals = {n: qualify_log_residuals(values, maximum_relative_error=MODEL_ERROR_LIMIT)
                 for n, values in errors.items()}
    statuses = {value["status"] for value in intervals.values()}
    status = "invalid" if "invalid" in statuses else "validated" if statuses == {"validated"} else "inconclusive"
    return {"status": status, "log_errors": errors, "intervals": intervals,
            "scope": "one predeclared confirmation look per case; both source means and the paired ratio must establish equivalence; no suite-wide equivalence coverage claim"}


def _confirmation_plan(models, count, available_seconds):
    """Choose one holdout count from training data, never from holdout results."""
    from scipy.stats import t
    logs = {n: [math.log(_prediction(m, count)) for m in models[n]] for n in models}
    spread = max(statistics.stdev(logs["reference"]), statistics.stdev(logs["candidate"]),
                 statistics.stdev(c-r for r, c in zip(logs["reference"], logs["candidate"], strict=True)))
    widths = {n: math.expm1(float(t.ppf(.95, n-1))*spread/math.sqrt(n)) for n in QUALIFICATION_COUNTS}
    desired = next((n for n in QUALIFICATION_COUNTS if widths[n] <= .75*MODEL_ERROR_LIMIT), QUALIFICATION_COUNTS[-1])
    pair_seconds = sum(math.exp(statistics.fmean(values)) for values in logs.values())
    feasible = [n for n in QUALIFICATION_COUNTS if n <= desired and
                (available_seconds is None or 1.25*n*pair_seconds < available_seconds)]
    return {"repeats_per_source": max(feasible, default=0), "desired_repeats_per_source": desired,
            "estimated_seconds_per_pair": pair_seconds, "training_log_sd": spread,
            "projected_relative_half_widths": {str(n): value for n, value in widths.items()},
            "nominal_relative_half_width_target": .75*MODEL_ERROR_LIMIT,
            "scope": "training-only cost plan for one fixed confirmation look; observed holdout variance determines its actual interval"}


def _identity(case, workers, precision, device, geometry):
    identities = {}
    for name, worker in workers.items():
        value = getattr(worker, "identity", {})
        identities[name] = {k: value.get(k) for k in ("source_hashes", "python", "numpy", "torch", "threads", "tf32_allowed")}
    return {"schema": SCHEMA, "protocol_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "case": case["id"], "input_sha256": case.get("fixture_hashes", {}),
            "frequency_offsets_hz": case["frequency_offsets_hz"], "geometry": geometry,
            "worker_implementations": identities, "precision": precision, "device": device,
            "performance_environment": case.get("performance_environment"),
            "model_error_limit": MODEL_ERROR_LIMIT}


def _find_anchor(directory, identity):
    if directory is None or not identity.get("performance_environment"):
        return None, "no supplied stable hardware/runtime identity or anchor directory"
    root = Path(directory)
    identity_hash = _digest(identity)
    # Data, not filenames, authorize reuse. Malformed/incomplete records never
    # become an applicable anchor merely because their names match a case.
    for path in sorted(root.glob("*.anchor.json"), reverse=True):
        try:
            value = json.loads(path.read_text())
            if value.get("identity_sha256") != identity_hash or value.get("identity") != identity:
                continue
            if value.get("schema") != SCHEMA or value.get("status") != "validated":
                continue
            held = value["full_validation"]
            frozen = value["frozen_prediction"]
            count = frozen["predeclared_validation_repeats"]
            if count not in QUALIFICATION_COUNTS or len(held) != count:
                continue
            if {row["repeat"] for row in held} != set(range(count)):
                continue
            if any(row["count"] != len(identity["frequency_offsets_hz"]) or
                   row["frozen_prediction_sha256"] != _digest(frozen) for row in held):
                continue
            if value["qualification"] != _qualification(held) or value["qualification"]["status"] != "validated":
                continue
            if value.get("payload_sha256") != _digest({k: v for k, v in value.items() if k != "payload_sha256"}):
                continue
            return {"path": str(path), "record": value}, None
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return None, "no exact implementation, geometry, fixture and environment match"


def measure_fft(case, workers, precision, device, *, policy, deadline, api,
                anchor_directory=None, validation_mode="qualify"):
    """Adaptively time, freeze, then independently validate one full-bank model.

    ``auto`` reuses an exact anchor or qualifies the complete bank. ``reuse``
    requires a saved anchor and checks a larger intermediate bank. A training
    pilot selects inner batching only; all inner calls form one outer sample.
    Holdout count and predictions freeze before any holdout execution. Model
    qualification tests mean log bias, separately from individual-run variation.
    """
    if validation_mode not in ("auto", "reuse", "qualify"):
        raise ValueError("validation_mode must be auto, reuse or qualify")
    if set(workers) != {"reference", "candidate"}:
        raise ValueError("exactly reference and candidate receiver workers are required")
    target = len(case["frequency_offsets_hz"])
    plan = measurement_plan(target, policy.looks[0])
    direct = plan["direct"]
    raw = {n: {"preparation": [], "scores": [], "models": [], "direct": [], "blocks": []} for n in workers}
    checks, looks, validations = [], [], []
    expected_geometry = None
    frozen, anchor, qualification = None, None, None
    anchor_reason, anchor_path, freeze_path = None, None, None
    model_state = "direct_full" if direct else "unvalidated"
    error_rows = {n: [] for n in workers}
    paired_errors = []
    full_score_calls = {n: 0 for n in workers}
    started = time.perf_counter()
    effective_policy = replace(policy, model_allowance_log=0. if direct else max(
        policy.model_allowance_log, -math.log1p(-MODEL_ERROR_LIMIT)))

    def prepare(name):
        nonlocal expected_geometry
        _remaining(deadline)
        result = workers[name].request(api.prepare_request(case, precision, device))
        _positive(result.get("wall_seconds"), "preparation")
        geometry = {k: result["geometry"][k] for k in GEOMETRY}
        if expected_geometry is None:
            expected_geometry = geometry
        if geometry != expected_geometry:
            raise api.SuiteError(case["id"] + ": FFT geometry changed across sources or measurements")
        return result

    def score(name, count):
        _remaining(deadline)
        result = workers[name].request(api.score_request(case, count))
        _positive(result.get("wall_seconds_including_finish"), "wrapped score")
        if result.get("measured_group_count") != count * case["configuration"]["lag_group_count"]:
            raise api.SuiteError(case["id"] + ": measured CFO/lag count differs from declared work")
        if count == target:
            full_score_calls[name] += 1
        return result

    def check_outputs(outputs, count, purpose, repeat):
        ref, cand = outputs["reference"], outputs["candidate"]
        agreement = api.numeric_agreement(ref, cand)
        if not agreement["eligible"] or ref.get("geometry") != cand.get("geometry"):
            raise api.SuiteError(case["id"] + ": measured-bank score, rank, gate or geometry mismatch")
        checks.append({"purpose": purpose, "repeat": repeat, "cfo_count": count, "agreement": agreement})

    def measure_pair(counts, purpose, index):
        result = {}
        for name in (("reference", "candidate") if index % 2 == 0 else ("candidate", "reference")):
            prepared = prepare(name)
            scores = {count: score(name, count) for count in counts}
            result[name] = {"prepare": prepared, "scores": scores}
        for count in counts:
            check_outputs({n: result[n]["scores"][count] for n in workers}, count, purpose, index)
        return result

    counts = [target] if direct else plan["training_counts"]
    pilot_raw = measure_pair(counts, "discarded_batch_pilot", 0)
    pilot_seconds = {n: pilot_raw[n]["prepare"]["wall_seconds"] + sum(
        s["wall_seconds_including_finish"] for s in pilot_raw[n]["scores"].values()) for n in workers}
    requested = max(1, math.ceil(MINIMUM_BLOCK_SECONDS/min(pilot_seconds.values())))
    work_cap = MAXIMUM_BLOCK_INVOCATIONS if direct else max(1, math.floor(.8*target/sum(counts)))
    block_invocations = min(requested, work_cap, MAXIMUM_BLOCK_INVOCATIONS)
    pilot = {"inference_eligible": False, "seconds_per_source": pilot_seconds,
             "minimum_training_block_seconds_target": MINIMUM_BLOCK_SECONDS,
             "requested_block_invocations": requested, "work_cap_invocations": work_cap,
             "selected_block_invocations": block_invocations,
             "raw": {n: {"preparation_seconds": pilot_raw[n]["prepare"]["wall_seconds"],
                          "score_seconds": {str(c): s["wall_seconds_including_finish"] for c, s in pilot_raw[n]["scores"].items()}}
                     for n in workers}}
    identity = _identity(case, workers, precision, device, expected_geometry)
    if not direct and validation_mode in ("reuse", "auto"):
        anchor, anchor_reason = _find_anchor(anchor_directory, identity)
    validation_count = None if direct or (validation_mode == "reuse" and anchor is None) else (
        plan["intermediate_count"] if anchor is not None else target)
    confirmation_plan = None
    sampling_started = time.monotonic()
    sampling_stop = None

    for look in policy.looks:
        for repeat in range(len(raw["reference"]["preparation"]), look):
            pairs = [measure_pair(counts, "timing", repeat*block_invocations+j) for j in range(block_invocations)]
            for name in workers:
                invocations = [pair[name] for pair in pairs]
                preparation = statistics.fmean(v["prepare"]["wall_seconds"] for v in invocations)
                times = [statistics.fmean(v["scores"][c]["wall_seconds_including_finish"] for v in invocations)
                         for c in counts]
                raw[name]["preparation"].append({"seconds": preparation,
                                                "geometry": invocations[0]["prepare"]["geometry"],
                                                "stages": invocations[0]["prepare"].get("stages", {})})
                for c, seconds in zip(counts, times):
                    first = invocations[0]["scores"][c]
                    raw[name]["scores"].append({"repeat": repeat, "count": c, "seconds": seconds,
                                                "receiver_stages": first.get("timing", {}),
                                                "arithmetic": first.get("arithmetic", {}),
                                                "resources": first.get("resources", {})})
                raw[name]["blocks"].append({"outer_repeat": repeat, "invocation_count": len(invocations),
                                            "preparation_seconds": [v["prepare"]["wall_seconds"] for v in invocations],
                                            "score_seconds_by_count": {str(c): [v["scores"][c]["wall_seconds_including_finish"] for v in invocations]
                                                                       for c in counts}})
                if direct:
                    raw[name]["direct"].append(preparation + times[0])
                else:
                    raw[name]["models"].append(_fit(preparation, counts, times, target))
        values = {n: raw[n]["direct"] if direct else [m["predicted_full_seconds"] for m in raw[n]["models"]] for n in workers}
        summary = summarize(values["reference"], values["candidate"], effective_policy,
                            model_validation="direct_full" if direct else "unvalidated")
        looks.append(summary)
        sampling_stop = summary["stop_reason"]
        if validation_count is not None:
            confirmation_plan = _confirmation_plan({n: raw[n]["models"] for n in workers}, validation_count,
                None if deadline is None else deadline-time.monotonic())
        if sampling_stop != "continue":
            break
        if not direct and validation_count is None:
            sampling_stop = "historical_anchor_unavailable"
            break
        if (not direct and summary["paired_candidate_over_reference"]["model_adjusted_gate_interval"][0]
                > policy.slowdown_threshold):
            sampling_stop = "freeze_for_potential_regression_validation"
            break
        reserve = (confirmation_plan["repeats_per_source"]*confirmation_plan["estimated_seconds_per_pair"]
                   if confirmation_plan is not None else 0.)
        next_cost = ((summary["next_look"]-look)*(time.monotonic()-sampling_started)/look + reserve)
        if deadline is not None and time.monotonic()+1.25*next_cost >= deadline:
            sampling_stop = "budget_limit"
            break

    if not direct:
        repeats = 0 if confirmation_plan is None else confirmation_plan["repeats_per_source"]
        frozen = {"schema": SCHEMA, "identity_sha256": _digest(identity),
                  "training_outer_count": len(values["reference"]), "target_count": target,
                  "models": {n: _mean_model(raw[n]["models"], target) for n in workers},
                  "validation_models": {n: _mean_model(raw[n]["models"], validation_count) for n in workers} if validation_count else None,
                  "validation_count": validation_count, "predeclared_validation_repeats": repeats,
                  "confirmation_plan": confirmation_plan, "model_error_limit": MODEL_ERROR_LIMIT,
                  "prediction_frozen_before_validation": True}
        if anchor_directory is not None:
            token = str(time.time_ns()) + "-" + _digest(identity)[:16]
            freeze_path = Path(anchor_directory) / (token + ".prediction.json")
            _save(freeze_path, frozen)
        for r in range(repeats):
            pair = measure_pair([validation_count], "current_intermediate" if anchor else "independent_full", r)
            observed = {n: {"preparation_seconds": pair[n]["prepare"]["wall_seconds"],
                            "score_including_finish_seconds": pair[n]["scores"][validation_count]["wall_seconds_including_finish"],
                            "full_seconds": pair[n]["prepare"]["wall_seconds"] + pair[n]["scores"][validation_count]["wall_seconds_including_finish"]}
                        for n in workers}
            predicted = {n: _prediction(frozen["validation_models"][n], validation_count) for n in workers}
            errors = {n: math.log(observed[n]["full_seconds"] / predicted[n]) for n in workers}
            relative = {n: abs(observed[n]["full_seconds"]-predicted[n])/predicted[n] for n in workers}
            paired_error = errors["candidate"]-errors["reference"]
            validations.append({"purpose": "current_intermediate" if anchor else "independent_full", "repeat": r,
                                "count": validation_count, "frozen_prediction_sha256": _digest(frozen),
                                "predicted_seconds": predicted, "observed": observed, "log_errors": errors,
                                "relative_errors": relative, "paired_log_error": paired_error,
                                "paired_relative_error": abs(math.expm1(paired_error)),
                                "single_run_within_bound": max(*relative.values(), abs(math.expm1(paired_error))) <= MODEL_ERROR_LIMIT,
                                "error_limit": MODEL_ERROR_LIMIT})
        if validations:
            qualification = _qualification(validations)
            model_state = qualification["status"] if qualification["status"] != "inconclusive" else "unvalidated"
        evidence = (anchor["record"]["full_validation"] if anchor else []) + validations
        error_rows = {n: [row["log_errors"][n] for row in evidence] for n in workers}
        paired_errors = [row["paired_log_error"] for row in evidence]
        if anchor:
            anchor_path = anchor["path"]
        elif validation_count == target and validations:
            record = {"schema": SCHEMA, "status": model_state, "identity": identity,
                      "identity_sha256": _digest(identity), "frozen_prediction": frozen,
                      "full_validation": validations, "qualification": qualification,
                      "timing_boundary": "full preparation plus wrapped scoring on resident fixture",
                      "model_validation_is_conditional_mean_equivalence": True,
                      "individual_prediction_coverage_claim": False}
            record["payload_sha256"] = _digest(record)
            if freeze_path is not None:
                anchor_path = str(freeze_path.with_name(freeze_path.name.replace(".prediction.json", ".anchor.json")))
                _save(anchor_path, record)
            anchor = {"record": record, "path": anchor_path}
        summary = summarize(values["reference"], values["candidate"], effective_policy,
                            model_validation=model_state,
                            reference_model_log_errors=error_rows["reference"],
                            candidate_model_log_errors=error_rows["candidate"],
                            paired_model_log_errors=paired_errors)
        if summary["performance_gate"] != "performance_regression":
            summary["stop_reason"] = sampling_stop
        looks[-1] = summary

    valid = model_state in ("direct_full", "validated")
    comparison = {"gate": summary["performance_gate"] if valid else "inconclusive",
                  "performance_pass_eligible": summary["gate_performance_pass_eligible"],
                  "expanded_full_prediction_ratio_interval": summary["paired_candidate_over_reference"]["model_adjusted_gate_interval"],
                  "observed_prediction_ratio": summary["paired_candidate_over_reference"]["point_seconds"],
                  "mean_reference_full_seconds": statistics.fmean(values["reference"]),
                  "mean_candidate_full_seconds": statistics.fmean(values["candidate"])}
    comparison["absolute_mean_full_seconds_difference"] = comparison["mean_candidate_full_seconds"] - comparison["mean_reference_full_seconds"]
    warnings = []
    if not valid:
        warnings.append("full-bank mean-equivalence model invalid or unqualified; no supported performance pass")
    if not summary["timing_precision_reached"]:
        warnings.append("requested full-runtime timing precision remains unresolved")
    if comparison["gate"] == "inconclusive":
        warnings.append("full-runtime regression decision remains inconclusive")
    return {"schema": SCHEMA, "id": case["id"], "adapter": "fft",
            "scope": "full resident FFT acquisition; excludes fixture generation and interpreter startup",
            "configuration": case["configuration"], "precision": precision, "raw": raw,
            "measurement_plan": {**plan, "timing_block_invocations": block_invocations, "discarded_pilot": pilot,
                                 "confirmation_plan": confirmation_plan}, "full_cfo_count": target,
            "full_target_measured": full_score_calls["reference"] > 0,
            "full_target_measurement_count_per_source": full_score_calls["reference"],
            "prediction": {n: {"predicted_full_seconds_by_repeat": values[n],
                                "predicted_full_time": summary[n], "status": model_state} for n in workers},
            "prediction_valid": valid, "comparison": comparison,
            "adaptive": summary, "looks": looks, "timing_precision_reached": summary["timing_precision_reached"],
            "anchors": {"validation_mode": validation_mode, "status": model_state,
                        "identity": identity, "path": anchor_path, "lookup_reason": anchor_reason,
                        "prediction_commitment_path": str(freeze_path) if freeze_path else None,
                        "frozen_prediction": frozen, "current_validation": validations,
                        "qualification": qualification,
                        "historical_full_validation": anchor["record"]["full_validation"] if anchor else []},
            "coverage": {"full_sample_timing_geometry": expected_geometry,
                         "measured_bank_numerical_checks": len(checks), "all_measured_counts_verified": True},
            "measured_bank_numerical_checks": checks, "warnings": warnings,
            "fixture_hashes": case.get("fixture_hashes", {}),
            "source_bound_metadata": case.get("source_bound_metadata", {}),
            "elapsed_seconds": time.perf_counter() - started,
            "reduced_bank_admissions_valid": False,
            "prediction_interval_target": "future outer timing-block mean per original call; not an individual cold invocation",
            "independence_scope": "paired outer timing blocks in persistent interpreters; inner calls are averaged, not independent samples; cold-process variance is outside this target"}

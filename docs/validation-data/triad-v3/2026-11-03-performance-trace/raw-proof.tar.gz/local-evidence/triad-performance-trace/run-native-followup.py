#!/usr/bin/env python3
"""One source-bound native performance follow-up; no automatic requalification.

The caller supplies its outer process-group timeout and optional CPU affinity.
This driver uses the maintained native, adaptive and sustained APIs unchanged.
Each output path is reserved exclusively; commitments are persisted before holds
or sustained work. A partial report remains if the outer watchdog interrupts it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = "triad-native-performance-followup-v1"
SOURCE_PATHS = ("tools/triad_perf_native.py", "tools/triad_perf_adaptive.py", "tools/triad_perf_conditional.py",
                "tools/triad_perf_sustained.py", "tools/triad_perf_hardware.py",
                "tools/triad-performance-native-cases.json")


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_bindings():
    return {**{path: file_sha(ROOT / path) for path in SOURCE_PATHS},
            "driver": file_sha(__file__)}


def write_json(path, value, *, exclusive=False):
    encoded = json.dumps(value, indent=2, allow_nan=False) + "\n"
    if exclusive:
        with path.open("x") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        return
    # Replace only this invocation's previously reserved report. Commitments
    # always use exclusive creation and are never rewritten.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", prefix=path.name + ".", suffix=".tmp",
                                         dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def load_anchor(path):
    """Accept a bare native anchor or an earlier output from this driver."""
    if path is None:
        return None
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError("anchor must be a JSON object")
    if value.get("schema") == SCHEMA:
        value = value.get("native_result", {}).get("anchors")
    if not isinstance(value, dict) or not value.get("anchor_sha256"):
        raise ValueError("input is neither a bare native anchor nor a driver result containing one")
    return value


def run(args, native, adaptive_policy, native_sustained, *, invocation=None,
        source_before=None, started=None):
    """Execute one configured case. API arguments also permit tiny mocked checks."""
    started = time.monotonic() if started is None else started
    deadline = started + args.budget_seconds
    source_before = source_bindings() if source_before is None else source_before
    prediction_prefix = args.output.stem + ".prediction-"
    sustained_commitment = args.output.with_name(args.output.stem + ".sustained-commitment.json")
    if args.output.exists() or sustained_commitment.exists() or any(args.output.parent.glob(prediction_prefix + "*.json")):
        raise FileExistsError("output or adjacent commitment already exists; choose a fresh output name")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    report = {"schema": SCHEMA, "status": "running", "exit_code": None,
        "scope": "one explicitly selected native performance case; not complete normal-CI coverage",
        "experiment": {"argv": invocation or [], "case_id": args.case_id, "mode": args.mode,
            "reference_binary": str(args.reference_binary), "candidate_binary": str(args.binary),
            "threads": args.threads, "budget_seconds": args.budget_seconds, "looks": list(args.looks),
            "family_count": args.family_count, "relative_precision_target": .05,
            "sustained_seconds": args.sustained_seconds,
            "anchor_input": None if args.anchor is None else str(args.anchor),
            "anchor_input_sha256": None if args.anchor is None else file_sha(args.anchor),
            "source_sha256": source_before, "source_root": str(ROOT), "python": sys.version,
            "started_unix_seconds": time.time(), "requalification_fallback": False,
            "deadline_scope": "cooperative API deadline and bounded native calls; caller must supply an outer process-group timeout"},
        "commitments": [], "warnings": [], "failures": []}
    write_json(args.output, report, exclusive=True)
    try:
        if source_before != source_bindings():
            raise RuntimeError("driver/helper sources changed during import or setup")
        matches = [case for case in native.scenarios("sustain") if case["id"] == args.case_id]
        if len(matches) != 1:
            raise ValueError("case-id must name exactly one maintained native sustain-profile case")
        case = matches[0]
        policy = adaptive_policy(relative_precision=.05, looks=args.looks, family_count=args.family_count)
        identities = {"reference": native.identity(args.reference_binary, case, args.threads),
                      "candidate": native.identity(args.binary, case, args.threads)}
        anchor = load_anchor(args.anchor)
        report["experiment"].update(case=case, case_sha256=native.digest(case), identities=identities,
                                    direct_measurement="training_seconds" not in case)
        if args.mode == "routine" and "training_seconds" in case:
            if not native.anchor_compatible(anchor, identities, case):
                raise ValueError("routine mode requires an exactly compatible validated anchor; no requalification fallback")
        write_json(args.output, report)

        def freeze_prediction(value):
            count = sum(item["kind"] == "prediction" for item in report["commitments"])
            path = args.output.with_name(prediction_prefix + f"{count:03d}.json")
            write_json(path, value, exclusive=True)
            report["commitments"].append({"kind": "prediction", "path": str(path),
                "sha256": file_sha(path), "persisted_before_independent_holds": True})
            write_json(args.output, report)

        result = native.measure_native_case(args.reference_binary, args.binary, case, policy,
            threads=args.threads, deadline=deadline, validation_mode=args.mode, anchor=anchor,
            trace_candidate=False, freeze_callback=freeze_prediction)
        report["native_result"] = result
        write_json(args.output, report)
        if source_before != source_bindings() or identities != {
                "reference": native.identity(args.reference_binary, case, args.threads),
                "candidate": native.identity(args.binary, case, args.threads)}:
            raise RuntimeError("source, binary or environment identity changed during native measurement")

        if args.sustained_seconds:
            def freeze_sustained(value):
                write_json(sustained_commitment, value, exclusive=True)
                report["commitments"].append({"kind": "sustained", "path": str(sustained_commitment),
                    "sha256": file_sha(sustained_commitment), "persisted_before_sustained_work": True})
                write_json(args.output, report)
            # The maintained helper verifies candidate qualification itself.
            # Rejection is retained as an error, never a silent skipped check.
            report["sustained_result"] = native_sustained(args.binary, case, result,
                minimum_seconds=args.sustained_seconds, threads=args.threads, deadline=deadline,
                freeze_callback=freeze_sustained)
            if report["sustained_result"].get("sustained_threshold_reached") is not True:
                report["warnings"].append("the one frozen sustained campaign did not reach its requested measured span; no rerun")

        if source_before != source_bindings() or identities != {
                "reference": native.identity(args.reference_binary, case, args.threads),
                "candidate": native.identity(args.binary, case, args.threads)}:
            raise RuntimeError("source, binary or environment identity changed during follow-up")
        gate = result.get("comparison", {}).get("gate")
        if not result.get("prediction_valid"):
            report["status"], report["exit_code"] = "unqualified", 2
            report["warnings"].append("requested full-runtime prediction is invalid or unqualified")
        elif gate == "performance_regression":
            report["status"], report["exit_code"] = "regression", 2
        else:
            if gate != "pass":
                report["warnings"].append("full-runtime regression comparison is inconclusive")
            if not result.get("prediction", {}).get("timing_precision_reached"):
                report["warnings"].append("requested 5% timing precision was not reached")
            report["status"] = "warning" if report["warnings"] else "passed"
            report["exit_code"] = 0
    except Exception as error:
        report["status"], report["exit_code"] = "failed", 2
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        report["elapsed_seconds"] = time.monotonic() - started
        report["completed_unix_seconds"] = time.time()
        write_json(args.output, report)
    return report


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", default="native-vlf-low-cn0")
    parser.add_argument("--reference-binary", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--looks", default="5,9,17,33,65")
    parser.add_argument("--family-count", type=int, default=14)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--budget-seconds", type=float, default=900.)
    parser.add_argument("--mode", choices=("qualify", "routine"), default="qualify")
    parser.add_argument("--anchor", type=Path)
    parser.add_argument("--sustained-seconds", type=float, default=0.)
    args = parser.parse_args(argv)
    try:
        args.looks = tuple(int(value) for value in args.looks.split(","))
        if not args.looks or any(n < 3 for n in args.looks) or tuple(sorted(set(args.looks))) != args.looks:
            raise ValueError
    except ValueError:
        parser.error("looks must be strictly increasing integers at least three")
    if args.family_count < 1 or args.threads < 1:
        parser.error("family-count and threads must be positive")
    if not math.isfinite(args.budget_seconds) or not 0 < args.budget_seconds <= 28800:
        parser.error("budget-seconds must be in (0,28800]")
    if not math.isfinite(args.sustained_seconds) or not 0 <= args.sustained_seconds <= 3600:
        parser.error("sustained-seconds must be in [0,3600]")
    for name in ("binary", "reference_binary", "output", "anchor"):
        value = getattr(args, name)
        if value is not None:
            setattr(args, name, value.resolve())
    for name in ("binary", "reference_binary"):
        value = getattr(args, name)
        if not value.is_file() or not os.access(value, os.X_OK):
            parser.error(name + " must be an existing executable file")
    if args.anchor is not None and not args.anchor.is_file():
        parser.error("anchor must be an existing JSON file")
    if args.mode == "qualify" and args.anchor is not None:
        parser.error("qualify mode does not consume an anchor; omit --anchor or choose routine")
    if args.output.exists():
        parser.error("output already exists; choose a fresh output name")
    return args


def main(argv=None):
    started = time.monotonic()
    args = parse_args(argv)
    source_before = source_bindings()
    sys.path.insert(0, str(ROOT / "tools"))
    import triad_perf_native as native
    from triad_perf_adaptive import AdaptivePolicy
    from triad_perf_sustained import native_sustained
    command = [sys.executable, str(Path(__file__).resolve()), *(sys.argv[1:] if argv is None else argv)]
    report = run(args, native, AdaptivePolicy, native_sustained, invocation=command,
                 source_before=source_before, started=started)
    print(json.dumps({"status": report["status"], "exit_code": report["exit_code"],
                      "elapsed_seconds": report["elapsed_seconds"], "output": str(args.output)}))
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())

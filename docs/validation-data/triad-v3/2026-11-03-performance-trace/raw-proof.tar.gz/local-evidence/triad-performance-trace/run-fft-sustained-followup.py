#!/usr/bin/env python3
"""One sustained FFT consistency observation from a completed frozen report.

No training, precision qualification, model update, fallback, or automatic retry
is performed. Use an outer process-group timeout and the original CPU affinity.
The forecast is inherited unchanged; this observation is not a fresh confidence
interval or complete physical-simulation throughput qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = "triad-fft-sustained-followup-v1"
ELIGIBLE_ANCHOR_STATUS = ("validated", "historically_supported_conditional")


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def source_bindings():
    paths = set(ROOT.glob("tools/triad*.py")) | set(ROOT.glob("tools/triad-performance*.json"))
    paths |= set(ROOT.glob("src/triad*.*")) | set(ROOT.glob("include/datapump/triad*.*"))
    paths |= {ROOT / name for name in ("src/channel_perturbation.hpp", "src/channel_spread.hpp",
                                     "src/tuning.cpp", "src/tuning_presets.cpp", "tools/triad-long.cpp",
                                     "include/datapump/pattern_pulse.hpp", "include/datapump/clock_sync.hpp")}
    return {**{str(path.relative_to(ROOT)): file_sha(path) for path in sorted(paths)},
            "driver": file_sha(__file__)}


def write_json(path, value, *, exclusive=False):
    encoded = json.dumps(value, indent=2, allow_nan=False) + "\n"
    if exclusive:
        with path.open("x") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        return
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", prefix=path.name + ".", suffix=".tmp",
                                         dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def select_forecast(report, case_id=None):
    if (report.get("schema") != "triad-performance-v2" or "backends" in report
            or report.get("device") != "cpu"
            or report.get("status") not in ("passed", "warning")
            or report.get("exit_code") != 0
            or report.get("complete_required_coverage") is not True):
        raise ValueError("input must be a completed, successful CPU backend report; no partial or main report")
    choices = []
    for index, row in enumerate(report.get("cases", [])):
        anchors = row.get("anchors", {})
        bank = anchors.get("identity", {}).get("frequency_offsets_hz")
        if (row.get("adapter") == "fft" and row.get("prediction_valid") is True
                and anchors.get("status") in ELIGIBLE_ANCHOR_STATUS
                and isinstance(anchors.get("frozen_prediction"), dict)
                and isinstance(bank, list) and bank):
            choices.append((len(bank), str(row.get("id")), index, row))
    if case_id is not None:
        choices = [item for item in choices if item[1] == case_id]
        if len(choices) != 1:
            raise ValueError("explicit case lacks exactly one eligible frozen FFT forecast; no fallback")
    if not choices:
        raise ValueError("report has no eligible frozen FFT forecast; no fallback")
    # Predeclared selection uses workload geometry only, never observed timing.
    choices.sort(key=lambda item: (-item[0], item[1], item[2]))
    count, selected, index, row = choices[0]
    return row, {"rule": "explicit case" if case_id else "largest full CFO bank, then lexical case id",
                 "eligible_count": len(choices), "case_id": selected, "report_case_index": index,
                 "full_cfo_count": count, "qualified_result_sha256": digest(row)}


def require_report_sources(report, current, binary_sha):
    candidate = report.get("candidate", {}).get("source_sha256")
    harness = report.get("harness_sha256")
    if not isinstance(candidate, dict) or not candidate or not isinstance(harness, dict) or not harness:
        raise ValueError("report lacks candidate/harness source provenance")
    for relative, expected in candidate.items():
        if current.get(relative) != expected:
            raise ValueError("candidate source mismatch: " + relative)
    for name, expected in harness.items():
        if current.get("tools/" + name) != expected:
            raise ValueError("harness source mismatch: " + name)
    if report.get("native_binary_sha256", {}).get("candidate") != binary_sha:
        raise ValueError("fixture binary differs from the completed report")


def run(args, api, cases_module, discover_hardware, fft_sustained, *, invocation,
        source_before, started):
    deadline = started + args.budget_seconds
    work = args.output.with_name(args.output.stem + ".work")
    commitment_path = args.output.with_name(args.output.stem + ".commitment.json")
    if any(path.exists() for path in (args.output, work, commitment_path)):
        raise FileExistsError("output, commitment, or work directory exists; use a fresh output")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    work.mkdir()
    record = {"schema": SCHEMA, "status": "running", "exit_code": None,
        "scope": "one independent sustained consistency observation; not a new CI, model qualification, or whole simulation timing",
        "experiment": {"argv": invocation, "started_unix_seconds": time.time(),
            "source_sha256": source_before, "candidate_root": str(ROOT),
            "fixture_binary": str(args.binary), "fixture_binary_sha256": file_sha(args.binary),
            "device": "cpu", "threads": args.threads, "budget_seconds": args.budget_seconds,
            "minimum_seconds": args.minimum_seconds,
            "fixture_cache_directory": str(args.output.parent / "triad-performance-fixtures"),
            "deadline_scope": "maintained worker deadline; caller supplies outer process-group timeout",
            "forecast_refitted": False, "precision_reselected": False, "automatic_retry": False},
        "warnings": [], "failures": []}
    write_json(args.output, record, exclusive=True)
    worker = None
    input_sha = None
    try:
        if source_before != source_bindings():
            raise RuntimeError("source changed during module import")
        raw = args.report.read_bytes()
        input_sha = hashlib.sha256(raw).hexdigest()
        previous = json.loads(raw)
        record["input"] = {"path": str(args.report), "sha256": input_sha, "bytes": len(raw)}
        del raw
        qualified, selection = select_forecast(previous, args.case_id)
        record["selection"] = selection
        record["original_forecast"] = {
            "anchor_status": qualified["anchors"]["status"],
            "precision": qualified.get("precision"),
            "frozen_prediction_sha256": digest(qualified["anchors"]["frozen_prediction"]),
            "candidate_full_time": qualified["prediction"]["candidate"]["predicted_full_time"],
            "source_identity": qualified["anchors"]["identity"],
            "prediction_valid": qualified["prediction_valid"]}
        require_report_sources(previous, source_before, record["experiment"]["fixture_binary_sha256"])
        fixture_started = time.monotonic()
        selected_cases = cases_module.prepare_cases(args.binary,
            args.output.parent / "triad-performance-fixtures", profile="ci", deadline=deadline,
            source_root=ROOT, case_ids=[selection["case_id"]])
        if len(selected_cases) != 1 or selected_cases[0]["id"] != selection["case_id"]:
            raise ValueError("fixture reconstruction did not return the selected case")
        case = selected_cases[0]
        case["performance_environment"] = discover_hardware("cpu", args.threads)
        record["case"] = case
        record["fixture_preparation_seconds"] = time.monotonic() - fixture_started
        record["environment_sha256"] = digest(case["performance_environment"])
        record["hardware_identity_scope"] = "current metadata only; no new stress calibration"
        worker = api.ReceiverWorker(ROOT, threads=args.threads, deadline=deadline,
                                   log_directory=work, name="candidate")
        record["worker_identity"] = worker.identity
        record["worker_identity_sha256"] = digest(worker.identity)
        record["worker_external_startup_seconds"] = worker.external_startup_seconds
        write_json(args.output, record)

        def freeze(value):
            # The maintained helper validates the original forecast and computes
            # its fixed repetition count before making this callback or timing.
            envelope = {"schema": SCHEMA, "input_report_sha256": input_sha,
                        "qualified_result_sha256": selection["qualified_result_sha256"],
                        "driver_sha256": source_before["driver"], "commitment": value}
            write_json(commitment_path, envelope, exclusive=True)
            record["frozen_commitment"] = {"path": str(commitment_path),
                                           "sha256": file_sha(commitment_path)}
            write_json(args.output, record)

        observation_started = time.perf_counter()
        record["observation_started_unix_seconds"] = time.time()
        try:
            record["sustained_result"] = fft_sustained(case, worker, qualified, api,
                minimum_seconds=args.minimum_seconds, deadline=deadline, freeze_callback=freeze)
        finally:
            record["independent_observation_elapsed_seconds"] = time.perf_counter() - observation_started
            record["observation_completed_unix_seconds"] = time.time()
        if digest(qualified) != selection["qualified_result_sha256"]:
            raise RuntimeError("the original qualified result was mutated")
        if not record["sustained_result"].get("sustained_threshold_reached"):
            record["warnings"].append("single predeclared observation ran shorter than requested; no automatic rerun")
        record["status"], record["exit_code"] = ("warning" if record["warnings"] else "completed"), 0
    except Exception as error:
        record["status"], record["exit_code"] = "failed", 2
        record["failures"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        try:
            if worker is not None:
                worker.close()
            record["worker_cleanup"] = "closed" if worker is not None else "not started"
        except Exception as error:
            record["failures"].append({"stage": "cleanup", "type": type(error).__name__, "message": str(error)})
            record["worker_cleanup"] = "incomplete; outer watchdog required"
        try:
            if source_before != source_bindings():
                raise RuntimeError("harness or timed source changed during the observation")
            if record["experiment"]["fixture_binary_sha256"] != file_sha(args.binary):
                raise RuntimeError("fixture binary changed during the observation")
            if input_sha is not None and input_sha != file_sha(args.report):
                raise RuntimeError("input report changed during the observation")
            record["provenance_guard"] = "unchanged"
        except Exception as error:
            record["failures"].append({"stage": "provenance", "type": type(error).__name__, "message": str(error)})
            record["provenance_guard"] = "failed"
        if record["failures"]:
            record["status"], record["exit_code"] = "failed", 2
        record["elapsed_seconds"] = time.monotonic() - started
        record["completed_unix_seconds"] = time.time()
        write_json(args.output, record)
    return record


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True, help="completed CPU backend JSON, not main duplicated report")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case-id", help="default: largest eligible full CFO bank, tie broken by case id")
    parser.add_argument("--binary", type=Path, default=ROOT / "build/dev-cli/triad_long")
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--budget-seconds", type=float, default=180.)
    parser.add_argument("--minimum-seconds", type=float, default=60.)
    args = parser.parse_args(argv)
    if args.threads < 1:
        parser.error("threads must be positive and must match the original performance environment")
    for name in ("budget_seconds", "minimum_seconds"):
        if not math.isfinite(getattr(args, name)) or not 0 < getattr(args, name) <= 28800:
            parser.error(name.replace("_", "-") + " must be in (0,28800]")
    args.report, args.output, args.binary = (path.resolve() for path in (args.report, args.output, args.binary))
    if not args.report.is_file() or not args.binary.is_file() or not os.access(args.binary, os.X_OK):
        parser.error("report must exist and binary must be executable")
    return args


def main(argv=None):
    started = time.monotonic()
    args = parse_args(argv)
    before = source_bindings()
    sys.path.insert(0, str(ROOT / "tools"))
    name = "triad_fft_sustained_followup_runner_api"
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools/triad-performance.py")
    api = importlib.util.module_from_spec(spec)
    sys.modules[name] = api
    spec.loader.exec_module(api)
    import triad_perf_cases as cases
    from triad_perf_hardware import discover_hardware
    from triad_perf_sustained import fft_sustained
    invocation = [sys.executable, str(Path(__file__).resolve()), *(sys.argv[1:] if argv is None else argv)]
    result = run(args, api, cases, discover_hardware, fft_sustained, invocation=invocation,
                 source_before=before, started=started)
    print(json.dumps({"status": result["status"], "exit_code": result["exit_code"],
                      "elapsed_seconds": result["elapsed_seconds"], "output": str(args.output)}))
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())

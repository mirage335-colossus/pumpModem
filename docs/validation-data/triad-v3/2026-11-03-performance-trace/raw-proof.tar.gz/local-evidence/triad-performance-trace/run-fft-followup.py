#!/usr/bin/env python3
"""Focused real FFT timing, with optional explicitly synthetic delay controls.

Use an outer process-group timeout and optional taskset. Reuse requires an exact
applicable real-kernel anchor. Injected runs can only reuse private copies of
existing anchors; they never create production qualification anchors. Delay is
added after a real score call, to both elapsed time and its returned timing field.
Scores, numerical decisions, arithmetic metadata and work counts are untouched.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = "triad-fft-performance-followup-v1"
BASELINE = "242ea15fa032ee117b9113a7f3cd07cc6e9f0254"


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_bindings():
    paths = set(ROOT.glob("tools/triad*.py")) | set(ROOT.glob("tools/triad-performance*.json"))
    paths |= set(ROOT.glob("src/triad*.*")) | set(ROOT.glob("include/datapump/triad*.*"))
    paths |= {ROOT / name for name in ("src/channel_perturbation.hpp", "src/channel_spread.hpp",
                                     "src/tuning.cpp", "src/tuning_presets.cpp", "tools/triad-long.cpp")}
    return {**{str(path.relative_to(ROOT)): file_sha(path) for path in sorted(paths)},
            "driver": file_sha(__file__)}


def write_json(path, value, *, exclusive=False):
    encoded = json.dumps(value, indent=2, allow_nan=False) + "\n"
    if exclusive:
        with path.open("x") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        return
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", prefix=path.name + ".", suffix=".tmp",
                                         dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


class DelayedScoreWorker:
    """A timed post-kernel delay experiment, never a substitute receiver."""
    def __init__(self, worker, *, target_count, selection, multiplier, delay_mode, deadline):
        self.worker = worker
        self.identity = worker.identity
        self.target_count = target_count
        self.selection = selection
        self.multiplier = multiplier
        self.delay_mode = delay_mode
        self.deadline = deadline
        self.events = []
        self.score_calls_seen = 0

    def request(self, request):
        started = time.perf_counter()
        result = self.worker.request(request)
        if request.get("action") != "score":
            return result
        self.score_calls_seen += 1
        count = len(request["frequency_offsets_hz"])
        applies = self.selection == "all-cfo" or (self.selection == "full-cfo" and count == self.target_count)
        if not applies:
            return result
        original = result.get("wall_seconds_including_finish")
        if isinstance(original, bool) or not isinstance(original, (int, float)) or not math.isfinite(original) or original <= 0:
            raise ValueError("real score call did not return positive finite wrapped timing")
        requested_delay = (self.multiplier - 1.) * original
        if time.monotonic() + requested_delay >= self.deadline:
            raise TimeoutError("synthetic score delay would exhaust the declared deadline")
        delay_started = time.perf_counter()
        if self.delay_mode == "sleep":
            time.sleep(requested_delay)
        else:
            until = delay_started + requested_delay
            while time.perf_counter() < until:
                pass
        measured_delay = time.perf_counter() - delay_started
        output = dict(result)
        output["wall_seconds_including_finish"] = original + measured_delay
        self.events.append({"score_call_index": self.score_calls_seen, "cfo_count": count,
            "original_real_kernel_wrapped_seconds": original, "requested_synthetic_delay_seconds": requested_delay,
            "measured_synthetic_delay_seconds": measured_delay,
            "returned_wrapped_seconds": output["wall_seconds_including_finish"],
            "actual_parent_request_seconds": time.perf_counter() - started})
        return output


def copy_anchor_inputs(source, destination):
    if not source.is_dir():
        raise ValueError("reuse anchor directory does not exist; no qualification fallback")
    destination.mkdir()
    records = []
    for path in sorted(source.glob("*.anchor.json")):
        target = destination / path.name
        checksum = file_sha(path)
        shutil.copyfile(path, target)
        if file_sha(target) != checksum or file_sha(path) != checksum:
            raise RuntimeError("anchor changed while making its private input copy")
        records.append({"original": str(path), "private_copy": str(target), "sha256": checksum})
    if not records:
        raise ValueError("reuse directory has no anchor records; no qualification fallback")
    return records


def run(args, api, cases_module, fft_module, discover_hardware, policy_type, *,
        invocation=None, source_before=None, started=None):
    started = time.monotonic() if started is None else started
    deadline = started + args.budget_seconds
    source_before = source_bindings() if source_before is None else source_before
    work = args.output.with_name(args.output.stem + ".work")
    if args.output.exists() or work.exists():
        raise FileExistsError("output or work directory exists; choose a fresh output name")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    work.mkdir()
    report = {"schema": SCHEMA, "status": "running", "exit_code": None,
        "scope": "one resident FFT case, not complete normal-CI or complete physical-simulation timing",
        "production_performance_claim_eligible": args.inject == "none",
        "experiment": {"argv": invocation or [], "case_id": args.case_id, "mode": args.mode,
            "baseline_ref": BASELINE, "candidate_root": str(ROOT), "source_sha256": source_before,
            "source_guard_scope": "isolated triad Python/native family and shared channel/tuning files; executable hash separately recorded",
            "fixture_binary": str(args.binary), "fixture_binary_sha256": file_sha(args.binary),
            "device": "cpu", "threads": args.threads, "budget_seconds": args.budget_seconds,
            "looks": list(args.looks), "family_count": args.family_count, "relative_precision_target": .05,
            "precision_request": args.precision, "anchor_directory": str(args.anchor_directory),
            "fixture_cache_directory": str(args.output.parent / "triad-performance-fixtures"),
            "started_unix_seconds": time.time(), "requalification_fallback": False,
            "deadline_scope": "maintained worker deadline; caller must supply outer process-group timeout",
            "injection": {"selection": args.inject, "multiplier": args.multiplier,
                "delay_mode": args.delay_mode, "scope": "synthetic post-real-kernel score-stage pipeline delay",
                "kernel_source_modified": False, "numerical_or_work_fields_modified": False,
                "real_kernel_identity_retained_for_anchor_applicability": True,
                "production_anchor_creation_allowed": args.inject == "none"}},
        "warnings": [], "failures": []}
    write_json(args.output, report, exclusive=True)
    real_workers = {}
    delayed = None
    baseline_directory = None
    try:
        if source_before != source_bindings():
            raise RuntimeError("source changed during numerical-module import")
        if args.inject != "none" and args.mode != "reuse":
            raise ValueError("injected controls may only reuse private copies of existing real-kernel anchors")
        policy = policy_type(relative_precision=.05, looks=args.looks, family_count=args.family_count)
        fixture_started = time.monotonic()
        all_cases = cases_module.prepare_cases(args.binary, args.output.parent / "triad-performance-fixtures",
            profile="ci", deadline=deadline, source_root=ROOT)
        matches = [case for case in all_cases if case["id"] == args.case_id]
        if len(matches) != 1:
            raise ValueError("case-id did not select exactly one maintained CI fixture")
        case = copy.deepcopy(matches[0])
        case["performance_environment"] = discover_hardware("cpu", args.threads)
        report["fixture_preparation_seconds"] = time.monotonic() - fixture_started
        report["fixture_preparation_scope"] = "prepare_cases maintains all cached CI fixtures; only selected case is timed"
        report["case"] = case
        report["hardware_identity_scope"] = "metadata only; no hardware stress calibration in this focused driver"
        baseline_directory = Path(tempfile.mkdtemp(prefix="baseline-", dir=work))
        report["reference"] = api.extract_baseline(ROOT, BASELINE, baseline_directory)
        for name, root in (("reference", baseline_directory), ("candidate", ROOT)):
            real_workers[name] = api.ReceiverWorker(root, threads=args.threads, deadline=deadline,
                                                   log_directory=work, name=name)
        report["real_worker_identities"] = {name: worker.identity for name, worker in real_workers.items()}
        qualification = api.qualify_fft(case, real_workers, "cpu")
        precision = qualification["selected"] if args.precision == "auto" else args.precision
        if not qualification["alternatives"][precision]["eligible"]:
            raise ValueError("requested arithmetic failed real-kernel numerical qualification")
        report["precision_qualification"] = qualification
        report["selected_precision"] = precision
        report["precision_selection_scope"] = ("fastest eligible current real-kernel pilot" if args.precision == "auto"
            else "explicit eligible policy for a matched anchor/control; not a claim that this pilot ranked it fastest")

        effective_anchor_directory = args.anchor_directory
        if args.mode == "reuse":
            effective_anchor_directory = work / "anchor-inputs"
            report["anchor_inputs"] = copy_anchor_inputs(args.anchor_directory, effective_anchor_directory)
            # Verify applicability on real workers before adding any synthetic
            # delay, so an absent anchor cannot masquerade as a detected control.
            geometry = None
            for worker in real_workers.values():
                prepared = worker.request(api.prepare_request(case, precision, "cpu"))
                current = {key: prepared["geometry"][key] for key in fft_module.GEOMETRY}
                if geometry is not None and current != geometry:
                    raise ValueError("real-worker preflight geometry differs")
                geometry = current
            identity = fft_module._identity(case, real_workers, precision, "cpu", geometry)
            anchor, reason = fft_module._find_anchor(effective_anchor_directory, identity)
            if anchor is None:
                raise ValueError("no applicable real-kernel anchor: " + reason + "; no qualification fallback")
            report["anchor_preflight"] = {"reason": reason, "identity": identity,
                "matched_private_path": anchor["path"], "verified_before_synthetic_injection": True}
        else:
            args.anchor_directory.mkdir(parents=True, exist_ok=True)
        report["effective_anchor_directory"] = str(effective_anchor_directory)
        timing_workers = dict(real_workers)
        if args.inject != "none":
            delayed = DelayedScoreWorker(real_workers["candidate"], target_count=len(case["frequency_offsets_hz"]),
                selection=args.inject, multiplier=args.multiplier, delay_mode=args.delay_mode, deadline=deadline)
            timing_workers["candidate"] = delayed
        write_json(args.output, report)
        result = fft_module.measure_fft(case, timing_workers, precision, "cpu", policy=policy,
            deadline=deadline, api=api, anchor_directory=effective_anchor_directory,
            validation_mode=args.mode)
        report["fft_result"] = result
        commitment = result.get("anchors", {}).get("prediction_commitment_path")
        if commitment:
            path = Path(commitment)
            report["frozen_commitment"] = {"path": str(path), "sha256": file_sha(path),
                "frozen_before_validation_as_recorded": json.loads(path.read_text()).get("prediction_frozen_before_validation")}
        for worker in real_workers.values():
            worker.request({"action": "hello"})
        if source_before != source_bindings() or report["experiment"]["fixture_binary_sha256"] != file_sha(args.binary):
            raise RuntimeError("harness, timed source or fixture binary changed during measurement")
        for record in report.get("anchor_inputs", []):
            if file_sha(record["original"]) != record["sha256"]:
                raise RuntimeError("production anchor input changed during reuse")
        gate = result.get("comparison", {}).get("gate")
        if not result.get("prediction_valid"):
            report["status"], report["exit_code"] = "unqualified", 2
            report["warnings"].append("full-runtime prediction is unqualified; no automatic retry or requalification")
        elif gate == "performance_regression":
            report["status"], report["exit_code"] = "regression", 2
        else:
            if gate != "pass":
                report["warnings"].append("full-runtime comparison is inconclusive")
            if not result.get("timing_precision_reached"):
                report["warnings"].append("requested 5% timing precision was not reached")
            report["status"], report["exit_code"] = ("warning" if report["warnings"] else "passed"), 0
    except Exception as error:
        report["status"], report["exit_code"] = "failed", 2
        report["failures"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        if delayed is not None:
            report["synthetic_delay_observations"] = {"score_calls_seen": delayed.score_calls_seen,
                "injected_score_call_count": len(delayed.events), "events": delayed.events,
                "scope": "not real-kernel acceleration or production performance evidence",
                "expected_control_response": ("regression gate should detect broad synthetic slowdown"
                    if args.inject == "all-cfo" else "full endpoint should reject a forecast that omitted full-bank-only delay"),
                "observed_gate": report.get("fft_result", {}).get("comparison", {}).get("gate"),
                "observed_prediction_valid": report.get("fft_result", {}).get("prediction_valid")}
        cleanup_errors = []
        for name, worker in real_workers.items():
            try:
                worker.close()
            except Exception as error:
                cleanup_errors.append({"worker": name, "type": type(error).__name__, "message": str(error)})
        if cleanup_errors:
            report["failures"].extend(cleanup_errors)
            report["status"], report["exit_code"] = "failed", 2
        if baseline_directory is not None and not cleanup_errors:
            shutil.rmtree(baseline_directory)
        report["worker_cleanup"] = "closed" if not cleanup_errors else "incomplete; outer watchdog remains required"
        report["elapsed_seconds"] = time.monotonic() - started
        report["completed_unix_seconds"] = time.time()
        write_json(args.output, report)
    return report


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", choices=("free-crystal", "broad-hf-timing"), default="free-crystal")
    parser.add_argument("--binary", type=Path, default=ROOT / "build/dev-cli/triad_long")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("qualify", "reuse"), default="qualify")
    parser.add_argument("--anchor-directory", type=Path, help="exact directory containing FFT *.anchor.json files; default outputparent/anchors-v3/cpu")
    parser.add_argument("--budget-seconds", type=float, default=900.)
    parser.add_argument("--looks", default="5,9,17,33")
    parser.add_argument("--family-count", type=int, default=14)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--precision", choices=("auto", "fp32", "fp64"), default="auto")
    parser.add_argument("--inject", choices=("none", "all-cfo", "full-cfo"), default="none")
    parser.add_argument("--multiplier", type=float, default=1.6)
    parser.add_argument("--delay-mode", choices=("sleep", "busy"), default="sleep")
    args = parser.parse_args(argv)
    try:
        args.looks = tuple(int(value) for value in args.looks.split(","))
        if not args.looks or any(n < 3 for n in args.looks) or tuple(sorted(set(args.looks))) != args.looks:
            raise ValueError
    except ValueError:
        parser.error("looks must be strictly increasing integers at least three")
    if args.family_count < 1 or args.threads < 1:
        parser.error("family-count and threads must be positive")
    if not math.isfinite(args.budget_seconds) or not 0 < args.budget_seconds <= 28800:
        parser.error("budget-seconds must be in (0,28800]")
    if not math.isfinite(args.multiplier) or not 1 < args.multiplier <= 10:
        parser.error("multiplier must be in (1,10]")
    if args.inject != "none" and args.mode != "reuse":
        parser.error("injected controls require reuse; they cannot create production qualification anchors")
    args.output = args.output.resolve()
    args.binary = args.binary.resolve()
    args.anchor_directory = (args.anchor_directory or args.output.parent / "anchors-v3/cpu").resolve()
    if not args.binary.is_file() or not os.access(args.binary, os.X_OK):
        parser.error("binary must be an existing executable")
    if args.output.exists() or args.output.with_name(args.output.stem + ".work").exists():
        parser.error("output or work directory already exists; choose a fresh output name")
    return args


def main(argv=None):
    started = time.monotonic()
    args = parse_args(argv)
    before = source_bindings()
    sys.path.insert(0, str(ROOT / "tools"))
    name = "triad_fft_followup_runner_api"
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools/triad-performance.py")
    api = importlib.util.module_from_spec(spec)
    sys.modules[name] = api
    spec.loader.exec_module(api)
    import triad_perf_cases as cases
    import triad_perf_fft_trace as fft
    from triad_perf_adaptive import AdaptivePolicy
    from triad_perf_hardware import discover_hardware
    command = [sys.executable, str(Path(__file__).resolve()), *(sys.argv[1:] if argv is None else argv)]
    report = run(args, api, cases, fft, discover_hardware, AdaptivePolicy,
                 invocation=command, source_before=before, started=started)
    print(json.dumps({"status": report["status"], "exit_code": report["exit_code"],
                      "elapsed_seconds": report["elapsed_seconds"], "output": str(args.output)}))
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Negative control: delay completion outside the receiver's internal timer."""
from pathlib import Path
import subprocess
import sys
import time

binary = Path(__file__).resolve().parents[2] / "build/dev-cli/triad_long"
result = subprocess.run([str(binary), *sys.argv[1:]], check=False)
args = sys.argv[1:]
if result.returncode == 0 and "--mode" in args and args[args.index("--mode") + 1] == "run":
    time.sleep(.2)
raise SystemExit(result.returncode)

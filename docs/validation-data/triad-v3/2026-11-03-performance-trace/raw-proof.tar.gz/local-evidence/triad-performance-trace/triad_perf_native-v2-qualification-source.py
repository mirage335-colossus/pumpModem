#!/usr/bin/env python3
"""Traceable duration forecasts for the real native triad simulation.

Short siblings execute complete streams, natural tails and final scoring. They
keep the full candidate bank. Predictions refer to complete CLI test wall time,
including startup/output, with native pipeline and receiver work also retained.
"""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time

SCHEMA = "triad-performance-native-v2"
ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = Path(__file__).with_name("triad-performance-native-cases.json")
STAGES = ("receiver", "generation_setup_other")
TIMED_STAGES = (*STAGES, "process_startup_output")
QUALIFICATION_REPEATS = 3
MINIMUM_BLOCK_SECONDS = .25
MAXIMUM_BLOCK_INVOCATIONS = 8


class NativePerformanceError(RuntimeError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def scenarios(profile="ci"):
    config = json.loads(CONFIG_PATH.read_text())
    if profile not in config["profiles"]:
        raise ValueError("unknown native performance profile")
    selected = set(config["profiles"][profile])
    return [{**row, "args": config["common_args"] + row["args"],
             "maximum_extrapolation": config["maximum_extrapolation"],
             "model_relative_error_limit": config["model_relative_error_limit"]}
            for row in config["cases"] if row["id"] in selected]


def environment_identity(threads):
    model = "unknown"
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        for line in cpuinfo.read_text().splitlines():
            if line.startswith("model name"):
                model = line.split(":", 1)[1].strip()
                break
    return {"system": platform.system(), "release": platform.release(), "machine": platform.machine(),
            "cpu_model": model, "threads": threads,
            "affinity_cpu_count": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else os.cpu_count()}


def identity(binary, case, threads):
    return {"binary_sha256": file_sha(binary), "environment": environment_identity(threads),
            "case_sha256": digest(case), "adapter_sha256": file_sha(__file__),
            "protocol": "complete-native-duration-siblings-v2", "arithmetic": "fp64",
            "timing_boundary": "external complete CLI test including startup and output; stages inside native trial separately retained"}


def _argv(binary, case, seconds, seed, threads, *, trace=False, configure=False):
    if not math.isfinite(seconds) or seconds < 8 or isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("invalid native duration or seed")
    args = [str(Path(binary).resolve()), *case["args"], "--seconds", repr(float(seconds)),
            "--seed", str(seed), "--threads", str(threads)]
    if configure:
        args += ["--mode", "configure"]
    else:
        args += ["--trials", str(case.get("batch_trials", 1))]
        if trace:
            args += ["--performance-trace", "yes"]
    return args


def _invoke(argv, deadline=None, timeout=120.):
    remaining = timeout if deadline is None else min(timeout, deadline-time.monotonic())
    if remaining <= 0:
        raise TimeoutError("native performance deadline exhausted")
    start = time.perf_counter()
    result = subprocess.run(argv, text=True, capture_output=True, timeout=remaining)
    elapsed = time.perf_counter()-start
    if result.returncode:
        raise NativePerformanceError(f"native command exited {result.returncode}: {result.stderr[-1600:]}")
    try:
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith("{")]
    except ValueError as exc:
        raise NativePerformanceError("native command returned invalid JSON") from exc
    return rows, elapsed


def _positive(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise NativePerformanceError(f"invalid native {label}")
    return value


def coverage_witnesses(row):
    """Actual completed execution/counter evidence, not source line coverage."""
    fmt = row["source_format"]
    model = row["channel_model"]
    path = model["path_evolution"]
    truth = row["path_truth_simulation_only"]
    front = row["frontend_report"]
    rows = row["capture_samples"]
    complete = row.get("complete_observation") is True and row["channel_samples"] == rows
    selective = truth["selective_perturbation"]
    columns = sum(c["tap_count"] for c in row["candidates"])
    if row["basis_values"] != rows * columns:
        raise NativePerformanceError("native basis work differs from full rows times complete candidate columns")
    if row["candidate_count"] != len(row["candidates"]):
        raise NativePerformanceError("native candidate accounting mismatch")
    if not complete or row["blocks"] < 1 or row["missing_samples"] > rows:
        raise NativePerformanceError("native run did not complete its declared stream")
    result = {
        "complete": complete,
        "encrypted": complete and fmt["encrypted"],
        "flat": complete and all(c["tap_count"] == 1 for c in row["candidates"]),
        "two_ray": complete and any(c["tap_count"] == 2 for c in row["candidates"]),
        "white_noise": complete and row["gaussian_projection_supported"] and row["complex_noise_variance"] > 0,
        "selective": complete and selective["enabled"] and selective.get("processed_rows", 0) >= rows,
        "erasure": complete and row["missing_samples"] > 0,
        "internal_burst": complete and row["burst_wait_tiles"] > 0 and fmt["tile_count"] > 1
                          and row["bit_seconds"] > fmt["tile_seconds"] * fmt["tile_count"],
        "sub_hz": complete and row["sample_rate"] < 1,
        "weak_signal": complete and row["cn0_db_hz"] <= -60,
        "null": complete and row["control"] == "null",
        "wrong_key": complete and row["control"] == "wrong-key",
        "signal_energy": complete and row["signal_energy"] > 0,
        "no_signal_energy": complete and row["signal_energy"] == 0,
        "frontend": complete and row["sampled_frontend"]["active"] and not row["analytical_null_supported"],
        "adc_clipping": complete and front["adc_clipped_components"] > 0,
        "dac_clipping": complete and front["dac_clipped_components"] > 0,
        "impulses": complete and front["impulse_events"] > 0,
        "overload": complete and front["overload_samples"] > 0,
        "ou_path": complete and path["ray_coherence_seconds"] > 0,
        "gaussian_path": complete and len(truth["gaussian_ray_teacher"]["fir_coefficients"]) > 1,
        "outage": complete and 0 <= path["outage_start_seconds"] < path["outage_end_seconds"] < row["bit_seconds"],
        "max_added": complete and fmt["added_symbols"] == 1000,
    }
    return result


def regime(row, case):
    """Duration-independent measured geometry; exact selected algorithm remains fixed."""
    fmt = {k: v for k, v in row["source_format"].items() if k != "tile_count"}
    return {"source_format": fmt, "sample_rate": row["sample_rate"],
            "candidate_bank": row["candidates"], "channel_model": row["channel_model"],
            "frontend": row["sampled_frontend"], "channel_tail_samples": row["channel_tail_samples"],
            "coherent_block_samples": row["coherent_block_samples"], "threads_used": row["threads_used"],
            "chunk_samples": int(_option(case["args"], "--chunk", 4096)),
            "control": row["control"], "cn0_db_hz": row["cn0_db_hz"],
            "workspace_bytes": row["working_bytes"], "arithmetic": "fp64"}


def _option(args, name, default):
    indices = [i for i, value in enumerate(args) if value == name]
    return args[indices[-1]+1] if indices else default


def run_native(binary, case, seconds, seed, *, threads=1, trace=False, deadline=None, timeout=120.):
    argv = _argv(binary, case, seconds, seed, threads, trace=trace)
    rows, external = _invoke(argv, deadline, timeout)
    if len(rows) != case.get("batch_trials", 1) or any(row.get("mode") != "run" for row in rows):
        raise NativePerformanceError("native trial count does not match the frozen test")
    witnesses, geometries = [], []
    for row in rows:
        for name in ("capture_samples", "end_to_end_wall_seconds", "wall_seconds", "basis_values"):
            _positive(row.get(name), name)
        witnesses.append(coverage_witnesses(row))
        geometries.append(regime(row, case))
    if any(value != geometries[0] for value in geometries[1:]):
        raise NativePerformanceError("native trial seeds changed the cost regime")
    actual = {name: all(w.get(name, False) for w in witnesses) for name in case["witnesses"]}
    if not all(actual.values()):
        raise NativePerformanceError("required native execution witnesses absent: " + ", ".join(k for k, v in actual.items() if not v))
    pipeline = math.fsum(row["end_to_end_wall_seconds"] for row in rows)
    receiver = math.fsum(row["wall_seconds"] for row in rows)
    if pipeline < receiver or external < pipeline:
        raise NativePerformanceError("native timing boundaries did not reconcile")
    return {"schema": SCHEMA, "argv": argv, "argv_sha256": digest(argv), "seed": seed,
            "requested_seconds": seconds, "batch_trials": len(rows),
            "samples_per_trial": rows[0]["capture_samples"], "total_rows": sum(row["capture_samples"] for row in rows),
            "stage_seconds": {"receiver": receiver, "generation_setup_other": pipeline-receiver,
                              "process_startup_output": external-pipeline},
            "full_test_wall_seconds": external, "native_pipeline_seconds": pipeline,
            "regime": geometries[0], "coverage": actual,
            "counter_summary": {"basis_values": sum(r["basis_values"] for r in rows),
                                "blocks": sum(r["blocks"] for r in rows),
                                "missing_samples": sum(r["missing_samples"] for r in rows),
                                "channel_samples": sum(r["channel_samples"] for r in rows)},
            "native_results": rows, "performance_only": True,
            "admission_scope": "short native decisions apply only to the actual short geometry, never the predicted full duration"}



def compare_native_outputs(reference, candidate):
    """Compare full physical work and decisions on the same paired seeds."""
    a, b = reference["native_results"], candidate["native_results"]
    if len(a) != len(b):
        raise NativePerformanceError("paired native trial counts differ")
    exact = ("capture_samples", "channel_samples", "source_samples", "candidate_count", "basis_values",
             "blocks", "missing_samples", "complete_observation", "all_samples_observed", "accepted",
             "presence", "correct", "wrong_accepted", "missed", "false_admission", "decoded_bit",
             "analytical_null_supported", "source_format", "candidates")
    maximum_error = 0.
    for old, new in zip(a, b):
        if any(old.get(key) != new.get(key) for key in exact):
            raise NativePerformanceError("paired native work, candidate geometry or discrete result differs")
        for key in ("score", "threshold", "margin", "observed_energy", "signal_energy"):
            x, y = float(old[key]), float(new[key])
            error = abs(x-y)
            if not math.isfinite(x) or not math.isfinite(y) or error > 1e-3 + 1e-6*max(abs(x), abs(y)):
                raise NativePerformanceError("paired native numerical result differs: " + key)
            maximum_error = max(maximum_error, error)
    return {"eligible": True, "maximum_absolute_error": maximum_error,
            "scope": "paired declared physical cases and numerical/discrete outcomes; not universal native sensitivity equivalence"}


def target_geometry(binary, case, *, threads=1, deadline=None, seconds=None):
    duration = case["target_seconds"] if seconds is None else seconds
    rows, elapsed = _invoke(_argv(binary, case, duration, 1, threads, configure=True), deadline, 20.)
    if len(rows) != 1 or rows[0].get("mode") != "configure":
        raise NativePerformanceError("target configuration response missing")
    return {"configuration": rows[0]["configuration"], "performance_geometry": rows[0].get("performance_geometry"),
            "configuration_wall_seconds": elapsed, "configuration_sha256": digest(rows[0])}


def target_rows_from_configuration(configuration, training):
    explicit = configuration.get("performance_geometry")
    if explicit and "capture_samples" in explicit:
        return int(explicit["capture_samples"]) * training["batch_trials"]
    # Legacy configure lacks capture rows. This fallback is scoped to the exact
    # static-clock recipes: complete source support changes while public padding
    # and tails remain fixed. Full holdouts must confirm the predicted row count.
    if training["regime"]["channel_model"].get("sample_clock_reference") != "RX0ppm; TX carries declared relative error":
        raise NativePerformanceError("legacy target geometry needs exact configure metadata for clocked paths")
    support = configuration["configuration"]["duration"]["source_support_seconds"]
    fs = training["regime"]["sample_rate"]
    old = training["native_results"][0]
    target_source = int(round(support*fs))
    return (target_source + old["capture_samples"]-old["source_samples"]) * training["batch_trials"]


def fit_duration_model(training, target_rows, *, maximum_extrapolation=8.):
    if isinstance(target_rows, bool) or not isinstance(target_rows, int) or target_rows < 1:
        raise ValueError("target_rows must be a positive integer")
    if len(training) != 2:
        raise ValueError("native duration model requires exactly two independent complete siblings")
    small, large = sorted(training, key=lambda row: row["total_rows"])
    if small["regime"] != large["regime"] or small["batch_trials"] != large["batch_trials"]:
        raise NativePerformanceError("duration siblings changed measured cost regime")
    x0, x1 = small["total_rows"], large["total_rows"]
    if not 0 < x0 < x1 <= target_rows or target_rows/x1 > maximum_extrapolation:
        raise NativePerformanceError("native resolved row geometry is duplicate, reversed or out of extrapolation bounds")
    predictions, slopes = {}, {}
    for stage in STAGES:
        a, b = small["stage_seconds"][stage], large["stage_seconds"][stage]
        slope = (b-a)/(x1-x0)
        prediction = b + slope*(target_rows-x1)
        if slope < 0 or not math.isfinite(prediction) or prediction <= 0:
            raise NativePerformanceError("native duration slope is unstable or nonpositive: " + stage)
        slopes[stage], predictions[stage] = slope, prediction
    predictions["process_startup_output"] = statistics.mean(row["stage_seconds"]["process_startup_output"] for row in training)
    return {"schema": SCHEMA, "stage_seconds": predictions,
            "full_test_wall_seconds": math.fsum(predictions.values()), "target_total_rows": target_rows,
            "slopes_seconds_per_row": slopes, "larger_sibling_total_rows": x1,
            "target_over_larger_rows": target_rows/x1, "regime_sha256": digest(large["regime"]),
            "training_record_sha256": [digest(row) for row in training],
            "method": "anchored affine complete-duration native stage model; fixed process startup/output",
            "prediction_is_frozen_before_full_execution": True}


def validate_holdout(prediction, actual, *, maximum_relative_error=.05):
    same_geometry = (prediction["target_total_rows"] == actual["total_rows"] and
                     prediction["regime_sha256"] == digest(actual["regime"]))
    errors = {stage: abs(prediction["stage_seconds"][stage]-actual["stage_seconds"][stage])/
                    prediction["stage_seconds"][stage] for stage in STAGES}
    predicted, observed = prediction["full_test_wall_seconds"], actual["full_test_wall_seconds"]
    relative = abs(observed-predicted)/predicted
    return {"single_run_within_bound": same_geometry and relative <= maximum_relative_error,
            "geometry_matched": same_geometry, "absolute_relative_error": relative,
            "allowed_relative_error": maximum_relative_error,
            "stage_absolute_relative_errors": errors, "log_error": math.log(observed/predicted),
            "prediction_sha256": digest(prediction), "actual_record_sha256": digest(actual),
            "predicted_full_seconds": predicted, "actual_full_seconds": observed,
            "stage_validation_scope": "diagnostic only; qualification uses independent log-mean equivalence"}


def _qualification(holds, allowance):
    from triad_perf_adaptive import qualify_log_residuals

    errors = {name: [h["validation"]["log_error"] for h in holds if h["source"] == name]
              for name in ("reference", "candidate")}
    errors["paired"] = [c - r for r, c in zip(errors["reference"], errors["candidate"], strict=True)]
    intervals = {name: qualify_log_residuals(values, maximum_relative_error=allowance)
                 for name, values in errors.items()}
    statuses = {interval["status"] for interval in intervals.values()}
    geometry_matches = all(h["validation"]["geometry_matched"] for h in holds)
    if not geometry_matches or "invalid" in statuses:
        status = "invalid"
    elif statuses == {"validated"}:
        status = "validated"
    else:
        status = "inconclusive"
    return {"status": status, "geometry_matches": geometry_matches, "log_errors": errors,
            "intervals": intervals,
            "scope": "one fixed validation look per case; both sources and paired ratio must establish equivalence"}


def _timing_block(invocations):
    """Average full original CLI invocations as one timing observation."""
    first = invocations[0]
    keys = ("total_rows", "batch_trials", "regime")
    if any(any(run[key] != first[key] for key in keys) for run in invocations):
        raise NativePerformanceError("timing block changed native geometry across invocations")
    if len(invocations) == 1:
        return first
    return {**{key: first[key] for key in keys},
            "stage_seconds": {stage: statistics.fmean(r["stage_seconds"][stage] for r in invocations)
                              for stage in TIMED_STAGES},
            "full_test_wall_seconds": statistics.fmean(r["full_test_wall_seconds"] for r in invocations),
            "invocations": invocations}


def _freeze_model(predictions):
    first = predictions[0]
    geometry_keys = ("target_total_rows", "regime_sha256")
    if any(any(p[key] != first[key] for key in geometry_keys) for p in predictions):
        raise NativePerformanceError("frozen prediction combines incompatible geometry")
    point = math.exp(statistics.fmean(math.log(p["full_test_wall_seconds"]) for p in predictions))
    stage_means = {stage: statistics.fmean(p["stage_seconds"][stage] for p in predictions)
                   for stage in TIMED_STAGES}
    # Report pooled additive stage shares at the same geometric-mean full-time
    # estimand used by the timing intervals and the independent holdout check.
    stage_sum = math.fsum(stage_means.values())
    return {**{key: first[key] for key in geometry_keys}, "full_test_wall_seconds": point,
            "stage_seconds": {stage: seconds * (point / stage_sum) for stage, seconds in stage_means.items()},
            "outer_training_prediction_sha256": [digest(p) for p in predictions],
            "outer_training_count": len(predictions),
            "method": "geometric mean of predeclared outer full-test forecasts; normalized pooled stage shares"}


def anchor_compatible(anchor, identities, case):
    if (not isinstance(anchor, dict) or anchor.get("schema") != SCHEMA or
            anchor.get("identities") != identities or anchor.get("case_sha256") != digest(case) or
            anchor.get("validated") is not True):
        return False
    try:
        if anchor["anchor_sha256"] != digest({k: v for k, v in anchor.items() if k != "anchor_sha256"}):
            return False
        frozen, holds = anchor["frozen_prediction"], anchor["full_holdouts"]
        allowance = float(case.get("model_relative_error_limit", .05))
        if frozen["sha256"] != digest({k: v for k, v in frozen.items() if k != "sha256"}):
            return False
        expected = {(source, index) for source in identities for index in range(QUALIFICATION_REPEATS)}
        if (len(holds) != len(expected) or {(h["source"], h["index"]) for h in holds} != expected or
                frozen["validation_duration_seconds"] != case["target_seconds"]):
            return False
        for hold in holds:
            prediction = frozen["validation_predictions"][hold["source"]]
            if (hold["kind"] != "qualify" or hold["frozen_prediction_sha256"] != frozen["sha256"] or
                    hold["prediction"] != prediction or
                    hold["validation"] != validate_holdout(prediction, hold["actual"], maximum_relative_error=allowance)):
                return False
        qualification = _qualification(holds, allowance)
        return (qualification["status"] == "validated" and anchor["qualification"] == qualification and
                anchor["log_errors"] == qualification["log_errors"])
    except (KeyError, TypeError, ValueError, ArithmeticError):
        return False


def measure_native_case(reference_binary, candidate_binary, case, policy, *, threads=1,
                        deadline=None, validation_mode="qualify", anchor=None,
                        trace_candidate=False, freeze_callback=None):
    """Collect paired full-time predictions and independently test one frozen fit.

    `freeze_callback` persists the pooled prediction before independent holds.
    Qualification measures three full holds per source. Routine mode reuses only
    an exact compatible anchor and independently checks an intermediate sibling;
    absent anchors leave predictions explicitly unqualified.
    """
    from triad_perf_adaptive import summarize
    if validation_mode not in ("qualify", "routine"):
        raise ValueError("unknown native anchor validation mode")
    if trace_candidate:
        raise ValueError("candidate-only trace clocks are for run_native diagnostics, outside paired timing")
    binaries = {"reference": Path(reference_binary), "candidate": Path(candidate_binary)}
    identities = {name: identity(binary, case, threads) for name, binary in binaries.items()}
    direct = "training_seconds" not in case
    compatible = not direct and anchor_compatible(anchor, identities, case)
    validation_duration = (case["target_seconds"] if validation_mode == "qualify" else
                           case.get("holdout_seconds") if compatible else None)
    validation_duration = None if direct else validation_duration
    configs = {n: target_geometry(b, case, threads=threads, deadline=deadline) for n, b in binaries.items()}
    hold_configs = (configs if validation_duration in (None, case["target_seconds"]) else
                    {n: target_geometry(b, case, threads=threads, deadline=deadline,
                                        seconds=validation_duration) for n, b in binaries.items()})
    records = {name: [] for name in binaries}
    values = {name: [] for name in binaries}
    models = {name: [] for name in binaries}
    intermediate_models = {name: [] for name in binaries}
    holds, looks, numerical_checks = [], [], []
    allowance = float(case.get("model_relative_error_limit", .05))
    max_extrapolation = case.get("maximum_extrapolation", 8.)
    adjusted_policy = replace(policy, model_allowance_log=0. if direct else max(
        policy.model_allowance_log, -math.log1p(-allowance)))

    def run_pair(seconds, seed, order_index):
        order = ("reference", "candidate") if order_index % 2 == 0 else ("candidate", "reference")
        results = {name: run_native(binaries[name], case, seconds, seed, threads=threads,
                                    deadline=deadline) for name in order}
        numerical_checks.append(compare_native_outputs(results["reference"], results["candidate"]))
        return results

    block_invocations = 1
    pilot = None
    validation_reserve = 0.
    if not direct:
        probes = [run_pair(duration, 640000 + 100 * j, j) for j, duration in enumerate(case["training_seconds"])]
        target_rows = {name: target_rows_from_configuration(configs[name], probes[-1][name]) for name in binaries}
        if len(set(target_rows.values())) != 1:
            raise NativePerformanceError("paired native target geometries differ")
        # Repeat the original short CLI invocation inside a single outer
        # sample, preserving per-invocation startup and the declared workload.
        # A noisy pilot chooses batch length only and never enters inference.
        pilot_seconds = {n: math.fsum(p[n]["full_test_wall_seconds"] for p in probes) for n in binaries}
        block_cost_fraction = max(sum(p[n]["total_rows"] for p in probes)/target_rows[n] for n in binaries)
        desired = math.ceil(MINIMUM_BLOCK_SECONDS / min(pilot_seconds.values()))
        work_cap = max(1, math.floor(.80 / block_cost_fraction))
        block_invocations = max(1, min(desired, work_cap, MAXIMUM_BLOCK_INVOCATIONS))
        pilot = {"source_record_sha256": [{n: digest(p[n]) for n in binaries} for p in probes],
                 "training_seconds_per_source": pilot_seconds, "inference_eligible": False,
                 "minimum_training_block_seconds_target": MINIMUM_BLOCK_SECONDS,
                 "target_rows_per_source": target_rows, "planned_fraction_of_full_row_work": block_invocations*block_cost_fraction,
                 "requested_block_invocations": desired, "row_work_cap_invocations": work_cap}
        if validation_duration is not None:
            validation_reserve = QUALIFICATION_REPEATS * math.fsum(
                probes[-1][n]["full_test_wall_seconds"] * target_rows_from_configuration(hold_configs[n], probes[-1][n])
                / probes[-1][n]["total_rows"] for n in binaries)

    sampling_started = time.monotonic()
    sampling_stop = None
    for index in range(policy.looks[-1]):
        seed = 1_000_000 + 1000*index
        if direct:
            pair = run_pair(case["target_seconds"], seed, index)
            for name, record in pair.items():
                records[name].append(record)
                values[name].append(record["full_test_wall_seconds"])
        else:
            pairs = [[], []]
            for invocation in range(block_invocations):
                order = (0, 1) if (index+invocation) % 2 == 0 else (1, 0)
                for j in order:
                    pairs[j].append(run_pair(case["training_seconds"][j], seed + 100*invocation + 10*j,
                                             index+invocation+j))
            for name in binaries:
                siblings = [_timing_block([pair[name] for pair in group]) for group in pairs]
                large_record = pairs[-1][0][name]
                model = fit_duration_model(siblings, target_rows_from_configuration(configs[name], large_record),
                                           maximum_extrapolation=max_extrapolation)
                models[name].append(model)
                records[name].append(siblings)
                values[name].append(model["full_test_wall_seconds"])
                if validation_duration is not None and validation_duration != case["target_seconds"]:
                    intermediate_models[name].append(fit_duration_model(siblings,
                        target_rows_from_configuration(hold_configs[name], large_record),
                        maximum_extrapolation=max_extrapolation))
        count = index+1
        if count in policy.looks:
            summary = summarize(values["reference"], values["candidate"], adjusted_policy,
                                model_validation="direct_full" if direct else "unvalidated")
            looks.append(summary)
            sampling_stop = summary["stop_reason"]
            if sampling_stop != "continue":
                break
            if not direct and validation_duration is None:
                sampling_stop = "historical_anchor_unavailable"
                break
            if (not direct and summary["paired_candidate_over_reference"]["model_adjusted_gate_interval"][0]
                    > policy.slowdown_threshold):
                sampling_stop = "freeze_for_potential_regression_validation"
                break
            projected_seconds = ((summary["next_look"]-count) * (time.monotonic()-sampling_started)/count
                                 + validation_reserve)
            if deadline is not None and time.monotonic() + 1.25*projected_seconds >= deadline:
                sampling_stop = "budget_limit"
                break

    frozen = None
    qualification = None
    if not direct:
        prediction = {n: _freeze_model(models[n]) for n in binaries}
        validation_prediction = ({n: _freeze_model(intermediate_models[n]) for n in binaries}
                                 if validation_duration not in (None, case["target_seconds"]) else prediction)
        frozen = {"index": len(values["reference"])-1, "identities": identities, "case_sha256": digest(case),
                  "predictions": prediction, "validation_predictions": validation_prediction,
                  "validation_duration_seconds": validation_duration,
                  "predeclared_validation_repeats": QUALIFICATION_REPEATS,
                  "frozen_at_unix_seconds": time.time()}
        frozen["sha256"] = digest(frozen)
        if freeze_callback:
            freeze_callback(frozen)
        if validation_duration is not None:
            for index in range(QUALIFICATION_REPEATS):
                actuals = run_pair(validation_duration, 840000 + 1000*index, index)
                for name, actual in actuals.items():
                    predicted = validation_prediction[name]
                    check = validate_holdout(predicted, actual, maximum_relative_error=allowance)
                    holds.append({"source": name, "index": index, "kind": validation_mode,
                                  "frozen_prediction_sha256": frozen["sha256"],
                                  "prediction": predicted, "actual": actual, "validation": check})
            qualification = _qualification(holds, allowance)

    error_keys = ("reference", "candidate", "paired")
    evidence = {name: [] for name in error_keys}
    if compatible and validation_mode == "routine":
        evidence = {name: list(anchor["log_errors"][name]) for name in error_keys}
    if qualification is not None:
        for name in error_keys:
            evidence[name].extend(qualification["log_errors"][name])
    state = ("direct_full" if direct else "unvalidated" if qualification is None else
             "unvalidated" if qualification["status"] == "inconclusive" else qualification["status"])
    final = summarize(values["reference"], values["candidate"], adjusted_policy, model_validation=state,
                      reference_model_log_errors=evidence["reference"], candidate_model_log_errors=evidence["candidate"],
                      paired_model_log_errors=evidence["paired"])
    final["stop_reason"] = sampling_stop if final["performance_gate"] != "performance_regression" else "performance_regression"
    looks[-1] = final
    new_anchor = anchor if compatible and validation_mode == "routine" else None
    if validation_mode == "qualify" and qualification is not None:
        new_anchor = {"schema": SCHEMA, "identities": identities, "case_sha256": digest(case),
                      "validated": state == "validated", "log_errors": qualification["log_errors"],
                      "qualification": qualification, "full_holdouts": holds, "frozen_prediction": frozen,
                      "scope": "exact binary/environment/case/protocol only; fixed-look mean equivalence of a frozen forecast"}
        new_anchor["anchor_sha256"] = digest(new_anchor)
    return {"id": case["id"], "adapter": "native_complete_simulation", "scope": case["scope"],
            "precision": "fp64", "prediction_valid": state in ("direct_full", "validated"),
            "measurement_plan": {"direct": direct, "validation_mode": validation_mode,
                                 "compatible_historical_anchor": compatible, "case": case,
                                 "timing_block_invocations": block_invocations, "discarded_pilot": pilot},
            "target_configuration": configs["candidate"], "reference_target_configuration": configs["reference"],
            "identities": identities,
            "raw": records, "predicted_full_seconds": values, "prediction": final,
            "outer_predictions": models,
            "comparison": {"gate": final["performance_gate"],
                           "expanded_full_prediction_ratio_interval": final["paired_candidate_over_reference"]["model_adjusted_gate_interval"]},
            "adaptive_looks": looks, "frozen_predictions": [frozen] if frozen is not None else [],
            "anchors": new_anchor or {}, "current_validation": {"holds": holds, "qualification": qualification},
            "paired_native_numerical_checks": numerical_checks,
            "coverage": {name: True for name in case["witnesses"]},
            "limits": ["Native receiver currently executes FP64 regardless of Python precision selection",
                       "Named completed execution witnesses are not exhaustive source-line or numerical-state coverage",
                       "Finite independent full holdouts bound only the declared matched regime",
                       "Timing precision does not establish smaller model error"]}

#!/usr/bin/env python3
"""Compact recorded v2/focused performance evidence without rerunning or refitting.

Usage: python3 summarize_run.py REPORT.json --output SUMMARY.json
An unfinished/coverage-incomplete report requires --allow-partial. This helper
does not qualify a report, recompute its statistics, or verify source files.
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys


SCHEMA = "triad-performance-evidence-summary-v2"
FOLLOWUP_SCHEMAS = ("triad-native-performance-followup-v1",
                    "triad-fft-performance-followup-v1", "triad-fft-sustained-followup-v1")


def select(record, keys):
    return {key: record[key] for key in keys if isinstance(record, dict) and key in record}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def complete(record):
    return (record.get("status") in ("passed", "warning", "failed")
            and type(record.get("exit_code")) is int
            and record.get("complete_required_coverage") is True)


def numeric_checks(rows):
    eligible = collections.Counter()
    maximum = {}
    for row in rows:
        check = row.get("agreement", row)
        eligible[str(check.get("eligible", "unrecorded"))] += 1
        for key in ("maximum_absolute_score_error", "maximum_absolute_error"):
            value = check.get(key)
            if isinstance(value, (int, float)) and math.isfinite(value):
                maximum[key] = max(maximum.get(key, 0.), value)
    return {"count": len(rows), "eligible_counts": dict(eligible), **maximum}


def holdouts(rows):
    """Keep exact scalar observations/linkage, omit repeated native CLI payloads."""
    retained = []
    for row in rows:
        value = select(row, ("source", "index", "repeat", "kind", "purpose", "count",
            "frozen_prediction_sha256", "predicted_seconds", "observed", "log_errors",
            "relative_errors", "paired_log_error", "paired_relative_error", "single_run_within_bound", "error_limit"))
        if "actual" in row:
            value["actual"] = select(row["actual"], ("argv_sha256", "seed", "requested_seconds",
                "batch_trials", "samples_per_trial", "total_rows", "stage_seconds",
                "full_test_wall_seconds", "native_pipeline_seconds", "counter_summary", "coverage"))
        if "validation" in row:
            value["validation"] = row["validation"]
        retained.append(value)
    return {"record_count": len(rows),
            "count_by_source": dict(collections.Counter(r.get("source", "paired") for r in rows)),
            "recorded_scalar_observations": retained}


def historical_anchor(record):
    """Retain scalar original proof and its identity without copying raw captures."""
    if not isinstance(record, dict):
        return record
    value = select(record, ("schema", "status", "validated", "identity", "identities",
        "identity_sha256", "case_sha256", "payload_sha256", "anchor_sha256", "frozen_prediction",
        "qualification", "qualification_looks", "confirmation_looks", "confirmation_stop_reason",
        "log_errors", "timing_boundary", "model_validation_is_conditional_mean_equivalence",
        "individual_prediction_coverage_claim", "scope"))
    value["original_record_sha256"] = digest(record)
    for key in ("full_validation", "full_holdouts"):
        if isinstance(record.get(key), list):
            value[key] = holdouts(record[key])
    value["proof_scope"] = "recorded scalar evidence; original payload hash retained, compact record is not an interchangeable anchor"
    return value


def sampling_work(case):
    """Count recorded timed calls; never infer independent samples from inner calls."""
    raw = case.get("raw", {})
    result = {}
    if case.get("adapter") == "native_complete_simulation":
        def invocations(value):
            if isinstance(value, list):
                for child in value:
                    yield from invocations(child)
            elif "invocations" in value:
                yield from invocations(value["invocations"])
            else:
                yield value
        for source, records in raw.items():
            calls = list(invocations(records))
            result[source] = {"outer_sample_count": len(records), "actual_cli_invocation_count": len(calls),
                "actual_simulation_trial_count": sum(r["batch_trials"] for r in calls),
                "actual_capture_rows_processed": sum(r["total_rows"] for r in calls),
                "sum_measured_cli_wall_seconds": math.fsum(r["full_test_wall_seconds"] for r in calls)}
        return {"scope": "timing samples only; excluded pilot and validation calls are separate; native full CLI wall boundary",
                "sources": result}
    if case.get("adapter") == "fft":
        for source, records in raw.items():
            blocks = records.get("blocks", [])
            counts = collections.Counter()
            for block in blocks:
                counts.update({count: len(times) for count, times in block.get("score_seconds_by_count", {}).items()})
            result[source] = {"outer_sample_count": len(blocks),
                "actual_preparation_call_count": sum(len(b["preparation_seconds"]) for b in blocks),
                "actual_score_call_count_by_cfo_bank_size": dict(counts),
                "sum_measured_resident_seconds": math.fsum(
                    math.fsum(b["preparation_seconds"]) + math.fsum(
                        math.fsum(times) for times in b["score_seconds_by_count"].values()) for b in blocks)}
        return {"scope": "timing samples only; excluded pilot and validation calls are separate; resident preparation plus scoring",
                "sources": result}
    if case.get("adapter") == "gaussian":
        calls = case.get("calls_per_outer_block", 1)
        for source, times in case.get("raw_full_seconds", {}).items():
            result[source] = {"outer_sample_count": len(times), "actual_helper_call_count": calls * len(times),
                              "sum_measured_helper_seconds": calls * math.fsum(times)}
        return {"scope": "resident helper timing samples only; excluded pilot is separate", "sources": result}
    return {"scope": "sampling call counts unavailable for this adapter"}


def case_summary(case):
    adaptive = case.get("adaptive", case.get("prediction", {}))
    result = select(case, ("id", "adapter", "scope", "precision", "prediction_valid", "comparison",
        "full_cfo_count", "full_target_measured", "full_target_measurement_count_per_source",
        "elapsed_seconds", "coverage", "warnings", "limits", "identities", "fixture_hashes",
        "source_bound_metadata", "precision_qualification", "reduced_bank_admissions_valid",
        "prediction_interval_target", "independence_scope"))
    result["adaptive"] = select(adaptive, ("sample_count", "next_look", "policy", "stop_reason",
        "timing_precision_reached", "timing_intervals_simultaneously_within_target", "model_validation",
        "performance_gate", "gate_performance_pass_eligible", "inference", "fit_instability",
        "reference", "candidate", "paired_candidate_over_reference",
        "conditional_full_time_intervals_seconds", "conditional_comparison"))
    if case.get("adapter") == "fft":
        result["full_prediction"] = {
            source: select(row, ("predicted_full_time", "status"))
            for source, row in case.get("prediction", {}).items()}
    result["recorded_sampling_work"] = sampling_work(case)
    plan = case.get("measurement_plan", {})
    result["measurement_plan"] = select(plan, ("direct", "validation_mode", "compatible_historical_anchor",
        "timing_block_invocations", "training_counts", "intermediate_count", "target_count",
        "maximum_extrapolation", "routine_cfo_work", "direct_cfo_work", "confirmation_plan", "pilot_cost_guard"))
    if "case" in plan:
        result["measurement_plan"]["native_case_sha256"] = digest(plan["case"])
        result["measurement_plan"]["native_case"] = select(plan["case"], ("id", "training_seconds",
            "holdout_seconds", "target_seconds", "batch_trials", "maximum_extrapolation", "witnesses"))
    anchor = case.get("anchors", {})
    result["anchor"] = select(anchor, ("schema", "validated", "status", "validation_mode", "identities",
        "identity", "case_sha256", "anchor_sha256", "path", "lookup_reason", "prediction_commitment_path",
        "qualification", "qualification_looks", "confirmation_looks", "confirmation_stop_reason",
        "applicability", "conditional_check", "conditional_model_bounds", "scope"))
    if "frozen_prediction" in anchor and anchor["frozen_prediction"] is not None:
        result["anchor"]["frozen_prediction"] = anchor["frozen_prediction"]
    historical = anchor.get("historical_record")
    if historical is not None:
        result["anchor"]["historical_record"] = historical_anchor(historical)
    for key in ("full_holdouts", "current_validation", "historical_full_validation"):
        if isinstance(anchor.get(key), list):
            if (key == "historical_full_validation" and isinstance(historical, dict)
                    and anchor[key] == historical.get("full_validation")):
                result["anchor"][key + "_alias"] = "anchor.historical_record.full_validation"
            else:
                result["anchor"][key] = holdouts(anchor[key])
    validation = case.get("current_validation", {})
    if validation:
        result["current_validation"] = select(validation, ("confirmation_looks", "confirmation_stop_reason",
            "conditional_model", "conditional_model_log_bounds"))
        if validation.get("qualification") is not None and validation.get("qualification") == anchor.get("qualification"):
            result["current_validation"]["qualification_alias"] = "anchor.qualification"
        else:
            result["current_validation"]["qualification"] = validation.get("qualification")
        if validation.get("holds") == anchor.get("full_holdouts"):
            result["current_validation"]["holds_alias"] = "anchor.full_holdouts"
        else:
            result["current_validation"]["holds"] = holdouts(validation.get("holds", []))
    if case.get("frozen_predictions"):
        if case["frozen_predictions"] == [anchor.get("frozen_prediction")]:
            result["current_frozen_predictions_alias"] = ["anchor.frozen_prediction"]
        else:
            result["current_frozen_predictions"] = case["frozen_predictions"]
    for key in ("paired_native_numerical_checks", "measured_bank_numerical_checks", "measured_numerical_checks"):
        if isinstance(case.get(key), list):
            result[key] = numeric_checks(case[key])
    return result


def delay_summary(value):
    """Aggregate post-kernel synthetic timing while retaining its raw-event hash."""
    result = {key: item for key, item in value.items() if key != "events"}
    events = value.get("events", [])
    result["event_count"] = len(events)
    result["events_sha256"] = digest(events)
    result["event_count_by_cfo_count"] = dict(collections.Counter(str(row.get("cfo_count")) for row in events))
    result["event_aggregates"] = {}
    for key in ("original_real_kernel_wrapped_seconds", "requested_synthetic_delay_seconds",
                "measured_synthetic_delay_seconds", "returned_wrapped_seconds", "actual_parent_request_seconds"):
        points = [row[key] for row in events if isinstance(row.get(key), (int, float)) and math.isfinite(row[key])]
        if points:
            result["event_aggregates"][key] = {"count": len(points), "sum": math.fsum(points),
                                                "min": min(points), "max": max(points)}
    result["aggregation_scope"] = "recorded synthetic delay bookkeeping; not a new performance confidence interval"
    return result


def sustained_summary(row):
    result = select(row, ("schema", "kind", "commitment", "observed_batch_trials",
        "observed_pipeline_seconds", "observed_receiver_seconds", "observed_generation_setup_other_seconds",
        "observed_process_startup_output_seconds", "observed_external_wall_seconds",
        "observed_external_elapsed_seconds", "observed_pipeline_span_seconds", "minimum_seconds",
        "sustained_threshold_reached", "predicted_vs_actual", "quarter_trial_counts",
        "quarter_mean_pipeline_seconds_per_trial", "first_to_last_quarter_mean_ratio", "coverage",
        "counter_summary", "qualification_claim", "interpretation", "full_cfo_count",
        "expected_group_count_per_repetition", "source_identity", "fixture_hashes", "numeric_comparison"))
    if "repetitions" in row:
        result["repetition_count"] = len(row["repetitions"])
        result["repetitions"] = [select(r, ("index", "preparation_seconds", "score_including_finish_seconds",
            "full_point_seconds", "measured_group_count")) for r in row["repetitions"]]
    return result


def backend_summary(report):
    result = select(report, ("schema", "device", "status", "exit_code", "complete_required_coverage",
        "elapsed_seconds", "budget_seconds", "stress_seconds_per_case", "profile", "scope", "candidate",
        "reference", "harness_sha256", "native_binary_sha256", "native_reference_is_candidate",
        "native_receiver_performance", "native_receiver_target", "tensor_receiver_policy", "uncertainty",
        "adaptive_policy", "required_case_ids", "fixture_preparation_seconds", "hardware_health",
        "cross_architecture", "warnings", "failures", "descendant_cleanup"))
    result["completed_coverage_record"] = complete(report)
    result["cases"] = [case_summary(case) for case in report.get("cases", [])]
    result["sustained_checks"] = [sustained_summary(row) for row in report.get("sustained_checks", [])]
    profile = report.get("hardware_profile", {})
    result["hardware_profile"] = select(profile, ("schema", "status", "device", "hardware", "elapsed_seconds"))
    result["hardware_profile"]["cases"] = {name: select(row, ("status", "reason", "input_storage",
        "multiplication", "accumulation", "output", "operations_per_second", "bytes_per_second",
        "process_cpu_cores_used", "wall_seconds", "device_seconds"))
        for name, row in profile.get("cases", {}).items()}
    paths = report.get("executed_path_coverage", {})
    result["executed_path_coverage"] = select(paths, ("schema", "scope", "contract_sha256", "device", "threads",
        "complete_applicable_coverage", "elapsed_seconds", "full_runtime_prediction_qualified",
        "prediction_scope", "unsupported_ids", "failed_ids"))
    result["executed_path_coverage"]["records"] = [select(row, ("id", "status", "applicable",
        "source_sha256", "execution_witnesses", "profiled_coverage_seconds", "unprofiled_diagnostic_seconds",
        "diagnostic_timing_scope", "full_runtime_prediction_qualified", "error_type", "error"))
        for row in paths.get("records", [])]
    return result


def followup_complete(report):
    return (report.get("status") in ("passed", "warning", "failed", "regression", "unqualified", "completed")
            and type(report.get("exit_code")) is int
            and isinstance(report.get("completed_unix_seconds"), (int, float)))


def followup_summary(report):
    result = select(report, ("schema", "status", "exit_code", "scope", "production_performance_claim_eligible",
        "experiment", "warnings", "failures", "elapsed_seconds", "completed_unix_seconds", "input",
        "selection", "original_forecast", "reference", "real_worker_identities", "worker_identity",
        "worker_identity_sha256", "worker_external_startup_seconds", "environment_sha256",
        "hardware_identity_scope", "precision_qualification", "selected_precision", "precision_selection_scope",
        "fixture_preparation_seconds", "fixture_preparation_scope", "effective_anchor_directory",
        "anchor_inputs", "anchor_preflight", "frozen_commitment", "commitments", "worker_cleanup",
        "provenance_guard", "observation_started_unix_seconds", "observation_completed_unix_seconds",
        "independent_observation_elapsed_seconds"))
    if "case" in report:
        result["case_sha256"] = digest(report["case"])
        result["case"] = select(report["case"], ("id", "adapter", "configuration", "fixture_hashes",
            "source_bound_metadata", "performance_environment", "input_directory", "lag_max_seconds",
            "lag_step_samples", "group_tile", "memory_mib", "fixture_scope"))
        if isinstance(report["case"].get("frequency_offsets_hz"), list):
            bank = report["case"]["frequency_offsets_hz"]
            result["case"]["frequency_bank"] = {"count": len(bank), "sha256": digest(bank),
                "minimum_hz": min(bank) if bank else None, "maximum_hz": max(bank) if bank else None}
    for key in ("native_result", "fft_result"):
        if isinstance(report.get(key), dict):
            result[key] = case_summary(report[key])
    if isinstance(report.get("sustained_result"), dict):
        result["sustained_result"] = sustained_summary(report["sustained_result"])
    if isinstance(report.get("synthetic_delay_observations"), dict):
        result["synthetic_delay_observations"] = delay_summary(report["synthetic_delay_observations"])
    return result


def summarize(report, *, allow_partial=False):
    if report.get("schema") in FOLLOWUP_SCHEMAS:
        full = followup_complete(report)
        if not full and not allow_partial:
            raise ValueError("follow-up is running or lacks a completion record; use --allow-partial")
        return {"schema": SCHEMA,
                "summary_scope": "recorded evidence only; statistics and source files are not revalidated",
                "input_evidence_complete": full, "partial_snapshot": not full,
                "completion_scope": "focused invocation finalized; does not imply qualified prediction or full-suite coverage",
                "recorded_status": report.get("status"), "recorded_exit_code": report.get("exit_code"),
                "recorded_elapsed_seconds": report.get("elapsed_seconds"),
                "warnings": report.get("warnings", []), "failures": report.get("failures", []),
                "followup": followup_summary(report)}
    if report.get("schema") != "triad-performance-v2":
        raise ValueError("unsupported performance report schema")
    backends = report.get("backends") if "backends" in report else [report]
    if not isinstance(backends, list) or not all(isinstance(row, dict) for row in backends):
        raise ValueError("malformed backend list")
    full = complete(report) and bool(backends) and all(complete(row) for row in backends)
    if not full and not allow_partial:
        raise ValueError("report is running or coverage-incomplete; use --allow-partial to label an incomplete snapshot")
    return {"schema": SCHEMA, "summary_scope": "recorded evidence only; statistics and source files are not revalidated",
            "input_evidence_complete": full, "partial_snapshot": not full,
            "recorded_status": report.get("status"), "recorded_exit_code": report.get("exit_code"),
            "recorded_elapsed_seconds": report.get("elapsed_seconds"),
            "warnings": report.get("warnings", []), "failures": report.get("failures", []),
            "backends": [backend_summary(row) for row in backends]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args(argv)
    before = args.input.stat()
    payload = args.input.read_bytes()
    after = args.input.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        parser.error("input changed during reading; wait for a stable report")
    try:
        raw = gzip.decompress(payload) if args.input.suffix == ".gz" else payload
        result = summarize(json.loads(raw), allow_partial=args.allow_partial)
        result["input"] = {"path": str(args.input.resolve()), "sha256": hashlib.sha256(payload).hexdigest(),
                           "bytes": len(payload), "encoding": "gzip-json" if raw is not payload else "json"}
        encoded = json.dumps(result, indent=2, allow_nan=False) + "\n"
    except (ValueError, TypeError, KeyError) as error:
        parser.error(str(error))
    if args.output:
        with args.output.open("x") as stream:
            stream.write(encoded)
    else:
        sys.stdout.write(encoded)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

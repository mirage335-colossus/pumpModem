#!/usr/bin/env python3
"""Run five disclosed wrapper controls through the actual reject-only guard.

This is compact experimental evidence, not a receiver benchmark or hardware
qualification. Both sources wrap the same unchanged binary; deliberate sleep
is outside the native receiver timer. Do not tune/retry based on the results.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


WRAPPER = r'''
import hashlib, json, os, subprocess, sys, time
from pathlib import Path
config = CONFIG
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
if sha(config['binary']) != config['binary_sha256']:
    print('control native binary identity changed', file=sys.stderr)
    raise SystemExit(92)
args = sys.argv[1:]
indices = [i for i,v in enumerate(args) if v == '--seconds']
if not indices:
    print('control requires explicit native --seconds', file=sys.stderr)
    raise SystemExit(93)
index = indices[-1] + 1
requested = float(args[index])
actual_args = list(args)
changed_work = config['mode'] == 'changed-work' and config['role'] == 'candidate'
if changed_work:
    actual_args[index] = repr(requested * 2.)
selected = config['mode'] == 'environment' or (config['role'] == 'candidate' and
    (config['mode'] == 'general' or (config['mode'] == 'full-only' and requested >= config['threshold_seconds'])))
delay = config['delay_seconds'] if selected else 0.
before = time.perf_counter()
if delay:
    time.sleep(delay)
child_start = time.perf_counter()
child = subprocess.run([config['binary'], *actual_args], capture_output=True)
child_end = time.perf_counter()
record = dict(config=config, wrapper_sha256=sha(__file__), requested_argv=args,
    actual_argv=[config['binary'], *actual_args], requested_seconds=requested,
    actual_requested_seconds=float(actual_args[index]), requested_injected_seconds=delay,
    actual_pre_native_delay_seconds=child_start-before, native_child_seconds=child_end-child_start,
    returned_exit_code=child.returncode, forwarded_stdout_sha256=hashlib.sha256(child.stdout).hexdigest(),
    forwarded_stderr_sha256=hashlib.sha256(child.stderr).hexdigest(),
    stage='pre-native setup outside native receiver and pipeline timers',
    scope='explicit process delay/work control; not a physical CPU slowdown or decoder change')
ledger = Path(config['ledger'])
ledger.mkdir(parents=True, exist_ok=True)
stem = config['role'] + '-' + str(os.getpid())
(ledger/(stem+'.json')).write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
if child.stderr:
    (ledger/(stem+'.stderr')).write_bytes(child.stderr)
sys.stdout.buffer.write(child.stdout)
sys.stderr.buffer.write(child.stderr)
sys.stdout.buffer.flush()
sys.stderr.buffer.flush()
if child.returncode < 0:
    os.kill(os.getpid(), -child.returncode)
raise SystemExit(child.returncode)
'''


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def run_bounded(command, timeout):
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          start_new_session=True) as process:
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.communicate(timeout=2.)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.communicate()
            raise
        return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--binary', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('execution'))
    parser.add_argument('--budget-seconds', type=float, default=120.)
    args = parser.parse_args()
    root = args.root.resolve()
    binary = (args.binary or root/'build/dev-cli/triad_long').resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    if not 0 < args.budget_seconds <= 120:
        raise ValueError('actual-control budget must be in (0,120] seconds')
    sys.path.insert(0, str(root/'tools'))
    import triad_perf_native as native
    case = next(c for c in native.scenarios('ci') if c['id'] == 'native-null')
    if case['target_seconds'] != 32.8 or case.get('batch_trials') != 4:
        raise ValueError('frozen native-null 32.8-second/four-trial control geometry changed')
    start = time.monotonic()
    deadline = start + args.budget_seconds
    modes = ('neutral', 'general', 'full-only', 'changed-work', 'environment')
    plan = dict(schema='triad-guard-actual-process-controls-v1', driver_sha256=sha(__file__),
        native_binary=str(binary), native_binary_sha256=sha(binary), native_case=case,
        modes=list(modes), injected_seconds=.10, full_threshold_seconds=32.8, short_probe_seconds=8.,
        diagnostic_workflow_job_count=33, diagnostic_hypothesis_count=1,
        multiplicity_scope='H=1 and diagnostic J=33 reproduce the per-hypothesis alpha of H=33,J=1; no parallel jobs or complete-suite coverage are claimed',
        expected_per_confirmation_look_alpha=.01/33,
        root=str(root), native_source_binding='same supplied binary under both source roles; no new compilation claim',
        source_sha256={str(p.relative_to(root)):sha(p) for p in (root/'tools').glob('triad_perf_guard*.py')},
        control_scope='actual complete guard executions with disclosed sleep or changed actual duration; not hardware timing qualification',
        budget_seconds=args.budget_seconds, no_retry_or_retuning=True)
    wrappers = {}
    for mode in modes:
        folder = output/mode
        folder.mkdir()
        wrappers[mode] = {}
        for role in ('reference', 'candidate'):
            config = dict(binary=str(binary), binary_sha256=plan['native_binary_sha256'], mode=mode, role=role,
                          delay_seconds=.10, threshold_seconds=32.8, ledger=str(folder/'wrapper-ledger'))
            wrapper = folder/(role+'-native')
            wrapper.write_text('#!'+sys.executable+'\n'+WRAPPER.replace('CONFIG', repr(config), 1))
            wrapper.chmod(0o700)
            wrappers[mode][role] = wrapper
    plan['wrapper_hashes'] = {mode:{role:sha(path) for role,path in pair.items()} for mode,pair in wrappers.items()}
    write_json(output/'plan.json', plan)
    result = dict(plan=plan, controls=[], complete=False)
    write_json(output/'summary.json', result)
    for offset, mode in enumerate(modes):
        folder = output/mode
        row = dict(mode=mode, wrappers={role:dict(path=str(path), sha256=sha(path))
                                      for role,path in wrappers[mode].items()})
        try:
            if mode == 'full-only':
                probes = {role:native.run_native(path, case, 8., 190_000+offset,
                    threads=1, deadline=deadline, timeout=max(.01, deadline-time.monotonic()))
                    for role,path in wrappers[mode].items()}
                row['short_probe'] = dict(raw=probes, agreement=native.compare_native_outputs(
                    probes['reference'], probes['candidate']))
            remaining = deadline-time.monotonic()
            if remaining <= 3:
                raise TimeoutError('actual-control campaign budget exhausted')
            command = [sys.executable,str(root/'tools/triad_perf_guard.py'),'--profile','ci',
                '--candidate-root',str(root),'--reference-root',str(root),
                '--binary',str(wrappers[mode]['candidate']),'--reference-binary',str(wrappers[mode]['reference']),
                '--case','native-null','--skip-hardware-probes','--device','cpu','--threads','2',
                '--workflow-job-count','33',
                '--native-threads','1','--seed',str(190_100+offset*100),
                '--budget-seconds',str(min(45.,remaining-2.)),'--output',str(folder/'guard')]
            before = time.monotonic()
            proc = run_bounded(command, remaining)
            row.update(argv=command, external_wall_seconds=time.monotonic()-before, exit_code=proc.returncode)
            (folder/'guard.stdout').write_bytes(proc.stdout)
            (folder/'guard.stderr').write_bytes(proc.stderr)
            report = json.loads((folder/'guard/summary.json').read_text())
            guard_plan = json.loads((folder/'guard/plan.json').read_text())
            row['multiplicity'] = {key:guard_plan[key] for key in (
                'family_size','per_hypothesis_alpha','per_confirmation_look_alpha','looks')}
            row['multiplicity']['workflow_job_count'] = guard_plan['policy']['workflow_job_count']
            if (guard_plan['family_size'] != 1 or guard_plan['policy']['workflow_job_count'] != 33 or
                    guard_plan['per_confirmation_look_alpha'] != .01/33 or guard_plan['looks'] != [12]):
                raise ValueError('control multiplicity does not match frozen 33-case CI allocation')
            row.update(guard_status=report['status'], confirmed_regressions=report['confirmed_regressions'],
                functional_failures=report['functional_failures'], measurement_count=report['measurement_count'],
                observations=[dict(phase=r['phase'],status=r['status'],
                    ratio=(r['observation']['candidate_seconds']/r['observation']['reference_seconds'])
                    if 'observation' in r else None) for r in report['measurements']])
            if mode in ('general','full-only'):
                row['expected_behavior_observed'] = proc.returncode == 2 and report['confirmed_regressions'] == ['native-null'] and not report['functional_failures']
            elif mode == 'changed-work':
                row['expected_behavior_observed'] = proc.returncode == 2 and bool(report['functional_failures']) and not report['confirmed_regressions']
            else:
                row['expected_behavior_observed'] = proc.returncode == 0 and not report['functional_failures'] and not report['confirmed_regressions']
            ledger = [json.loads(p.read_text()) for p in sorted((folder/'wrapper-ledger').glob('*.json'))]
            row['wrapper_ledger'] = ledger
            if mode == 'full-only':
                short = [r for r in ledger if r['requested_seconds'] == 8.]
                row['short_probe_no_delay'] = len(short) == 2 and all(r['requested_injected_seconds'] == 0. for r in short)
                row['expected_behavior_observed'] &= row['short_probe_no_delay']
            row['status'] = 'completed'
        except Exception as exc:
            row.update(status='incomplete', error=type(exc).__name__+': '+str(exc), expected_behavior_observed=False)
        result['controls'].append(row)
        result['elapsed_seconds'] = time.monotonic()-start
        write_json(output/'summary.json',result)
        if row['status'] != 'completed':
            break
    result['complete'] = len(result['controls']) == len(modes) and all(r['status'] == 'completed' for r in result['controls'])
    result['all_expected_behaviors_observed'] = result['complete'] and all(r['expected_behavior_observed'] for r in result['controls'])
    result['elapsed_seconds'] = time.monotonic()-start
    write_json(output/'summary.json',result)
    print(json.dumps({key:result[key] for key in ('complete','all_expected_behaviors_observed','elapsed_seconds')}))
    return 0 if result['all_expected_behaviors_observed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Seven additional fixed-case oracle measurements; no threshold tuning."""
import importlib.util
import json
import math
from pathlib import Path
import resource
from statistics import NormalDist
import sys
import time

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("known_channel_diagnostic", root / "diagnose.py")
diagnostic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diagnostic)
repo = root.parents[2]
campaign = repo / "local-evidence/triad-helper-001/eme-target-campaign"
started = time.perf_counter()


def cpu_seconds():
    child = resource.getrusage(resource.RUSAGE_CHILDREN)
    own = resource.getrusage(resource.RUSAGE_SELF)
    return own.ru_utime + own.ru_stime + child.ru_utime + child.ru_stime


cpu_started = cpu_seconds()
original_capture = diagnostic.capture


def budgeted_capture(*args, **kwargs):
    if cpu_seconds() - cpu_started > 110 or time.perf_counter() - started > 140:
        raise RuntimeError("bounded remaining-signal diagnostic budget reached before another export")
    return original_capture(*args, **kwargs)


diagnostic.capture = budgeted_capture
retained_cases = []
for index in range(8):
    path = campaign / f"signal-{index:04d}" / "result.json"
    result = diagnostic.load(path)
    assert result["trial"]["seed"] == 92019 + index
    assert result["trial"]["bit"] == index % 2
    retained_cases.append(path)
records = []
required_distance_ratio = 2 * NormalDist().inv_cdf(.99) ** 2
for index, retained_path in enumerate(retained_cases):
    seed = 92019 + index
    if seed == 92021:
        destination = root
        result = diagnostic.load(root / "oracle.json")
        reused = True
    else:
        destination = root / f"signal-{index:04d}"
        destination.mkdir()
        diagnostic.ROOT = destination
        diagnostic.RETAINED = retained_path
        diagnostic.main()
        result = diagnostic.load(destination / "oracle.json")
        removed = []
        for capture in result["captures"]:
            for filename in ("observation.c128", "validity.u8"):
                path = destination / capture["name"] / filename
                removed.append({"path": str(path.relative_to(destination)), "bytes": path.stat().st_size,
                                "sha256": capture["sha256"][filename]})
                path.unlink()
        result["evidence_retention"] = {
            "raw_arrays_retained": False,
            "note": "Only these newly generated large IQ/validity arrays were deleted after exact retained-raw hash verification and oracle metrics were saved. Hashes, commands, manifests, evaluator truth and metrics remain. Original seed 92021 arrays are retained in the parent directory.",
            "removed_files": removed,
        }
        diagnostic.save(destination / "oracle.json", result)
        reused = False
    assert result["original_failure"]["raw_match"] and result["original_failure"]["validity_match"]
    record = {"trial": f"signal-{index:04d}", "seed": seed, "true_bit": result["true_bit"],
              "oracle_bit": result["oracle_decision_bit"],
              "oracle_error": result["oracle_decision_bit"] != result["true_bit"],
              "llr_bit1_over_bit0": result["llr_bit1_over_bit0_residual_noise_corrected"],
              "d_squared_over_noise_variance": result["d_squared_over_noise_variance"],
              "conditional_equal_prior_pe": result["conditional_equal_prior_binary_error_probability"],
              "ideal_energy_multiplier_for_1pct": required_distance_ratio / result["d_squared_over_noise_variance"],
              "ideal_energy_increase_db_for_1pct": 10 * math.log10(required_distance_ratio / result["d_squared_over_noise_variance"]),
              "raw_sha256": result["original_failure"]["actual_raw_sha256"],
              "raw_hash_match": result["original_failure"]["raw_match"],
              "reused_existing_diagnostic": reused,
              "complete_oracle_result": str(destination / "oracle.json"),
              "raw_arrays_retained": reused}
    records.append(record)
    print(json.dumps({"completed": record}), flush=True)
summary = {
    "scope": "Eight fixed retained EME target signal trials; full-complex equal-prior binary oracle with exact synchronization, epoch and channel realization. No practical receiver rerun, calibration/admission claim, thresholds or model tuning.",
    "cases": records,
    "oracle_actual_errors": sum(record["oracle_error"] for record in records),
    "signal_count": len(records),
    "mean_conditional_equal_prior_pe": sum(record["conditional_equal_prior_pe"] for record in records) / len(records),
    "sum_conditional_equal_prior_pe": sum(record["conditional_equal_prior_pe"] for record in records),
    "required_d_squared_over_variance_for_1pct": required_distance_ratio,
    "energy_scale_scope": "Ideal conditional known-channel bit-distance energy scaling only, 2*NormalDist.inv_cdf(.99)^2. It is not an achieved duration, a planner result, or a practical receiver guarantee.",
    "additional_exports": 21,
    "existing_seed_reused": 92021,
    "additional_wall_seconds": time.perf_counter() - started,
    "additional_process_and_children_cpu_seconds": cpu_seconds() - cpu_started,
    "all_original_raw_hashes_matched": all(record["raw_hash_match"] for record in records),
    "source_or_campaign_modified": False,
}
diagnostic.save(root / "eight-signal-oracle.json", summary)
print(json.dumps({key: value for key, value in summary.items() if key != "cases"}, indent=2))

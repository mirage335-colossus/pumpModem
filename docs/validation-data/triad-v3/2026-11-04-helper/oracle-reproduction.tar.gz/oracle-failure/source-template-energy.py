#!/usr/bin/env python3
"""Public source bit-difference energy; no receiver adaptation."""
import hashlib
import json
import math
import os
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "2"
os.environ["OMP_NUM_THREADS"] = "2"
import numpy as np

root = Path(__file__).resolve().parent
repo = root.parents[2]
protocol = json.loads((repo / "local-evidence/triad-helper-001/eme-target-campaign/protocol.json").read_text())
directory = repo / protocol["configuration"]["templates"]
manifest = json.loads((directory / "manifest.json").read_text())
oracle = json.loads((root / "oracle.json").read_text())
path = directory / manifest["templates"]["file"]
hasher = hashlib.sha256()
with path.open("rb") as stream:
    while block := stream.read(1024 * 1024):
        hasher.update(block)
template_sha = hasher.hexdigest()
assert template_sha == protocol["template_sha256"]
shape = tuple(manifest["templates"]["shape"])
templates = np.memmap(path, dtype="<c16", mode="r", shape=shape)
epoch_index = manifest["templates"]["epoch_offsets_seconds"].index(0)
bit0, bit1 = templates[epoch_index]
energy0 = float(np.vdot(bit0, bit0).real)
energy1 = float(np.vdot(bit1, bit1).real)
delta = bit1 - bit0
d2 = float(np.vdot(delta, delta).real)
midpoint = (bit0 + bit1) * .5
common = float(np.vdot(midpoint, midpoint).real)
average = (energy0 + energy1) / 2
fmt = manifest["format"]
fine_rate, dwell = fmt["fine_chip_rate_hz"], fmt["dwell_seconds"]
guard = fmt["quiet_seconds"] + fmt["ramp_seconds"] + fmt["margin_seconds"] + 8 / fine_rate
first = math.ceil(guard * fine_rate)
last = math.floor((dwell - guard) * fine_rate)
calendar_cells = round(fmt["bit_seconds"] * fine_rate)
result = {
    "template_file": str(path), "sha256": template_sha,
    "expected_sha256": protocol["template_sha256"], "hash_match": True,
    "shape": shape, "epoch_offset_seconds": 0,
    "source_bit0_energy_samples": energy0, "source_bit1_energy_samples": energy1,
    "source_bit0_energy_seconds": energy0 / manifest["sample_rate_hz"],
    "source_bit1_energy_seconds": energy1 / manifest["sample_rate_hz"],
    "source_bit_difference_energy_samples": d2,
    "source_bit_difference_energy_seconds": d2 / manifest["sample_rate_hz"],
    "difference_energy_over_average_source_energy": d2 / average,
    "difference_energy_over_sum_source_energy": d2 / (energy0 + energy1),
    "symmetric_bit_dependent_half_difference_energy_samples": d2 / 4,
    "symmetric_bit_dependent_fraction_of_average_energy": d2 / (4 * average),
    "common_midpoint_energy_samples": common,
    "energy_decomposition_residual": common + d2 / 4 - average,
    "emitted_source_bit0_energy_samples": oracle["source_energy_bit0"]["data_energy_samples"],
    "emitted_source_bit1_energy_samples": oracle["source_energy_bit1"]["data_energy_samples"],
    "source_bit0_template_vs_emitted_absolute_error": energy0 - oracle["source_energy_bit0"]["data_energy_samples"],
    "source_bit1_template_vs_emitted_absolute_error": energy1 - oracle["source_energy_bit1"]["data_energy_samples"],
    "propagated_difference_energy_samples": oracle["d_squared_samples"],
    "propagated_over_source_difference_energy": oracle["d_squared_samples"] / d2,
    "template_requested_bit_seconds": fmt["requested_bit_seconds"],
    "observed_requested_bit_seconds": json.loads((root / "noisy/manifest.json").read_text())["format"]["requested_bit_seconds"],
    "actual_bit_seconds": fmt["bit_seconds"],
    "fine_chip_rate_hz": fine_rate,
    "fine_calendar_cells": calendar_cells,
    "protected_payload_fine_coefficients": fmt["fine_coefficients"],
    "protected_inner_coefficients": fmt["inner_coefficients"],
    "payload_fraction_of_calendar_cells": fmt["fine_coefficients"] / calendar_cells,
    "full_pulse_protected_guard_seconds": guard,
    "protected_center_indices_per_dwell": list(range(first, last + 1)),
    "protected_centers_per_dwell": max(0, last - first + 1),
    "scope": "Full public source templates with fixed calibration. The common midpoint includes common cover and any common payload component; it is not a separate exact cover-only energy measurement. Only the bit difference cancels all common cover. Propagated difference additionally includes the selected channel realization.",
}
(root / "source-template-energy.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(result, indent=2))

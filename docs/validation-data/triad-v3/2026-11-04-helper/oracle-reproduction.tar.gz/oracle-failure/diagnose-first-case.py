#!/usr/bin/env python3
"""Known-channel/synchronization diagnostic only; never a practical decoder."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import time

os.environ["OPENBLAS_NUM_THREADS"] = "2"
os.environ["OMP_NUM_THREADS"] = "2"
import numpy as np

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
RETAINED = REPO / "local-evidence/triad-helper-001/eme-target-campaign/signal-0002/result.json"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def capture(retained, name, bit, cn0):
    command = list(retained["export_command"])
    command[command.index("--output") + 1] = str(ROOT / name)
    command[command.index("--bit") + 1] = str(bit)
    command[command.index("--cn0") + 1] = str(cn0)
    start = time.perf_counter()
    result = subprocess.run(command, cwd=REPO, capture_output=True, text=True, timeout=40)
    elapsed = time.perf_counter() - start
    (ROOT / (name + ".log")).write_text(result.stdout + result.stderr)
    record = {"name": name, "command": command, "returncode": result.returncode, "wall_seconds": elapsed}
    save(ROOT / (name + "-command.json"), record)
    if result.returncode:
        raise RuntimeError(f"export failed: {record}; {result.stderr}")
    directory = ROOT / name
    manifest = load(directory / "manifest.json")
    truth = load(directory / "evaluator-truth.json")
    record["sha256"] = {filename: digest(directory / filename) for filename in
                        ("observation.c128", "validity.u8", "manifest.json", "evaluator-truth.json")}
    save(ROOT / (name + "-command.json"), record)
    return record, manifest, truth


def main():
    started = time.perf_counter()
    retained = load(RETAINED)
    binary = Path(retained["export_command"][0])
    noisy, manifest, truth = capture(retained, "noisy", 0, 1.5)
    matched = noisy["sha256"]["observation.c128"] == retained["input_sha256"]
    valid_matched = noisy["sha256"]["validity.u8"] == retained["validity_sha256"]
    verification = {"retained_result": str(RETAINED), "retained_result_sha256": digest(RETAINED),
                    "expected_raw_sha256": retained["input_sha256"],
                    "actual_raw_sha256": noisy["sha256"]["observation.c128"],
                    "raw_match": matched, "validity_match": valid_matched,
                    "exporter_sha256": digest(binary), "original_decisions": retained["decisions"]}
    save(ROOT / "hash-verification.json", verification)
    if not matched or not valid_matched:
        raise RuntimeError("reconstructed capture differs; oracle analysis was not run")
    print("Original noisy capture SHA-256 and validity verified.", flush=True)
    near0, m0, t0 = capture(retained, "near-mean-bit0", 0, 200)
    near1, m1, t1 = capture(retained, "near-mean-bit1", 1, 200)
    for candidate, candidate_truth in ((m0, t0), (m1, t1)):
        for key in ("calendar", "helper_plan", "format", "channel"):
            assert candidate[key] == manifest[key], key
        for key in ("tx", "rx", "arrival_seconds", "random_seed_roots"):
            assert candidate_truth[key] == truth[key], key
        for key in ("reference_data_mean_norm", "post_plan_composite_gain", "template_data_gain"):
            assert candidate["power"][key] == manifest["power"][key], key
    assert near0["sha256"]["validity.u8"] == near1["sha256"]["validity.u8"] == retained["validity_sha256"]
    assert set((ROOT / "noisy/validity.u8").read_bytes()) == {1}
    variance = manifest["power"]["complex_noise_variance"]
    near_variance = m0["power"]["complex_noise_variance"]
    assert near_variance == m1["power"]["complex_noise_variance"]
    q = math.sqrt(near_variance / variance)
    y = np.memmap(ROOT / "noisy/observation.c128", dtype="<c16", mode="r")
    z0 = np.memmap(ROOT / "near-mean-bit0/observation.c128", dtype="<c16", mode="r")
    z1 = np.memmap(ROOT / "near-mean-bit1/observation.c128", dtype="<c16", mode="r")
    assert y.shape == z0.shape == z1.shape == tuple(manifest["observation"]["shape"])
    distance, llr_raw, llr_corrected, noise_energy, noise_dot, mean0_energy, mean1_energy = ([] for _ in range(7))
    fp64_vs_longdouble = []
    for first in range(0, y.size, 65536):
        last = min(y.size, first + 65536)
        noisy_block = np.asarray(y[first:last])
        near0_block, near1_block = np.asarray(z0[first:last]), np.asarray(z1[first:last])
        delta = near1_block - near0_block
        midpoint = (near0_block + near1_block) * .5
        raw = 2 * np.vdot(noisy_block - midpoint, delta).real / variance
        # Same noise seed and unchanged channel: z0=s0+q*n, y=s0+n.
        # Remove the tiny common residual noise from both near-means using
        # this identity. This is an evaluator-only precision crosscheck.
        noise = (noisy_block - near0_block) / (1 - q)
        corrected_midpoint = midpoint - q * noise
        llr_raw.append(float(raw))
        llr_corrected.append(float(2 * np.vdot(noisy_block - corrected_midpoint, delta).real / variance))
        distance.append(float(np.vdot(delta, delta).real))
        noise_energy.append(float(np.vdot(noise, noise).real))
        noise_dot.append(float(np.vdot(noise, delta).real))
        exact0, exact1 = near0_block - q * noise, near1_block - q * noise
        mean0_energy.append(float(np.vdot(exact0, exact0).real))
        mean1_energy.append(float(np.vdot(exact1, exact1).real))
        residual_ld = (noisy_block - corrected_midpoint).astype(np.clongdouble)
        delta_ld = delta.astype(np.clongdouble)
        reference = float(2 * np.sum(residual_ld.conj() * delta_ld, dtype=np.clongdouble).real / variance)
        fp64_vs_longdouble.append(abs(llr_corrected[-1] - reference))
    d2 = math.fsum(distance)
    ratio = d2 / variance
    statistic = math.fsum(llr_raw)
    corrected = math.fsum(llr_corrected)
    pe = .5 * math.erfc(math.sqrt(ratio / 4))
    result = {
        "scope": "Full-complex sampled equal-prior binary oracle conditional on the exact transmitted epoch, synchronization and full channel realization. Not an implementable receiver or a general reception/sensitivity claim.",
        "original_failure": verification,
        "captures": [noisy, near0, near1],
        "capture_samples": int(y.size),
        "sample_rate_hz": manifest["sample_rate_hz"],
        "original_noise_variance": variance,
        "near_mean_cn0_db_hz": 200,
        "near_mean_noise_variance": near_variance,
        "near_mean_noise_amplitude_ratio_q": q,
        "source_reference": {key: manifest["power"][key] for key in
                             ("reference_bit", "reference_epoch_seconds", "reference_window_seconds", "reference_data_mean_norm",
                              "reference_data_mean_real_power", "post_plan_composite_gain", "template_data_gain",
                              "reference_normalized_data_mean_norm", "reference_measured_helper_to_data_ratio", "nominal_helper_to_data_ratio")},
        "source_energy_bit0": t0["source_energy"],
        "source_energy_bit1": t1["source_energy"],
        "d_squared_samples": d2,
        "d_squared_over_noise_variance": ratio,
        "llr_bit1_over_bit0_near_means": statistic,
        "llr_bit1_over_bit0_residual_noise_corrected": corrected,
        "oracle_decision_bit": int(corrected > 0),
        "true_bit": 0,
        "llr_expected_given_bit0": -ratio,
        "llr_expected_given_bit1": ratio,
        "llr_standard_deviation": math.sqrt(2 * ratio),
        "conditional_equal_prior_binary_error_probability": pe,
        "pe_formula": "Q(sqrt(d_squared/(2*variance))) = 0.5*erfc(sqrt(d_squared/(4*variance)))",
        "mean0_complete_capture_energy_samples": math.fsum(mean0_energy),
        "mean1_complete_capture_energy_samples": math.fsum(mean1_energy),
        "noise_energy_over_expected": math.fsum(noise_energy) / (y.size * variance),
        "precision_crosscheck": {"llr_change_from_removing_common_200dbhz_noise": corrected - statistic,
                                 "predicted_llr_change": 2 * q * math.fsum(noise_dot) / variance,
                                 "max_per_chunk_fp64_vs_longdouble_llr_error": max(fp64_vs_longdouble),
                                 "noise_cancellation_in_candidate_difference": "same seed and variance; z1-z0 cancels near-noiseless additive noise to output-rounding accuracy"},
        "wall_seconds": time.perf_counter() - started,
        "practical_receiver_executed": False,
        "campaign_or_source_modified": False,
    }
    save(ROOT / "oracle.json", result)
    print(json.dumps({key: result[key] for key in
                      ("d_squared_samples", "d_squared_over_noise_variance", "llr_bit1_over_bit0_near_means",
                       "llr_bit1_over_bit0_residual_noise_corrected", "oracle_decision_bit",
                       "conditional_equal_prior_binary_error_probability", "precision_crosscheck", "wall_seconds")}, indent=2))


if __name__ == "__main__":
    main()

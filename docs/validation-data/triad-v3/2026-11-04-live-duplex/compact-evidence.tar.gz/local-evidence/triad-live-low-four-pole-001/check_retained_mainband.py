#!/usr/bin/env python3
"""Paired frozen-profile transfer check on two retained complete PCM captures."""
import hashlib
import json
from pathlib import Path
import tarfile
import time
import types

import numpy as np


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify(path, expected):
    actual = digest(path)
    if actual != expected:
        raise ValueError(f"identity mismatch: {path}")
    return actual


started = time.perf_counter()
here = Path(__file__).resolve().parent
evidence = here.parent
output = here / "retained-mainband-comparison.json"
if output.exists():
    raise FileExistsError("preserve existing comparison; refusing overwrite")
freeze = json.loads((here / "profile-freeze.json").read_text())
new_path = here / "audio-profile.json"
new_hash = verify(new_path, freeze["profile_sha256"])
new_profile = json.loads(new_path.read_text())
with tarfile.open(here / "executed-source.tar.gz", "r:gz") as archive:
    code = archive.extractfile("tools/triad_live_model.py").read()
source_hash = hashlib.sha256(code).hexdigest()
if source_hash != freeze["model_source_sha256"]:
    raise ValueError("frozen model implementation mismatch")
model = types.ModuleType("frozen_triad_model")
exec(compile(code, "archived-triad-live-model", "exec"), model.__dict__)
old_path = evidence / "triad-live-full-capture-001/audio-profile.json"
old_freeze = json.loads((old_path.parent / "profile-freeze.json").read_text())
old_hash = verify(old_path, old_freeze["profile_sha256"])
old_profile = json.loads(old_path.read_text())
cases = [("rate24000-carrier15500", "triad-live-full-capture-001", "triad-live-full-analysis-002"),
         ("aurora-each65", "triad-live-full-continuation-001", "triad-live-full-continuation-001")]
rows = []
for name, capture_directory, original_directory in cases:
    start = time.perf_counter()
    source = evidence / "triad-live-full-input-001" / name
    capture = evidence / capture_directory / name
    meta = json.loads((source / "stimulus.json").read_text())
    provider = json.loads((capture / "capture.json").read_text())
    receipt = json.loads((capture / "capture-identity.json").read_text())
    original_path = evidence / original_directory / (name + "-analysis.json")
    original = json.loads(original_path.read_text())
    if provider.get("status") != "complete" or provider.get("failure"):
        raise ValueError("capture is incomplete or failed")
    if any(provider.get("discontinuity", {}).get(k, True) for k in ("capture", "playback")):
        raise ValueError("capture/playback discontinuity")
    if any(provider.get(k) for k in ("cleanup_errors", "finalization_errors")):
        raise ValueError("provider finalization failed")
    if any(provider.get(k) != 0 for k in ("capture_returncode", "playback_returncode")):
        raise ValueError("capture/playback exit failure")
    identities = {
        "stimulus_sha256": verify(source / "stimulus.f32", receipt["stimulus_sha256"]),
        "capture_sha256": verify(capture / "capture.f32", receipt["capture_sha256"]),
        "provider_sha256": verify(capture / "provider.f32", receipt["provider_sha256"]),
        "original_analysis_sha256": digest(original_path),
        "capture_receipt_sha256": digest(capture / "capture-identity.json")}
    for key, path in [("capture_metadata_sha256", capture / "capture.json"),
                      ("stimulus_metadata_sha256", source / "stimulus.json"),
                      ("command_sha256", capture / "command.json")]:
        identities[key] = verify(path, receipt[key]) if key in receipt else digest(path)
    if identities["stimulus_sha256"] != meta["stimulus_sha256"] or identities["stimulus_sha256"] != provider["input_sha256"]:
        raise ValueError("stimulus/provider receipts disagree")
    if original["profile_sha256"] != old_hash:
        raise ValueError("retained original metrics used a different profile")
    fs = meta["sample_rate"]
    if fs != new_profile["sample_rate"] or provider["capture"]["logical_rate"] != fs:
        raise ValueError("sample-rate contract mismatch")
    if (capture / "capture.f32").stat().st_size != 4 * provider["capture"]["logical_samples"]:
        raise ValueError("capture length differs from finalized provider metadata")
    tx = np.fromfile(source / "stimulus.f32", dtype="<f4")
    rx = np.fromfile(capture / "capture.f32", dtype="<f4")
    aligned, valid, alignment = model.align_capture(tx, rx, fs, meta["markers"]["markers"])
    payload = np.zeros(len(tx), bool)
    a = meta["markers"]["payload"]["start"]
    b = a + meta["markers"]["payload"]["samples"]
    payload[a:b] = True
    payload &= valid
    pcm = model.quantize_production_playback(tx)
    metrics = {}
    for key, profile in [("original_profile_recomputed", old_profile), ("final_four_pole_profile", new_profile)]:
        prediction = model.simulate_audio_profile(tx, profile, include_noise=False, production_s16=True)
        metrics[key] = {
            "payload": model.assess_prediction(pcm, aligned, profile, payload, prediction=prediction),
            "wrapped": model.assess_prediction(pcm, aligned, profile, valid, prediction=prediction)}
    old = metrics["original_profile_recomputed"]["payload"]
    new = metrics["final_four_pole_profile"]["payload"]
    rows.append(dict(case=name, identities=identities,
        receipt_fields_absent=[key for key in ("capture_metadata_sha256", "stimulus_metadata_sha256", "command_sha256") if key not in receipt],
        alignment=alignment, original_retained_payload_metrics=original["payload_energy_and_model_residual"],
        metrics=metrics,
        energy_error_change_db=new["energy_prediction_error_db"]-old["energy_prediction_error_db"],
        residual_ratio_change_db=new["fixed_model_residual_to_signal_db"]-old["fixed_model_residual_to_signal_db"],
        elapsed_seconds=time.perf_counter()-start))
result = dict(scope="post-hoc transfer check on retained physical captures; no new hardware or fitting, no noise-margin/admission requalification",
    original_profile_sha256=old_hash, final_profile_sha256=new_hash, frozen_model_source_sha256=source_hash,
    analysis_source_sha256=digest(Path(__file__)), rows=rows,
    whole_prediction_reused_for_all_masks=True, total_analysis_seconds=time.perf_counter()-started)
output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
for row in rows:
    print(row["case"], json.dumps({"metrics": row["metrics"]["final_four_pole_profile"]["payload"],
        "energy_error_change_db": row["energy_error_change_db"], "residual_ratio_change_db": row["residual_ratio_change_db"]}))
print("total_seconds", result["total_analysis_seconds"])

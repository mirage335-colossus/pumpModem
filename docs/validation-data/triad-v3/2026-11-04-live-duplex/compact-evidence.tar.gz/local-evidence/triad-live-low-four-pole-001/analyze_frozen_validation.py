#!/usr/bin/env python3
"""Score one COMPLETED fresh LF capture against its pre-capture frozen model.

No hardware access, model refitting, threshold adjustment, or archive extraction.
The checked archived model bytes are executed directly, even if current tools
have subsequently changed. Run with OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import tarfile
import time
import types

import numpy as np
import scipy


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def checked(path, expected, description):
    actual = digest(path)
    if actual != expected:
        raise ValueError(f"{description} identity mismatch: {actual} != {expected}")
    return actual


started = time.perf_counter()
here = Path(__file__).resolve().parent
repo = here.parents[1]
output = here / "validation-result.json"
if output.exists():
    raise FileExistsError(f"retain the existing result; refusing to overwrite {output}")
freeze_path = here / "profile-freeze.json"
freeze = json.loads(freeze_path.read_text())
profile_path = here / "audio-profile.json"
profile_hash = checked(profile_path, freeze["profile_sha256"], "frozen profile")
profile = json.loads(profile_path.read_text())
archive = here / "executed-source.tar.gz"
with tarfile.open(archive, "r:gz") as source:
    model_bytes = source.extractfile("tools/triad_live_model.py").read()
model_hash = hashlib.sha256(model_bytes).hexdigest()
if model_hash != freeze["model_source_sha256"]:
    raise ValueError("archived model source does not match the pre-capture freeze")
model = types.ModuleType("frozen_triad_live_model")
model.__file__ = "executed-source.tar.gz/tools/triad_live_model.py"
exec(compile(model_bytes, model.__file__, "exec"), model.__dict__)

# No evolving receive samples are opened until completed-provider metadata
# proves successful capture, playback, finalization and continuous sampling.
capture_path = here / "validation/capture.json"
capture = json.loads(capture_path.read_text())
if capture.get("schema") != "triad-audio-capture-v1" or capture.get("status") != "complete":
    raise ValueError("capture is not complete; wait for the original owner process")
if capture.get("failure") or capture.get("cleanup_errors") or capture.get("finalization_errors"):
    raise ValueError("capture reports failure/cleanup/finalization errors")
if capture.get("capture_returncode") != 0 or capture.get("playback_returncode") != 0:
    raise ValueError("capture/playback did not exit successfully")
if any(capture.get("discontinuity", {}).get(k, True) for k in ("capture", "playback")):
    raise ValueError("continuous capture/playback evidence is invalid")
if not all(capture.get("audio_format", {}).get(k) for k in ("capture", "playback")):
    raise ValueError("actual provider format evidence is absent")

tx_path = here / "validation/tx.f32"
rx_path = here / "validation/rx.f32"
manifest_path = here / "validation/probe.json"
manifest = json.loads(manifest_path.read_text())
tx_hash = checked(tx_path, freeze["validation_stimulus_sha256"], "frozen validation stimulus")
if tx_hash != manifest["sample_sha256"] or tx_hash != capture["input_sha256"]:
    raise ValueError("probe/provider input does not match the frozen stimulus")
fs = profile["sample_rate"]
if manifest["sample_rate"] != fs or capture["capture"]["logical_rate"] != fs:
    raise ValueError("profile, probe and capture sample grids differ")
if rx_path.stat().st_size != 4 * capture["capture"]["logical_samples"]:
    raise ValueError("finalized capture sample count differs from its file")
if tx_path.stat().st_size != 4 * manifest["samples"]:
    raise ValueError("frozen stimulus sample count differs from its file")

training = Path(freeze["training_source"])
if not training.exists():
    training = repo / "local-evidence/triad-live-low-refinement-001/training"
training_hash = checked(training / "rx.f32", freeze["training_capture_sha256"], "LF training capture")
training_tx_hash = checked(training / "tx.f32", profile["low_frequency_section"]["source_sample_sha256"], "LF training stimulus")
broad_capture = repo / "local-evidence/triad-live-full-capture-001/training/capture.f32"
broad_hash = checked(broad_capture, freeze["broad_training_capture_sha256"], "broad training capture")
rx_hash = digest(rx_path)
identification_seconds = time.perf_counter() - started
tx = np.fromfile(tx_path, dtype="<f4")
rx = np.fromfile(rx_path, dtype="<f4")

stage = time.perf_counter()
aligned, valid, alignment = model.align_capture(tx, rx, fs, manifest["markers"])
alignment_seconds = time.perf_counter() - stage
stage = time.perf_counter()
result = model.assess_low_frequency_validation(tx, aligned, fs, manifest, profile, valid)
tone_seconds = time.perf_counter() - stage
stage = time.perf_counter()
prediction = model.simulate_audio_profile(tx, profile, include_noise=False, production_s16=True)
pcm = model.quantize_production_playback(tx)
payload = np.zeros(len(tx), bool)
a = manifest["payload"]["start"]
b = a + manifest["payload"]["samples"]
payload[a:b] = True
payload &= valid
result["payload_prediction"] = model.assess_prediction(pcm, aligned, profile, payload, prediction=prediction)
result["wrapped_prediction"] = model.assess_prediction(pcm, aligned, profile, valid, prediction=prediction)
prediction_seconds = time.perf_counter() - stage
result.update(
    analysis_utc=datetime.now(timezone.utc).isoformat(), alignment=alignment,
    profile_sha256=profile_hash,
    frozen_envelope={"gain_db": freeze["gain_envelope_db"], "phase_radians": freeze["phase_envelope_radians"]},
    identities={"model_source_sha256": model_hash, "model_archive_sha256": digest(archive),
                "freeze_sha256": digest(freeze_path), "analysis_source_sha256": digest(Path(__file__)),
                "validation_stimulus_sha256": tx_hash, "validation_capture_sha256": rx_hash,
                "validation_manifest_sha256": digest(manifest_path), "capture_metadata_sha256": digest(capture_path),
                "lf_training_capture_sha256": training_hash, "lf_training_stimulus_sha256": training_tx_hash,
                "broad_training_capture_sha256": broad_hash},
    timing={"identity_seconds": identification_seconds, "alignment_seconds": alignment_seconds,
            "tone_analysis_seconds": tone_seconds, "continuous_prediction_and_metrics_seconds": prediction_seconds,
            "total_analysis_seconds": time.perf_counter()-started},
    environment={"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__,
                 "platform": platform.platform()},
    evidence_scope="fresh variant1 physical validation after four-pole profile freeze; no fitting of this capture",
    model_parameter_estimation_seconds=0., whole_prediction_reused_for_all_masks=True)
if (result["gain_envelope_db"] != freeze["gain_envelope_db"] or
        result["phase_envelope_radians"] != freeze["phase_envelope_radians"]):
    raise ValueError("analysis envelope differs from the pre-capture freeze")
output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"output": str(output), "status": result["status"],
                  "resolved_count": result["resolved_count"], "timing": result["timing"]}, indent=2))

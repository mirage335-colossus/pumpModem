#!/usr/bin/env python3
"""Compact figure from retained frozen profiles and physical line measurements."""
import hashlib
import json
import os
from pathlib import Path
import tarfile
import types

os.environ.setdefault("MPLCONFIGDIR", "/tmp/triad-live-matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

here = Path(__file__).resolve().parent
evidence = here.parent
fresh = json.loads((here / "validation-result.json").read_text())
with tarfile.open(here / "executed-source.tar.gz", "r:gz") as archive:
    code = archive.extractfile("tools/triad_live_model.py").read()
if hashlib.sha256(code).hexdigest() != fresh["identities"]["model_source_sha256"]:
    raise ValueError("model code no longer matches validated source")
model = types.ModuleType("frozen_model_for_plot")
exec(compile(code, "archived-triad-live-model", "exec"), model.__dict__)
paths = [evidence / "triad-live-full-capture-001/audio-profile.json",
         evidence / "triad-live-low-refinement-001/audio-profile.json",
         here / "audio-profile.json"]
if hashlib.sha256(paths[-1].read_bytes()).hexdigest() != fresh["profile_sha256"]:
    raise ValueError("four-pole profile differs from validated profile")
profiles = [json.loads(p.read_text()) for p in paths]
older = json.loads((evidence / "triad-live-low-refinement-001/validation-result.json").read_text())
frequency = np.geomspace(.45, 100, 700)
fig, axes = plt.subplots(2, 1, figsize=(8.4, 6.7), sharex=True, constrained_layout=True)
labels = ["Original one-pole + FIR", "Three-pole + FIR", "Four-pole + FIR"]
colors = ["#cf6b20", "#337ab7", "#16805d"]


def relative_phase(h, f, guard_seconds):
    removed = h * np.exp(2j * np.pi * f * guard_seconds)
    return np.unwrap(np.angle(removed)[::-1])[::-1] * 180 / np.pi


for profile, label, color in zip(profiles, labels, colors):
    h = model.spectral_response(profile, frequency)
    guard = profile["alignment"]["causal_guard_samples"] / profile["sample_rate"]
    axes[0].semilogx(frequency, 20 * np.log10(abs(h)), color=color, label=label, lw=1.7)
    axes[1].semilogx(frequency, relative_phase(h, frequency, guard), color=color, lw=1.7)
for report, label, marker, color, size in [
        (older, "Earlier physical validation (diagnostic reuse)", "o", "#a5a5a5", 20),
        (fresh, "Fresh physical validation after four-pole freeze", "x", "#151515", 38)]:
    rows = [r for r in report["rows"] if r["resolved"]]
    f = np.array([r["frequency_hz"] for r in rows])
    h = np.array([complex(r["measured_real"], r["measured_imag"]) for r in rows])
    guard = report["alignment"]["causal_guard_samples"] / profiles[-1]["sample_rate"]
    axes[0].scatter(f, 20*np.log10(abs(h)), label=label, marker=marker, c=color, s=size, zorder=5)
    axes[1].scatter(f, relative_phase(h, f, guard), marker=marker, c=color, s=size, zorder=5)
for ax in axes:
    ax.axvspan(.45, .5, color="#eeeeee", zorder=-2)
    ax.grid(True, which="both", alpha=.25)
    ax.set_xlim(.45, 100)
axes[0].set_ylabel("Combined-path gain (dB)")
axes[1].set_ylabel("Phase after removing alignment guard (degrees)")
axes[1].set_xlabel("Audio frequency (Hz)")
axes[0].legend(fontsize=8, loc="lower right")
axes[0].set_title("Cable path: frozen models versus separate physical captures")
fig.suptitle("Fresh 12-tone check: max error 0.672 dB / 0.0446 rad; burst/step payload residual −41.06 dB\n"
             "Below 0.5 Hz remains extrapolation. Points have no independent-repeat confidence bounds.", fontsize=10)
fig.savefig(here / "low-frequency-model-comparison.png", dpi=170)
fig.savefig(here / "low-frequency-model-comparison.pdf")
print("wrote low-frequency-model-comparison.png and .pdf")

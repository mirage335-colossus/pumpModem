#!/usr/bin/env python3
"""Retained FHSS timing diagnostic; no audio access, no original-file writes."""
import os
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "2"
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
import triad_live_duplex as campaign
import triad_live_model as model
import triad_live_waveforms as wave


def read(path):
    return json.loads(path.read_text())


def write(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2, sort_keys=True)+"\n")


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


started = time.perf_counter()
prepared = ROOT/"local-evidence/triad-live-full-input-001"
capture = ROOT/"local-evidence/triad-live-full-continuation-001"
src, dest = prepared/"fhss-burst3", capture/"fhss-burst3"
meta = read(src/"stimulus.json")
manifest = read(src/"native/manifest.json")
profile = read(capture/"audio-profile.json")
case = meta["case"]
prior = manifest["resolved_configuration"]["initial_arrival_bounds_seconds"]
recipe = dict(schema="triad-live-fhss-timing-recipe-v1", prepared=str(prepared.relative_to(ROOT)),
    capture=str(capture.relative_to(ROOT)), case="fhss-burst3", public_prior_seconds=prior,
    prior_source="native manifest resolved_configuration.initial_arrival_bounds_seconds",
    grid="zero-centered quarter-native-sample lattice plus both exact prior endpoints",
    fractional_phases=4, interpolation_half_support=32, truth_centering=False,
    original_nominal_analysis=str((capture/"fhss-burst3-analysis.json").relative_to(ROOT)),
    input_sha256={str(p.relative_to(ROOT)): digest(p) for p in
        (src/"stimulus.json", src/"stimulus.f32", src/"native/manifest.json",
         src/"native/basis.c64", dest/"capture.f32", capture/"audio-profile.json",
         capture/"fhss-burst3-analysis.json")},
    source_sha256={str(p.relative_to(ROOT)): digest(p) for p in
        (ROOT/"tools/triad_live_waveforms.py", ROOT/"tools/triad_live_model.py",
         ROOT/"tools/triad_live_duplex.py", Path(__file__))},
    frozen_before_scoring=True, threads=2,
    command="/tmp/triad-weak-env/bin/python local-evidence/triad-live-fhss-timing-001/reproduce.py")
# This recipe records public bounds before any payload correlation is read.
write("recipe.json", recipe)
receipt = campaign.verify_capture_receipt(src,dest)
profile_receipt = campaign.verify_profile_receipt(prepared,capture,profile)
native = wave.load_export(src/"native")
nfs, fs = native["sample_rate"], meta["sample_rate"]
tx = np.fromfile(src/"stimulus.f32", dtype="<f4")
rx = np.fromfile(dest/"capture.f32", dtype="<f4")
aligned, valid, alignment = model.align_capture(tx,rx,fs,meta["markers"]["markers"])
predicted = model.simulate_audio_profile(tx,profile,include_noise=False,production_s16=True)
payload = meta["markers"]["payload"]
a, b = payload["start"], payload["start"]+payload["samples"]
bridge = meta["details"]["bridge"]
kwargs = dict(occupied_bandwidth_hz=manifest["occupied_bandwidth_hz"],
    source_start_seconds=bridge["source_start_seconds"],
    expected_samples=len(native["signal"]),undo_fixed_gain=case["gain"])
real, rv, ddc = wave.from_audio(aligned[a:b],fs,nfs,case["carrier_hz"],**kwargs)
pred, pv, _ = wave.from_audio(predicted[a:b],fs,nfs,case["carrier_hz"],**kwargs)
bank = np.empty_like(native["basis"],dtype=np.complex64)
for ci in range(bank.shape[0]):
    for col in range(bank.shape[2]):
        audio,_ = wave.to_audio(native["basis"][ci,:,col],nfs,fs,case["carrier_hz"],
            occupied_bandwidth_hz=manifest["occupied_bandwidth_hz"],fixed_gain=case["gain"],
            source_start_seconds=bridge["source_start_seconds"],max_peak=.9)
        padded = np.zeros(len(tx),np.float32)
        padded[a:a+len(audio)] = audio
        filtered = model.apply_audio_profile(padded,profile)
        bank[ci,:,col],_,_ = wave.from_audio(filtered[a:b],fs,nfs,case["carrier_hz"],**kwargs)
indices = np.minimum(len(valid[a:b])-1,np.floor(np.arange(len(real))*fs/nfs).astype(int))
score_valid = rv & pv & valid[a:b][indices] & native["validity"]
edge = math.ceil((bridge["resample_half_support_seconds"]+ddc["resample_half_support_seconds"])*nfs)
score_valid[:edge],score_valid[-edge:] = False,False
np.savez_compressed(OUT/"retained-workspace.npz",real=real,predicted=pred,basis=bank,mask=score_valid)
preparation_seconds = time.perf_counter()-started
results, nominal, timings = {},{},{}
for name, observed in (("real",real),("predicted",pred)):
    nominal[name] = wave.project_diagnostic(observed,bank,score_valid,candidate_bits=native["candidate_bits"])
    before = time.perf_counter()
    results[name] = wave.bounded_timing_projection(observed,bank,nfs,prior,
        mask=score_valid,candidate_bits=native["candidate_bits"],fractional_phases=4,
        interpolation_half_support=32)
    timings[name] = time.perf_counter()-before
    write(name+"-timing.json",results[name])
write("nominal-reproduction.json",nominal)
summary = dict(schema="triad-live-fhss-timing-result-v1", original_nominal_evidence_preserved=True,
    recipe_sha256=digest(OUT/"recipe.json"),capture_receipt=receipt,profile_receipt=profile_receipt,
    alignment=alignment,preparation_seconds=preparation_seconds,timing_search_seconds=timings,
    total_seconds=time.perf_counter()-started,
    public_prior_seconds=prior,number_of_delays=results["real"]["timing_hypotheses"],
    minimum_native_samples_per_fhss_dwell=.4*nfs,source_template_includes_continuous_fhss_tails=True,
    real={k:results["real"][k] for k in ("chosen_bit","selected_delay_seconds","best_retained_observation_fraction",
        "best_projection_energy_samples","observation_energy_samples","zero_delay_best_projection_energy_samples")},
    predicted={k:results["predicted"][k] for k in ("chosen_bit","selected_delay_seconds","best_retained_observation_fraction",
        "best_projection_energy_samples","observation_energy_samples","zero_delay_best_projection_energy_samples")},
    measured_predicted_delay_difference_seconds=results["real"]["selected_delay_seconds"]-results["predicted"]["selected_delay_seconds"],
    nominal_retained_fractions={k:v["best_retained_observation_fraction"] for k,v in nominal.items()},
    operational_admission=None, independent_hardware_captures=1,
    limits="retained single capture; fixed epoch/frequency/clock, one gain per complete pattern, linear frozen audio model, finite interpolation; maximization is not a calibrated admission test",
    source_unchanged_during_run=all(digest(ROOT/path)==sha for path,sha in recipe["source_sha256"].items()))
write("result.json",summary)
print(json.dumps(summary,sort_keys=True))

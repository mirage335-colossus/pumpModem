#!/usr/bin/env python3
"""TRAINING-only exploratory fourth-pole fit; old validation is diagnostic."""
import json
from pathlib import Path
import time
import numpy as np
from scipy import signal, optimize

root = Path("local-evidence/triad-live-low-refinement-001")
section = json.loads((root / "low-frequency-section.json").read_text())
validation = json.loads((root / "validation-result.json").read_text())
t = section["measured_transfer"]
f = np.array(t["frequency_hz"])
h = np.array(t["real"]) + 1j * np.array(t["imag"])
coherence = np.array(t["coherence"])
scatter = np.array(t["period_scatter_rms"])
use = np.array(t["fit_used"])
fs = section["sample_rate"]
gain = max(float(np.median(abs(h[use][-4:]))), 1e-4)
weight = np.sqrt(coherence[use]) / np.sqrt(scatter[use]**2 + (.01 * gain)**2)


def sos(parameters):
    g, pole1, pole2, corner, q, delay = parameters
    w = 2*np.pi*corner
    b1, a1 = signal.bilinear([1., 0., 0.], np.polymul([1., 2*np.pi*pole1], [1., 2*np.pi*pole2]), fs=fs)
    b2, a2 = signal.bilinear([1., 0., 0.], [1., w/q, w*w], fs=fs)
    return np.array([np.r_[b1,a1],np.r_[b2,a2]])


def response(parameters, frequencies):
    _, shape = signal.sosfreqz(sos(parameters), worN=2*np.pi*np.asarray(frequencies)/fs)
    return parameters[0]*shape*np.exp(-2j*np.pi*np.asarray(frequencies)*parameters[-1])


def objective(parameters):
    error = (response(parameters,f[use])-h[use])*weight
    return np.r_[error.real,error.imag]


guard = section["alignment"]["causal_guard_samples"]/fs
initial = [section["residual_gain"],section["real_pole_hz"],.3,
           section["biquad_frequency_hz"],section["biquad_q"],section["residual_delay_seconds"]]
start = time.perf_counter()
fit = optimize.least_squares(objective,initial,
    bounds=([gain*.2,.05,.01,.05,.25,max(0.,guard-.002)],
            [gain*5,80.,5.,40.,1.5,guard+.002]),max_nfev=200)
elapsed = time.perf_counter()-start
predicted = response(fit.x,f)
error = predicted[use]-h[use]
rows=[]
for row in validation["rows"]:
    ff=row["frequency_hz"]
    measured=complex(row["measured_real"],row["measured_imag"])
    pp=response(fit.x,[ff])[0]
    rows.append(dict(frequency_hz=ff,gain_error_db=float(20*np.log10(abs(measured)/abs(pp))),
        phase_error_radians=float(np.angle(measured*pp.conjugate())),resolved=row["resolved"]))
result=dict(scope="four-pole candidate fit to original training only; reused old validation is diagnostic, not independent qualification",
    fit_seconds=elapsed,converged=bool(fit.success),function_evaluations=fit.nfev,
    parameter_names=["gain","real_pole1_hz","real_pole2_hz","biquad_frequency_hz","Q","delay_seconds"],
    parameters=fit.x.tolist(),sos=sos(fit.x).tolist(),training_bin_count=int(use.sum()),
    training_complex_rms=float(np.sqrt(np.mean(abs(error)**2))),
    original_training_complex_rms=section["fit"]["complex_rms"],
    maximum_training_gain_error_db=float(np.max(abs(20*np.log10(abs(predicted[use])/abs(h[use]))))),
    maximum_training_phase_error_radians=float(np.max(abs(np.angle(predicted[use]*h[use].conjugate())))),
    reused_validation_diagnostic=rows,
    implementation_note="two real poles combine into one biquad: same two SOS sections and four states as three-pole candidate")
print(json.dumps(result,indent=2,allow_nan=False))

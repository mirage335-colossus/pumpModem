#!/usr/bin/env python3
"""Read-only low-frequency model diagnosis; no hardware or model replacement.

Run from the repository root with OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2.
The stable cascade is selected using training bins only. Held-out samples serve
only as a check; this candidate is not an independently qualified replacement.
"""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import least_squares

sys.path.insert(0, "tools")
import triad_live_model as model


capture = Path("local-evidence/triad-live-full-capture-001")
inputs = Path("local-evidence/triad-live-full-input-001")
profile = json.loads((capture / "audio-profile.json").read_text())
report = json.loads((capture / "low-frequency-analysis.json").read_text())
meta = json.loads((inputs / "low-frequency/stimulus.json").read_text())
x = np.memmap(inputs / "low-frequency/stimulus.f32", dtype="<f4", mode="r")
y = np.memmap(capture / "low-frequency/capture.f32", dtype="<f4", mode="r")
fs = 48000
first = meta["markers"]["payload"]["start"]
delay = report["alignment"]["offset_samples"] - report["alignment"]["causal_guard_samples"]
integer_delay = round(delay)
phasor = np.exp(-2j * np.pi * np.arange(fs) / fs)
raw_checks = []
for start, end in [(10, 110), (150, 250), (310, 410)]:
    tx = 0j
    rx = 0j
    for second in range(start, end):
        index = first + second * fs
        tx += np.dot(model.quantize_production_playback(x[index:index + fs]), phasor)
        rx += np.dot(y[index + integer_delay:index + integer_delay + fs], phasor)
    h = rx / tx * np.exp(2j * np.pi * (delay - integer_delay) / fs)
    raw_checks.append(dict(start_seconds=start, end_seconds=end,
                           response_magnitude=float(abs(h)), response_phase=float(np.angle(h))))

transfer = profile["measured_transfer"]
f = np.array(transfer["frequency_hz"])
h = np.array(transfer["real"]) + 1j * np.array(transfer["imag"])
coherence = np.array(transfer["coherence"])
use = (f >= 3.5) & (f <= 200) & (coherence >= .95)
f, h = f[use], h[use]
ids = np.unique(np.argmin(abs(np.log(f[:, None]) - np.linspace(np.log(f.min()), np.log(f.max()), 80)), axis=0))
f, h = f[ids], h[ids]


def response(parameters, frequencies):
    gain, real_pole, biquad_frequency, q, delay = parameters
    frequencies = np.asarray(frequencies)
    s = 1j * frequencies
    return (gain * s / (s + real_pole) * s * s /
            (s * s + biquad_frequency / q * s + biquad_frequency ** 2) *
            np.exp(-2j * np.pi * frequencies * delay))


def residual(parameters):
    error = response(parameters, f) - h
    return np.r_[error.real, error.imag]


fit = least_squares(residual, [.84, 5, 2, .7, 256 / fs],
                    bounds=([.1, .01, .01, .2, 0], [2, 100, 100, 2, .02]),
                    max_nfev=150)
original_error = model.spectral_response(profile, f) - h
probe_frequencies = [.005, .05, 1, 3.5, 10]
predicted = response(fit.x, probe_frequencies)
out = dict(
    scope="training-only exploratory stable cascade; no replacement profile or validation acceptance",
    raw_one_hz_dft_checks=raw_checks,
    raw_check_limit="constant marker delay approximation; measured relative clock slope is approximately -2.1e-12",
    training_bin_count=len(f),
    parameter_names=["gain", "real_pole_hz", "biquad_frequency_hz", "biquad_q", "delay_seconds"],
    fitted_parameters=fit.x.tolist(),
    training_complex_rms=float(np.sqrt(np.mean(residual(fit.x) ** 2))),
    frozen_model_same_band_complex_rms=float(np.sqrt(np.mean(np.r_[original_error.real, original_error.imag] ** 2))),
    candidate_predictions=[dict(frequency_hz=ff, magnitude=float(abs(hh)), phase=float(np.angle(hh)))
                           for ff, hh in zip(probe_frequencies, predicted)],
    profile_sha256=hashlib.sha256((capture / "audio-profile.json").read_bytes()).hexdigest(),
    input_identity=json.loads((capture / "low-frequency/capture-identity.json").read_text()),
    next_evidence_needed="independent concentrated low-band training and validation before replacing the frozen model",
)
print(json.dumps(out, indent=2, allow_nan=False))

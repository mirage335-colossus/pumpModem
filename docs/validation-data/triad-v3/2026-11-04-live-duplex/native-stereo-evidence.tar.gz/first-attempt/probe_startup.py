import ctypes as C
import json
from pathlib import Path
import time
p=Path(__file__).with_name('startup-diagnostic.json')
if p.exists(): raise FileExistsError(p)
a=C.CDLL('libasound.so.2'); P=C.c_void_p; U=C.c_ulong
signatures={'snd_pcm_open':(C.c_int,[C.POINTER(P),C.c_char_p,C.c_int,C.c_int]),'snd_pcm_set_params':(C.c_int,[P,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_int,C.c_uint]),'snd_pcm_get_params':(C.c_int,[P,C.POINTER(U),C.POINTER(U)]),'snd_pcm_sw_params_malloc':(C.c_int,[C.POINTER(P)]),'snd_pcm_sw_params_current':(C.c_int,[P,P]),'snd_pcm_sw_params_get_start_threshold':(C.c_int,[P,C.POINTER(U)]),'snd_pcm_sw_params_get_avail_min':(C.c_int,[P,C.POINTER(U)]),'snd_pcm_sw_params_set_start_threshold':(C.c_int,[P,P,U]),'snd_pcm_sw_params':(C.c_int,[P,P]),'snd_pcm_readi':(C.c_long,[P,P,U]),'snd_pcm_state':(C.c_int,[P]),'snd_pcm_wait':(C.c_int,[P,C.c_int]),'snd_pcm_close':(C.c_int,[P]),'snd_pcm_sw_params_free':(None,[P]),'snd_asoundlib_version':(C.c_char_p,[])}
for n,(rest,args) in signatures.items(): f=getattr(a,n);f.restype=rest;f.argtypes=args
def check(n,*args):
 r=getattr(a,n)(*args)
 if r<0: raise RuntimeError((n,r))
 return r
pcm=P(); sw=P(); rows=[]; result={}; started=time.monotonic()
try:
 check('snd_pcm_open',C.byref(pcm),b'hw:1,0',1,1)
 check('snd_pcm_set_params',pcm,2,3,2,48000,0,100000)
 buffer=U(); period=U(); threshold=U(); avail=U()
 check('snd_pcm_get_params',pcm,C.byref(buffer),C.byref(period))
 check('snd_pcm_sw_params_malloc',C.byref(sw))
 check('snd_pcm_sw_params_current',pcm,sw)
 check('snd_pcm_sw_params_get_start_threshold',sw,C.byref(threshold))
 check('snd_pcm_sw_params_get_avail_min',sw,C.byref(avail))
 data=(C.c_int16*(2400*2))()
 result={'library_version':a.snd_asoundlib_version().decode(),'buffer_frames':buffer.value,'period_frames':period.value,'original_start_threshold':threshold.value,'avail_min':avail.value,'read_frames':2400,'channels':2,'device':'hw:1,0'}
 for phase in ('original','capture_threshold_one'):
  if phase!='original':
   check('snd_pcm_sw_params_set_start_threshold',pcm,sw,1)
   check('snd_pcm_sw_params',pcm,sw)
  reads=[]
  for i in range(8):
   before=a.snd_pcm_state(pcm); n=a.snd_pcm_readi(pcm,data,2400)
   reads.append({'state_before':before,'read_result':n,'state_after':a.snd_pcm_state(pcm)})
   if n>0: break
   if n!=-11: raise RuntimeError(('unexpected read error',n))
   a.snd_pcm_wait(pcm,20)
  result[phase]=reads
finally:
 if sw: a.snd_pcm_sw_params_free(sw)
 if pcm: a.snd_pcm_close(pcm)
result['wall_seconds']=time.monotonic()-started
result['same_handle_only_start_threshold_changed']=True
p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

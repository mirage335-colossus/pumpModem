#!/usr/bin/env python3
"""Check the new production capture against an already frozen cable model."""
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import triad_live_model as model

here = Path(__file__).resolve().parent
result_path = here / "analysis.json"
if result_path.exists():
    raise FileExistsError("preserve the original analysis")
started = time.perf_counter()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((here / "plan.json").read_text())
for name in ("stimulus", "stimulus_metadata", "profile"):
    if digest(ROOT / plan[name]) != plan[name + "_sha256"]:
        raise ValueError("frozen input changed: " + name)
metadata = json.loads((here / "capture.json").read_text())
if metadata["status"] != "complete" or metadata.get("failure"):
    raise ValueError("production capture failed")
if any(metadata["discontinuity"][key] for key in ("capture", "playback")):
    raise ValueError("physical discontinuity")
fmt = metadata["audio_format"]["capture"]
if any(fmt[k] != v for k, v in dict(logical_rate=48000, hardware_rate=48000,
        hardware_channels=2, logical_channels=1, selected_capture_channel=0).items()):
    raise ValueError("unexpected hardware/logical capture contract")
tx = np.fromfile(ROOT / plan["stimulus"], dtype="<f4")
rx = np.fromfile(here / "capture.f32", dtype="<f4")
provider = np.fromfile(here / "provider.f32", dtype="<f4")
if len(rx) != metadata["capture"]["logical_samples"] or len(provider) != metadata["capture"]["raw_samples"]:
    raise ValueError("PCM length does not match finalized capture metadata")
if len(provider) < len(rx) or not np.array_equal(rx, provider[:len(rx)]):
    raise ValueError("same-rate selected-channel monitor and logical PCM disagree")
stimulus = json.loads((ROOT / plan["stimulus_metadata"]).read_text())
profile = json.loads((ROOT / plan["profile"]).read_text())
aligned, valid, alignment = model.align_capture(tx, rx, 48000, stimulus["markers"]["markers"])
prediction = model.simulate_audio_profile(tx, profile, include_noise=False, production_s16=True)
pcm = model.quantize_production_playback(tx)
payload = stimulus["markers"]["payload"]
mask = np.zeros(len(valid), dtype=bool)
a = payload["start"]
mask[a:a + payload["samples"]] = valid[a:a + payload["samples"]]
metrics = model.assess_prediction(pcm, aligned, profile, mask, prediction=prediction)
within = (abs(metrics["energy_prediction_error_db"]) <= plan["gain_error_envelope_db"]
          and metrics["fixed_model_residual_to_signal_db"] <= plan["payload_residual_envelope_db"])
result = dict(scope="production native ALSA stereo-required fixture, fixed mono channel and frozen-model payload check",
    audio_format=metadata["audio_format"], alignment=alignment, payload_metrics=metrics,
    within_frozen_engineering_envelope=within, frozen_profile_refitted=False,
    provider_prefix_equals_logical_pcm=True, logical_samples=len(rx), provider_samples=len(provider),
    observed_peak=float(np.max(np.abs(rx))), near_fullscale_samples=int(np.sum(np.abs(rx) >= .999)),
    capture_sha256=digest(here / "capture.f32"), provider_sha256=digest(here / "provider.f32"),
    metadata_sha256=digest(here / "capture.json"), plan_sha256=digest(here / "plan.json"),
    model_source_sha256=digest(ROOT / "tools/triad_live_model.py"), analysis_source_sha256=digest(Path(__file__)),
    analysis_wall_seconds=time.perf_counter()-started,
    operational_admission=None, independent_hardware_observations=1)
result_path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(result, indent=2, allow_nan=False))
raise SystemExit(0 if within else 1)
